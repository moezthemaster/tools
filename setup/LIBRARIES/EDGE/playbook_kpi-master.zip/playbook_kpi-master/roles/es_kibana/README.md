<p align="center"> <img src="https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/playbook_kpi/blob/master/imgs/logo-elastic.png" width="350px"> </p>


Requirements
------------

python-passlib package must be present in the yum repo

Target server must be Linux.


Role Variables
--------------

### elastic_action
<code>`required: True`</code> <code>`default: ""`</code>

    Action requested.

List of possible values :

|   State   | Description                    |
|:---------:|:------------------------------ |
|  create   | Install  Elastic stack         |
| configure | Configure and secure the elastic stack         |
|  delete   | Remove used packages from a VM |


### es_repo_name
<code>`required: True`</code> <code>`default: "sofabsc-gts-yum"`</code>

    Available yum repo to download and install required packages

### es_repo_url
<code>`required: True`</code> <code>`default: "https://sofabsc.socgen/nexus/content/repositories/yum-gts"`</code>

    Yum repo url

### es_version
<code>`required: True`</code> <code>`default: "5.2.2"`</code>

    Elasticsearch version to install

### java_package
<code>`required: True`</code> <code>`default: "java-1.8.0-openjdk"`</code>

    Java version to install

### kibana_version
<code>`required: True`</code> <code>`default: "5.2.2"`</code>
    Kibana version to install

### es_network_host
<code>`required: True`</code> <code>`default: "localhost"`</code>

    Elasticsearch host, localhost is used to prevent external access via browser

### es_http_port
<code>`required: True`</code> <code>`default: "9200"`</code>

    Elasticsearch port to use

### kibana_host
<code>`required: True`</code> <code>`default: "localhost"`</code>

    Kibana host, localhost is used to prevent unallowed external access to kibana, nginx is used to make a redirection for authorized persons

### kibana_port
<code>`required: True`</code> <code>`default: "5601"`</code>
    Kibana port to use

### es_conf_path
<code>`required: True`</code> <code>`default: "/etc/elasticsearch/"`</code>

  Path to elasticsearch configuration files

### kiban_conf_path 
<code>`required: True`</code> <code>`default: "/etc/kibana"`</code>

  Path to kibana configuration files

Dependencies
------------

None


Example Playbook
----------------

      - hosts: hostname
        roles:
          - { role: es_kibana, elastic_action: 'create'}
          - { role: es_kibana, elastic_action: 'configure'}


Author Information
------------------

Abdessamad BAYZI

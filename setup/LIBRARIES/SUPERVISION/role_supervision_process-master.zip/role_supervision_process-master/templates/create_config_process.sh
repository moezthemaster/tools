#!/bin/bash


#Creation de la configuration de Patrol pour Apache
#envoi des info en paramètre
#creation du fichier de config
#envoi de la configuration a l'agent Patrol
#restart de l'agent Patrol
###
###
#   Process : 
#   LABEL - COMMAND - MIN - MAX - OWNER
#
#
####################
cd /produits/patrol/PATROL_AGT
. ./patrolrc.sh

PATROL_DIR=/produits/patrol/PATROL_AGT/config

LOG=${PATROL_DIR}/config_process.log
process_file_default=${PATROL_DIR}/config_standard_process
make_process () {


echo "Modification du fichier de configuration Process" >>$LOG

sed -i -e "s#LABEL#$label#g" $process_file
sed -i -e "s#COMMAND#$cmd#g" $process_file
sed -i -e "s#MIN#$min#g" $process_file
sed -i -e "s#MAX#$max#g" $process_file
sed -i -e "s#OWNER#$owner#g" $process_file

}

check_agent(){

    if [ `ps -fu patrol | grep PatrolAgent  | grep -c 14451` != 1 ]
    then
        if [ `sudo -l | wc -l` > 3 ]
        then
             sudo /etc/init.d/patrol start
        else
             sudo systemctl start patrol.service
        fi
    fi
    cpt=0
    while [ `pconfig +tcp +get -p 14451 | wc -l ` == 1 ] && [ $cpt != 6 ]
    do 
        sleep 10
        ((cpt++))
    done 
}

add_process () {

    check_agent
    echo "Apply Process configuration" >> $LOG
    pconfig +tcp -p 14451 $process_file


}


restart_agt () {

    echo "Patrol Agent restarting" >> $LOG 
    pconfig +tcp -p 14451 +RESTART
}

rm_process () {

  echo "Modification du fichier de configuration Process" >>$LOG

  sed -i -e "s#REPLACE.*}#DELETE }#g" $process_file

}


USAGE ()
{
  echo
  echo "Usage: $progname <action> <args>*"
  echo "        action: Add ou Remove"
  echo "        args: "
  echo
  exit 1
}

echo `date` >>$LOG
echo "Launching script.." >>$LOG



while test -n "$1"; do
    case "$1" in
        --usage|-u)
            USAGE
            exit 0
            ;;        
        -LBL)
            label=$2
            label=$(echo $label | sed 's# #_#g')
            echo "Label : $label" >>$LOG 
            shift
            ;;
        -CMD)
            cmd=$2
            echo "Cmd : $cmd">>$LOG
            shift
            ;;
        -MIN)
            min=$2
            echo "MIN: $min" >>$LOG
            shift
            ;;
        -MAX)
            max=$2
            echo "MAX : $max" >>$LOG
            shift
            ;;
        -OWN)
            owner=$2
            echo "Owner : $owner" >>$LOG
            shift
            ;;
        -SEV)
            severity=`echo ${2^^}`
            echo "SEV : $severity" >>$LOG
            shift
            ;;
        -ACT)
            action_config=$2
            echo "Action : $action_config" >>$LOG 
            shift
            ;;
        *)
            echo "Argument inconnu: $1"
            USAGE
            exit 3
            ;;
    esac
    shift
done

if [ -z "$label" ]
then
    USAGE
fi

process_file="${process_file_default}_${label}"

case ${severity} in 
    CRITICAL|WARNING)   
        process_file_standard="${process_file_default}_${severity}.save"

        ;;
    *)   
        if [ ${action_config} == "Add" ]
        then    
            USAGE
        fi
        ;;
esac

case ${action_config} in 
    Add)
        #Initialisation des fichiers de conf
        rm -f ${process_file}
        cp ${process_file_standard} ${process_file}
        
        make_process
        add_process
        restart_agt
        ;;
    Remove) 
        rm_process
        add_process
        restart_agt
        ;;
    *)   
        USAGE
        ;;
esac


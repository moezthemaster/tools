#!/usr/bin/python
# -*- coding: utf-8 -*-

import logging

from tests.mock.mockdodv1 import MockDod
from edge.dns.dodv1.updater import DnsUpdater
from tests.mock.mock import MockDod as MockDodv2

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

LIST_HOSTNAMES = ("dtrvlxvm1", "dtrvlxvm2")


class MockedUpdater(MockDod, MockDodv2, DnsUpdater):

    def __init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname, new_hostname):
        MockDod.__init__(self, share_database=True)
        MockDodv2.__init__(self, tuple(), hostname=None, share_database=True)
        DnsUpdater.__init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname, new_hostname)


updater = MockedUpdater(
    "DEV", "EU France (Greater Paris)", "eu-fr-paris-1", "ITEC_CLOUD_DEV_DC2_03", "trv", LIST_HOSTNAMES[0], ""
)


class TestDnsUpdater:

    def test_add_dns_record(self):
        updater.host_delete(LIST_HOSTNAMES[0], "fr.world.socgen")
        result = updater.host_add(
            LIST_HOSTNAMES[0], "fr.world.socgen", "192.163.200.0/21"
        )
        assert result

    def test_update_dns_record(self):
        updater.new_hostname = "testedgevm1new"
        result = updater.host_search_infos(LIST_HOSTNAMES[0])
        response = updater.run()
        result2 = updater.host_search_infos("testedgevm1new")
        assert updater.changed
        assert response["output"][0]["hostname"] == "testedgevm1new"
        assert result[0].ip == result2[0].ip

    def test_update_dns_record_which_not_exist(self):
        updater.hostname = LIST_HOSTNAMES[1]
        updater.new_hostname = "testedgevm2new"
        try:
            updater.run()
        except Exception as err:
            assert "hostname={} not found in DodV1".format(LIST_HOSTNAMES[1]) == err.args[0]

    def test_update_dns_record_with_fake_hostname(self):
        try:
            MockedUpdater(
                "DEV", "EU France (Greater Paris)", "eu-fr-paris-1", "ITEC_CLOUD_DEV_DC2_03", "trv", "fake_hostname", ""
            )
            assert False
        except Exception as err:
            assert "fake_hostname must match this regex '^(d|h|p)trv[a-zA-Z0-9_-]+$'" == err.args[0]

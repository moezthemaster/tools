#!groovy
import static sgcib.coc.bootcamp.Git.*
import static sgcib.coc.bootcamp.Maven.*

class Utils {
    static Properties readProperties(script, String file, String default_file) {
        Properties default_props = new Properties()
        String default_prop_file = script.readFile default_file
        default_props.load(new StringReader(default_prop_file))

        Properties props = new Properties()
        String prop_file = script.readFile file
        props.load(new StringReader(prop_file))

        Properties merged = new Properties();
        merged.putAll(default_props);
        merged.putAll(props);
        merged
    }
}

def deploy(String script_path) {
    properties = Utils.readProperties(this, 'jenkins/job.properties', "${script_path}/conf/default.properties",)
    String run_pipeline = properties.run_pipeline
    String run_behave_tests = properties.run_behave_tests
    String sonarInstance = properties.sonarInstance
    String jdkVersion = properties.jdkVersion
    String sonarVersion = properties.sonarVersion
    String sonarProjectKey = properties.sonarProjectKey
    String sonarProjectName = properties.sonarProjectName
    String sonarSourceFolder = properties.sonarSources
    String publish = properties.publish
    String release_type = properties.release_type
    String artifactoryCreds = properties.artifactoryCreds
    String artifactoryUrl = properties.artifactoryUrl
    String gitRepo = properties.gitRepo
    String bandit_project = properties.bandit_project

    println "script_path: ${script_path}"

    if (run_pipeline == 'true') {
        stage('SCM') {
            //deleteDir()
            checkout scm
            sh '''su automation -c "sudo chmod -R 777 ${WORKSPACE}/.git ${WORKSPACE}/VERSION ${WORKSPACE}/setup.*"''' 
        }

        common = load "${script_path}/lib/python_lib.groovy"

        stage('Create venv') {
            sh "cp -r /SERVICE/work/tools/python ."
        }

        common.withPyEnv("./python") {
            stage('Tests + Lint') {
                sh "python -m tox"    
                version = sh(script: 'cat VERSION', returnStdout: true)
            }

            stage('Checking package') {
                sh "python setup.py check -ms"
            }

            if (env.BRANCH_NAME == "master") {
                stage('QUALITY CHECK') {
                    try{
                        withSonarQubeEnv(sonarInstance) {
                        withEnv([
                             "PATH+SONAR_HOME=${tool sonarVersion}/bin", "SONAR_SCANNER_OPTS=-Xmx1536m"]) {
                        sh "sonar-scanner -Dsonar.projectKey=${sonarProjectKey} \
                        -Dsonar.projectVersion='${version}' \
                        -Dsonar.projectName='${sonarProjectName}' \
                        -Dsonar.sources='${sonarSourceFolder}' -Dsonar.host.url=$SONAR_HOST_URL \
                        -Dsonar.python.coverage.reportPath=coverage.xml \
                        -Dsonar.dynamicAnalysis=reuseReports \
                        -Dsonar.core.codeCoveragePlugin=cobertura \
                        -Dsonar.python.coverage.forceZeroCoverage=true \
                        -Dsonar.python.xunit.reportPath=nosetests.xml \
                        -Dsonar.python.xunit.skipDetails=false \
                        -Dsonar.verbose=false"
                      }
                  }
                }catch(err){
                    error "Checking code quality failed"
                }
              }
            }

            /*           
            stage('Integration tests'){
                def pipeline = load("${script_path}/lib/tests_integration.groovy")
                pipeline.tests_integrations_lib(script_path, false)
            }
            */
            if (run_behave_tests == 'true') {
                stage('Integration tests'){
                def pipeline = load("${script_path}/lib/tests_behave.groovy")
                }
            }
            
            stage('Security check:bandit'){
                sh "bandit -r ${bandit_project} -n5 -x tests && echo \"Bandit passed\"|| echo \"Bandit failed: \$?\""
            }
            
            if (publish == 'true' && env.BRANCH_NAME == 'master') {

                stage('Bump version and push') {
                    withCredentials([usernamePassword(credentialsId: 'genericCreds', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USER')]) {
                        sh "git fetch --prune origin 'refs/tags/*:refs/tags/*' '+refs/heads/*:refs/remotes/origin/*'"
                        sh "su automation -c \"bumpversion ${release_type} --allow-dirty\""
                        
                        // push version update and clean pipeline var
                        sh """sed -i 's/^run_pipeline[" "]*=[" "]*true/run_pipeline=false/I' jenkins/job.properties"""

                        sh "git add VERSION setup.cfg jenkins/job.properties setup.py"
                        sh 'git commit -m "Version "`cat VERSION`'
                        sh "git push 'https://${GIT_USER}:${GIT_PASSWORD}@${gitRepo}' HEAD:master"

                        // tag creation
                        if (!release_type.startsWith('dev')) {
                            sh "su automation -c \"bumpversion release --tag --tag-name=`cat VERSION` --allow-dirty\""
                            sh "git push 'https://${GIT_USER}:${GIT_PASSWORD}@${gitRepo}' `cat VERSION`"
                        }
                    }
                }
                stage('Publish on Artifactory') {
                    withCredentials([usernamePassword(credentialsId: 'artifactoryCreds', passwordVariable: 'ARTI_PASSWORD', usernameVariable: 'ARTI_USER')]) {
                        sh "rm -rf ${WORKSPACE}/dist"
                        sh "python setup.py bdist_wheel"
                        sh "export REQUESTS_CA_BUNDLE=/SERVICE/work/tools/python/lib/python3.6/site-packages/certifi/cacert.pem"
                        sh "twine upload --repository-url ${artifactoryUrl} -u ${ARTI_USER} -p \'${ARTI_PASSWORD}\' ${WORKSPACE}/dist/*.whl"
                    }
                }
            }
        }
    }
}

return this.&deploy

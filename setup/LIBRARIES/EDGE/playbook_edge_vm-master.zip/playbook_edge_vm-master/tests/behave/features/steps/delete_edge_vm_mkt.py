#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
from time import sleep
import ansible_play
import subprocess


@then('Delete edge VM mkt')
def step_impl(context):
    # You may want this to run as user root instead
    # or make this an environmental variable, or
    # a CLI prompt. Whatever you want!

    become_user_password = 'foo-whatever'
    run_data = {
        'app_id': context.params['app_id'],
        'app_env': context.params['app_env'],
        'state': "absent",
        'code_irt': context.params['code_irt'],
        'vm_pubkey': context.params['vm_pubkey'],
    }

    if 'vm_hostname' in context.params:
        run_data['vm_hostname'] = context.params['vm_hostname']

    runner = ansible_play.Runner(
        hostnames='localhost',
        playbook='delete_mkt.yml',
        tags="",
        private_key_file=context.private_key,
        run_data=run_data,
        become_pass=become_user_password,
        verbosity=100,
        connection='local'
    )

    stats = runner.run()

    print("Debug")
    run_success = True
    hosts = sorted(stats.processed.keys())
    for h in hosts:
        t = stats.summarize(h)
        print("{} => {}".format(h, t))
        if t['unreachable'] > 0 or t['failures'] > 0:
            run_success = False

    assert run_success is True
    context.vm_purged = True

    print("Vm {} with IP {} deleted\n".format(context.params['vm_hostname'], context.params['vm_ipaddr']))

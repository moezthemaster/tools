
class MockedFlexeraRequest(object):
    def __init__(self, ip_address):
        self.ip_address = ip_address

    def request_flexera_configuration(self):
        return 0

class PoliteClass:
    """Class handling salutation"""

    @staticmethod
    def hello_phrase(username: str) -> str:
        return "Hello {}".format(username)

    def be_polite(self, username: str) -> None:
        print(self.hello_phrase(username))

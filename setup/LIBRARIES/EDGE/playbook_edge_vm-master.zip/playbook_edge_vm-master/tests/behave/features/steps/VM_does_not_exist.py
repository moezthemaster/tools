#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *

@given('VM does not exist')
def step_impl(context):
    context.vm_hostname=''



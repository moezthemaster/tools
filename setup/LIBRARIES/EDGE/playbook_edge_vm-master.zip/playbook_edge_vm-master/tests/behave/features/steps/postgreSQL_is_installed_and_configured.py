#!/usr/bin/env python
# -*- coding: utf-8 -*-

import testinfra
import re
from behave import *
from time import sleep


def cool_print1():
    print("\n")
    print("###########################################################################################")
    print("#                           TEST POSTGRESQL RESTART AFTER VM REBOOT                       #")
    print("#                             Rebooting machine. Waiting.....                             #")
    print("###########################################################################################")
    print("\n")


def cool_print2():
    print("\n")
    print("###########################################################################################")
    print("#                      TEST POSTGRESQL RESTART AFTER KILLING HIS PROCESS                  #")
    print("#                           Killing postgres process. Waiting.....                        #")
    print("###########################################################################################")
    print("\n")


def cool_print3():
    print("\n")
    print("###########################################################################################")
    print("#                      TEST POSTGRESQL HHTP_PORT IS LISTENING                             #")
    print("#                           shoud listen on port: 12400                                   #")
    print("###########################################################################################")
    print("\n")


@then('postgresql is installed and configured')
def step_impl(context):
    reboot_command = 'sudo reboot'
    postgresql_pid_command = 'systemctl status postgresql95'
    server = testinfra.get_host('ssh://automation@' + context.params['vm_ipaddr'])

    def get_postgresql_pid():
        ch = "Main PID"
        postgresql_status = server.run(postgresql_pid_command).stdout.splitlines()
        for i in postgresql_status:
            if re.search(ch, i) is not None:
                postgresql_pid = i.split()[2]
                return postgresql_pid
            else:
                pass

    cool_print1()
    server.run(reboot_command)
    sleep(10)
    pid_before_kill = get_postgresql_pid()

    count = 0

    while pid_before_kill is None and count < 6:
        try:
            sleep(10)
            pid_before_kill = get_postgresql_pid()
            count += 1
        except Exception:
            raise Exception("Somethong goes wrong!")

    if pid_before_kill is None:
        print("Postgresql automatic restart failed. PID is {}".format(pid_before_kill))
    else:
        print("Postgresql restarted automatically after VM reboot and his PID is: {}".format(pid_before_kill))

    cool_print2()
    server.run("sudo kill -9 {}".format(pid_before_kill))
    sleep(30)

    pid_after_kill = get_postgresql_pid()
    print("Postgresql PID after kill: {}".format(pid_after_kill))

    if pid_before_kill != pid_after_kill and None not in [pid_before_kill, pid_after_kill]:
        assert context.failed is False
    else:
        assert context.failed is True

    cool_print3()
    get_postgresql_port_command = "sudo netstat  -tlunp | grep  postgres"
    postgresql_port = server.run(get_postgresql_port_command).stdout.splitlines()
    ch = "LISTEN"

    def get_http_port():
        for i in postgresql_port:
            if re.search(ch, i) is not None:
                port = i.split()[3]
                http_port = port[3:]
                return http_port

    postgresql_http_port = get_http_port()

    print("Postgresql is Listening on {} http_port".format(postgresql_http_port))
    print('port')
    if postgresql_port != 12400:
        assert context.failed is False
    else:
        assert context.failed is True

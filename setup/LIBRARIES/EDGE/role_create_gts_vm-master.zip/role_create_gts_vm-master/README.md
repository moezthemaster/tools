Create GTS VM [DEPRECATED]
=========
WARNING: #THIS REPO IS DEPRECATED #

Requirements
------------
This role can't be used outside playbook_edge_vm, multiple variables and files are retreived from this playbook:

Variables:
  - playbook_version: '{{ansible_env.PWD|basename}}_1.0.2'
  - virtual_env_folder: '/var/tmp/virtualenv/{{playbook_version}}'
  # choices: settings_prod.cfg | settings_uat.cfg
  - EDGE_settings_file: 'settings_prod.cfg'
  - CLOUDAW_settings_file: 'settings_prod.cfg'

Files are in files repertory in playbook_edge_vm, it contains some config files and requirements to install with pip

specifics ansible modules must be present on deployment platform (RET/INF responsible) :
  - sg_gts_cloud_pubkey.py
  - sg_gts_cloud_vm.py
  - sg_gts_dod.py
  - sg_gts_token.py


Role Input Variables
--------------------

  
 **app_id**
`required: True`

      Application Trigram 

**vm_hostname**
`required: True`

     vm name
     set it to 'none' or blank for dynamic naming
    
**vm_network**
`required: True`

     Network Identifier
     
**vm_desc**
`required: True` 

     vm description

**app_env**
`required: True`

     vm environment
     default is 'prd'
     choices:
         - 'dev'
         - 'hml'
         - 'prd'

**vm_profile**
`required: True`

     vm size
     default is 'Micro 1vCPU-1GB'
     choices: 
          - 'Micro 1vCPU-1GB'
          - 'Medium 2vCPU-4GB'
          - 'Small 1vCPU-2GB'
          - 'Large 4vCPU-8GB'
          - 'Large-mem32 4vCPU-32GB'
          - 'XLarge 8vCPU-16GB'
          - 'XLarge-mem32 8vCPU-32GB'
          - 'XLarge-mem64 8vCPU-64GB'

**vm_region**
`required: True`

     vm region
     default is "EU France (Greater Paris)"
     choices: ['EU France (Greater Paris)', 'EU France (North)']

**vm_az**
`required: True`

     vm zone
     default is "eu-fr-paris-1"
     choices: ['eu-fr-paris-1', 'eu-fr-paris-2', 'eu-fr-north-1']

**vm_os**
`required: True`

     vm operating system
     default is "RHEL_7.3_x64-RET-EDGE",
     choices: 
         - 'RHEL_7.3_x64-RET-EDGE'
         - 'RHEL_7.3_x64-CLOUDCELL-RET'
         - 'CENTOS_7.0_x64-RET-EDGE'
         - 'RHEL_7.3_x64-WEBCELL-RET-EDGE'
         - 'CENTOS_7.0_x64-WEBCELL-RET-EDGE'
         

**vm_replication**
`required: True`

     define if a replication is needed
     default is False,
     choices: [False, True]


**vm_backup**
`required: True`

     define if a backup is needed
     default is "none",
     choices: 
         - 'none'
         - 'daily-31d-2AM'
         - 'daily-31d-4AM'

**vm_pubkey**
`required: True`

     vm public key to be deployed  
     default is "ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEA43kkbWmmtCfZwjsXlmQbeTGOVMlDMA0njeo65Gs42VCElN1R8gHyQisgUZa6lWkWp3z0Asqzc0ApMQUODDUC2v+u7yU2y0zF8vVKxySm1ev0GlhbAG0Zowf5Q4I0XLEXsmOpMrXUG5GFMBuWSiMiWgPDyGCVgZjj7+MVjTrXIisjYTe40ZyUIGdtiboxkbBs1sbCG8vhha4VFUjTmkzkxiFgVzro08BCzlgZnACGSJWPFC88LE1NeOAGM/lfOmVuIC940zhJIxF09K4Prmd2HO7w2g3q/fSv9hHeX4loxPtOgbvQArLUyo/0aMf24BYgnYJoUqBw311hjKG+xLOpdw== postinstall@retinf"

**data_disk**
`required: True`

     vm data disk size
     default is 0
     choices: 
          - 0
          - 20
          - 60
          - 160
          - 300
          - 500
          - 750
          - 1000

**state**
`required: True`

     vm state
     default is "present",
     choices:
         - 'present' to create create vm
         - 'absent' to delete vm 

**deprecated_endClient**
`required: False`

     This input is deprecated, if filled it overrides the endClient worked out from Kat. 

Role Output Variables
---------------------

**ip_address**
`required: True`

     VM IP address.

**uuid**
`required: True`

    VM Identifier.

**hostname**
`required: True`  

    VM name.

Dependencies
------------

A list of other roles hosted on Galaxy should go here, plus any details in regards to parameters that may need to be set for other roles, or variables that are used from other roles.

Networks availables:

```/etc/ansible/gts_cloud_network_mapping.yml ```


```yaml

DEV:
  EU France (Greater Paris):
    eu-fr-paris-1:
      - CDN
      - CITS
      - CITS_2
    eu-fr-paris-2:
      - CDN
      - CITS
      - APP_CCELL_BSC
      - TECH_CCELL_BSC
      - APP_CCELL_ITIM
      - TECH_CCELL_ITIM
  EU France (North):
    eu-fr-north-1:
      - CDN
      - CITS
      - APP_CCELL_BSC
      - TECH_CCELL_BSC
      - APP_CCELL_ITIM
      - TECH_CCELL_ITIM
HML:
  EU France (Greater Paris):
    eu-fr-paris-1:
      - CDN_HOB
      - CDN_HOT
      - L1_BACKEND
      - L1_COMMON
      - L1_SPECIFIC
      - L1_TECHNICAL
    eu-fr-paris-2:
      - CDN_HOB
      - CDN_HOT
      - L1_BACKEND
      - L1_COMMON
      - L1_SPECIFIC
      - L1_TECHNICAL
      - APP_CCELL_ITIM
      - TECH_CCELL_ITIM
      - APP_FRONT_WCELL_DMZ4_DC1_ITIM
      - APP_FRONT_WCELL_DMZ5_DC1_ITIM
      - APP_BACK_WCELL_DMZ4_DC1_ITIM
      - APP_BACK_WCELL_DMZ5_DC1_ITIM
      - TECH_WCELL_DMZ3_DC1_ITIM
      - VWH_BSC_DMZ51_APP_DC1_GAIA
      - VWH_BSC_DMZ52_APP_DC1_GAIA
      - VWH_BSC_DMZ3_TECH_DC1
  EU France (North):
    eu-fr-north-1:
      - CDN_HOB
      - CDN_HOT
      - L1_BACKEND
      - L1_COMMON
      - L1_SPECIFIC
      - L1_TECHNICAL
      - APP_CCELL_ITIM
      - TECH_CCELL_ITIM
      - APP_FRONT_WCELL_DMZ4_SC2_ITIM
      - APP_FRONT_WCELL_DMZ5_SC2_ITIM
      - APP_BACK_WCELL_DMZ4_SC2_ITIM
      - APP_BACK_WCELL_DMZ5_SC2_ITIM
      - TECH_WCELL_DMZ3_SC2_ITIM
      - VWH_BSC_DMZ51_APP_SC2_GAIA
      - VWH_BSC_DMZ52_APP_SC2_GAIA
      - VWH_BSC_DMZ3_TECH_SC2
PRD:
  EU France (Greater Paris):
    eu-fr-paris-1:
      - CDN
      - L1_BACKEND
      - L1_COMMON
      - L1_SPECIFIC
      - L1_TECHNICAL
      - LEGACY_CDN
      - SHARED_SERVICES
    eu-fr-paris-2:
      - CDN
      - L1_BACKEND
      - L1_COMMON
      - L1_SPECIFIC
      - L1_TECHNICAL
      - LEGACY_CDN
      - SHARED_SERVICES
      - APP_CCELL_BSC
      - TECH_CCELL_BSC
      - APP_CCELL_ITIM
      - TECH_CCELL_ITIM
      - APP_FRONT_WCELL_DMZ1_DC1_ITIM
      - APP_FRONT_WCELL_DMZ2_DC1_ITIM
      - APP_FRONT_WCELL_DMZ3_DC1_ITIM
      - APP_BACK_WCELL_DMZ1_DC1_ITIM
      - APP_BACK_WCELL_DMZ2_DC1_ITIM
      - APP_BACK_WCELL_DMZ3_DC1_ITIM
      - TECH_WCELL_DMZ1_DC1_ITIM
      - TECH_WCELL_DMZ2_DC1_ITIM
      - VWP_BSC_DMZ11_APP_DC1_GAIA
      - VWP_BSC_DMZ21_APP_DC1_GAIA
      - VWP_BSC_DMZ31_APP_DC1_NGAIA
      - VWP_BSC_DMZ41_APP_DC1_NGAIA
      - VWP_BSC_DMZ12_APP_DC1_GAIA
      - VWP_BSC_DMZ22_APP_DC1_GAIA
      - VWP_BSC_DMZ32_APP_DC1_NGAIA
      - VWP_BSC_DMZ42_APP_DC1_NGAIA
      - VWP_BSC_DMZ1_TECH_DC1
      - VWP_BSC_DMZ2_TECH_DC1
  EU France (North):
    eu-fr-north-1:
      - CDN
      - L1_BACKEND
      - L1_COMMON
      - L1_SPECIFIC
      - L1_TECHNICAL
      - LEGACY_CDN
      - SHARED_SERVICES
      - APP_CCELL_BSC
      - TECH_CCELL_BSC
      - APP_CCELL_ITIM
      - TECH_CCELL_ITIM
      - APP_FRONT_WCELL_DMZ1_SC2_ITIM
      - APP_FRONT_WCELL_DMZ2_SC2_ITIM
      - APP_FRONT_WCELL_DMZ3_SC2_ITIM
      - APP_BACK_WCELL_DMZ1_SC2_ITIM
      - APP_BACK_WCELL_DMZ2_SC2_ITIM
      - APP_BACK_WCELL_DMZ3_SC2_ITIM
      - TECH_WCELL_DMZ1_SC2_ITIM
      - TECH_WCELL_DMZ2_SC2_ITIM
      - VWP_BSC_DMZ11_APP_SC2_GAIA
      - VWP_BSC_DMZ21_APP_SC2_GAIA
      - VWP_BSC_DMZ31_APP_SC2_NGAIA
      - VWP_BSC_DMZ41_APP_SC2_NGAIA
      - VWP_BSC_DMZ12_APP_SC2_GAIA
      - VWP_BSC_DMZ22_APP_SC2_GAIA
      - VWP_BSC_DMZ32_APP_SC2_NGAIA
      - VWP_BSC_DMZ42_APP_SC2_NGAIA
      - VWP_BSC_DMZ1_TECH_SC2
      - VWP_BSC_DMZ2_TECH_SC2

```

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - { role: role_create_gts_vm, vm_hostname:dcinlx099, app_id: 'cin', vm_network: 'CITS', vm_os: 'RHEL_7.2_x64-RET', state: 'present' }

or

    ---
    - hosts: localhost
      connection: local
      vars:
         app_id: 'cin'
         vm_network: "CITS"
         vm_desc: "GTS CLOUD VM"
         app_env: "dev"
         vm_profile: "Micro 1vCPU-1GB"
         vm_region: "EU France (Greater Paris)"
         vm_az: "eu-fr-paris-1" 
         vm_os: "RHEL_7.2_x64-RET"
         vm_pubkey: "ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEA43kkbWmmtCfZwjsXlmQbeTGOVMlDMA0njeo65Gs42VCElN1R8gHyQisgUZa6lWkWp3z0Asqzc0ApMQUODDUC2v+u7yU2y0zF8vVKxySm1ev0GlhbAG0Zowf5Q4I0XLEXsmOpMrXUG5GFMBuWSiMiWgPDyGCVgZjj7+MVjTrXIisjYTe40ZyUIGdtiboxkbBs1sbCG8vhha4VFUjTmkzkxiFgVzro08BCzlgZnACGSJWPFC88LE1NeOAGM/lfOmVuIC940zhJIxF09K4Prmd2HO7w2g3q/fSv9hHeX4loxPtOgbvQArLUyo/0aMf24BYgnYJoUqBw311hjKG+xLOpdw== postinstall@retinf"
         data_disk: 0 
         state: "present"
      roles:
         - { role: role_create_gts_vm }


# - EXAMPLE
## CREATE
     ansible-playbook playbook.yml -k -s -e 'state=present'
     ansible-playbook playbook.yml -k -s -e 'vm_hostname=pcinlx111804023 state=present app_env=prd'
## DELETE
     ansible-playbook playbook.yml -k -s -e 'vm_hostname=pcinlx111804023 state=absent app_env=prd'


License
-------

BSD

Author Information
------------------

An optional section for the role authors to include contact information, or a website (HTML is not allowed).

#!/usr/bin/python
# -*- coding: utf-8 -*-

#

''' Module to recreate network mapping from python file.'''

from __future__ import print_function
import argparse
import autopep8

MAPPING = {}

TAB_HEADER = """
|   Environment  | Region                                | AZ                |
Network         |
|:-------:|:-------------------------------:|:---------------------:|:---------------:| """

def add_to_mapping(env, region, az, network, **kwargs):
    if env not in MAPPING:
        MAPPING[env] = {}
    if region not in MAPPING[env]:
        MAPPING[env][region] = {}
    if az not in MAPPING[env][region]:
        MAPPING[env][region][az] = {}
    if network not in MAPPING[env][region][az]:
        MAPPING[env][region][az][network] = {}

    for key, val in kwargs.iteritems():
        if val != '':
            MAPPING[env][region][az][network][key] = val

def parse_networks(filename):
    with open(filename) as fid:
        headers = map(str.strip, fid.readline().split(':'))
        for line in fid:
            network = map(str.strip, line.split(':'))

            values = dict(zip(headers[4:],network[4:]))
            add_to_mapping(env=network[0], region=network[1],
                           az=network[2], network=network[3],
                           **values)

def main(args):
    ''' Main function for map2wiki.'''

    if args.csv_file:
        parse_networks(args.csv_file)
        print("### Available Regions, AZs and Networks (RCR/ex-RET): ")
        print(TAB_HEADER)
        for env, val_env in sorted(MAPPING.iteritems()):
            env_fmt = env
            for region, region_val  in sorted(val_env.iteritems()):
                region_fmt = region
                for az, az_val in sorted(region_val.iteritems()):
                    az_fmt = az
                    for network, network_val in sorted(az_val.iteritems()):
                        if 'network_tag' not in network_val or network_val['network_tag'] != 'mkt':
                            print("| {} | {} | {} | {} |".format(env_fmt, region_fmt, az_fmt, network))
                            env_fmt = " "
                            region_fmt = " "
                            az_fmt = " " 
        print('\n') 

        print("### Available Regions, AZs and Networks (GCR/ex-MKT): ")
        print(TAB_HEADER)
        for env, val_env in sorted(MAPPING.iteritems()):
            env_fmt = env
            for region, region_val  in sorted(val_env.iteritems()):
                region_fmt = region
                for az, az_val in sorted(region_val.iteritems()):
                    az_fmt = az
                    for network, network_val in sorted(az_val.iteritems()):
                        if 'network_tag' in network_val and network_val['network_tag'] == 'mkt':
                            print("| {} | {} | {} | {} |".format(env_fmt, region_fmt, az_fmt, network))
                            env_fmt = " "
                            region_fmt = " "
                            az_fmt = " " 
        print('\n') 


if __name__ == '__main__':
    """ This is executed when run from the command line """

    parser = argparse.ArgumentParser()

    # Required positional argument
    parser.add_argument("csv_file", help="A file containing the network list")

    args = parser.parse_args()
    main(args = args)


#!/usr/bin/python
# -*- coding: utf-8 -*-


class IdmDatabase(object):
    def __init__(self, shared_database=None):
        if isinstance(shared_database, list):
            self.database = shared_database
        else:
            self.database = []

    def _search(self, ip, hostname):
        try:
            index = list(map(lambda x: x["ip"], self.database)).index(ip)
            if self.database[index]['hostname'] != hostname:
                raise Exception("Whats Incoherence")
        except ValueError:
            return None
        vm = self.database[index]
        return vm

    def _enroll(self, ip, hostname):
        found = list(filter(lambda record: record["ip"] == ip, self.database))
        if found:
            if found[0]["hostname"] != hostname:
                raise Exception('ip {} is already assign for hostname={}'.format(
                    ip, found[0]["hostname"]
                ))
        found = list(filter(lambda record: record["hostname"] == hostname, self.database))
        if found:
            if found[0]["ip"] != ip:
                raise Exception('hostname {} is already assign for ip={}'.format(
                    hostname, found[0]["ip"]
                ))
        self.database.append({"ip": ip, "hostname": hostname})
        return True

    def _unenroll(self, hostname):
        try:
            index = list(map(lambda x: x["hostname"], self.database)).index(hostname)
        except ValueError:
            return True
        self.database.pop(index)
        return True

    def _ip_checker(self, ip):
        try:
            index = list(map(lambda x: x["ip"], self.database)).index(ip)
            return {
                u'id': 0,
                u'principal': u'iru_pga_edge_service@IRU-P-2.DNS20.SOCGEN',
                u'version': u'4.5.0',
                u'result': {
                    u'additional': {u'idnsname': [u'{}'.format(self.database[index]["hostname"])]},
                    u'value': u'{}'.format(ip), u'summary':
                        u'IP "{}" exists'.format(ip)
                },
                u'error': None
            }
        except ValueError:
            return {
                u'id': 0,
                u'principal': u'iru_pga_edge_service@IRU-P-2.DNS20.SOCGEN',
                u'version': u'4.5.0', u'result': None,
                u'error': {
                    u'message': u'The IPv4 address {} is not assigned in this domain.'.format(ip),
                    u'code': 4001,
                    u'data': {u'reason': u'The IPv4 address {} is not assigned in this domain.'.format(ip)},
                    u'name': u'NotFound'
                }
            }

    def _host_checker(self, hostname):
        try:
            index = list(map(lambda x: x["hostname"], self.database)).index(hostname)
            return {
                u'id': 0,
                u'principal': u'iru_pga_edge_service@IRU-P-2.DNS20.SOCGEN',
                u'version': u'4.5.0',
                u'result': {
                    u'additional': {
                        u'arecord': [u'{}'.format(self.database[index]["ip"])]
                    },
                    u'value': u'{}.iru-p-2.dns20.socgen'.format(hostname),
                    u'summary': u'Host "{}.iru-p-2.dns20.socgen" exists'.format(hostname)
                },
                u'error': None
            }
        except ValueError:
            return {
                u'id': 0,
                u'principal': u'iru_pga_edge_service@IRU-P-2.DNS20.SOCGEN',
                u'version': u'4.5.0',
                u'result': None,
                u'error': {
                    u'message': u'The host "{}.iru-p-2.dns20.socgen" does not exist.'.format(hostname),
                    u'code': 4001,
                    u'data': {
                        u'reason': u'The host "{}.iru-p-2.dns20.socgen" does not exist.'.format(hostname)},
                    u'name': u'NotFound'
                }
            }


class MockedIdm(IdmDatabase):
    def __init__(self, env, **kwargs):
        IdmDatabase.__init__(self, **kwargs)

    def get_realm(self):
        pass

    def get_domain(self):
        pass

    def destroy_token(self):
        pass

    def enroller(self, hostname, ip_address, trigram):
        found = self._search(ip_address, hostname)
        realm = "IRU-P-2.DNS20.SOCGEN"
        if found:
            return {
                u'id': 0,
                u'principal': u'iru_pga_edge_service@{}'.format(realm.upper()),
                u'version': u'4.5.0',
                u'result': {
                    u'failed': {},
                    u'result': {
                        u'dn': u'fqdn={}.{},cn=computers,cn=accounts,dc={},dc={},dc={}'.format(hostname, realm, realm.split('.')[0], realm.split('.')[1], realm.split('.')[2]),
                        u'has_keytab': False,
                        u'cn': [u'{}.{}'.format(hostname, realm)],
                        u'objectclass': [u'ipaobject', u'nshost', u'ipahost',
                                         u'pkiuser', u'ipaservice', u'ieee802device',
                                         u'ipasshhost', u'top', u'ipaSshGroupOfPubKeys'],
                        u'ipakrbokasdelegate': False,
                        u'description': [u'EDGE SERVER'],
                        u'fqdn': [u'{}.{}'.format(hostname, realm)],
                        u'nsosversion': [u'Linux'],
                        u'managing_host': [u'{}.{}'.format(hostname, realm)],
                        u'memberof_hostgroup': [u'hg_a_pga', u'hg_p_std'],
                        u'ipauniqueid': [u'520ceec0-7925-11e8-9e7d-005056857189'],
                        u'has_password': True,
                        u'ipakrbrequirespreauth': True,
                        u'ipakrboktoauthasdelegate': False,
                        u'managedby_host': [u'{}.{}'.format(hostname, realm)],
                        u'serverhostname': [hostname],
                        u'memberofindirect_hbacrule': [
                            u'HB_T_INXN3',u'HB_T_SDIV', u'HB_T_AIXN2', u'HB_T_DB2N2',
                            u'HB_T_BTBSI', u'HB_T_TEAMHABIL', u'HB_T_BACKN3', u'HB_T_OMTR',
                            u'HB_T_INXN2', u'HB_T_BACKN2', u'HB_T_BTAPIIBF', u'HB_T_MDBMFA',
                            u'HB_T_STORN1', u'HB_T_BDDF', u'HB_T_SUPPMUT', u'HB_T_BHF',
                            u'HB_T_AIXN1', u'HB_T_MDBMFI', u'HB_T_DB2N3', u'HB_T_BTAPISFS',
                            u'HB_T_DMQINF', u'HB_T_LNXN2', u'HB_T_BTAPIMOP', u'HB_T_BTAPIBKS',
                            u'HB_T_BACKN1', u'HB_T_MDBMFAN2', u'HB_T_ORAN3', u'HB_T_BTAPIPSM',
                            u'HB_T_BTAUTOL1', u'HB_T_STORN2', u'HB_T_BTFRO', u'HB_T_MDBBFT',
                            u'HB_T_SUPRVISION', u'HB_T_BTAUTOL2', u'HB_T_MDBMFIN2', u'HB_T_WEBM',
                            u'HB_T_STORN3', u'HB_T_BTAPICSC', u'HB_T_CTE', u'HB_T_UNDI',
                            u'HB_T_BDDP', u'HB_T_BDDU', u'HB_T_MDBDMQ', u'HB_T_BTAPIDIS',
                            u'HB_T_IPMAPI', u'HB_T_MDBBFTN2', u'HB_T_GCL', u'HB_T_ORAN2',
                            u'HB_T_BTMET', u'HB_T_LNXN1', u'HB_T_SUPER', u'HB_T_EAO'
                        ]
                    },
                    u'value': u'{}.{}'.format(hostname, realm),
                    u'summary': u'Added host "{}.{}"'.format(hostname, realm)
                },
                u'error': {
                    u"code": 4002
                }
            }
        else:
            self._enroll(ip_address,hostname)
            return {
                u'id': 0,
                u'principal': u'iru_pga_edge_service@{}'.format(realm.upper()),
                u'version': u'4.5.0',
                u'result': {
                    u'failed': {},
                    u'result': {
                        u'dn': u'fqdn={}.{},cn=computers,cn=accounts,dc={},dc={},dc={}'.format(hostname, realm, realm.split('.')[0], realm.split('.')[1], realm.split('.')[2]),
                        u'has_keytab': False,
                        u'cn': [u'{}.{}'.format(hostname, realm)],
                        u'objectclass': [u'ipaobject', u'nshost', u'ipahost',
                                         u'pkiuser', u'ipaservice', u'ieee802device',
                                         u'ipasshhost', u'top', u'ipaSshGroupOfPubKeys'],
                        u'ipakrbokasdelegate': False,
                        u'description': [u'EDGE SERVER'],
                        u'fqdn': [u'{}.{}'.format(hostname, realm)],
                        u'nsosversion': [u'Linux'],
                        u'managing_host': [u'{}.{}'.format(hostname, realm)],
                        u'memberof_hostgroup': [u'hg_a_pga', u'hg_p_std'],
                        u'ipauniqueid': [u'520ceec0-7925-11e8-9e7d-005056857189'],
                        u'has_password': True,
                        u'ipakrbrequirespreauth': True,
                        u'ipakrboktoauthasdelegate': False,
                        u'managedby_host': [u'{}.{}'.format(hostname, realm)],
                        u'serverhostname': [hostname],
                        u'memberofindirect_hbacrule': [
                            u'HB_T_INXN3',u'HB_T_SDIV', u'HB_T_AIXN2', u'HB_T_DB2N2',
                            u'HB_T_BTBSI', u'HB_T_TEAMHABIL', u'HB_T_BACKN3', u'HB_T_OMTR',
                            u'HB_T_INXN2', u'HB_T_BACKN2', u'HB_T_BTAPIIBF', u'HB_T_MDBMFA',
                            u'HB_T_STORN1', u'HB_T_BDDF', u'HB_T_SUPPMUT', u'HB_T_BHF',
                            u'HB_T_AIXN1', u'HB_T_MDBMFI', u'HB_T_DB2N3', u'HB_T_BTAPISFS',
                            u'HB_T_DMQINF', u'HB_T_LNXN2', u'HB_T_BTAPIMOP', u'HB_T_BTAPIBKS',
                            u'HB_T_BACKN1', u'HB_T_MDBMFAN2', u'HB_T_ORAN3', u'HB_T_BTAPIPSM',
                            u'HB_T_BTAUTOL1', u'HB_T_STORN2', u'HB_T_BTFRO', u'HB_T_MDBBFT',
                            u'HB_T_SUPRVISION', u'HB_T_BTAUTOL2', u'HB_T_MDBMFIN2', u'HB_T_WEBM',
                            u'HB_T_STORN3', u'HB_T_BTAPICSC', u'HB_T_CTE', u'HB_T_UNDI',
                            u'HB_T_BDDP', u'HB_T_BDDU', u'HB_T_MDBDMQ', u'HB_T_BTAPIDIS',
                            u'HB_T_IPMAPI', u'HB_T_MDBBFTN2', u'HB_T_GCL', u'HB_T_ORAN2',
                            u'HB_T_BTMET', u'HB_T_LNXN1', u'HB_T_SUPER', u'HB_T_EAO'
                        ]
                    },
                    u'value': u'{}.{}'.format(hostname, realm),
                    u'summary': u'Added host "{}.{}"'.format(hostname, realm)
                },
                u'error': None
            }

    def unroller(self, hostname):
        realm = "IRU-P-2.DNS20.SOCGEN"
        self._unenroll(hostname)
        result = {
            u'id': 0,
            u'principal': u'iru_pga_edge_service@{}'.format(realm.upper()),
            u'version': u'4.5.0',
            u'result': {
                u'failed': {},
                u'value': u'{}.{}'.format(hostname, realm),
                u'summary': u'Deleted host "{}.{}"'.format(hostname, realm)
            },
            u'error': None
        }
        return result

    def ip_checker(self, hostname, ip_address):
        return self._ip_checker(ip_address)

    def host_checker(self, hostname):
        return self._host_checker(hostname=hostname)

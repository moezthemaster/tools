import inspect
import weakref

class Switcher(object):
    """

    """

    def get_whats_environment(self, hostname):
        first_letter = str(hostname.strip()[:1])
        method_name = 'environment_' + str(first_letter).lower()
        method = getattr(self, method_name, lambda: "Invalid hostname")
        return method()

    def environment_d(self):
        return 'DEV'

    def environment_h(self):
        return 'HML'

    def environment_p(self):
        return 'PRD'


whats_env = Switcher()
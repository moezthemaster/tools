
from edge.interfaces import Kat
from edge.kat.service import KatService

KAT_DICT = {
    'PGA' : 'RESG/GTS/RET/API/VDF',
    'CLD' : 'ITIM/ASI/SDC',
    'SFA' : 'RESG/BSC/DCO/VDF',
    'PTA': 'ITEC/FCC/TRA',
    'FOO' : 'BAR'
}


class MockedKat(Kat):
    def get_single_component_data(self, trigram, irt_code):
        response = []
        if trigram.upper() in KAT_DICT:
            response.append({'client_ME': KAT_DICT[trigram.upper()]})
        return response


class MockedKatService(KatService, MockedKat):
    pass

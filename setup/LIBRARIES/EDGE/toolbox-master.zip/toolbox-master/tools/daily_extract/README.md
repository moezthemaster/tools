---

Le script << daily_extract.py >> permet de récupérer les informations d'echec
depuis le serveur KPI de l'équipe EDGE : 

Il récupère tous les échecs de la journée spécifiée par ordre de timestamp, et
affiche le résultat au format csv tel que souhaité dans le fichier excel

--------------
Requirements :
--------------
Le script d'inventaire utilise le module logzero, ainsi que les librairies d'accès elastcisearch v5 et configparser

----------------------
Installer les dépendances listées dans requirements.txt:

```shell
pip install --user --install -r requirements.txt
```

Le fichier /etc/ansible/gts_edge_credentials.cfg doit être présent avec les informations d'authentification pour l'infra Elasticsearch

Si vous souhaitez avoir le lien http vers les logs A4C, il faut paramètrer une clé ssh vers votre user sur peatlx20.dns20.socgen (serveur cloudify de prod) 

----------------------
Execution du script :
----------------------
```
$ ./daily_extract.py --help
usage: error_analysis.py [-h] [-v] [-d DATE] [-o {csv,xls}] [-f OUTPUT_FILE]
                         [-k A4C_KEY] [-r REMOTE_USER] [--version]

optional arguments:
  -h, --help            show this help message and exit
  -v, --verbose         Verbosity (-v, -vv, etc)
  -d DATE, --date DATE  Date for the extract. By default previous day is
                        analyzed
  -o {csv,xls}, --output {csv,xls}
                        Type of output, csv or excel file
  -f OUTPUT_FILE, --output_file OUTPUT_FILE
  -k A4C_KEY, --a4c_key A4C_KEY
                        private key file to connect to a4c
  -r REMOTE_USER, --remote_user REMOTE_USER
                        remote user to connect to a4c
  --version             show program's version number and exit

```

----------------------
TO DO :
----------------------
+ Ajouter la sauvegarde excel
+ Ajouter de l'intelligence sur les colonnes categorie, status et count

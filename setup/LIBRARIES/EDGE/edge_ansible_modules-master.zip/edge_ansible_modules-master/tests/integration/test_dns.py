
import os
import sys
import pytest
import logging

sys.path.append(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
)

from dodaw.exception import DodError

from files.sg_gts_manage_ip import DnsFeederAdapter, DnsCleanerAdapter

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

HOSTNAME = 'dpgalx4100'


class TestDns(object):
    def test_create_delete_vm_with_hostname(self):

        try:
            feeder = DnsFeederAdapter('dev',
                                   'EU France (Greater Paris)',
                                   'eu-fr-paris-1',
                                   'CITS_2',
                                   trigram='pga',
                                   hostname=HOSTNAME)
            cleaner = DnsCleanerAdapter('dev',
                                     'EU France (Greater Paris)',
                                     'eu-fr-paris-1',
                                     'CITS_2',
                                     trigram='pga',
                                     hostname=HOSTNAME)
            logger.info('Cleaning DOD')
            init_response = cleaner.run()
            logger.info('Dod cleaned - response: {}'.format(init_response))
            logger.info('Loading records')
            feeder_response = feeder.run()
            logger.info('Dod loaded - response: {}'.format(feeder_response))
            assert feeder.changed
            # clean  again
            cleaner.changed = False
            cleaner.run()
            logger.info('Dod cleaned again')
            assert cleaner.changed
        except DodError as err:
            pytest.xfail("{u'status_code': u'500'" in err.args[0])

    def test_create_delete_vm_without_hostname(self):
        try:
            feeder = DnsFeederAdapter('dev',
                                   'EU France (Greater Paris)',
                                   'eu-fr-paris-1',
                                   'CITS_2',
                                   trigram='pga')
            feeder_response = feeder.run()
            print('Feeder response: {}'.format(feeder_response))
            hostname_reserved = feeder_response['output'][0]['hostname']
            assert feeder.changed
            assert hostname_reserved
            #clean
            cleaner = DnsCleanerAdapter('dev',
                                     'EU France (Greater Paris)',
                                     'eu-fr-paris-1',
                                     'CITS_2',
                                     trigram='pga',
                                     hostname=hostname_reserved)
            cleaner_response = cleaner.run()
            assert cleaner.changed
        except DodError as err:
            pytest.xfail("{u'status_code': u'500'" in err.args[0])

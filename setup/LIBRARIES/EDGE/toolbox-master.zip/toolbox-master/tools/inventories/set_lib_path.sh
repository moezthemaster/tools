current_path=`pwd`
export PYTHONPATH="$current_path/libs/edge"
export PYTHONPATH="$PYTHONPATH:$current_path/libs/cloudaw"
export PYTHONPATH="$PYTHONPATH:$current_path/libs/dodaw"
export PYTHONPATH="$PYTHONPATH:$current_path/libs/incubaw"
export PYTHONPATH="$PYTHONPATH:$current_path/libs/whatsaw"
export PYTHONPATH="$PYTHONPATH:$current_path/libs/py-edge-vault"

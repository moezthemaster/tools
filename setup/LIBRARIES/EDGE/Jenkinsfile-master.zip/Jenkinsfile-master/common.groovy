#!groovy
import static sgcib.coc.bootcamp.Git.*
import static sgcib.coc.bootcamp.Maven.*

class Utils {
    static Properties readProperties(script, String file, String default_file) {
        Properties default_props = new Properties()
        String default_prop_file = script.readFile default_file
        default_props.load (new StringReader(default_prop_file))

        Properties props = new Properties()
        String prop_file = script.readFile file
        props.load (new StringReader(prop_file))
        
        Properties merged = new Properties();
        merged.putAll(default_props);
        merged.putAll(props);
        merged
    }
}
    
def deploy(String script_path) {
    properties = Utils.readProperties(this, 'jenkins/job.properties', "${script_path}/conf/default.properties",)

    String appName = properties.appName
    String slave = properties.slave

    String sonarProjectKey = properties.sonarProjectKey
    String sonarProjectName = properties.sonarProjectName
    String sonarVersion = properties.sonarVersion
    String sonarInstance = properties.sonarInstance
    String artifactoryCreds = properties.artifactoryCreds
    String jdkVersion = properties.jdkVersion

    String pythonPath = properties.pythonPath

    String goProd = properties.goProd
    String version = properties.version
    String notifyMails = properties.notifyMails
    String rollback = properties.rollback
    String rollbackTag =properties.rollbackTag
    String sgConnectCreds =properties.sgConnectCreds
    String[] region_array = properties.region.split(",")

    if(goProd==true && rollback==true){
        error("Build aborted. goProd property and rollback property can't be both set to true")
    }
    if(rollback==true){
        error("Build aborted. Rollback currently not implemented")
        version = "${rollbackTag}"
    }else{
        
        // stage('TESTS') {
        //     withEnv(["PATH+PYTHON=${pythonPath}"]) {
        //         sh 'python --version'
        //         sh 'mkdir -p tmp'
        //         sh 'cp /CLDPRDAP192/work/tools/swarm/workspace/CLD/config.py .'
        //         sh 'nosetests -v -w ${WORKSPACE}/tests --with-xunit --cover-erase --cover-branches  --cover-xml --with-coverage'
        //         sh 'coverage xml'
        //         version = sh(script: 'cat ${WORKSPACE}/VERSION', returnStdout: true).trim()
        //     }
        // }

        stage('QUALITY CHECK'){
            withSonarQubeEnv(sonarInstance) {
                withEnv(["JAVA_HOME=${tool jdkVersion}",
                        "PATH+SONAR_HOME=${tool sonarVersion}/bin:${tool jdkVersion}/bin", "SONAR_SCANNER_OPTS=-Xmx1536m"]) {
                    sh "sonar-scanner -Dsonar.projectKey=${sonarProjectKey} \
                    -Dsonar.projectVersion='${version}' \
                    -Dsonar.projectName='${sonarProjectName}' \
                    -Dsonar.sources='./ccs/' -Dsonar.host.url=$SONAR_HOST_URL \
                    -Dsonar.exclusions='**/*.js' \
                    -Dsonar.python.coverage.reportPath=coverage.xml \
                    -Dsonar.dynamicAnalysis=reuseReports \
                    -Dsonar.core.codeCoveragePlugin=cobertura \
                    -Dsonar.python.coverage.forceZeroCoverage=true \
                    -Dsonar.python.xunit.reportPath=nosetests.xml \
                    -Dsonar.python.xunit.skipDetails=false \
                    -Dsonar.verbose=true"
                }
            }
        }

        stage('GENERATE SITE-PACKAGES') {
            withCredentials([usernamePassword(credentialsId: artifactoryCreds, passwordVariable: 'ARTI_PASSWORD', usernameVariable: 'ARTI_USER')]){
                sh """rm -f *.tar.gz
                cp -r '${pythonPath}' '${appName}'
                '${appName}'/bin/python -m pip install -r requirements.txt
                tar -czf '${WORKSPACE}'/site-packages.tar.gz --directory='${appName}'/lib/python3.6 site-packages
                rm -rf '${appName}'"""
            }
        }
        
        stage('ARTIFACTORY') {
            withCredentials([usernamePassword(credentialsId: artifactoryCreds, passwordVariable: 'ARTI_PASSWORD', usernameVariable: 'ARTI_USER')]){
                sh "find ${WORKSPACE} -iname '*git*' -exec rm -rf {} | true"
                sh "find ${WORKSPACE} -iname '*agrant*' -exec rm -rf {} | true"
                sh "find ${WORKSPACE} -iname '__pycache__' -exec rm -rf {} | true"
                sh """tar -czf '${appName}'_'${version}'.tar.gz *
                curl -u '${ARTI_USER}':'${ARTI_PASSWORD}' -T '${appName}'_'${version}'.tar.gz 'https://cdp-artifactory.fr.world.socgen/artifactory/pypi-local-resg-gts-mkt-cld/'${appName}'/${version}/'${appName}'_${version}.tar.gz'"""
            }
        }
        
        try{
            stage('DEV DEPLOYMENT') {
                region_array.each { region ->
                    def deploy_region = load("${script_path}/lib/deploy_region.groovy")
                    deploy_region(script_path, region, "DEV", version, false)
                }
            }
        }catch(Exception ex) {
           
        }

        try{
            stage('UAT DEPLOYMENT') {
                region_array.each { region ->
                    def deploy_region = load("${script_path}/lib/deploy_region.groovy")
                    deploy_region(script_path, region, "UAT", version, false)
                }
            }
        }catch(Exception ex) {
           
        }

        if("${goProd}"=="true") {
            stage('PRD DEPLOYMENT') {
                region_array.each { region ->
                    def deploy_region = load("${script_path}/lib/deploy_region.groovy")
                    deploy_region(script_path, region, "PRD", version, false)
                }
            }
        }

    }            
    
}

return this.&deploy

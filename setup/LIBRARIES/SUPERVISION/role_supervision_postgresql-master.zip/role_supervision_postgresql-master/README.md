Role supervision_postgresql
=========

Monitor a postgresql using the Patrol or Zabbix Agent.

This role is an applicative monitoring role

If no action is specified when calling this role, it will execute the following action :

**create.yml** : Installing the KM files needed by the Patrol Agent or configuration files for Zabbix Agent


Here's a description of the other task that can be executed in this role, filling the *patrol_action* with the name of the task requested :

**configure.yml** : Configuring Patrol or Zabbix Agent to monitore postgresql

* Starting Agent
* Sending system stantard monitoring configuration for postgresql to Agent
* Restarting the Agent


**delete.yml** : Removing the postgresql monitoring from the Agent

* Remove postgresql monitoring from agent


**start.yml** : Start Agent's postgresql monitoring

* Start the monitoring (and alerting) for postgresql
 
 
**stop.yml** : Stop Patrol Agent's postgresql monitoring

* Stop the monitoring (and alerting) for postgresql
 

**status.yml** : Get a status of the Patrol Agent

* Return which parameter is in alert state for this Patrol Agent

This role is developped for **FastIT & PAAP projects**. Some updates may have to be done for other needs : contact us :email: List.FR-Admin-Monitoring-L3@socgen.com, or Fork it.

# Installation

```
ansible-galaxy install git+https://sgithub.fr.world.socgen/GTS-MFI-COMPOSANTS-EDGE/role_supervision_postgresql.git,2.0.0 -p roles -f
```

This above command will install role_supervision_postgresql with its dependencies in the specified folder roles of current folder

Requirements
------------

Facts gathering shouldn't be disabled.

Target servers must be Linux.

Patrol Agent should be install and add to the monitoring infra.

You must create an ansible.cfg file on same folder with the playbook which will be launched.

libray is the location ansible looks to find modules for role_supervision_mongodb.

  ```
    [defaults]
    library        = ./roles/edge_ansible_modules/files
  ```
edge_ansible_modules is one of dependencies for role_supervision_postgresql. he contains modules that edge_ansible_modules looks for its operation

You have to specify an inventory file containing localhost as hostname.

NOTE: This role can only be executed through A4C or Ansible Tower platform.


Role Variables
--------------

Here are the requested values for each action :

**create.yml**


**configure.yml**


**delete.yml**


**status.yml**


**start.yml**


**stop.yml**

Dependencies
------------

None

Example Playbook
----------------

```yaml
- hosts: target
  gather_facts: yes
  roles:
    - {role: role_supervision_postgresql,
             patrol_action: 'create'
       }
    - {role: role_supervision_postgresql,
             patrol_action: 'configure',
      }
```

Alertes Générées
----------------


    host			|objectClass		|object				|parameter		|parameterValue			|message	
    *				|POSTGRES-SG		|*				|connection					|*		|[POSTGRES] Connection problem on Database %mc_object% 
    *				|POSTGRES-SG		|*				|disk_space					|*		|[POSTGRES] Nearly no more space available on FS for datas on %mc_object% 
    *				|POSTGRES-SG		|*				|backends					|*		|[POSTGRES] Max_connections nearly reached on %mc_object% 
    *				|POSTGRES-SG		|*				|database_size					|*		|[POSTGRES] DB size is over 50GB on %mc_object%	   
    *				|POSTGRES-SG		|*				|commitratio					|*		|[POSTGRES] Commit ratio is low on %mc_object%
    *				|POSTGRES-SG		|*				|hitratio					|*		|[POSTGRES] Hit ratio is low on %mc_object%
    *				|POSTGRES-SG		|*				|sequence					|*		|[POSTGRES] Sequence limit is reached on %mc_object%


Summary of monitored parameters
-----------------

* **connection** : Checks that Postgres Cluster is up and running ; Simply connects, issues a 'SELECT version()', and leaves ;
* **disk_space** : Checks on the available physical disk space used by Postgres ;
* **backends** : Checks the current number of connections for one or more databases, and optionally compares it to the maximum allowed, which is determined by the Postgres configuration variable max_connections ;
* **database_size** : Checks the size of all databases and complains when they are too big ; 
* **commitratio** : Checks the commit ratio (writes) of all databases and complains when they are too low ; Anything lower than 80%-90% might point at a serious problem ;
* **hitratio** : Checks the hit ratio of all databases and complains when they are too low ; The result is a ratio between the number of pages read in memory and the number of blocks read on disks ;
* **sequence** : Checks how much room is left on all sequences in the database.


Seuils Par Defaut
-----------------

| ALERTES	    |  WARNING	    |  CRITICAL	  |  DATABASES EXCLUES |
|:-----------:|:------------:|:-----------:|:------------------:|
| disk_space	 |    85%	      |    92%      |       	-           |
| backends	   | 90%         	|   95%	      | template0,template1,postgres,pgbench | 
| database_size| 	50Go	| 	| template0,template1,postgres,pgbench| 
| commitratio	| 90%	| 80%	| template0,template1,postgres,pgbench| 
| hitratio| 	90%| 	80%| 	template0,template1,postgres,pgbench| 
| sequence	| 85%	| 95%| 	-


License
-------

BSD

Author Information
------------------

Yanis BEKRAR

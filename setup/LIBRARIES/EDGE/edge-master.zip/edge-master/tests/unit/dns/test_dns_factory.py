#!/usr/bin/python
# -*- coding: utf-8 -*-

import logging


from edge.dns import DnsFeederFactory
from edge.dns import DnsCleanerFactory
from edge.dns.dodv1.feeder import DnsFeeder
from edge.dns.dodv2.cleaner import DnsCleaner

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


class TestDnsFactory:

    def test_dns_get_dodv1(self):
        dns_feeder = DnsFeederFactory(
            "DEV", "EU France (Greater Paris)", "eu-fr-paris-1", "ITEC_CLOUD_DEV_DC2_03"
        )
        assert id(dns_feeder[0]) == id(DnsFeeder)

    def test_dns_get_dodv2(self):
        dns_cleaner = DnsCleanerFactory(
            "HML", "EU France (Greater Paris)", "eu-fr-paris-1", "L1_COMMON"
        )
        assert id(dns_cleaner[0]) == id(DnsCleaner)

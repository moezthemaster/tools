#!/bin/sh

if [ "$1" = "create" ]
then
    python create_full_delete_vm_on_tower.py create
elif [ "$1" = "delete" ]
then
    python create_full_delete_vm_on_tower.py delete
fi

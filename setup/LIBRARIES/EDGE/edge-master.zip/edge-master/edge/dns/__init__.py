
import edge.dns.dodv1.feeder
import edge.dns.dodv2.feeder
import edge.dns.dodv1.cleaner
import edge.dns.dodv2.cleaner
import edge.dns.dodv1.updater
import edge.dns.dodv2.updater
import edge.dns.dodv1.informer
import edge.dns.dodv2.informer

from edge.conf.cloud_network import get_details


class DnsFeederFactory(object):
    def __new__(cls, env, region_cloud, az_cloud, network_id):
        cloud_network_dict = get_details(
            env, region_cloud, az_cloud, network_id
        )
        if cloud_network_dict.get("network_tag", None) == "mkt":
            return edge.dns.dodv1.feeder.DnsFeeder, "mkt"
        else:
            return edge.dns.dodv2.feeder.DnsFeeder, "ret"


class DnsCleanerFactory(object):
    def __new__(cls, env, region_cloud, az_cloud, network_id):
        cloud_network_dict = get_details(
            env, region_cloud, az_cloud, network_id
        )
        if cloud_network_dict.get("network_tag", None) == "mkt":
            return edge.dns.dodv1.cleaner.DnsCleaner, "mkt"
        else:
            return edge.dns.dodv2.cleaner.DnsCleaner, "ret"


class DnsUpdaterFactory(object):
    def __new__(cls, env, region_cloud, az_cloud, network_id):
        cloud_network_dict = get_details(
            env, region_cloud, az_cloud, network_id
        )
        if cloud_network_dict.get("network_tag", None) == "mkt":
            return edge.dns.dodv1.updater.DnsUpdater, "mkt"
        else:
            return edge.dns.dodv2.updater.DnsUpdater, "ret"


class DnsInformerFactory(object):
    def __new__(cls, network_index="ret"):
        if network_index == "mkt":
            return edge.dns.dodv1.informer.DnsInformer, "mkt"
        elif network_index == "ret":
            return edge.dns.dodv2.informer.DnsInformer, "ret"

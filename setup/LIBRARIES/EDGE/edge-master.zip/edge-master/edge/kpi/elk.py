import json
import requests
from requests.compat import urljoin

from edge.conf import settings
from py_edge_vault import secrets


class Loader(object):
    def __init__(self):
        vault_secret = secrets.get_secrets(context=settings.KPI_CREDENTIALS_GROUP, env=settings.KPI_ENV)
        self.user = vault_secret['username']
        self.pwd = vault_secret['password']

    def index_data(self, **params):
        """
        Indexing data in elasticsearch db
        :return: indexation status
        """
        data = dict(params)
        
        headers = {"Content-type": "application/json",
                   "Accept": "application/json"}
        endpoint = "/edge/vm/{}".format(data['id_execution'])
        url = urljoin(settings.ELK_URL, endpoint)
        r = requests.post(url, auth=(self.user, self.pwd), json=data, headers=headers)
        r.raise_for_status()
        response = r.json()["_shards"]
        return response


    def get_data(self, vm_hostname):
        """
        Get indexed data from elasticsearch
        :return: response
        """
        data = {
            "query":{
                "term":{
                    "hostname": vm_hostname
                } 
            },
            "sort": [
                { 
                    "timestamp": {
                        "order": "desc" 
                    } 
                }
            ],
            "size": 1
        }
        
        headers = {"Content-type": "application/json",
                   "Accept": "application/json"}
        endpoint = "/edge/vm/_search"
        url = urljoin(settings.ELK_URL, endpoint)
        r = requests.get(url, auth=(self.user, self.pwd), json=data, headers=headers)
        r.raise_for_status()
        response = r.json()['hits']['hits']
        return response

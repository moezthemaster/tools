import json
import time
from sample.apis import api
from sample.apis.vm import Vm

class TestHome:
    """ Test home url """
    def test_get_home_url(self, flask_app_client):
        """ Test GET home url"""
        res = flask_app_client.get('/')
        assert "Edge Automation" == res.json()["team"]



class TestVm:
    """ Test vm url """
    def test_get_url_vm(self, flask_app_client):
        """ Test get info vm"""
        res = flask_app_client.get('/vm/dpgalx001')
        assert "vm dpgalx001 not exist" == res.json()["msg"]

    def test_post_url_vm(self, flask_app_client):
        """ Test create vm"""
        payload = dict(
            hostname="dpgalx002",
            trigram="pga",
            desc="string",
            env="string",
            os="centos",
            network="string",
        )
        res = flask_app_client.post(api.url_for(Vm), data=json.dumps(payload), headers={'content-type': 'application/json'})
        assert "creation of vm in progress" == res.json()["status"]
        time.sleep(32)
        res = flask_app_client.post(api.url_for(Vm), data=json.dumps(payload), headers={'content-type': 'application/json'})
        assert "created" == res.json()["status"]

    def test_to_get_infos_hostname_which_already_exists(self, flask_app_client):
        """ Test get info vm"""
        res = flask_app_client.get('/vm/dpgalx002')
        assert "dpgalx002" == res.json()["hostname"]

    def test_to_delete_vm(self, flask_app_client):
        """ Test delete vm """
        payload = dict(
            hostname="dpgalx002"
        )
        res = flask_app_client.delete(api.url_for(Vm), data=json.dumps(payload),
                                      headers={'content-type': 'application/json'})
        assert "vm dpgalx002 has deleted" == res.json()["msg"]
        payload = dict(
            hostname="dpgalx003"
        )
        res = flask_app_client.delete(api.url_for(Vm), data=json.dumps(payload),
                                      headers={'content-type': 'application/json'})
        assert "vm dpgalx003 not exist" == res.json()["msg"]
#!/usr/bin/python
# -*- coding: utf-8 -*-

#

import pytest

from edge.dns.dodv2.cleaner import DnsCleaner
from tests.mock.mock import MockDod

mocked_dod_inits = (
    (),
    ('A',),
    ('PTR',),
    ('CNAME',),
    ('A','PTR'),
    ('A','CNAME'),
    ('CNAME','PTR'),
    ('CNAME','PTR','A'),
)

HOSTNAME='dpgalx200'


@pytest.fixture(params=mocked_dod_inits)
def mocked_dod_init(request):
    return request.param


class MockedCleaner(DnsCleaner, MockDod):
    def __init__(self, init_types, env, region_cloud, az_cloud, network_id, trigram, hostname):
        MockDod.__init__(self, init_types, hostname=hostname)
        DnsCleaner.__init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname)


class TestDnsCleaner(object):
    def test_delete_records(self, mocked_dod_init):
        cleaner = MockedCleaner(init_types=mocked_dod_init, env='dev', region_cloud='EU France (Greater Paris)',
                              az_cloud='eu-fr-paris-1', network_id='CDN', trigram="pga", hostname=HOSTNAME)
        cleaner.run()
        assert len(cleaner.dns_database) == 0

    def test_clean_dns_with_fake_hostname(self, mocked_dod_init):
        try:
            MockedCleaner(
                init_types=mocked_dod_init, env='dev', region_cloud='EU France (Greater Paris)',
                az_cloud='eu-fr-paris-1', network_id='CDN', trigram="pga", hostname='fake_hostname'
            )
            assert False
        except Exception as err:
            assert "hostname must be alphanumeric" == err.args[0]

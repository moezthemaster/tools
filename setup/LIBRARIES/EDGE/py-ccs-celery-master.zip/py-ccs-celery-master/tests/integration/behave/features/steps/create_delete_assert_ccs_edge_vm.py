#!/applis/ccsp/virtualenv/py-ccs-celery/bin/python
# -*- coding: utf-8 -*-
import paramiko
import re
import socket
import subprocess
import testinfra
from behave import *
from create_delete_vm import ManageVm
from time import sleep


@given('vm does not exist')
def step_impl(context):
    assert context.failed is False


@when('create full edge ccs vm')
def step_impl(context):
    run_data = {
        'vm_os': "CENTOS_7.5_x64-RET-EDGE",
        'app_env': "prd",
        'vm_hostname': "ppgalxceljenkins001",
        'app_id': 'pga',
        'vm_network': 'L1_COMMON',
        'vm_pubkey': 'ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAyLXUQ9eoPr8Akx+WeJzRgAOMyUbTQ3/RDu44N2svQTa7I0ZKzqelNrSqqsgSmNN7giQGRyIvx/XgUwi9UjrxFX0XRTvwjAcXNHV2pxybbhPb8/2jiAfFTCjkwQBwtoSTEL1I5noAIgapQDZghYFkv0GUiAkebKzl0A+cNqm5Zc2UPNTqsCtIAZ5Uid+XOdECHan29Iyow0f+O/2O6mZKBGvWFJbRLCokKLUrTmhbgWIiWgQGp/PnF0XVVPiQgRfbRz1xH08JNiQz1lnvZ4ME4BhQoxSK1O8QL+dQsSXhvQyjfO8yYI+X4X73Ie9yBfZpPiGAZLo3hTVha46veVfZGw== a373785@PXPLSV02',
        'code_irt': 'A7048',
        'data_disk': 20,
        'vm_profile': "Micro 1vCPU-1GB",
        'vm_desc': "jenkins test vm creation via ccs endpoint"
    }

    context.vm = ManageVm(vm_os=run_data['vm_os'], app_env=run_data['app_env'], vm_hostname=run_data['vm_hostname'],
                          app_id=run_data['app_id'], vm_network=run_data['vm_network'],
                          vm_pubkey=run_data['vm_pubkey'], code_irt=run_data['code_irt'],
                          vm_desc=run_data['vm_desc'], data_disk=run_data['data_disk'])
    context.create_vm = context.vm.create_full_vm()

    if context.create_vm[1] == 'SUCCESS':
        # uuid = context.create_vm[0]
        # print(uuid)
        assert context.failed is False
    else:
        assert context.failed is True

    context.vm_hostname = run_data['vm_hostname']
    context.data_disk = run_data['data_disk']
    context.vm_profile = run_data['vm_profile']
    chaine = re.compile('\w* ([0-9]+)vCPU-([0-9]+)GB')
    res = chaine.search(context.vm_profile)
    context.vm_cpu = res.group(1)
    context.vm_ram = res.group(2)


@then('VM accepts ssh with automation')
def step_impl(context):
    private_key = "/applis/ccsp/.ssh/id_rsa"
    key = paramiko.RSAKey.from_private_key_file(private_key)
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(hostname=context.vm_hostname, username='automation', pkey=key)
        client.close()
    except (BadHostKeyException, AuthenticationException, SSHException, socket.error) as e:
        print(e)
        assert context.failed is True

    assert context.failed is False


@then('VM is connected to WHATS')
def step_impl(context):
    test_user = 'a445095'
    print("Test existance of user {} \n".format(test_user))

    server = testinfra.get_host('ssh://automation@' + context.vm_hostname)

    cmd_id = server.run("id {}".format(test_user))

    print("stdout => " + cmd_id.stdout + "\n")
    print("stderr => " + cmd_id.stderr + "\n")

    if 'no such user' in cmd_id.stderr:
        assert context.failed is True
    else:
        assert context.failed is False


@then('VM is registered in DNS')
def step_impl(context):
    try:
        subprocess.check_output('nslookup {}'.format(context.vm_hostname), shell=True)
        assert context.failed is False
    except Exception:
        assert context.failed is True


@then('VM parameters are OK')
def step_impl(context):
    print(" Test extra disk has correct size and RAM & CPU are OK\n")

    server = testinfra.get_host('ssh://automation@' + context.vm_hostname)

    # Test if mountpoint requested is mounted
    cmd_disk = server.run("lsblk -l --noheadings --nodeps /dev/sdb -o size")

    if cmd_disk.stdout.strip() == '{}G'.format(context.data_disk):
        assert context.failed is False
    else:
        assert context.failed is True

    # Test the number of CPU
    cmd_cpu = server.run("cat /proc/cpuinfo | grep 'cpu cores' | cut -d':' -f2 | tr -d ' ' ")

    if cmd_cpu.stdout[:-1] == context.vm_cpu:
        assert context.failed is False
    else:
        assert context.failed is True

    # Test the amount of RAM
    cmd_ram = server.run("cat /proc/meminfo | grep 'MemTotal' | cut -d':' -f2 | tr -d ' ' ")

    if int(cmd_ram.stdout[:-3]) / (float(context.vm_ram) * 1024 * 1024) > 0.95:
        assert context.failed is False
    else:
        assert context.failed is True


@then('VM flexera is installed')
def step_impl(context):
    print("Test user flexera is created and Flexera Agent is well installed\n")

    server = testinfra.get_host('ssh://automation@' + context.vm_hostname)

    # Test if user flexera is created
    user = server.user('flexera').exists

    if user:
        assert context.failed is False
    else:
        assert context.failed is True

    # Test if group flexera is created
    group = server.group('flexera').exists

    if group:
        assert context.failed is False
    else:
        assert context.failed is True

    # Test if flexera agent is running
    commande = "ps -edf | grep -i /opt/managesoft/libexec/ndtask | grep -vc grep"
    started = server.run(commande)

    if int(started.stdout) == 1:
        assert context.failed is False
    else:
        assert context.failed is True

    # Test if flexera is registred on the Infra Server
    commande = "sudo grep -c 'successfully installed the merged deployment policy' /var/opt/managesoft/log/policy.log"
    count = 0
    reg = server.run(commande)
    while count < 3 and not int(reg.stdout) > 0:
        sleep(10)
        reg = server.run(commande)
        count += 1

    if int(reg.stdout) > 0:
        assert context.failed is False
    else:
        assert context.failed is True


@then('Hostname is short')
def step_impl(context):
    print("Test VM hostname is short\n")

    server = testinfra.get_host('ssh://automation@' + context.vm_hostname)
    command_short_hostname = server.run('hostname -s')
    command_hostname = server.run('hostname')

    if command_short_hostname.stdout.strip() == command_hostname.stdout.strip():

        assert context.failed is False
    else:
        assert context.failed is True


@then('delete vm')
def step_impl(context):
    context.delete_vm = context.vm.delete_vm()
    if context.delete_vm[1] == 'SUCCESS':
        # uuid = context.create_vm[0]
        # print(uuid)
        assert context.failed is False
    else:
        assert context.failed is True


import time

from ccs_celery.abstract import TaskServiceManager
from ccs_celery.services._dod.module import dod_module
from ccs_celery.services.rollback import RollBackMixins


class DodMixins(object):

    def on_failure(self, exc, kwargs, excinfo):
        try:
            self.rollback()
        except Exception as err:
            self.logger.error("Rollback for {} module has failded".format(str(err)))
        finally:
            self.data.services[self._task_name]["finished_at"] = time.time()
            self.data.services[self._task_name]["status"] = "FAILED"
            self.data.services[self._task_name]["exception_class"] = str(type(exc))
            self.data.services[self._task_name]["exception_msg"] = str(exc)
            self.data.services[self._task_name]["exception_traceback"] = str(excinfo)

    def on_success(self, result, kwargs):
        self.data.services[self._task_name]["finished_at"] = time.time()
        self.data.services[self._task_name]["status"] = "SUCCESS"
        self.data.services[self._task_name]["return_value"] = result

    def task(self):
        interesting_keys = (
            'vm_hostname', 'vm_az', 'vm_region', 'vm_network',
            'app_id', 'app_env', 'state', 'network_index'
        )
        self.data.services[self._task_name] = {
            "changed": False,
            "launch_at": time.time(),
            "service_kwargs": {x: self.data.shared_data[x] for x in interesting_keys if x in self.data.shared_data},
        }
        self.logger.info("Invoke {} module with kwargs={}".format(
            self._task_name,
            self.data.services[self._task_name]["service_kwargs"])
        )
        result = dod_module(**self.data.services[self._task_name]["service_kwargs"])
        if self.data.shared_data["state"] in ("present", "absent"):
            self.data.services[self._task_name]["rollback_kwargs"] = dict(
                state=self.nor_state(self.data.shared_data["state"]),
                **{x: self.data.services[self._task_name]["service_kwargs"][x] \
                   for x in self.data.services[self._task_name]["service_kwargs"].keys() if x != "state"}
            )
        self.data.services[self._task_name]["changed"] = result[0]
        if self.data.shared_data["state"] == "present":
            self.data.shared_data["vm_hostname"] = result[1]["output"][0]["hostname"]
            self.data.shared_data["vm_ip"] = result[1]["output"][0]["ip"]
            self.data.shared_data["vm_subnet"] = result[1]["subnet"]
            self.data.shared_data["vm_zone"] = result[1]["output"][0]["zone"]
        return result


class DodInfosTask(TaskServiceManager):
    def __init__(self, data):
        super().__init__("DodInfos", data)

    def on_failure(self, exc, kwargs, excinfo):
        self.data.services[self._task_name]["finished_at"] = time.time()
        self.data.services[self._task_name]["status"] = "FAILED"
        self.data.services[self._task_name]["exception_class"] = str(type(exc))
        self.data.services[self._task_name]["exception_msg"] = str(exc)
        self.data.services[self._task_name]["exception_traceback"] = str(excinfo)

    def on_success(self, result, kwargs):
        self.data.services[self._task_name]["finished_at"] = time.time()
        self.data.services[self._task_name]["status"] = "SUCCESS"
        self.data.services[self._task_name]["return_value"] = result

    def _set_up(self):
        self.data.services[self._task_name] = {
            "changed": False,
            "launch_at": time.time(),
            "service_kwargs": {}
        }
        self.data.services[self._task_name]["service_kwargs"]["vm_hostname"] = self.data.shared_data["vm_hostname"]
        self.data.services[self._task_name]["service_kwargs"]["app_env"] = self.data.shared_data["app_env"]
        self.data.services[self._task_name]["service_kwargs"]["network_index"] = self.data.shared_data["network_index"]
        self.data.services[self._task_name]["service_kwargs"]["state"] = "infos"

    def task(self):
        self._set_up()
        self.logger.info("Invoke {} module with kwargs={}".format(
            self._task_name,
            self.data.services[self._task_name]["service_kwargs"])
        )
        result = dod_module(**self.data.services[self._task_name]["service_kwargs"])
        self.data.shared_data["vm_ip"] = result[1][0]["ip_address"]
        self.data.shared_data["vm_subnet"] = result[1][0]["vm_subnet"]
        self.data.shared_data["vm_region"] = result[1][0]["vm_region"]
        self.data.shared_data["vm_az"] = result[1][0]["vm_az"]
        self.data.shared_data["vm_network"] = result[1][0]["vm_network"]
        self.data.shared_data["dns_zone"] = result[1][0]["vm_zone"]
        self.data.shared_data["dns_publish"] = result[1][0]["dns_publish"]
        return result


class DodTask(DodMixins, TaskServiceManager, RollBackMixins):
    def __init__(self, data):
        TaskServiceManager.__init__(self, "Dod", data)


class UnRegisterDodTask(DodMixins, TaskServiceManager, RollBackMixins):
    def __init__(self, data):
        TaskServiceManager.__init__(self, "UnRegisterDod", data)

package view.run_input_required

import groovy.json.JsonSlurperClassic

def userInput = true
def didTimeout = false
def deploy = false
def run_on_uat = 'sed -i -e "s/CLOUDAW_settings_file: \'settings_prod.cfg\'' +
        '/CLOUDAW_settings_file: \'settings_uat.cfg\'/g" defaults/edge_config.yml'
def inventory_path = '/etc/ansible/hosts'
def nodes = ["AnsibleTower", "pedglx112"]
def tasks = [:]
def gitUrl = 'https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/playbook_edge_vm.git'
def gitRepo = 'sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/playbook_edge_vm.git'

///////////////*PLAYBOOK RUN VARS*//////////////////////////////////////////////////////////////////////////////////////
def playbook_run = 'ansible-playbook'
def playbook_create_mkt = 'create_full_mkt.yml'
def playbook_delete_mkt = 'delete_mkt.yml'
def rhel_config = 'tests/behave/features/config/create_delete_RHEL_DEV_MKT.yml'
def centos_config = 'tests/behave/features/config/create_delete_CENTOS_PRD_MKT.yml'

///////////////*BEHAVE TESTS VARS*//////////////////////////////////////////////////////////////////////////////////////
def behave_run = "behave tests/behave/features"
//def create_delete_RHEL = "create_delete_RHEL.feature"
def create_delete_rhel_mkt = "create_delete_rhel_mkt.feature"
def create_delete_centos = "create_delete_centos.feature"
def create_delete_centos_mkt = "create_delete_centos_mkt.feature"
def squid_installed_on_CentOS = "squid_installed_on_CentOS.feature"
def squid_installed_on_rhel = "squid_installed_on_rhel.feature"
def postgresql_installed_on_rhel = "postgresql_installed_on_rhel.feature"
def postgresql_installed_on_centos = "postgresql_installed_on_centos.feature"

///////////////*PREPARE BEHAVE ENV VARS*////////////////////////////////////////////////////////////////////////////////
def behave_copy_tests = "cp -rp tests/behave/features/behave.ini ."
def behave_copy_extra_playbooks = "cp -rp tests/behave/features/extra_playbooks/* ."
def galaxy_install_requirements = "ansible-galaxy install --force -r roles/requirements.yml -p roles/ --ignore-errors"
def galaxy_install_extra_requirements = "ansible-galaxy install --force -r roles/extra_requirements.yml -p roles/ --ignore-errors"


///////////////*MESSAGES AND ECHO VARS*/////////////////////////////////////////////////////////////////////////////////
def not_confirmed = "You did not confirmed deployement"
def not_itsm_ticket = "You did not provide change number"
def message_simple = "playbook_edge_vm build successful"
def message_on_deploy = "Deployment of tag's virtualenv on EDG platform has been succeded"

def run_remote_command = "ssh -i ~/.ssh/id_rsa automation@hedglx002"
def run_remote_command_on_pedglx002 = "ssh -i ~/.ssh/id_rsa automation@pedglx002"
def remove_ccs_cd_celery = "rm -rf ccs_cd_celery"
def second_workspace = "/applis/edgp/spicev2/workspace/EDG/2be2fd94/workspace/PGA/playbook_edge_vm"
def run_remote_command_on_pedglx112 = "ssh -i ~/.ssh/id_rsa automation@pedglx112"

///////////////*REQUIREMENTS FOR SETTING VIRTUALENV AND GENERATE CONFIG FILE*///////////////////////////////////////////


node('AnsibleTower') {
    sh 'rm -rf ./*'
    stage('Configuring workflow') {
        try {
            timeout(time: 60, unit: 'SECONDS') {
                def outcome = input id: 'Run-behave-tests',
                        message: 'Workflow Configuration',
                        ok: 'Submit',
                        parameters: [
                                [
                                        $class      : 'BooleanParameterDefinition',
                                        defaultValue: true,
                                        name        : 'Run Behave RHEL VM?',
                                        description : 'Create rhel vm in PRD via Ansible Tower'
                                ],
                                [
                                        $class      : 'BooleanParameterDefinition',
                                        defaultValue: true,
                                        name        : 'Run Behave CentOS VM?',
                                        description : 'Create CentOS vm in PRD'
                                ],
                                [
                                        $class      : 'BooleanParameterDefinition',
                                        defaultValue: true,
                                        name        : 'Run Behave CentOS squid?',
                                        description : 'Create CentOS vm and install squid in DEV '
                                ],
                                [
                                        $class      : 'BooleanParameterDefinition',
                                        defaultValue: true,
                                        name        : 'Run Behave RHEL squid?',
                                        description : 'Create rhel vm and install squid in HML'
                                ],
                                [
                                        $class      : 'BooleanParameterDefinition',
                                        defaultValue: true,
                                        name        : 'Behave RHEL postgresql?',
                                        description : 'Create rhel vm and install postgesql in DEV'
                                ],
                                [
                                        $class      : 'BooleanParameterDefinition',
                                        defaultValue: true,
                                        name        : 'Behave CentOS postgresql?',
                                        description : 'Create CentOS vm and install postgesql in HML'
                                ],
                                [
                                        $class      : 'BooleanParameterDefinition',
                                        defaultValue: true,
                                        name        : 'Run Create RHEL VM in MKT network?',
                                        description : 'Create rhel vm in DEV mkt network'
                                ],
                                [
                                        $class      : 'BooleanParameterDefinition',
                                        defaultValue: true,
                                        name        : 'Run Behave CentOS VM in MKT network?',
                                        description : 'Create CentOS vm in PRD mkt network'
                                ],
                                [
                                        $class      : 'StringParameterDefinition',
                                        defaultValue: "master",
                                        name        : 'Enter your tag',
                                        description : 'confirm tag'
                                ],
                                [
                                        $class     : 'ChoiceParameterDefinition', choices: 'PRD\nUAT\nDEV',
                                        name       : 'Select your cloud platform environement',
                                        description: 'make selection'
                                ]
                        ]

                env.RHEL_TEST = "${outcome.get('Run Behave RHEL VM?')}"
                env.CENTOS_TEST = "${outcome.get('Run Behave CentOS VM?')}"
                env.CENTOS_SQUID_TEST = "${outcome.get('Run Behave CentOS squid?')}"
                env.RHEL_SQUID_TEST = "${outcome.get('Run Behave RHEL squid?')}"
                env.RHEL_POSTGRES_TEST = "${outcome.get('Behave RHEL postgresql?')}"
                env.CENTOS_POSTGRES_TEST = "${outcome.get('Behave CentOS postgresql?')}"
                env.RHEL_MKT_TEST = "${outcome.get('Run Create RHEL VM in MKT network?')}"
                env.CENTOS_MKT_TEST = "${outcome.get('Run Behave CentOS VM in MKT network?')}"
                env.BRANCH_TEST = "${outcome.get('Enter your tag')}"
                env.ENV_TEST = "${outcome.get('Select your cloud platform environement')}"
            }

        } catch (err) {
            def user = err.getCauses()[0].getUser()
            if ('SYSTEM' == user.toString()) {
                didTimeout = true
                env.RHEL_TEST = true
                env.CENTOS_TEST = true
                env.CENTOS_SQUID_TEST = true
                env.RHEL_SQUID_TEST = true
                env.RHEL_POSTGRES_TEST = true
                env.CENTOS_POSTGRES_TEST = true
                env.RHEL_MKT_TEST = true
                env.CENTOS_MKT_TEST = true
                env.BRANCH_TEST = 'master'
                env.ENV_TEST = 'PRD'

            } else {
                userInput = false
                echo "Aborted by: [${user}]"
            }
            // throw err
        }
    }

    currentBuild.result = "SUCCESS"

    stage("Init env on Principal slave") {
        if (didTimeout) {
            // Run playbook on default values
            echo "Run playbook on default values"
            git url: "${gitUrl}"
             if ("${env.BRANCH_TEST}" =~ /^([0-9]+)/) {
                echo "Run playbook release ${env.BRANCH_TEST} on ${env.ENV_TEST} cloud platform"
                checkout scm: [
                        $class           : 'GitSCM',
                        userRemoteConfigs: [[url: "${gitUrl}"]],
                        branches         : [[name: "tags/${env.BRANCH_TEST}"]]],
                        poll: false

               } else if ("${env.BRANCH_TEST}" == "master") {
                echo "PLAYING BRANCH ${env.BRANCH_TEST}"
                checkout([
                        $class                           : 'GitSCM',
                        branches                         : [[name: "${env.BRANCH_TEST}"]],
                        doGenerateSubmoduleConfigurations: false,
                        extensions                       : [],
                        submoduleCfg                     : [],
                        userRemoteConfigs                : [[url: "${gitUrl}"]]])

                sh "chmod +x scripts/update_version.sh && chmod +x scripts/template.sh"
                sh "version=${env.BRANCH_TEST} scripts/template.sh defaults/edge_config_template.yml > defaults/edge_config.yml"
                sh "cat defaults/edge_config.yml"
            } else if ("${env.BRANCH_TEST}" != "master") {
                echo "PLAYING BRANCH ${env.BRANCH_TEST}"
                checkout([
                        $class                           : 'GitSCM',
                        branches                         : [[name: "${env.BRANCH_TEST}"]],
                        doGenerateSubmoduleConfigurations: false,
                        extensions                       : [],
                        submoduleCfg                     : [],
                        userRemoteConfigs                : [[url: "${gitUrl}"]]])

                sh "chmod +x scripts/update_version.sh && chmod +x scripts/template.sh"
                sh "version=${env.BRANCH_TEST} scripts/template.sh defaults/edge_config_template.yml > defaults/edge_config.yml"
                sh "cat defaults/edge_config.yml"
            }
        } else if (userInput) {
            if ("${env.ENV_TEST}" == 'DEV') {
                echo "DEV VRA platform is not myet iplemented. Please select 'PRD' or UAT' platform"
                error("VRA platform not implemented")
            }
            if ("${env.BRANCH_TEST}" =~ /^([0-9]+)/) {
                echo "Run playbook release ${env.BRANCH_TEST} on ${env.ENV_TEST} cloud platform"
                checkout scm: [
                        $class           : 'GitSCM',
                        userRemoteConfigs: [[url: "${gitUrl}"]],
                        branches         : [[name: "tags/${env.BRANCH_TEST}"]]],
                        poll: false

               } else if ("${env.BRANCH_TEST}" == "master") {
                echo "PLAYING BRANCH ${env.BRANCH_TEST}"
                checkout([
                        $class                           : 'GitSCM',
                        branches                         : [[name: "${env.BRANCH_TEST}"]],
                        doGenerateSubmoduleConfigurations: false,
                        extensions                       : [],
                        submoduleCfg                     : [],
                        userRemoteConfigs                : [[url: "${gitUrl}"]]])

                sh "chmod +x scripts/update_version.sh && chmod +x scripts/template.sh"
                sh "version=${env.BRANCH_TEST} scripts/template.sh defaults/edge_config_template.yml > defaults/edge_config.yml"
                sh "cat defaults/edge_config.yml"
            } else if ("${env.BRANCH_TEST}" != "master") {
                echo "PLAYING BRANCH ${env.BRANCH_TEST}"
                checkout([
                        $class                           : 'GitSCM',
                        branches                         : [[name: "${env.BRANCH_TEST}"]],
                        doGenerateSubmoduleConfigurations: false,
                        extensions                       : [],
                        submoduleCfg                     : [],
                        userRemoteConfigs                : [[url: "${gitUrl}"]]])

                sh "chmod +x scripts/update_version.sh && chmod +x scripts/template.sh"
                sh "version=${env.BRANCH_TEST} scripts/template.sh defaults/edge_config_template.yml > defaults/edge_config.yml"
                sh "cat defaults/edge_config.yml"
            }
        } else if (!userInput) {
            // Exit on failure
            echo "Run aborted"
            error("this build was aborted")
        } else {
            // Exit on failure
            echo "unknown problem"
            error("Something is going wrong")
        }
        sh "${behave_copy_tests}; ${behave_copy_extra_playbooks}; ${galaxy_install_requirements}; ${galaxy_install_extra_requirements}"
    }
/*    stage('Init env on second slave') {
        node('pedglx112') {
            sh 'rm -rf ./*'
            sh 'rm -f /applis/edgp/.ssh/known_hosts'
            if (didTimeout) {
                // Run playbook on default values
                echo "Run playbook on default values"
                git url: "${gitUrl}"
                if ("${env.BRANCH_TEST}" =~ /^([0-9]+)/) {
                    echo "Run playbook release ${env.BRANCH_TEST} on ${env.ENV_TEST} cloud platform"
                    checkout scm: [
                            $class           : 'GitSCM',
                            userRemoteConfigs: [[url: "${gitUrl}"]],
                            branches         : [[name: "tags/${env.BRANCH_TEST}"]]],
                            poll: false

                   } else if ("${env.BRANCH_TEST}" == "master") {
                    echo "PLAYING BRANCH ${env.BRANCH_TEST}"
                    checkout([
                            $class                           : 'GitSCM',
                            branches                         : [[name: "${env.BRANCH_TEST}"]],
                            doGenerateSubmoduleConfigurations: false,
                            extensions                       : [],
                            submoduleCfg                     : [],
                            userRemoteConfigs                : [[url: "${gitUrl}"]]])

                    sh "chmod +x scripts/update_version.sh && chmod +x scripts/template.sh"
                    sh "version=${env.BRANCH_TEST} scripts/template.sh defaults/edge_config_template.yml > defaults/edge_config.yml"
                    sh "cat defaults/edge_config.yml"
                } else if ("${env.BRANCH_TEST}" != "master") {
                    echo "PLAYING BRANCH ${env.BRANCH_TEST}"
                    checkout([
                            $class                           : 'GitSCM',
                            branches                         : [[name: "${env.BRANCH_TEST}"]],
                            doGenerateSubmoduleConfigurations: false,
                            extensions                       : [],
                            submoduleCfg                     : [],
                            userRemoteConfigs                : [[url: "${gitUrl}"]]])

                    sh "chmod +x scripts/update_version.sh && chmod +x scripts/template.sh"
                    sh "version=${env.BRANCH_TEST} scripts/template.sh defaults/edge_config_template.yml > defaults/edge_config.yml"
                    sh "cat defaults/edge_config.yml"
                }
            } else if (userInput) {
                if ("${env.ENV_TEST}" == 'DEV') {
                    echo "DEV VRA platform is not myet iplemented. Please select 'PRD' or UAT' platform"
                    error("VRA platform not implemented")
                }
                if ("${env.BRANCH_TEST}" =~ /^([0-9]+)/) {
                    echo "Run playbook release ${env.BRANCH_TEST} on ${env.ENV_TEST} cloud platform"
                    checkout scm: [
                            $class           : 'GitSCM',
                            userRemoteConfigs: [[url: "${gitUrl}"]],
                            branches         : [[name: "tags/${env.BRANCH_TEST}"]]],
                            poll: false

                   } else if ("${env.BRANCH_TEST}" == "master") {
                    echo "PLAYING BRANCH ${env.BRANCH_TEST}"
                    checkout([
                            $class                           : 'GitSCM',
                            branches                         : [[name: "${env.BRANCH_TEST}"]],
                            doGenerateSubmoduleConfigurations: false,
                            extensions                       : [],
                            submoduleCfg                     : [],
                            userRemoteConfigs                : [[url: "${gitUrl}"]]])

                    sh "chmod +x scripts/update_version.sh && chmod +x scripts/template.sh"
                    sh "version=${env.BRANCH_TEST} scripts/template.sh defaults/edge_config_template.yml > defaults/edge_config.yml"
                    sh "cat defaults/edge_config.yml"
                } else if ("${env.BRANCH_TEST}" != "master") {
                    echo "PLAYING BRANCH ${env.BRANCH_TEST}"
                    checkout([
                            $class                           : 'GitSCM',
                            branches                         : [[name: "${env.BRANCH_TEST}"]],
                            doGenerateSubmoduleConfigurations: false,
                            extensions                       : [],
                            submoduleCfg                     : [],
                            userRemoteConfigs                : [[url: "${gitUrl}"]]])

                    sh "chmod +x scripts/update_version.sh && chmod +x scripts/template.sh"
                    sh "version=${env.BRANCH_TEST} scripts/template.sh defaults/edge_config_template.yml > defaults/edge_config.yml"
                    sh "cat defaults/edge_config.yml"
                }
            } else if (!userInput) {
                // Exit on failure
                echo "Run aborted"
                error("this build was aborted")
            } else {
                // Exit on failure
                echo "unknown problem"
                error("Something is going wrong")
            }
            sh "cd ${second_workspace}/tests/jenkins/ &&  chmod 777 runner.sh"
            sh "${behave_copy_tests}; ${behave_copy_extra_playbooks}; ${galaxy_install_requirements}; ${galaxy_install_extra_requirements}"
        }
        withCredentials([usernamePassword(credentialsId: 'edge_creds_test', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USER')]) {
            echo "INSTALL VIRTUALENV ON pedglx112"
            try {
                sh "${run_remote_command_on_pedglx112} rm -rf ./ccs_cd_celery/"
                sh "${run_remote_command_on_pedglx112} git --git-dir=./ccs_cd_celery/.git clone " +
                        "'https://${env.GIT_USER}:${env.GIT_PASSWORD}" +
                        "@sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/ccs_cd_celery.git'"
            } catch (err) {
               sh "${run_remote_command_on_pedglx112} rm -rf ./ccs_cd_celery/"
               sh "${run_remote_command_on_pedglx112} \"git config --global http.sslVerify false\""
            } finally {
                sh "${run_remote_command_on_pedglx112} rm -rf ./ccs_cd_celery/"
                sh "${run_remote_command_on_pedglx112} git --git-dir=./ccs_cd_celery/.git clone " +
                        "'https://${env.GIT_USER}:${env.GIT_PASSWORD}" +
                        "@sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/ccs_cd_celery.git'"
            }
            try {
                sh "${run_remote_command_on_pedglx112} \"cd ./ccs_cd_celery/ && ansible-galaxy install --force -r requirements.yml -p roles/ --ignore-errors && chmod +x install_virtualenv.sh && ./install_virtualenv.sh edgpadm /applis/edgp ${env.BRANCH_TEST}\""
            } catch (err) {
                error("Failed to install virtualenv on pedglx112")
                currentBuild.result = 'FAILURE'
            }
        }
    }*/
    if (userInput) {
        if ("${env.ENV_TEST}" == 'UAT') {
            echo "Setting UAT VRA environement"
            sh "${run_on_uat}"
        }
    }

    try {

        if ("${env.CENTOS_TEST}" == 'true') {
            tasks["CentOS VM - (PRD)"] = {
                stage("CentOS VM - (PRD) - Patrol") {
                    // sleep 30
                    sh "${behave_run}/${create_delete_centos}"
                }
            }
        }

        if ("${env.CENTOS_SQUID_TEST}" == 'true') {
            tasks["CentOS squid - (DEV)"] = {
                stage("CentOS squid - (DEV) - Zabbix") {
                    // sleep 60
                    sh "${behave_run}/${squid_installed_on_CentOS}"
                }
            }
        }

        if ("${env.RHEL_SQUID_TEST}" == 'true') {
            tasks["RHEL squid - (DEV)"] = {
                stage("RHEL squid - (DEV) - Zabbix") {
                    // sleep 90
                    sh "${behave_run}/${squid_installed_on_rhel}"
                }
            }
        }

        if ("${env.RHEL_POSTGRES_TEST}" == 'true') {
            tasks["RHEL postgresql - (DEV)"] = {
                stage("RHEL postgresql - (DEV) - Patrol") {
                    // sleep 120
                    sh "${behave_run}/${postgresql_installed_on_rhel}"
                }
            }
        }

        if ("${env.CENTOS_POSTGRES_TEST}" == 'true') {
            tasks["CentOS postgresql - (DEV)"] = {
                stage("CentOS postgresql - (DEV) - Zabbix") {
                    // sleep 150
                    sh "${behave_run}/${postgresql_installed_on_centos}"
                }
            }
        }

        if ("${env.RHEL_MKT_TEST}" == 'true') {
            tasks["RHEL VM in MKT - (DEV)"] = {
                stage("RHEL VM in MKT - (DEV) - Zabbix") {
                    node('pedglx112') {
                        sh "cd ${second_workspace} && ${behave_run}/${create_delete_rhel_mkt}"
                    }
                }
            }
        }

        if ("${env.CENTOS_MKT_TEST}" == 'true') {
            tasks["CENTOS VM in MKT - (PRD)"] = {
                stage("CENTOS VM in MKT - (PRD) - Patrol") {
                    node('pedglx112') {
                        sh "cd ${second_workspace} && ${behave_run}/${create_delete_centos_mkt}"
                    }
                }
            }
        }


        if ("${env.RHEL_TEST}" == 'true') {
            tasks["RHEL VM Tower - (PRD)"] = {
                stage("RHEL VM Tower - (PRD) - Patrol") {
                    node('pedglx112'){
                        try {
                            println "#################### VM CREATE ####################"
                            out = sh script: "cd ${second_workspace}/tests/jenkins && ./runner.sh create", returnStdout: true
                            jsonSluper = jsonParse(out)
                            jobStatus = jsonSluper["status"]
                            jobId = jsonSluper["job_id"]
                            if (jobStatus.trim() == "successful") {
                                println "vm create job ${jobId} successful.\nTower url: https://tower32.safe.socgen/#/jobs/${jobId}"
                            } else if (jobStatus.trim() == "failed") {
                                error()
                            }
                        } catch (err) {
                            println "build failed. you can find more details in: https://tower32.safe.socgen/#/jobs/${jobId}"
                            throw err
                        } finally {
                            println "#################### VM DELETE ####################"
                            out = sh script: "cd ${second_workspace}/tests/jenkins && ./runner.sh delete", returnStdout: true
                            jsonSluper = jsonParse(out)
                            jobStatus = jsonSluper["status"]
                            jobId = jsonSluper["job_id"]
                            if (jobStatus.trim() == "successful") {
                                println "vm delete job ${jobId} successful.\nTower url: https://tower32.safe.socgen/#/jobs/${jobId}"
                            } else if (jobStatus.trim() == "failed") {
                                error("vm delete failed. you can find more details in: https://tower32.safe.socgen/#/jobs/${jobId}")
                            }
                        }
                    }
                }
            }
        }

        parallel tasks

        def properties = readProperties  file: 'jenkins/tests_validations/job.properties'

        if ("${env.BRANCH_TEST}" == 'master' && "${properties.tag}" == 'true' ) {
            echo "All tests succeeded"
            currentBuild.result = 'SUCCESS'
            withCredentials([usernamePassword(credentialsId: 'edge_creds_test', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USER')]) {

                stage('Generate tag...') {
                    env.CONFIGURE_EDG = true
                    sh "git fetch --prune origin 'refs/tags/*:refs/tags/*' '+refs/heads/*:refs/remotes/origin/*'"
                    sh "current_version=\$(git tag -l | sort -V | tail -1 | cut -d/ -f3) && tested_version=\$(scripts/update_version.sh \$current_version ${properties.release_type}) && echo \"\$tested_version\" > files/current_version.txt && version=\$tested_version scripts/template.sh defaults/edge_config_template.yml > defaults/edge_config.yml"
                    sh "yes | cp -rf files/job.properties jenkins/tests_validations/job.properties"
                    sh "git add defaults/edge_config.yml"
                    sh "git add jenkins/tests_validations/job.properties"
                    sh 'git commit -am "update version in edge_config.yml"'
                    sh "git tag `head -n 1 files/current_version.txt`"
                    sh "git push 'https://${GIT_USER}:${GIT_PASSWORD}@${gitRepo}' HEAD:master `head -n 1 files/current_version.txt`"
                }
                if ("${properties.itsm_ticket}" != 'not_provided' && "${properties.deploy}" == 'true') {
                    //TODO: regex sur le numero change et verification de ce dernier via API ITSM quand elle sera implementee
                    stage('Deploy virtualenv of tag on edg platform') {
                        echo "CONFIGURING EDG PLATFORM"
                        def current_version = sh(script: "head -n 1 files/current_version.txt", returnStdout: true)
                        try {
                            sh "${run_remote_command} ${remove_ccs_cd_celery}"
                            sh "${run_remote_command} git --git-dir=/home/automation/ccs_cd_celery/.git clone " +
                                    "'https://${env.GIT_USER}:${env.GIT_PASSWORD}" +
                                    "@sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/ccs_cd_celery.git'"
                            sh "${run_remote_command_on_pedglx002} ${remove_ccs_cd_celery}"
                            sh "${run_remote_command_on_pedglx002} git --git-dir=/home/automation/ccs_cd_celery/.git clone " +
                                    "'https://${env.GIT_USER}:${env.GIT_PASSWORD}" +
                                    "@sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/ccs_cd_celery.git'"
                        } catch (err) {
                            sh "${run_remote_command} ${remove_ccs_cd_celery}"
                            sh "${run_remote_command} \"git config --global http.sslVerify false\""
                            sh "${run_remote_command_on_pedglx002} ${remove_ccs_cd_celery}"
                            sh "${run_remote_command_on_pedglx002} \"git config --global http.sslVerify false\""
                        } finally {
                            sh "${run_remote_command} ${remove_ccs_cd_celery}"
                            sh "${run_remote_command} git --git-dir=/home/automation/ccs_cd_celery/.git clone " +
                                    "'https://${env.GIT_USER}:${env.GIT_PASSWORD}" +
                                    "@sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/ccs_cd_celery.git'"
                            sh "${run_remote_command_on_pedglx002} ${remove_ccs_cd_celery}"
                            sh "${run_remote_command_on_pedglx002} git --git-dir=/home/automation/ccs_cd_celery/.git clone " +
                                    "'https://${env.GIT_USER}:${env.GIT_PASSWORD}" +
                                    "@sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/ccs_cd_celery.git'"
                        }
                        try {
                            sh "${run_remote_command} \"cd ./ccs_cd_celery/ && ansible-galaxy install --force -r requirements.yml -p roles/ && chmod +x install_virtualenv.sh && ./install_virtualenv.sh edghadm /applis/edgh ${current_version}\""
                            sh "${run_remote_command_on_pedglx002} \"cd ./ccs_cd_celery/ && ansible-galaxy install --force -r requirements.yml -p roles/ && chmod +x install_virtualenv.sh && ./install_virtualenv.sh edgpadm /applis/edgp ${current_version}\""
                            env.BUILD_MESSAGE = "${message_simple}. ${message_on_deploy} with change number " +
                                "${properties.itsm_ticket}"
                        } catch (err) {
                            error("Failed to configure EDG orchestrator platform")
                            currentBuild.result = 'FAILURE'
                        }
                    }
                }
            }
        }


         stage('Team Notification') {

            mail body: "${env.BUILD_MESSAGE}" +
                    "\n Build: ${env.BUILD_URL}",
                    from: 'service.bsc-sofa@socgen.com ',
                    mimeType: 'text/html',
                    subject: 'playbook_edge_vm build successful',
                    to: 'list.fr-ret-edge-automation@socgen.com'
                    //to: 'moez.selmi@socgen.com'
        }

    } catch (err) {
        currentBuild.result = "FAILURE"
        mail body: "playbook_edge_vm build error is here: ${env.BUILD_URL}",
                from: 'service.bsc-sofa@socgen.com ',
                mimeType: 'text/html',
                subject: 'playbook_edge_vm build failed',
                to: 'list.fr-ret-edge-automation@socgen.com'
                //to: 'moez.selmi@socgen.com'

        throw err
    }
}

@NonCPS
def jsonParse(def json) {
    new groovy.json.JsonSlurperClassic().parseText(json)
}

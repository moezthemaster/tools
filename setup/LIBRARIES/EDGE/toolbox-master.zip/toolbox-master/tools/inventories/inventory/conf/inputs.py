INPUTS_DATA = {

    "APP": {
        "code_irt": "A0464",
        "client": "GTS"
    },

    "XPL": {
        "code_irt": "A0500",
        "client": "GTS"
    },

    "AGA": {
        "code_irt": "A0660",
        "client": "ITIM"
    },

    "DTG": {
        "code_irt": "A1007",
        "client": "SGCIB"
    },

    "RCT": {
        "code_irt": "A1286",
        "client": "BSC"
    },

    "PTA": {
        "code_irt": "A1545",
        "client": "ITIM"
    },

    "IPJ": {
        "code_irt": "A1584",
        "client": "ITIM"
    },

    "IPK": {
        "code_irt": "A1584",
        "client": "ITIM"
    },

    "BTC": {
        "code_irt": "A1606",
        "client": "ITIM"
    },

    "CTX": {
        "code_irt": "A1606",
        "client": "ITIM"
    },

    "CXB": {
        "code_irt": "A1606",
        "client": "ITIM"
    },

    "GBO": {
        "code_irt": "A1606",
        "client": "ITIM"
    },

    "GPK": {
        "code_irt": "A1606",
        "client": "ITIM"
    },

    "KRT": {
        "code_irt": "A1606",
        "client": "ITIM"
    },

    "PRB": {
        "code_irt": "A1606",
        "client": "ITIM"
    },

    "SYK": {
        "code_irt": "A1606",
        "client": "ITIM"
    },

    "VPX": {
        "code_irt": "A1606",
        "client": "ITIM"
    },

    "DMQ": {
        "code_irt": "A1634",
        "client": "ITIM"
    },

    "MBE": {
        "code_irt": "A1638",
        "client": "ITIM"
    },

    "MBO": {
        "code_irt": "A1638",
        "client": "ITIM"
    },

    "SWM": {
        "code_irt": "A1638",
        "client": "ITIM"
    },

    "BAD": {
        "code_irt": "A1649",
        "client": "ITIM"
    },

    "IGK": {
        "code_irt": "A1669",
        "client": "ITIM"
    },

    "BRS": {
        "code_irt": "A1681",
        "client": "ITIM"
    },

    "BWD": {
        "code_irt": "A1681",
        "client": "ITIM"
    },

    "VFW": {
        "code_irt": "A1757",
        "client": "ITIM"
    },

    "SST": {
        "code_irt": "A1763",
        "client": "ITIM"
    },

    "PFI": {
        "code_irt": "A1833",
        "client": "ITIM"
    },

    "RCE": {
        "code_irt": "A1849",
        "client": "ITIM"
    },

    "ACV": {
        "code_irt": "A1865",
        "client": "ITIM"
    },

    "IDD": {
        "code_irt": "A1911",
        "client": "ITIM"
    },

    "SOP": {
        "code_irt": "A1911",
        "client": "ITIM"
    },

    "ASV": {
        "code_irt": "A1926",
        "client": "ITIM"
    },

    "GXE": {
        "code_irt": "A1929",
        "client": "ITIM"
    },

    "GXO": {
        "code_irt": "A1929",
        "client": "ITIM"
    },

    "CCW": {
        "code_irt": "A1933",
        "client": "ITIM"
    },

    "SBB": {
        "code_irt": "A1942",
        "client": "ITIM"
    },

    "NGO": {
        "code_irt": "A1956",
        "client": "ITIM"
    },

    "ABM": {
        "code_irt": "A1974",
        "client": "ITIM"
    },

    "CLD": {
        "code_irt": "A1975",
        "client": "ITIM"
    },

    "ICE": {
        "code_irt": "A1975",
        "client": "ITIM"
    },

    "JMF": {
        "code_irt": "A1975",
        "client": "ITIM"
    },

    "ILP": {
        "code_irt": "A1979",
        "client": "ITIM"
    },

    "AMD": {
        "code_irt": "A1982",
        "client": "ITIM"
    },

    "AMZ": {
        "code_irt": "A1982",
        "client": "ITIM"
    },

    "GBI": {
        "code_irt": "A1993",
        "client": "ITIM"
    },

    "GDB": {
        "code_irt": "A1993",
        "client": "ITIM"
    },

    "ARD": {
        "code_irt": "A2309",
        "client": "BSC"
    },

    "ERE": {
        "code_irt": "A2309",
        "client": "BSC"
    },

    "GGI": {
        "code_irt": "A2381",
        "client": "BSC"
    },

    "RFG": {
        "code_irt": "A2389",
        "client": "BSC"
    },

    "AFE": {
        "code_irt": "A2525",
        "client": "BSC"
    },

    "AFF": {
        "code_irt": "A2525",
        "client": "BSC"
    },

    "ELR": {
        "code_irt": "A2529",
        "client": "BSC"
    },

    "USL": {
        "code_irt": "A2534",
        "client": "BSC"
    },

    "SKA": {
        "code_irt": "A2616",
        "client": "BSC"
    },

    "MSL": {
        "code_irt": "A2676",
        "client": "BSC"
    },

    "GRB": {
        "code_irt": "A2689",
        "client": "BSC"
    },

    "TNU": {
        "code_irt": "A2689",
        "client": "BSC"
    },

    "DM0": {
        "code_irt": "A2690",
        "client": "BSC"
    },

    "DM8": {
        "code_irt": "A2690",
        "client": "BSC"
    },

    "WVE": {
        "code_irt": "A2718",
        "client": "BSC"
    },

    "AUR": {
        "code_irt": "A2719",
        "client": "BSC"
    },

    "DPT": {
        "code_irt": "A2742",
        "client": "BSC"
    },

    "SBX": {
        "code_irt": "A2742",
        "client": "BSC"
    },

    "SFA": {
        "code_irt": "A2742",
        "client": "BSC"
    },

    "BSC": {
        "code_irt": "A2744",
        "client": "BSC"
    },

    "TKN": {
        "code_irt": "A2752",
        "client": "BSC"
    },

    "JNK": {
        "code_irt": "A2760",
        "client": "BSC"
    },

    "CAO": {
        "code_irt": "A2767",
        "client": "BSC"
    },

    "RWS": {
        "code_irt": "A2767",
        "client": "BSC"
    },

    "AID": {
        "code_irt": "A2775",
        "client": "BSC"
    },

    "MRC": {
        "code_irt": "A2779",
        "client": "BSC"
    },

    "ECR": {
        "code_irt": "A2783",
        "client": "BSC"
    },

    "SLK": {
        "code_irt": "A2788",
        "client": "BSC"
    },

    "DWP": {
        "code_irt": "A2791",
        "client": "BSC"
    },

    "SNX": {
        "code_irt": "A2791",
        "client": "BSC"
    },

    "TFA": {
        "code_irt": "A2791",
        "client": "BSC"
    },

    "ADT": {
        "code_irt": "A2793",
        "client": "BSC"
    },

    "CBU": {
        "code_irt": "A2804",
        "client": "BSC"
    },

    "HMI": {
        "code_irt": "A2827",
        "client": "BSC"
    },

    "IFR": {
        "code_irt": "A2840",
        "client": "BSC"
    },

    "API": {
        "code_irt": "A2847",
        "client": "BSC"
    },

    "FSF": {
        "code_irt": "A2860",
        "client": "BSC"
    },

    "GPC": {
        "code_irt": "A2870",
        "client": "BSC"
    },

    "DHR": {
        "code_irt": "A2879",
        "client": "BSC"
    },

    "DEX": {
        "code_irt": "A2888",
        "client": "BSC"
    },

    "ORN": {
        "code_irt": "A2893",
        "client": "BSC"
    },

    "ELV": {
        "code_irt": "A2894",
        "client": "BSC"
    },

    "GLR": {
        "code_irt": "A2897",
        "client": "BSC"
    },

    "FCR": {
        "code_irt": "A2899",
        "client": "BSC"
    },

    "ANU": {
        "code_irt": "A2910",
        "client": "BSC"
    },

    "KRS": {
        "code_irt": "A2914",
        "client": "BSC"
    },

    "WEK": {
        "code_irt": "A2925",
        "client": "BSC"
    },

    "FIR": {
        "code_irt": "A2932",
        "client": "BSC"
    },

    "OCN": {
        "code_irt": "A2940",
        "client": "BSC"
    },

    "DAX": {
        "code_irt": "A2953",
        "client": "BSC"
    },

    "FLG": {
        "code_irt": "A2972",
        "client": "ITIM"
    },

    "MOB": {
        "code_irt": "A5042",
        "client": "ITIM"
    },

    "NGE": {
        "code_irt": "A5042",
        "client": "ITIM"
    },

    "SSB": {
        "code_irt": "A5042",
        "client": "ITIM"
    },

    "SSN": {
        "code_irt": "A5042",
        "client": "ITIM"
    },

    "SKM": {
        "code_irt": "A5064",
        "client": "ITIM"
    },

    "FRM": {
        "code_irt": "A5075",
        "client": "ITIM"
    },

    "EPB": {
        "code_irt": "A5080",
        "client": "ITIM"
    },

    "ICD": {
        "code_irt": "A5080",
        "client": "ITIM"
    },

    "IED": {
        "code_irt": "A5080",
        "client": "ITIM"
    },

    "KFC": {
        "code_irt": "A5080",
        "client": "ITIM"
    },

    "MNB": {
        "code_irt": "A5080",
        "client": "ITIM"
    },

    "DEP": {
        "code_irt": "A5092",
        "client": "ITIM"
    },

    "SYA": {
        "code_irt": "A5092",
        "client": "ITIM"
    },

    "FGE": {
        "code_irt": "A5112",
        "client": "ITIM"
    },

    "CCB": {
        "code_irt": "A5129",
        "client": "ITIM"
    },

    "CDW": {
        "code_irt": "A5129",
        "client": "ITIM"
    },

    "DGA": {
        "code_irt": "A5129",
        "client": "ITIM"
    },

    "DGS": {
        "code_irt": "A5129",
        "client": "ITIM"
    },

    "RBV": {
        "code_irt": "A5129",
        "client": "ITIM"
    },

    "VTX": {
        "code_irt": "A5129",
        "client": "ITIM"
    },

    "BPP": {
        "code_irt": "A5130",
        "client": "ITIM"
    },

    "BIB": {
        "code_irt": "A5131",
        "client": "SGCIB"
    },

    "MKB": {
        "code_irt": "A5132",
        "client": "ITIM"
    },

    "PAB": {
        "code_irt": "A5132",
        "client": "ITIM"
    },

    "PAD": {
        "code_irt": "A5132",
        "client": "ITIM"
    },

    "SNG": {
        "code_irt": "A5132",
        "client": "ITIM"
    },

    "FMR": {
        "code_irt": "A5137",
        "client": "ITIM"
    },

    "IST": {
        "code_irt": "A5138",
        "client": "ITIM"
    },

    "ITE": {
        "code_irt": "A5138",
        "client": "ITIM"
    },

    "BPD": {
        "code_irt": "A5139",
        "client": "ITIM"
    },

    "MWS": {
        "code_irt": "A5143",
        "client": "ITIM"
    },

    "OCI": {
        "code_irt": "A5156",
        "client": "ITIM"
    },

    "BVI": {
        "code_irt": "A5157",
        "client": "ITIM"
    },

    "PON": {
        "code_irt": "A5166",
        "client": "ITIM"
    },

    "BEC": {
        "code_irt": "A5168",
        "client": "ITIM"
    },

    "GLD": {
        "code_irt": "A5173",
        "client": "ITIM"
    },

    "ACD": {
        "code_irt": "A5175",
        "client": "ITIM"
    },

    "KIT": {
        "code_irt": "A5175",
        "client": "ITIM"
    },

    "GCN": {
        "code_irt": "A5176",
        "client": "ITIM"
    },

    "BQP": {
        "code_irt": "A5177",
        "client": "ITIM"
    },

    "RPR": {
        "code_irt": "A5179",
        "client": "ITIM"
    },

    "GPM": {
        "code_irt": "A5181",
        "client": "ITIM"
    },

    "CCL": {
        "code_irt": "A5183",
        "client": "ITIM"
    },

    "TOP": {
        "code_irt": "A5184",
        "client": "ITIM"
    },

    "VIZ": {
        "code_irt": "A5186",
        "client": "ITIM"
    },

    "OCP": {
        "code_irt": "A5189",
        "client": "ITIM"
    },

    "IMO": {
        "code_irt": "A5192",
        "client": "ITIM"
    },

    "JDD": {
        "code_irt": "A5193",
        "client": "ITIM"
    },

    "RCF": {
        "code_irt": "A5194",
        "client": "ITIM"
    },

    "BOP": {
        "code_irt": "A5196",
        "client": "ITIM"
    },

    "RED": {
        "code_irt": "A5199",
        "client": "ITIM"
    },

    "SRD": {
        "code_irt": "A5199",
        "client": "ITIM"
    },

    "SRR": {
        "code_irt": "A5199",
        "client": "ITIM"
    },

    "DTI": {
        "code_irt": "A5201",
        "client": "ITIM"
    },

    "DNC": {
        "code_irt": "A5208",
        "client": "ITIM"
    },

    "FDE": {
        "code_irt": "A5209",
        "client": "ITIM"
    },

    "PRS": {
        "code_irt": "A5220",
        "client": "ITIM"
    },

    "CDR": {
        "code_irt": "A5221",
        "client": "ITIM"
    },

    "PPR": {
        "code_irt": "A5225",
        "client": "ITIM"
    },

    "DRE": {
        "code_irt": "A5229",
        "client": "ITIM"
    },

    "DPI": {
        "code_irt": "A5233",
        "client": "ITIM"
    },

    "DPX": {
        "code_irt": "A5233",
        "client": "ITIM"
    },

    "NCI": {
        "code_irt": "A5234",
        "client": "ITIM"
    },

    "QID": {
        "code_irt": "A5237",
        "client": "ITIM"
    },

    "OBU": {
        "code_irt": "A5239",
        "client": "ITIM"
    },

    "OBV": {
        "code_irt": "A5239",
        "client": "ITIM"
    },

    "OBX": {
        "code_irt": "A5239",
        "client": "ITIM"
    },

    "RAI": {
        "code_irt": "A5254",
        "client": "ITIM"
    },

    "ACW": {
        "code_irt": "A5255",
        "client": "ITIM"
    },

    "CBO": {
        "code_irt": "A5256",
        "client": "ITIM"
    },

    "SKC": {
        "code_irt": "A5258",
        "client": "ITIM"
    },

    "IBF": {
        "code_irt": "A5261",
        "client": "ITIM"
    },

    "VPC": {
        "code_irt": "A5262",
        "client": "ITIM"
    },

    "BIR": {
        "code_irt": "A5266",
        "client": "ITIM"
    },

    "EER": {
        "code_irt": "A5266",
        "client": "ITIM"
    },

    "OER": {
        "code_irt": "A5266",
        "client": "ITIM"
    },

    "ESO": {
        "code_irt": "A5267",
        "client": "ITIM"
    },

    "MDC": {
        "code_irt": "A5268",
        "client": "ITIM"
    },

    "PIT": {
        "code_irt": "A5270",
        "client": "GTS"
    },

    "SLC": {
        "code_irt": "A5276",
        "client": "ITIM"
    },

    "EGC": {
        "code_irt": "A5279",
        "client": "ITIM"
    },

    "BER": {
        "code_irt": "A5280",
        "client": "ITIM"
    },

    "ECT": {
        "code_irt": "A5283",
        "client": "ITIM"
    },

    "ECY": {
        "code_irt": "A5283",
        "client": "ITIM"
    },

    "RKF": {
        "code_irt": "A5284",
        "client": "ITIM"
    },

    "CSN": {
        "code_irt": "A5286",
        "client": "ITIM"
    },

    "CSW": {
        "code_irt": "A5286",
        "client": "ITIM"
    },

    "EKO": {
        "code_irt": "A5290",
        "client": "ITIM"
    },

    "REE": {
        "code_irt": "A5292",
        "client": "ITIM"
    },

    "BFO": {
        "code_irt": "A5298",
        "client": "ITIM"
    },

    "FFB": {
        "code_irt": "A5318",
        "client": "ITIM"
    },

    "FFS": {
        "code_irt": "A5318",
        "client": "ITIM"
    },

    "CCG": {
        "code_irt": "A6866",
        "client": "BSC"
    },

    "EAA": {
        "code_irt": "A7011",
        "client": "GTS"
    },

    "EAF": {
        "code_irt": "A7011",
        "client": "GTS"
    },

    "EAT": {
        "code_irt": "A7011",
        "client": "GTS"
    },

    "BDD": {
        "code_irt": "A7036",
        "client": "ITIM"
    },

    "EAL": {
        "code_irt": "A7048",
        "client": "GTS"
    },

    "EAX": {
        "code_irt": "A7048",
        "client": "GTS"
    },

    "EDG": {
        "code_irt": "A7048",
        "client": "GTS"
    },

    "OTO": {
        "code_irt": "A7048",
        "client": "GTS"
    },

    "PGA": {
        "code_irt": "A7048",
        "client": "GTS"
    },

    "TRV": {
        "code_irt": "A7048",
        "client": "GTS"
    },

    "SPV": {
        "code_irt": "A7096",
        "client": "GTS"
    },

    "DKR": {
        "code_irt": "A7130",
        "client": "GTS"
    },

    "DPF": {
        "code_irt": "A7130",
        "client": "GTS"
    },

    "BEB": {
        "code_irt": "A7131",
        "client": "GTS"
    },

    "BHI": {
        "code_irt": "A7131",
        "client": "GTS"
    },

    "BHT": {
        "code_irt": "A7131",
        "client": "GTS"
    },

    "RTD": {
        "code_irt": "A7131",
        "client": "GTS"
    },

    "DNF": {
        "code_irt": "A7135",
        "client": "GTS"
    },

    "EVN": {
        "code_irt": "A7135",
        "client": "GTS"
    },

    "RAA": {
        "code_irt": "A7136",
        "client": "GTS"
    },

    "RMQ": {
        "code_irt": "A7136",
        "client": "GTS"
    },

    "AGL": {
        "code_irt": "A7205",
        "client": "ITIM"
    },

    "OGM": {
        "code_irt": "A8304",
        "client": "BSC"
    },

    "ALC": {
        "code_irt": "A8320",
        "client": "BSC"
    },

    "DRD": {
        "code_irt": "A8323",
        "client": "BSC"
    },

    "ODR": {
        "code_irt": "A8327",
        "client": "BSC"
    },

    "MSI": {
        "code_irt": "A8328",
        "client": "BSC"
    },

    "STN": {
        "code_irt": "A8329",
        "client": "BSC"
    },

    "FBK": {
        "code_irt": "A8331",
        "client": "BSC"
    },

    "SRO": {
        "code_irt": "A8332",
        "client": "BSC"
    },

    "DGO": {
        "code_irt": "A8334",
        "client": "BSC"
    },

    "CFS": {
        "code_irt": "A8336",
        "client": "BSC"
    },

    "CPL": {
        "code_irt": "A8342",
        "client": "BSC"
    },

    "MYC": {
        "code_irt": "A8342",
        "client": "BSC"
    },

    "RDL": {
        "code_irt": "A8346",
        "client": "BSC"
    },

    "DFC": {
        "code_irt": "A8361",
        "client": "BSC"
    },

    "FTT": {
        "code_irt": "A8363",
        "client": "BSC"
    },

    "PPE": {
        "code_irt": "A8369",
        "client": "BSC"
    },

    "RAM": {
        "code_irt": "A8396",
        "client": "BSC"
    },

    "OAR": {
        "code_irt": "A8403",
        "client": "BSC"
    },

    "PIG": {
        "code_irt": "A8423",
        "client": "BSC"
    },

    "CTL": {
        "code_irt": "A8441",
        "client": "BSC"
    },

    "FOD": {
        "code_irt": "A8446",
        "client": "BSC"
    },

    "AER": {
        "code_irt": "A8447",
        "client": "BSC"
    },

    "NOA": {
        "code_irt": "A8448",
        "client": "BSC"
    },

    "MKP": {
        "code_irt": "A8457",
        "client": "BSC"
    },

    "YIP": {
        "code_irt": "AF029",
        "client": "BSC"
    },

    "RVC": {
        "code_irt": "AN202",
        "client": "ITIM"
    },

    "IGP": {
        "code_irt": "AN218",
        "client": "ITIM"
    },

    "SCO": {
        "code_irt": "AN248",
        "client": "ITIM"
    },

    "SPT": {
        "code_irt": "AN263",
        "client": "ITIM"
    },

    "SPW": {
        "code_irt": "AN263",
        "client": "ITIM"
    },

    "IDG": {
        "code_irt": "AN317",
        "client": "ITIM"
    },

    "BCC": {
        "code_irt": "AN336",
        "client": "ITIM"
    },

    "WGR": {
        "code_irt": "AN336",
        "client": "ITIM"
    },

    "BRM": {
        "code_irt": "AN355",
        "client": "ITIM"
    },

    "IAO": {
        "code_irt": "AN361",
        "client": "ITIM"
    },

    "BFP": {
        "code_irt": "AN376",
        "client": "ITIM"
    },

    "PKE": {
        "code_irt": "AN377",
        "client": "ITIM"
    },

    "GCX": {
        "code_irt": "AN380",
        "client": "ITIM"
    },

    "MNC": {
        "code_irt": "AN386",
        "client": "ITIM"
    },

    "DCD": {
        "code_irt": "AN389",
        "client": "ITIM"
    },

    "DMN": {
        "code_irt": "AN389",
        "client": "ITIM"
    },

    "OMN": {
        "code_irt": "AN389",
        "client": "ITIM"
    },

    "RDS": {
        "code_irt": "AN391",
        "client": "ITIM"
    },

    "ICA": {
        "code_irt": "AN397",
        "client": "ITIM"
    },

    "ICW": {
        "code_irt": "AN397",
        "client": "ITIM"
    },

    "NQL": {
        "code_irt": "AN397",
        "client": "ITIM"
    },

    "OAC": {
        "code_irt": "AN397",
        "client": "ITIM"
    },

    "OII": {
        "code_irt": "AN397",
        "client": "ITIM"
    },

    "OPI": {
        "code_irt": "AN397",
        "client": "ITIM"
    },

    "OSB": {
        "code_irt": "AN397",
        "client": "ITIM"
    },

    "ZBT": {
        "code_irt": "AN397",
        "client": "ITIM"
    },

    "ZCD": {
        "code_irt": "AN397",
        "client": "ITIM"
    },

    "ZCL": {
        "code_irt": "AN397",
        "client": "ITIM"
    },

    "ZCM": {
        "code_irt": "AN397",
        "client": "ITIM"
    },

    "ZDM": {
        "code_irt": "AN397",
        "client": "ITIM"
    },

    "ZVO": {
        "code_irt": "AN397",
        "client": "ITIM"
    },

    "MPS": {
        "code_irt": "AN400",
        "client": "ITIM"
    },

    "ERP": {
        "code_irt": "AN404",
        "client": "ITIM"
    },

    "DOT": {
        "code_irt": "AN405",
        "client": "ITIM"
    },

    "POD": {
        "code_irt": "AN405",
        "client": "ITIM"
    },

    "TSI": {
        "code_irt": "AN410",
        "client": "ITIM"
    },

    "LCI": {
        "code_irt": "AN411",
        "client": "ITIM"
    },

    "DFR": {
        "code_irt": "AN413",
        "client": "ITIM"
    },

    "DPM": {
        "code_irt": "AN414",
        "client": "ITIM"
    },

    "MND": {
        "code_irt": "AN414",
        "client": "ITIM"
    },

    "BND": {
        "code_irt": "AN416",
        "client": "ITIM"
    },

    "GWL": {
        "code_irt": "AN421",
        "client": "ITIM"
    },

    "WAH": {
        "code_irt": "AN424",
        "client": "ITIM"
    },

    "RDO": {
        "code_irt": "AN425",
        "client": "ITIM"
    },

    "CNS": {
        "code_irt": "AN426",
        "client": "ITIM"
    },

    "PEC": {
        "code_irt": "AN427",
        "client": "ITIM"
    },

    "WSX": {
        "code_irt": "AN428",
        "client": "ITIM"
    },

    "WSY": {
        "code_irt": "AN428",
        "client": "ITIM"
    },

    "WSZ": {
        "code_irt": "AN428",
        "client": "ITIM"
    },

    "WXS": {
        "code_irt": "AN428",
        "client": "ITIM"
    },

    "ERM": {
        "code_irt": "AN429",
        "client": "ITIM"
    },

    "WXB": {
        "code_irt": "AN429",
        "client": "ITIM"
    },

    "WXE": {
        "code_irt": "AN429",
        "client": "ITIM"
    },

    "WXP": {
        "code_irt": "AN429",
        "client": "ITIM"
    },

    "WSA": {
        "code_irt": "AN430",
        "client": "ITIM"
    },

    "WSJ": {
        "code_irt": "AN430",
        "client": "ITIM"
    },

    "WXY": {
        "code_irt": "AN430",
        "client": "ITIM"
    },

    "WSK": {
        "code_irt": "AN431",
        "client": "ITIM"
    },

    "WSD": {
        "code_irt": "AN434",
        "client": "ITIM"
    },

    "WXT": {
        "code_irt": "AN434",
        "client": "ITIM"
    },

    "WSB": {
        "code_irt": "AN435",
        "client": "ITIM"
    },

    "WSL": {
        "code_irt": "AN437",
        "client": "ITIM"
    },

    "WXR": {
        "code_irt": "AN437",
        "client": "ITIM"
    },

    "IMD": {
        "code_irt": "AN438",
        "client": "ITIM"
    },

    "VCE": {
        "code_irt": "AN440",
        "client": "ITIM"
    },

    "VIA": {
        "code_irt": "AN442",
        "client": "ITIM"
    },

    "OXC": {
        "code_irt": "AN444",
        "client": "ITIM"
    },

    "APU": {
        "code_irt": "AN446",
        "client": "ITIM"
    },

    "RVP": {
        "code_irt": "AN447",
        "client": "ITIM"
    },

    "ALS": {
        "code_irt": "AN448",
        "client": "ITIM"
    },

    "ZAL": {
        "code_irt": "AN448",
        "client": "ITIM"
    },

    "ZCO": {
        "code_irt": "AN482",
        "client": "ITIM"
    },

    "XOP": {
        "code_irt": "AN483",
        "client": "ITIM"
    },

    "ZOP": {
        "code_irt": "AN483",
        "client": "ITIM"
    },

    "DBC": {
        "code_irt": "AN484",
        "client": "ITIM"
    },

    "GCD": {
        "code_irt": "AN485",
        "client": "ITIM"
    },

    "BDL": {
        "code_irt": "AN486",
        "client": "ITIM"
    },

    "DBD": {
        "code_irt": "AN486",
        "client": "ITIM"
    },

    "DBE": {
        "code_irt": "AN486",
        "client": "ITIM"
    },

    "DED": {
        "code_irt": "AN488",
        "client": "ITIM"
    },

    "LVC": {
        "code_irt": "AN489",
        "client": "ITIM"
    },

    "BUD": {
        "code_irt": "AN491",
        "client": "ITIM"
    },

    "ICC": {
        "code_irt": "AN492",
        "client": "ITIM"
    },

    "ITV": {
        "code_irt": "AN493",
        "client": "ITIM"
    },

    "ITJ": {
        "code_irt": "AN494",
        "client": "ITIM"
    },

    "DAC": {
        "code_irt": "AN495",
        "client": "ITIM"
    },

    "WCA": {
        "code_irt": "AN496",
        "client": "ITIM"
    },

    "WCB": {
        "code_irt": "AN496",
        "client": "ITIM"
    },

    "ZAP": {
        "code_irt": "AN497",
        "client": "ITIM"
    },

    "WGE": {
        "code_irt": "AN644",
        "client": "ITIM"
    },

    "WEM": {
        "code_irt": "AN683",
        "client": "ITIM"
    },

    "SFD": {
        "code_irt": "AN843",
        "client": "ITIM"
    },

    "WSH": {
        "code_irt": "AN937",
        "client": "ITIM"
    },

    "WFB": {
        "code_irt": "AN938",
        "client": "ITIM"
    },

    "FPI": {
        "code_irt": "AN939",
        "client": "ITIM"
    },

    "WXQ": {
        "code_irt": "AN940",
        "client": "ITIM"
    },

    "CIB": {
        "code_irt": "AN942",
        "client": "ITIM"
    },

    "WCD": {
        "code_irt": "AN944",
        "client": "ITIM"
    },

    "NTS": {
        "code_irt": "AN952",
        "client": "ITIM"
    },

    "PMA": {
        "code_irt": "AR001",
        "client": "ITIM"
    },

    "SML": {
        "code_irt": "AR019",
        "client": "ITIM"
    },

    "HAD": {
        "code_irt": "AR026",
        "client": "GTS"
    },

    "SDO": {
        "code_irt": "AS013",
        "client": "ITIM"
    },

    "VOR": {
        "code_irt": "AS015",
        "client": "ITIM"
    },

    "EVP": {
        "code_irt": "AS017",
        "client": "ITIM"
    },

    "APL": {
        "code_irt": "NRINF",
        "client": "GTS"
    },

    "DAP": {
        "code_irt": "NRINF",
        "client": "GTS"
    },

    "MFA": {
        "code_irt": "NRINF",
        "client": "GTS"
    },

    "OGP": {
        "code_irt": "NRINF",
        "client": "GTS"
    },
}

FAKE_DATA = {
    'vm_os': 'CENTOS_7.5_x64-RET-EDGE',
    'vm_profile': 'Micro 1vCPU-1GB',
    'code_irt': 'A7048',
    'endClient': 'GTS',
    'app_env': 'DEV',
    'disk_size': '20',
    'vm_backup': 'none'
}

dodaw
===============================
[![Build Status](https://itbox-jenkins-gts.fr.world.socgen/job/EdgeAPI/job/py_edge_libraries/job/dodaw/job/master/badge/icon)](https://itbox-jenkins-gts.fr.world.socgen/job/EdgeAPI/job/py_edge_libraries/job/dodaw/job/master/)
[![Quality Gate](https://itbox-sonar.fr.world.socgen/sonar/api/badges/gate?key=GTS-RET-AUTOMATION-EDGE:dodaw)](https://itbox-sonar.fr.world.socgen/sonar/dashboard/index/GTS-RET-AUTOMATION-EDGE:dodaw)


Description
-----------
dod api wrapper


Examples
--------

import pytest

def pytest_addoption(parser):
    parser.addoption("--hostname", action="store", default='dpgalxtestwhats49')
    parser.addoption("--ip", action="store", default='1.5.95.2')


@pytest.fixture
def HOSTNAME(request):
    return request.config.getoption("--hostname")


@pytest.fixture
def IP_ADDRESS(request):
    return request.config.getoption("--ip")

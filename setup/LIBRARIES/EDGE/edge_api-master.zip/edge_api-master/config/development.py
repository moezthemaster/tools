import os

_basedir = os.path.abspath(os.path.dirname(__file__))

SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(_basedir, '{{db_path}}')
SQLALCHEMY_TRACK_MODIFICATIONS = True

DEBUG = False
TRAP_HTTP_EXCEPTIONS = True
ERROR_404_HELP = True
BUNDLE_ERRORS = True

SWAGGER_UI_OAUTH_CLIENT_ID = '{{swagger_ui_oauth_client_id}}'
SWAGGER_UI_OAUTH_REALM = '{{swagger_ui_oauth_realm}}'
SWAGGER_UI_OAUTH_APP_NAME = '{{swagger_ui_app_name}}'

DL_LOGGER_CONFFILE = os.path.join(_basedir, '{{dev_logger_conffile}}')

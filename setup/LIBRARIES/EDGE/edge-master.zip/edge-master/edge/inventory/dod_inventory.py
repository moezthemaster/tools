#!/usr/bin/python
# -*- coding: utf-8 -*-
#

DOCUMENTATION = '''


'''

EXAMPLES = '''

'''

import logging
import edge.interfaces
try:
    from sets import Set
except ImportError:
    pass
from edge.conf import settings

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.getLevelName(settings.LOGGER_LEVEL))
DNS_SERVICE = 'PRD2 France RET'


class Extractor(edge.interfaces.Dod):

    def search_DoD(self, record_type, trigram="", env="d", ip_list=[]):
        logger.info("search_DoD_inventory")
        results = []
        if trigram:
            logger.info("create hostname")
            hostname = "^{}{}lx".format(env, trigram)
            logger.info("record_type: {} , hostname: {}".
                        format(record_type, hostname))
            results = self.search_dns_record(record_type,
                                            dns_service=DNS_SERVICE,
                                            hostname=hostname,
                                            view='production')
            logger.debug("Got {} result in DoD request".format(len(results)))
        elif ip_list:
            logger.info("get_DoD_inventory_from_ip")
            for ip in ip_list:
                ip_str = "^{}$".format(ip)
                result = self.search_dns_record(record_type,
                                                dns_service=DNS_SERVICE,
                                                ip=ip_str,
                                                view='production')
                if result:
                    results.append(result)
            logger.debug("Got {} result in DoD request".format(len(results)))
        return results

    def check_dns_entries(self, hostname, ip, dod_inventory):
        """
        [description]
            get errors report per ip and hostname
        Returns:
            List of errors, an error is a string
        """
        try:
            set()
        except Exception:
            raise
        try:
            dod_types = set(["A", "PTR", "CNAME"])
            dod_reverse_types = set(["A", "PTR"])
        except:

            dod_types = Set(["A", "PTR", "CNAME"])
            dod_reverse_types = Set(["A", "PTR"])
        errors = []
        records_hostname = [record for record in dod_inventory
                            if record["hostname"] == hostname or
                            record["alias"] == hostname]
        if len(records_hostname) < 3:
            records_types = [t["type"] for t in records_hostname]
            try:
                missing_types = dod_types - set(records_types)
            except:
                missing_types = dod_types - Set(records_types)
            errors.append("{}: Missing records {} in dns for hostname.".format(
                hostname, ", ".join(missing_types)))
        if len(records_hostname) > 3:
            records_types = [t["type"] for t in records_hostname]
            errors.append("{}: too many records in dns {} ".format(
                hostname, ", ".join(records_types)))
        for record in records_hostname:
            if record["ip"] != ip and record["type"] != "CNAME":
                errors.append("{}: ip {} does not match dns record {} id = {}"
                              .format(
                                  hostname, ip, record["ip"], record["id"]))

        records_ip = [record for record in dod_inventory if record["ip"] == ip]
        if len(records_ip) < 2:
            records_types = [t["type"] for t in records_ip]
            try:
                missing_types = dod_reverse_types - set(records_types)
            except:
                missing_types = dod_reverse_types - Set(records_types)
            errors.append("{}: Missing records {} in dns for IP.".format(
                hostname, ", ".join(missing_types)))
        if len(records_ip) > 2:
            records_types = [t["type"] for t in records_hostname]
            errors.append("{}: too many records in dns {}".format(
                hostname, ", ".join(records_types)))
        for record in records_ip:
            if record["hostname"] != hostname:
                errors.append(
                    "{}: hostname does not match dns record {}. id = {}"
                    .format(hostname, record["hostname"], record["id"]))
        return errors

Role Patrol_jboss
=========

Monitor a jboss using the Patrol Agent.

This role is an applicative monitoring role

If no action is specified when calling this role, it will execute the following action :

**create.yml** : Installing the KM files needed by the Patrol Agent


Here's a description of the other task that can be executed in this role, filling the *patrol_action* with the name of the task requested :

**configure.yml** : Configuring Patrol Agent to monitore jboss

* Starting Patrol Agent
* Sending system stantard monitoring configuration for jboss to Patrol Agent
* Restarting the Patrol Agent


**delete.yml** : Removing the jboss monitoring from Patrol Agent

* Removing jboss monitoring from Patrol agent


This role is developped for **FastIT & PAAP projects**. Some updates may have to be done for other needs : contact us :email: list.fr-ret-edge-automation@socgen.com, or Fork it.

# Installation

```
ansible-galaxy install git+https://sgithub.fr.world.socgen/GTS-MFI-COMPOSANTS-EDGE/role_supervision_jboss.git,1.1.0 -p roles -f
```

This above command will install role_supervision_jboss with its dependencies in the specified folder roles of current folder
Requirements
------------

Facts gathering shouldn't be disabled.

Target servers must be Linux.

Patrol Agent should be install and add to the monitoring infra.

You must create an ansible.cfg file on same folder with the playbook which will be launched.

libray is the location ansible looks to find modules for role_supervision_jboss.

  ```
    [defaults]
    library        = ./roles/edge_ansible_modules/files
  ```
edge_ansible_modules is one of dependencies for role_supervision_mongodb. he contains modules that edge_ansible_modules looks for its operation


NOTE: This role can only be executed through A4C or Ansible Tower platform.


Role Variables
--------------

Here are the requested values for each action :

**create.yml**


**configure.yml**

- `pat_label : label of the jboss  (ie. hostname_Port)`
- `pat_username : username of jboss`
- `pat_password : password of jboss`
- `pat_javahome : the java home directory of jboss`
- `pat_jbosshome : the jboss home directory`
- `pat_port : Port JMX of the jboss server`
- `pat_ear : activation of EARs supervision on a supervised JBoss (default is false)`


**delete.yml**


Dependencies
------------

None

Example Playbook
----------------


      - hosts: server_to_monitore
        gather_facts: yes
        roles:     
           - { role: role_patrol_jboss,
                 patrol_action: "create",
             }
            - { role: role_patrol_jboss,
                   patrol_action: "configure",
                   pat_label: "localhost_9999",
                   pat_username: "jbossadmin",
                   pat_password: "jbosspasswd",
                   pat_javahome: "/home/java",
                   pat_jbosshome: "/home/jboss",
                   pat_port:"9999"
              }



Generated Alarms
----------------


    host      |objectClass    |object       |parameter    |parameterValue     |message  
    *         |PJB_ENVIRONMENT    |*    |CollectionStatus     |*    |[JBOSS] Operation of the Patrol collector for JBoss of the server %mc_object% is abnormal
    *       |PJB_JVM_OS       |*    |ProcessCpuUtilization    |*    |[JBOSS] CPU overconsumption of the JVM %mc_object% (%mc_parameter_value% \%)
    *       |PJB_MEMORY       |*    |MemoryUtilizationPercent |*    |[JBOSS] Memory overconsumption of the JVM %mc_object% (%mc_parameter_value% \%)
    *       |PJB_MEMORY_POOL    |*    |UsageUtilization     |*    |[JBOSS] Memory overconsumption of the JBOSS Pool %mc_object% (%mc_parameter_value% \%)
    *       |PJB_JBOSS_DOMAIN   |*    |ServerStatus       |*    |[JBOSS] Impossible connection to the Jboss domaine %mc_object%
    *       |PJB_SERVER       |*    |ServerStatus       |*    |[JBOSS] Impossible connection to the Jboss server %mc_object% | -



Default Thresholds
-----------------

| CLASS       | Parametre  | Unité   | Homo     | Prod              | 
|:-----------:|:----------:|:-------:|:--------:|:-----------------:|
| PJB_JVM_OS  | ProcessCpuUtilization   | %  | 80 to 90 :Warn after 20 min </br> > 90 :Alarm after 20 min | 80 to 90 :Warn after 20 min </br> > 90 :Alarm after 20 min |
| PJB_MEMORY       | MemoryUtilizationPercent | % | 80 to 90 :Warn after 20 min </br> > 90 :Alarm after 20 min | 80 to 90 :Warn after 20 min </br> > 90 :Alarm after 20 min |  
| ~~PJB_MEMORY_POOL~~  | ~~UsageUtilization~~ | ~~%~~ | ~~80 to 90 :Warn after 20 min~~ </br> ~~> 90 :Alarm after 20 min~~ | ~~80 to 90 :Warn after 20 min~~ </br> ~~> 90 :Alarm after 20 min~~ |
| PJB_JBOSS_DOMAIN | ServerStatus  | 0=RUNNING</br>1=STOPPED  | ≠ 0 :Alarm after 5 min  | > 0 :Alarm after 5 min | 
| PJB_SERVER | ServerStatus | 0=RUNNING</br>1=STOPPED | ≠ 0 :Alarm after 5 min   | > 0 :Alarm after 5 min |


Troubleshooting
---------------

In case of troubleshooting or for more information, you contact the Feature Team EDGE :email: list.fr-ret-edge-automation@socgen.com


Author Information
------------------

Yanis BEKRAR

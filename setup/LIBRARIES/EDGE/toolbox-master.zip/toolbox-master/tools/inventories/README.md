---

Le script << inventaire.py >> permet de récupérer les informations des différents inventaires : 

- SgCloud
- DNS
- Whats
- Marley

Le script << inventaire.py >> permet de vérifier les incohérences suivantes :

- Récupérer, pour un tigramme donné, les VM qui sont dans le SG Cloud d'UAT et de PROD ;
- Récupérer les entrées DNS, pour un trigramme donné, ainsi que pour les hostnames et ip identifiés à l'étape précedente ;
- Vérifier la cohérence des entrées (A, PTR, CNAME) dans le DNS ;
- Vérifier la liste des VM dans Marley inventoriées, ainsi que celles du trigramme;
- Vérifier les entrées Whats pour chacun des hostnames et ips rencontrées lors des étapes précédentes
- Tester si un serveur est up

-------------------
Comment ça marche ?
-------------------

Le script s'execute quotidiennement grace à un cron crée sur la VM **peaalx21**. Il tourne pendant 3h au cours de la semaine, et 5h pendant le weekend

Le code est deployé sur le chemin suivant:
/applis/pgapadm/TeamEdge/toolbox

Pour visualiser le cron: crontab -l

Attention : l'utilisation du script en sandbox peut remonter des résultats incorrects dûs principalement au blocage de l'accès à certains réseaux
Il est préconisé de lancer le script depuis un serveur qui à accès à l'ensemble des zones

------------
Pré-requis :
------------
Le script d'inventaire utilise le module logzero, ainsi que les librairies d'accès au référentiels mises à disposition par la FT Edge. Celle-ci peuvent être installée avec pip, ou en clonant les repos correspondants pour faciliter les correctifs en mode developpement.

----------------------
Installer les dépendances listées dans requirements.txt:

```shell
pip install --user -r requirements.txt
```

#### Si ERREUR : Could not find a version that satisfies the requirement requirements.txt (from versions: ) No matching distribution found for requirements.txt"

alors: (c'est que vos dépendances sont déjà installées mais faut les mettre à jour)

```shell
pip install --user --upgrade -r requirements.txt
```

Le fichier /etc/ansible/gts_edge.cfg doit être présent sur la machine:

------------------
Mode Développeur :
------------------

----------------------
Créer un répertoire libs dans inventories, puis y cloner les différentes librairies:

```shell
mkdir -p libs; cd libs
git clone https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge
git clone https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/dodaw
git clone https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/cloudaw
git clone https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/incubaw
git clone https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/whatsaw

cd ..
. ./set_lib_path.sh

```

Vous pouvez alors créer des branches dans les différents repo pour y faire vos modifications et tester en direct sans devoir faire de push dans les repo

#### Si ERREUR : Could not find a version that satisfies the requirement requirements.txt (from versions: ) No matching distribution found for requirements.txt"

alors: (c'est que vos dépendances sont déjà installées mais faut les mettre à jour)

```shell
pip install --user --upgrade -r requirements.txt
```

Le fichier /etc/ansible/gts_edge.cfg doit être présent sur la machine :


----------------------
Execution du script :
----------------------
```
usage: inventaire.py [-h] [-v] [--version] [-c] [-d] [-m] [-w]
                     [--no_uat | --no_prod]
                     trigram

positional arguments:
  trigram               The trigram to inventory

optional arguments:
  -h, --help            show this help message and exit
  -v, --verbose         Verbosity (-v, -vv, etc)
  --version             show program's version number and exit
  -c, --cloud-inventory
                        Output cloud inventory
  -d, --dns_inventory   Output DNS inventory
  -m, --marley_inventory
                        Output Marley inventory
  -w, --whats_inventory
                        Output Whats inventory
  --no_uat              Skip calls to UAT VRA
  --no_prod             Skip calls to PROD VRA

```
----------------------
# solution en cas d'erreur :
----------------------
si "/usr/lib/python2.7/site-packages/urllib3/connection.py:344: SubjectAltNameWarning: Certificate for puidlx211.iru-p-2.dns20.socgen has no `subjectAltName`, falling back to check for a `commonName` for now. This feature is being removed by major browsers and deprecated by RFC 2818. (See https://github.com/shazow/urllib3/issues/497 for details.)
  SubjectAltNameWarning"
  
Solution : exécuter l'inventaire en ignorant les Warnings avec l'option **-W ignore** :

python -W ignore inventaire.py trigram


-------------------------
Automatisation et scripts
-------------------------

L'appel du script d'inventaire est automatisé pour tourner chaque soir (22h-01h en semaine, 20h-01h le week-end) et traite les trigrammes en boucle en commencant par le plus ancien.
Ceci est traité par le script shell run_nightly_inventory.sh qui prend en paramètre la durée du traitement en seconde

Le script en lui-même se base sur les fichiers disponibles dans le répertoire logs. Dans ce répertoire se trouvent :

trig.log : fichier du dernier inventaire du trigramme trig
trig.err : fichier d'erreurs du dernier inventaire pour le trigramme
trig.log.backup : sauvegarde de l'inventaire précédent
output.txt : fichier de log du run_nightly_inventory.sh

Pour ajouter un trigramme dans l'inventaire, il suffit donc de créer le fichier .log correspondant. Example pour ajouter le trigramme 'pga':

    touch -t 197001010000 logs/pga.log

de même si vous souhaitez prioriser un trigramme dans le run du soir, vous pouvez modifier la date du fichier log avec cette même commande afin qu'il soit traité en premier 

Différents scripts sont mis à disposition pour l'extraction de incohérence vra et DNS :

extract_vra_orphans.sh : Extrait la liste des VM orphelines (i.e. qui n'ont pas d'entrée DNS)

extract_dns_issues.sh : Extrait les problèmes détectés au niveau des entrées DNS

filter_logs.sh : Explose les fichiers de logs en fonction des client, et génère des fichiers distincts pour les inventaires vra, dns, whats, marley, ainsi qu'un fichier qui reprend les incohérences
 

----------------------
TO DO :
----------------------
+ Utiliser le fichier requirements du playbook_edge_vm pour les installations des prérequis
+ Permettre la vérification d'une machine unique par hostname ou ip

-------------------------
Rattrapage de l'écart SgCloud vs Marley
-------------------------

Le script rematche_marley.py permet de rattraper l'écart entre sg_cloud et marley pour un trigramme donné. Si une VM existe dans Vra et pas dans marley, le script crée l'asset. Il le supprime dans le cas contraire.
pour lancer le script, il faut suivre les memes étapes pour le lancement du script d'inventaire.

```shell
python rematche_marley.py trigram
```

Pour lancer sur plusieurs trigrams en paralléle, modifier le fichier run_rematche.sh en passant la liste des trigramms que vous voulez nettoyer, puis lancer le script:
```shell
./run_rematche.sh
```
La log sera généré dans un /tmp/log/trigram
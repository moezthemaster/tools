
import time

from ccs_celery.abstract import TaskServiceManager
from ccs_celery.services.rollback import RollBackMixins
from ccs_celery.services._whats.module import whats_module, whats_client_module


class WhatsTask(TaskServiceManager, RollBackMixins):

    def __init__(self, data):
        super().__init__("Whats", data)

    def on_failure(self, exc, kwargs, excinfo):
        try:
            self.rollback()
        except Exception as err:
            self.logger.error("Rollback for {} module has failded".format(str(err)))
        finally:
            self.data.services[self._task_name]["finished_at"] = time.time()
            self.data.services[self._task_name]["status"] = "FAILED"
            self.data.services[self._task_name]["exception_class"] = str(type(exc))
            self.data.services[self._task_name]["exception_msg"] = str(exc)
            self.data.services[self._task_name]["exception_traceback"] = str(excinfo)

    def on_success(self, result, kwargs):
        self.data.services[self._task_name]["finished_at"] = time.time()
        self.data.services[self._task_name]["status"] = "SUCCESS"
        self.data.services[self._task_name]["return_value"] = result

    def _set_up(self):
        self.data.services[self._task_name] = {
            "changed": False,
            "launch_at": time.time(),
            "service_kwargs": {}
        }
        self.data.services[self._task_name]["service_kwargs"]["whats_hostname"] = self.data.shared_data["vm_hostname"]
        self.data.services[self._task_name]["service_kwargs"]["whats_ip"] = self.data.shared_data["vm_ip"]
        self.data.services[self._task_name]["service_kwargs"]["whats_trigram"] = self.data.shared_data["app_id"]
        self.data.services[self._task_name]["service_kwargs"]["state"] = self.data.shared_data["state"]

    def task(self):
        self._set_up()
        self.logger.info("Invoke {} module with kwargs={}".format(
            self._task_name,
            self.data.services[self._task_name]["service_kwargs"])
        )
        result = whats_module(**self.data.services[self._task_name]["service_kwargs"])
        if self.data.shared_data["state"] in ("present", "absent"):
            self.data.services[self._task_name]["rollback_kwargs"] = dict(
                state=self.nor_state(self.data.shared_data["state"]),
                **{x: self.data.services[self._task_name]["service_kwargs"][x] \
                   for x in self.data.services[self._task_name]["service_kwargs"].keys() if x != "state"}
            )
        self.data.services[self._task_name]["changed"] = result[0]
        if self.data.shared_data["state"] == "present":
            self.data.shared_data["idm_realm"] = result[1]["idm_realm"]
            self.data.shared_data["idm_domain"] = result[1]["idm_domain"]
        return result


class WhatsInfosTask(TaskServiceManager, RollBackMixins):

    def __init__(self, data):
        super().__init__("WhatsInfos", data)

    def on_failure(self, exc, kwargs, excinfo):
        try:
            self.rollback()
        except Exception as err:
            self.logger.error("Rollback for {} module has failded".format(str(err)))
        finally:
            self.data.services[self._task_name]["finished_at"] = time.time()
            self.data.services[self._task_name]["status"] = "FAILED"
            self.data.services[self._task_name]["exception_class"] = str(type(exc))
            self.data.services[self._task_name]["exception_msg"] = str(exc)
            self.data.services[self._task_name]["exception_traceback"] = str(excinfo)

    def on_success(self, result, kwargs):
        self.data.services[self._task_name]["finished_at"] = time.time()
        self.data.services[self._task_name]["status"] = "SUCCESS"
        self.data.services[self._task_name]["return_value"] = result

    def _set_up(self):
        self.data.services[self._task_name] = {
            "changed": False,
            "launch_at": time.time(),
            "service_kwargs": {}
        }
        self.data.services[self._task_name]["service_kwargs"]["whats_hostname"] = self.data.shared_data["vm_hostname"]
        self.data.services[self._task_name]["service_kwargs"]["whats_ip"] = self.data.shared_data["vm_ip"]
        self.data.services[self._task_name]["service_kwargs"]["whats_trigram"] = self.data.shared_data["app_id"]
        self.data.services[self._task_name]["service_kwargs"]["state"] = "present"

    def task(self):
        self._set_up()
        self.logger.info("Invoke {} module with kwargs={}".format(
            self._task_name,
            self.data.services[self._task_name]["service_kwargs"])
        )
        result = whats_module(**self.data.services[self._task_name]["service_kwargs"])
        self.logger.error(result[1])
        self.data.shared_data["idm_realm"] = result[1]["idm_realm"]
        self.data.shared_data["idm_domain"] = result[1]["idm_domain"]
        return result


class RegisterWhatsClientTask(TaskServiceManager, RollBackMixins):

    def __init__(self, data):
        super().__init__("RegisterWhatsClient", data)

    def on_failure(self, exc, kwargs, excinfo):
        try:
            self.rollback()
        except Exception as err:
            self.logger.error("Rollback for {} module has failded".format(str(err)))
        finally:
            self.data.services[self._task_name]["finished_at"] = time.time()
            self.data.services[self._task_name]["status"] = "FAILED"
            self.data.services[self._task_name]["exception_class"] = str(type(exc))
            self.data.services[self._task_name]["exception_msg"] = str(exc)
            self.data.services[self._task_name]["exception_traceback"] = str(excinfo)

    def on_success(self, result, kwargs):
        self.data.services[self._task_name]["finished_at"] = time.time()
        self.data.services[self._task_name]["status"] = "SUCCESS"
        self.data.services[self._task_name]["return_value"] = result

    def _set_up(self):
        self.data.services[self._task_name] = {
            "changed": False,
            "launch_at": time.time(),
            "service_kwargs": {}
        }
        self.data.services[self._task_name]["service_kwargs"]["hostname"] = self.data.shared_data["vm_hostname"]
        self.data.services[self._task_name]["service_kwargs"]["ip_address"] = self.data.shared_data["vm_ip"]
        self.data.services[self._task_name]["service_kwargs"]["realm"] = self.data.shared_data["idm_realm"]
        self.data.services[self._task_name]["service_kwargs"]["domain"] = self.data.shared_data["idm_domain"]

    def task(self):
        self._set_up()
        self.logger.info("Invoke {} module with kwargs={}".format(
            self._task_name,
            self.data.services[self._task_name]["service_kwargs"])
        )
        result = whats_client_module(**self.data.services[self._task_name]["service_kwargs"])
        self.data.services[self._task_name]["changed"] = result[0]
        return result


class UnRegisterWhatsClientTask(TaskServiceManager, RollBackMixins):

    def __init__(self, data):
        super().__init__("UnRegisterWhatsClient", data)

    def on_failure(self, exc, kwargs, excinfo):
        try:
            self.rollback()
        except Exception as err:
            self.logger.error("Rollback for {} module has failded".format(str(err)))
        finally:
            self.data.services[self._task_name]["finished_at"] = time.time()
            self.data.services[self._task_name]["status"] = "FAILED"
            self.data.services[self._task_name]["exception_class"] = str(type(exc))
            self.data.services[self._task_name]["exception_msg"] = str(exc)
            self.data.services[self._task_name]["exception_traceback"] = str(excinfo)

    def on_success(self, result, kwargs):
        self.data.services[self._task_name]["finished_at"] = time.time()
        self.data.services[self._task_name]["status"] = "SUCCESS"
        self.data.services[self._task_name]["return_value"] = result

    def _set_up(self):
        self.data.services[self._task_name] = {
            "changed": False,
            "launch_at": time.time(),
            "service_kwargs": {}
        }

    def task(self):
        self._set_up()
        self.logger.info("Invoke {} module with kwargs={}".format(
            self._task_name,
            self.data.services[self._task_name]["service_kwargs"])
        )
        self.data.services[self._task_name]["changed"] = True
        self.data.services[self._task_name]["rollback_kwargs"] = dict()
        self.data.services[self._task_name]["rollback_kwargs"]["hostname"] = self.data.shared_data["vm_hostname"]
        self.data.services[self._task_name]["rollback_kwargs"]["ip_address"] = self.data.shared_data["vm_ip"]
        self.data.services[self._task_name]["rollback_kwargs"]["realm"] = self.data.shared_data["idm_realm"]
        self.data.services[self._task_name]["rollback_kwargs"]["domain"] = self.data.shared_data["idm_domain"]
        return True, 'Used only for rollback issue...'

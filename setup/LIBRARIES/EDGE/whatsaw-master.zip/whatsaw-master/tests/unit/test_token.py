import unittest
try:
    from unittest import mock
except ImportError:
    import mock
from whatsaw.token import Token
from py_edge_vault import secrets
from tests.mock.idm import mock_vault, mock_get_exitcode_stdout_stderr

class MockedToken(Token):
    def __init__(self, env):
        Token.__init__(self, env)

class TestToken(unittest.TestCase):
    @mock.patch('whatsaw.token.get_exitcode_stdout_stderr')
    @mock.patch('py_edge_vault.secrets.get_secrets')
    def test_kb_token(self, mock_creds, mock_token):

        mock_creds.return_value = mock_vault()
        mock_token.return_value = mock_get_exitcode_stdout_stderr()

        kb_token = MockedToken('DEV')
        assert kb_token.environment == 'DEV'

    


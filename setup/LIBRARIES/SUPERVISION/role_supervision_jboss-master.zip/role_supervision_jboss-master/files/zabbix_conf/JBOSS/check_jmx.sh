#!/bin/sh

#Plugin to monitor JAVA_JMX , with a plugin for JBOSS
#Author : F.TCHATO
#2018 for SG


RDIR=`dirname $0`

#GET JMX CREDENTIAL

PARAMS=$(tail -n 1 $RDIR/jboss_jmx_input.conf)
JMX_USR=$(echo $PARAMS | cut -d';' -f 1)
JMX_PWD=$(echo $PARAMS | cut -d';' -f 2)
JBOSS_HOME=$(echo $PARAMS | cut -d';' -f 3)
JAVA_HOME=$(echo $PARAMS | cut -d';' -f 4)

JMX_PROTOCOL='remote+http'

JAVA_CMD=$JAVA_HOME/bin/java
OUTPUT=`$JAVA_CMD -cp -Djava.util.logging.manager=java.util.logging.LogManager -Djava.util.logging.config.file=logging.properties -jar  $RDIR/jmxquery_jboss.jar -U service:jmx:$JMX_PROTOCOL://$5:$4 -u $JMX_USR -p $JMX_PWD -O $1 -A $2 -K $3`
EXIT_STATUS=$?
STATUS=`echo $OUTPUT`
if [[ $STATUS =~ "=" ]]
then
        VALUE=`echo $OUTPUT | cut -d= -f2`
else
        VALUE=`echo $OUTPUT | cut -d: -f2`
fi
echo "$VALUE"



from celery import Celery

from ccs_celery.settings import settings


app = Celery(
    'ccs-celery-tasks',
    broker=settings.BROKER_URL,
    backend=settings.BACKEND_RESULT_URL
)

app.autodiscover_tasks(['ccs_celery.run_tasks'])

#!/usr/bin/env bash
sudo pip freeze | xargs sudo pip uninstall -y 2> /dev/null
if [ "$?" -ne "0" ]
then
  sudo pip freeze | xargs sudo pip uninstall -y
fi
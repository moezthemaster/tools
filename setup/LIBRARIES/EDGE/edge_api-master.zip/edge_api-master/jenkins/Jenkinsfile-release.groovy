import static sgcib.coc.bootcamp.Git.*
import static sgcib.coc.bootcamp.Python.*
import static sgcib.coc.bootcamp.Maven.*
import static sgcib.coc.bootcamp.Utils.*

properties = readProperties(this, 'jenkins/job.properties')

String slave = properties.slave
String gitCreds = properties.gitCreds
String gitRepo = properties.gitRepo

String jdkVersion = properties.jdkVersion
String mavenVersion = properties.mavenVersion

node(slave) {
    stage('Checkout') {
        git branch: "${BRANCH}", credentialsId: "${gitCreds}", url: "${gitRepo}"
    }

    stage('Preparing release') {
        bumpVersion(this, 'phase')
    }

    stage('Push new version + tag on GitHub') {
        push(this, gitCreds, 'origin', BRANCH) {}
    }

    stage('Import on XLD'){
        mvn(this, jdkVersion, mavenVersion, 'clean xldeploy:import')
    }

    stage('Bump version') {
        bumpVersion(this, RELEASE_TYPE)
    }

    stage('Push SNAPSHOT + tag') {
        push(this, gitCreds, 'origin', BRANCH) {}
    }
}
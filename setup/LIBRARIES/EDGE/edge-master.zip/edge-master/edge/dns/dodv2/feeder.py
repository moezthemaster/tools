#!/usr/bin/python
# -*- coding: utf-8 -*-

#

DOCUMENTATION = '''




'''

EXAMPLES = '''

'''

import logging
import time
import traceback

import edge.dns.dodv2.hostname

import edge.interfaces
import edge.conf.cloud_network
from edge.conf import settings
from edge.exception import EdgeException
from edge.dns.dodv2.response import ResponseMixin
from edge.dns.dodv2.hostname import is_valide_hostname

A, CNAME, PTR = 'A', 'CNAME', 'PTR'
PRODUCTION = 'production'
KWARGS_SEARCH = {
    'dns_service':settings.DOD_DNS_SERVICE,
    'view': PRODUCTION,
}

#logger = logging.getLogger("dod_logger")
logger = logging.getLogger(__name__)


class DnsFeeder(edge.interfaces.Dod, ResponseMixin):
    def __init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname=None):
        if hostname not in (None, ""):
            is_valide_hostname(trigram, hostname)
        self.env = env
        self.hostname = hostname
        cloud_network_dict = edge.conf.cloud_network.get_details(env, region_cloud, az_cloud, network_id)
        self.network_cidr = cloud_network_dict['network_cidr'] #other name: vm_subnet
        self.dns_cname = cloud_network_dict['dns_cname'] #other name: dns_publish
        self.dns_zone = cloud_network_dict['dns_zone']
        self.trigram = trigram
        self._record_A = None
        self.record_PTR = None
        self.record_CNAME = None
        self.ip_address = None
        self.changed = False

    @property
    def record_A(self):
        return self._record_A

    @record_A.setter
    def record_A(self, value):
        if value:
            self._record_A = value
            self.ip_address = value['ip']
            logger.debug('Ip_address updated from record A freshly created')

    @property
    def fqdn(self):
        try:
            assert self.hostname, "hostname is None"
        except AssertionError as e:
            raise EdgeException(repr(e))
        return '{}.{}.'.format(self.hostname, self.dns_zone)

    def run(self):
        '''
        If no hostname, generate a hostname according to existing hostnames for the same trigram and environment.
        When VM is created, create DNS records, if no record exists already. It is processed for  A record, PTR and CNAME.
        if error when VM is created, roll back all DNS registered previously.
        :return:
        '''
        try:
            if not self.hostname:
                self.record_A = self._reserve_hostname()
            else:
                self.record_A = self._register_record()
            time.sleep(5)
            self.record_PTR = self._create_PTR(
                zone=self.dns_zone,
                hostname=self.hostname,
                ip=self.ip_address
            )
            self.record_CNAME = self._create_CNAME(
                hostname=self.fqdn,
                alias=self.hostname,
                zone=self.dns_cname
            )
            response = self._get_response()
            return response
        except Exception as e:
            logger.debug('Exception raised {}'.format(repr(e)))
            logger.debug('{}'.format(traceback.format_exc()))
            self._rollback() #does not throw an exception
            raise

    def _create_A(self, **kwargs):
        logger.debug('Checking record A')
        found = self.search_dns_record(
            record_type='^A$',
            hostname='^{}$'.format(self.hostname),
            **KWARGS_SEARCH
        )
        if not found:
            created = self.create_dns_record(
                dns_service=settings.DOD_DNS_SERVICE,
                record_type=A,
                view=PRODUCTION,
                inA=True,
                inPTR=True,
                **kwargs
            )
            logger.debug('Record A created {}'.format(created))
            self.changed = True
            return created
        logger.debug('record A exists already, no record created')
        self.ip_address = found[0]['ip']
        logger.debug('Ip_address updated from record A available in Dod')

    def _create_PTR(self, **kwargs):
        '''
        Create record if it does not exist
        :param record_type: record type to create A, PTR or CNAME
        :param kwargs: used to create a record, parameters are different according to the record type
        :return: created record, None otherwise
        '''
        logger.debug('Creating record PTR')
        found = self.search_dns_record(
            record_type='^PTR$',
            hostname='^{}$'.format(self.hostname),
            **KWARGS_SEARCH
        )
        if not found:
            created = self.create_dns_record(
                dns_service=settings.DOD_DNS_SERVICE,
                record_type=PTR,
                view=PRODUCTION,
                inA=True,
                inPTR=True,
                **kwargs
            )
            self.changed = True
            return created
        logger.debug('record PTR exists already, no record created')

    def _create_CNAME(self, **kwargs):
        '''
        Create record if it does not exist
        :param record_type: record type to create A, PTR or CNAME
        :param kwargs: used to create a record, parameters are different according to the record type
        :return: created record, None otherwise
        '''
        logger.debug('Creating record CNAME')
        found = self.search_dns_record(
            record_type='^CNAME$',
            alias='^{}$'.format(self.hostname),
            **KWARGS_SEARCH
        )
        if not found:
            created = self.create_dns_record(
                dns_service=settings.DOD_DNS_SERVICE,
                record_type=CNAME,
                view=PRODUCTION,
                inA=True,
                inPTR=True,
                **kwargs
            )
            self.changed = True
            return created
        found_fqdn = found[0]['hostname']
        found_hostname = found_fqdn.split('.')[0]
        logger.debug('found_hostname = {}, found_fqdn = {}'.format(found_hostname, found_fqdn))
        if found_fqdn != self.fqdn and found_hostname == self.hostname:
            raise EdgeException('CNAME record for {} already created for different zone {}'.format(self.fqdn, found_fqdn))
        if found_hostname != self.hostname:  # resolve bug [RET-444]
            logger.debug('CNAME exists but record is created: {} != {}'.format(found_hostname, self.hostname))
            created = self.create_dns_record(
                dns_service=settings.DOD_DNS_SERVICE,
                record_type=CNAME,
                view=PRODUCTION,
                inA=True,
                inPTR=True,
                **kwargs
            )
            self.changed = True
            return created
        logger.debug('record CNAME exists already, no record created')

    def _propose_hostname(self):
        '''
        Find out free hostname
        :return: hostname string
        '''
        env_first_char = self.env[0] #handle first character DEV->D PRD->P...
        prefix = '{}{}lx'.format(env_first_char, self.trigram)
        found = self.search_dns_record(
            record_type='^A$',
            hostname='^{}'.format(prefix[:6]),
            **KWARGS_SEARCH
        )
        free_slot = edge.dns.dodv2.hostname.free_slot(records=found, prefix=prefix)
        hostname = '{}{:03d}'.format(prefix, free_slot)
        return hostname

    def _rollback(self):
        '''
        Clean records created previously, CNAME record is cleaned first for dependencies
        :return: None
        '''
        logger.debug('Rollback started')
        try:
            # we treat CNAME first for dependencies
            for record in (self.record_CNAME, self.record_A, self.record_PTR):
                if record:
                    self.delete_dns_record(dns_service=settings.DOD_DNS_SERVICE, id=record['id'])
            self.changed = False
        except Exception as e:
            logger.error('Rollback has raised an exception: {}'.format(e.args[0]))
        logger.debug('Rollback ended correctly')

    def _reserve_hostname(self, retries=15):
        '''
        Pick an hostname, reserve this hostname by creating an A record and check if no record was created concurrently.
        If an A record has been created in the meantime, delete our record and try another hostname
        :param retries:
        :return: A record created
        '''
        logger.debug('Starting hostname reservation')
        for i in range(retries):
            try:
                self.hostname = self._propose_hostname()
                logger.debug('attempting hostname: {}'.format(self.hostname))
                created = self._create_A(
                    zone=self.dns_zone,
                    hostname=self.hostname,
                    ip_subnet=self.network_cidr,
                    ip_range='server'
                )
                if created:
                    #Check if an A record was created by somebody else in the meantime
                    found = self.search_dns_record(
                        record_type='^A$',
                        hostname='^{}$'.format(self.hostname),
                        **KWARGS_SEARCH
                    )
                    if len(found) >= 2:
                        for r in found:
                            if int(r['id']) < int(created['id']):
                                logger.debug('Hostname {} has been reserved by somebody else'.format(self.hostname))
                                self.delete_dns_record(dns_service=settings.DOD_DNS_SERVICE, id=created['id'])
                                break
                        else:
                            logger.debug('First to reserve: {} and record A created'.format(self.hostname))
                            return created
                    else:
                        logger.debug('Hostname reserved: {} and record A created'.format(self.hostname))
                        return created
            except Exception as e:
                logger.debug('Exception in reservation {}'.format(repr(e)))
                logger.debug('{}'.format(traceback.format_exc()))
                pass

        raise EdgeException('Too many attempts')

    def _register_record(self, retries=15):
        '''
        If an A record has been created in the meantime with the same ip address, delete the last record and try another ip
        :param retries:
        :return: A record created
        '''

        logger.debug('Starting ip reservation')
        for i in range(retries):
            try:
                created = self._create_A(
                    zone=self.dns_zone,
                    hostname=self.hostname,
                    ip_subnet=self.network_cidr,
                    ip_range='server'
                )
                found = self.search_dns_record(
                    record_type='^A$',
                    ip='^{}$'.format(self.ip_address),
                    **KWARGS_SEARCH
                )
                if len(found) >= 2:
                    for r in found:
                        if int(r['id']) < int(created['id']):
                            logger.debug('ip {} has been reserved by somebody else'.format(self.ip_address))
                            self.delete_dns_record(dns_service=settings.DOD_DNS_SERVICE, id=created['id'])
                            break
                        else:
                            logger.debug('First to reserve: {} and record A created'.format(self.ip_address))
                            return created
                else:
                    logger.debug('ip reserved: {} and record A created'.format(self.ip_address))
                    return created

            except Exception as e:
                logger.debug('Exception in reservation {}'.format(repr(e)))
                logger.debug('{}'.format(traceback.format_exc()))
                pass

        raise EdgeException('Too many attempts')

# the inclusion of the tests module is not meant to offer best practices for
# testing in general, but rather to support the `find_packages` example in
# setup.py that excludes installing the "tests" package


import pytest

import edge
import ccs_celery
from unittest import mock

from tests.mock.kat import MockedKatService
from ccs_celery.run_tasks import create_vm, delete_vm

from six import with_metaclass
from tests.mock.mock import MockDod
from edge.whats.idm import Idm
from edge.cloud_vm.vm import Vm
from tests.mock.cloud import MockedCloudVra
from tests.mock.flexera import MockedFlexeraRequest
from tests.mock.marley_hpoo import MockedMarleyHPOO
from tests.mock.vm_session import MockVmSession, mocked_vault
from tests.mock.whats import MockedIdm, MockedRegisterWhatsClient
from edge.dns.metaclass import DnsFeederMetaClass, DnsUpdaterMetaClass, DnsCleanerMetaClass, DnsInformerMetaClass


SHARED_DATABASE = []
SHARED_DATABASE_IDM = []
SHARED_DATABASE_SSH = []
SHARED_DATABASE_CLOUD = []


class MockedFeederDodv2(with_metaclass(DnsFeederMetaClass, MockDod)):
    def __init__(self, *args, **kwargs):
        MockDod.__init__(self, (), hostname=None, shared_database=SHARED_DATABASE)


class MockedUpdaterDodv2(with_metaclass(DnsUpdaterMetaClass, MockDod)):
    def __init__(self, *args, **kwargs):
        MockDod.__init__(self, (), hostname=None, shared_database=SHARED_DATABASE)


class MockedCleanerDodv2(with_metaclass(DnsCleanerMetaClass, MockDod)):
    def __init__(self, *args, **kwargs):
        MockDod.__init__(self, (), hostname=None, shared_database=SHARED_DATABASE)


class MockedInformerDodv2(with_metaclass(DnsInformerMetaClass, MockDod)):
    def __init__(self, *args, **kwargs):
        MockDod.__init__(self, (), hostname=None, shared_database=SHARED_DATABASE)


class MockedVmSession(MockVmSession):

    def __init__(self, ip_address, shared_database=SHARED_DATABASE_SSH):
        MockVmSession.__init__(self, ip_address, shared_database)


class MockedWhats(MockedIdm, Idm):
    def __init__(self, env):
        MockedIdm.__init__(self, env=env, shared_database=SHARED_DATABASE_IDM)
        Idm.__init__(self)


class MockedVm(MockedCloudVra, Vm):
    def __init__(self, hostname):
        MockedCloudVra.__init__(
            self, shared_database=SHARED_DATABASE_CLOUD, shared_database_ssh=SHARED_DATABASE_SSH
        )
        Vm.__init__(self, hostname)
        self.token = mock.Mock()


class TestTaskCcsCelery(object):

    @mock.patch.object(ccs_celery.services._kat.module, 'KatServiceImpl', MockedKatService)
    @mock.patch.object(ccs_celery.services._dod.module, 'IdmImpl', MockedWhats)
    @mock.patch.object(ccs_celery.services._whats.module, 'IdmImpl', MockedWhats)
    @mock.patch.object(edge.connection.connectionhelper, 'VmSessionSsh', MockedVmSession)
    @mock.patch.object(edge.network.networkhelper, 'VmSessionSsh', MockedVmSession)
    @mock.patch.object(ccs_celery.services._vm_infos.func, 'VmSessionSsh', MockedVmSession)
    @mock.patch.object(ccs_celery.services._dod.module, 'DnsFeederAdapter', MockedFeederDodv2)
    @mock.patch.object(ccs_celery.services._dod.module, 'DnsUpdaterAdapter', MockedUpdaterDodv2)
    @mock.patch.object(ccs_celery.services._dod.module, 'DnsCleanerAdapter', MockedCleanerDodv2)
    @mock.patch.object(ccs_celery.services._dod.module, 'DnsInformerAdapter', MockedInformerDodv2)
    @mock.patch.object(edge.connection.connectionhelper.os, 'system', lambda x: 1)
    @mock.patch.object(ccs_celery.services._cloud.module, 'VmImpl', MockedVm)
    @mock.patch.object(edge.network.networkhelper.secrets, 'get_secrets', mocked_vault)
    @mock.patch.object(ccs_celery.services._whats.module, 'RegisterWhatsClient', MockedRegisterWhatsClient)
    @mock.patch.object(ccs_celery.services._marley.module, 'MarleyLoaderImpl', MockedMarleyHPOO)
    @mock.patch.object(ccs_celery.services._flexera.module.flexera, 'FlexeraRequest', MockedFlexeraRequest)
    @mock.patch('edge.network.networkhelper.paramiko')
    def test_creation_vm_ok(app, paramiko):
        result = create_vm.apply(
            kwargs={
                "vm_hostname": "dpgalx10000",
                "app_env": 'dev',
                "app_id": 'PGA',
                "vm_network": 'CITS',
                "vm_pubkey": 'ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAyLXUQ9eoPr8Akx+WeJzRgAOMyUbTQ3/RDu44N2svQTa7I0ZKzqelNrSqqsgSmNN7giQGRyIvx/XgUwi9UjrxFX0XRTvwjAcXNHV2pxybbhPb8/2jiAfFTCjkwQBwtoSTEL1I5noAIgapQDZghYFkv0GUiAkebKzl0A+cNqm5Zc2UPNTqsCtIAZ5Uid+XOdECHan29Iyow0f+O/2O6mZKBGvWFJbRLCokKLUrTmhbgWIiWgQGp/PnF0XVVPiQgRfbRz1xH08JNiQz1lnvZ4ME4BhQoxSK1O8QL+dQsSXhvQyjfO8yYI+X4X73Ie9yBfZpPiGAZLo3hTVha46veVfZGw== a373785@PXPLSV02',
                "code_irt": 'A7048'
            }
        )
        assert result.get() == "Vm successfully {} created...".format("dpgalx10000")

    @mock.patch.object(ccs_celery.services._kat.module, 'KatServiceImpl', MockedKatService)
    @mock.patch.object(ccs_celery.services._dod.module, 'IdmImpl', MockedWhats)
    @mock.patch.object(ccs_celery.services._whats.module, 'IdmImpl', MockedWhats)
    @mock.patch.object(edge.connection.connectionhelper, 'VmSessionSsh', MockedVmSession)
    @mock.patch.object(edge.network.networkhelper, 'VmSessionSsh', MockedVmSession)
    @mock.patch.object(ccs_celery.services._dod.module, 'DnsFeederAdapter', MockedFeederDodv2)
    @mock.patch.object(ccs_celery.services._dod.module, 'DnsUpdaterAdapter', MockedUpdaterDodv2)
    @mock.patch.object(ccs_celery.services._dod.module, 'DnsCleanerAdapter', MockedCleanerDodv2)
    @mock.patch.object(ccs_celery.services._dod.module, 'DnsInformerAdapter', MockedInformerDodv2)
    @mock.patch.object(edge.connection.connectionhelper.os, 'system', lambda x: 1)
    @mock.patch.object(ccs_celery.services._cloud.module, 'VmImpl', MockedVm)
    @mock.patch.object(edge.network.networkhelper.secrets, 'get_secrets', mocked_vault)
    @mock.patch.object(ccs_celery.services._whats.module, 'RegisterWhatsClient', MockedRegisterWhatsClient)
    @mock.patch.object(ccs_celery.services._marley.module, 'MarleyLoaderImpl', MockedMarleyHPOO)
    @mock.patch.object(ccs_celery.services._flexera.module.flexera, 'FlexeraRequest', MockedFlexeraRequest)
    @mock.patch.object(ccs_celery.services._cloud.module, 'find_network_infos', lambda x, vm_region=None, vm_az=None: ("dev", 'EU France (Greater Paris)', 'eu-fr-paris-1', 'CITS', "192.88.80.0/21", "dns21-1.socgen", "dns21.socgen"))
    @mock.patch('edge.network.networkhelper.paramiko')
    def test_delete_vm_ok(app, paramiko):
        result = delete_vm.apply(
            kwargs={
                "vm_hostname": "dpgalx10000",
                "app_env": 'dev',
                "app_id": 'PGA',
                "vm_network": 'CITS',
                "vm_pubkey": 'ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAyLXUQ9eoPr8Akx+WeJzRgAOMyUbTQ3/RDu44N2svQTa7I0ZKzqelNrSqqsgSmNN7giQGRyIvx/XgUwi9UjrxFX0XRTvwjAcXNHV2pxybbhPb8/2jiAfFTCjkwQBwtoSTEL1I5noAIgapQDZghYFkv0GUiAkebKzl0A+cNqm5Zc2UPNTqsCtIAZ5Uid+XOdECHan29Iyow0f+O/2O6mZKBGvWFJbRLCokKLUrTmhbgWIiWgQGp/PnF0XVVPiQgRfbRz1xH08JNiQz1lnvZ4ME4BhQoxSK1O8QL+dQsSXhvQyjfO8yYI+X4X73Ie9yBfZpPiGAZLo3hTVha46veVfZGw== a373785@PXPLSV02',
                "code_irt": 'A7048'
            }
        )
        assert result.get() == "Vm successfully {} deleted...".format("dpgalx10000")

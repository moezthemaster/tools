
import time

from ccs_celery.abstract import TaskServiceManager
from ccs_celery.services.rollback import RollBackMixins
from ccs_celery.services._connection.module import connection_module


class RegisterPubKeyTask(TaskServiceManager, RollBackMixins):

    def __init__(self, data):
        super().__init__("RegisterPubKey", data)

    def on_failure(self, exc, kwargs, excinfo):
        try:
            self.rollback()
        except Exception as err:
            self.logger.error("Rollback for {} module has failded".format(str(err)))
        finally:
            self.data.services[self._task_name]["finished_at"] = time.time()
            self.data.services[self._task_name]["status"] = "FAILED"
            self.data.services[self._task_name]["exception_class"] = str(type(exc))
            self.data.services[self._task_name]["exception_msg"] = str(exc)
            self.data.services[self._task_name]["exception_traceback"] = str(excinfo)

    def on_success(self, result, kwargs):
        self.data.services[self._task_name]["finished_at"] = time.time()
        self.data.services[self._task_name]["status"] = "SUCCESS"
        self.data.services[self._task_name]["return_value"] = result

    def _set_up(self):
        self.data.services[self._task_name] = {
            "changed": False,
            "launch_at": time.time(),
            "service_kwargs": {}
        }
        self.data.services[self._task_name]["service_kwargs"]["ip"] = self.data.shared_data["vm_ip"]
        self.data.services[self._task_name]["service_kwargs"]["vm_hostname"] = self.data.shared_data["vm_hostname"]
        self.data.services[self._task_name]["service_kwargs"]["pubkey"] = self.data.shared_data["vm_pubkey"]
        self.data.services[self._task_name]["service_kwargs"]["remote_user"] = "automation"
        self.data.services[self._task_name]["service_kwargs"]["remote_group"] = "automation"
        self.data.services[self._task_name]["service_kwargs"]["state"] = self.data.shared_data["state"]

    def task(self):
        self._set_up()
        self.logger.info("Invoke {} module with kwargs={}".format(
            self._task_name,
            self.data.services[self._task_name]["service_kwargs"])
        )
        result = connection_module(**self.data.services[self._task_name]["service_kwargs"])
        self.data.services[self._task_name]["changed"] = result[0]
        return result


class UnRegisterPubKeyTask(TaskServiceManager, RollBackMixins):

    def __init__(self, data):
        super().__init__("UnRegisterPubKey", data)

    def on_failure(self, exc, kwargs, excinfo):
        try:
            self.rollback()
        except Exception as err:
            self.logger.error("Rollback for {} module has failded".format(str(err)))
        finally:
            self.data.services[self._task_name]["finished_at"] = time.time()
            self.data.services[self._task_name]["status"] = "FAILED"
            self.data.services[self._task_name]["exception_class"] = str(type(exc))
            self.data.services[self._task_name]["exception_msg"] = str(exc)
            self.data.services[self._task_name]["exception_traceback"] = str(excinfo)

    def on_success(self, result, kwargs):
        self.data.services[self._task_name]["finished_at"] = time.time()
        self.data.services[self._task_name]["status"] = "SUCCESS"
        self.data.services[self._task_name]["return_value"] = result

    def _set_up(self):
        self.data.services[self._task_name] = {
            "changed": False,
            "launch_at": time.time(),
            "service_kwargs": {}
        }
        self.data.services[self._task_name]["rollback_kwargs"] = dict()
        self.data.services[self._task_name]["rollback_kwargs"]["ip"] = self.data.shared_data["vm_ip"]
        self.data.services[self._task_name]["rollback_kwargs"]["vm_hostname"] = self.data.shared_data["vm_hostname"]
        self.data.services[self._task_name]["rollback_kwargs"]["pubkey"] = self.data.shared_data["vm_pubkey"]
        self.data.services[self._task_name]["rollback_kwargs"]["remote_user"] = "automation"
        self.data.services[self._task_name]["rollback_kwargs"]["remote_group"] = "automation"
        self.data.services[self._task_name]["rollback_kwargs"]["state"] = "present"

    def task(self):
        self._set_up()
        self.logger.info("Invoke {} module with kwargs={}".format(
            self._task_name,
            self.data.services[self._task_name]["service_kwargs"])
        )
        self.data.services[self._task_name]["changed"] = True
        return True, 'Used only for rollback issue...'

import os

_basedir = os.path.abspath(os.path.dirname(__file__))

SQLALCHEMY_DATABASE_URI = ('sqlite:///' +
                           os.path.join(_basedir, '../db/production.db'))
SQLALCHEMY_TRACK_MODIFICATIONS = True

DEBUG = False
TRAP_HTTP_EXCEPTIONS = True
ERROR_404_HELP = True
BUNDLE_ERRORS = True

SWAGGER_UI_OAUTH_CLIENT_ID = 'ddb46a42-a4b2-4d86-b2d5-6e64ecff23e7'
SWAGGER_UI_OAUTH_REALM = '/'
SWAGGER_UI_OAUTH_APP_NAME = 'ITAAS'

DL_LOGGER_CONFFILE = os.path.join(_basedir, 'production_sg_datalake.cfg')

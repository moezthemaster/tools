#!/usr/bin/python
# -*- coding: utf-8 -*-

#

DOCUMENTATION = '''
---


'''

EXAMPLES = '''

'''

from .conf import settings
from py_edge_vault import secrets
from whatsaw.switch import whats_env



def get_user_passwd(environment):
    vault_secret = secrets.get_secrets(context=getattr(settings, 'CREDENTIALS_GROUP_{}'.format(environment)), env=getattr(settings, 'ENV_{}'.format(environment)))

    username = vault_secret['username']
    password = vault_secret['password']
    return username, password

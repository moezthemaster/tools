import os
import sys

if "TREE_DIR" in os.environ.keys():
    ANSIBLE_MODULES_PATH = [
        os.path.join(os.environ["TREE_DIR"], 'roles/edge'),
        os.path.join(os.environ["TREE_DIR"], "library"),
        os.path.join(os.environ["TREE_DIR"], 'roles/py_edge_vault'),
    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/edge',
        './roles/py_edge_vault'
    ]
for path in ANSIBLE_MODULES_PATH:
    sys.path.append(path)

from ansible.module_utils.basic import AnsibleModule
from edge.flexera import flexera


def configure_flexera_agent(params):
    ip_address = params['flexera_ip_address']
    configure = flexera.FlexeraRequest(ip_address)
    request = configure.request_flexera_configuration()
    if request == 1:
        result = {'status': 'FAILURE', 'code': request}
        return True, False, result
    else:
        return False, True, {'status': 'SUCCESS', 'code': request}


def uninstall_flexera_agent(params):
    return False, False, {'status': 'SUCCESS', 'code': 0}


def main():
    fields = {
        "flexera_ip_address": {"required": True, "type": "str"},
        "state": {
            "default": "present",
            "choices": ['present', 'absent'],
            "type": "str"
        },
    }

    choice_map = {
        "present": configure_flexera_agent,
        "absent": uninstall_flexera_agent,
    }

    module = AnsibleModule(argument_spec=fields)
    is_error, has_changed, result = choice_map.get(
        module.params['state'])(module.params)
    if not is_error:
        module.exit_json(changed=has_changed, meta=result)
    else:
        module.fail_json(msg="Could not install flexera", meta=result)


if __name__ == '__main__':
    main()

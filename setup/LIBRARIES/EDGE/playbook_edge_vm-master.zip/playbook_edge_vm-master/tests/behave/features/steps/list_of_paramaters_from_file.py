import os
import yaml

from behave import *

@given('list of paramaters from file {filename}')
def step_impl(context, filename):
    dir_path = os.path.dirname(os.path.realpath(__file__))
    stream = open(os.path.join(dir_path, '../config', filename), "r")
    params = yaml.load(stream)
    if hasattr(context, 'params'):
       context.params.update(params)
    else:
      context.params = params

    assert context.failed is False


import logging

from edge.conf import settings
from edge.interfaces import MarleyHPOO
from edge.exception import MarleyError


logging.basicConfig(level=logging.getLevelName(settings.LOGGER_LEVEL))
logger = logging.getLogger(__name__)


class MarleyLoader(MarleyHPOO):

    def invoc_step_marley_v5(self, **params):
        '''
        Invoke Step_Marley_V5 HPOO Flow
        :return: response
        '''
        data = dict(params)

        try:
            data['vm_os'] = data['vm_os'].replace('-', ' ').replace('_', ' ').replace('x', 'en ').replace('RET', 'bits')
            data['cpuCount'] = data['vm_profile'].split('vCPU')[0].split(' ')[1]
            data['memorySize'] = int(data['vm_profile'].split('vCPU')[1].split('-')[1][:-2]) * 1024
        except Exception as e:
            raise MarleyError(e.args[0])

        if data['app_env'] == "dev":
            data['app_env'] = "DEV"
        elif data['app_env'] == "hml":
            data['app_env'] = "HOMO"
        elif data['app_env'] == "prd":
            data['app_env'] = "PROD"

        result = self.marley_hpoo_execute(**data)
        return result


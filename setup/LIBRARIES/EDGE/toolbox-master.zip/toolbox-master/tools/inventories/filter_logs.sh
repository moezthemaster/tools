#!/bin/ksh

RES_DIR="./inventory_status"


for f in logs/*.log; do
   res=`grep BG_ $f | cut -d ';' -f9 | sed 's!^BG_\([^-]*\)-.*$!\1!' | sort | uniq | paste -sd " " -`
   trig=`echo $f | sed 's!^.*\(...\).log$!\1!'`
   if [ -z "$res" ]; then
      destdir="others"
   else
      destdir=$res
   fi
   for dir in $destdir; do
     echo "Spliting file $f to $dir"
     mkdir -p $RES_DIR/$dir
     sed -n '/^## Cloud /,/## DNS/p' $f | sed '$ d' > $RES_DIR/$dir/${trig}_vra.log
     sed -n '/^## DNS /,/## Marley/p' $f | sed '$ d' > $RES_DIR/$dir/${trig}_dns.log
     sed -n '/^## Marley /,/## Whats/p' $f | sed '$ d' > $RES_DIR/$dir/${trig}_marley.log
     sed -n '/^## Whats/,/### /p' $f | sed '$ d' > $RES_DIR/$dir/${trig}_whats.log
     sed -n '/^### /,/^$/p' $f | sed '$ d' > $RES_DIR/$dir/${trig}_errors.log
   done
done

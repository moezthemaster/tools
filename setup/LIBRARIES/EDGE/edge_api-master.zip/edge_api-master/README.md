# Sample project repository

# :warning: Important Notice : this is a Work In Progress.

This project is a template for Python REST server projects in SG

This project is automatically built and deployed, and use a Continuous Delivery Pipeline by ITEC/ARC/COC.

To start with Python in SG, [install the pre-configured interpreter](http://go.fr.world.socgen/python).

## Continuous Delivery platform

For more info about Continuous Delivery and the Center of Competency, check [CD Platform's website](https://sgithub.fr.world.socgen/pages/CenterOfCompetency/)

You can also contact us via [JIRA](http://go.fr.world.socgen/cochd)

## The project

_/sample/apis/contacts_ : return team contact using SGConnect authentication. Great. :grin:

This project is mainly based around [Flask-RESTPlus](http://flask-restplus.readthedocs.io/en/stable/), a Python framework for web services.

## Checking it out

You can run a test server on your machine, very easily !

First, make sure you have the [CoC python interpreter](http://go.fr.world.socgen/python) installed.

By default, the Flask application will be run using the default.py config file. 
To specify another config file, user _CONFFILE_PATH_ environment variable.

```
export CONFFILE_PATH='/my_app/config/development_configuration_file.py'
```

Next, install the dependencies and run the app :

```
pip install -r requirements.txt
git submodule update --init
python manage.py db upgrade
python manage.py run
```

Don't forget to modify your configuration variables in puppet/hiera/dev.yaml

Open your favorite browser and go to _http://localhost:5000/documentation/

## Launching tests

From the whiteapp folder:

```
pytest
```

## Using the template for your own use

### Pre-requisites

We'll assume you have :
* A working Jenkins Slave with python, java, maven, hiera-eyaml installed. If it is not the case, contact the [CenterOfCompetency](http://go.fr.world.socgen/coc-hd)
* A machine on which to deploy
* A service account with access to your github repo, XL Deploy, and the machine on hwich to deploy. You can also use separate accounts for all this of course
* An AD Group that contains people in your team

### Using the template

1. On sGitHub, create an organisation on sGitHub for your application, and a repository in this organisation

2. Copy the content of this repo in your new repo, and modify all the __\<CHANGEIT placeholders>__ to have the good value (pom.xml + jenkins/job.properties)

3. Push your modification on sgithub, and launch [the following job](https://itbox-jenkins-gts.fr.world.socgen/job/Public/job/JobGenerator/) to create your jobs on Jenkins

4. Your folder will be created at the root of Jenkins, look for it (you must be logged in) and create 2 sets of credentials in it :
  * _gitCreds_ : SSH key to clone and deploy to the git repo for releases. Follow [this documentation](https://sgithub.fr.world.socgen/CenterOfCompetency/cdpu-github/blob/master/ghe-interface-tools/jenkins_clone_ghe_repos.md) 
  * _genericCreds_ : Credentials of the service account that will be used to deploy on your server, scan credentials on sgithub and connect to XLD. User/password

7. Create all the credentials required from the properties file. Make them scoped to this folder (need help on here probably). You can also set the id manually if you feel like it
  * _gitCreds_ :
    * _Kind_ : SSH Username with private key
    * _Username_ : git
    * _Private Key_ : Enter directly. Follow [this documentation](https://developer.github.com/enterprise/2.8/guides/managing-deploy-keys/#setup-2) to add the deploy key to your sGitHub repo :warning: The key must allow write access. The private part of your key goes in Jenkins 
    * _ID_ : gitCreds
    * _Description_ : <Orga>/<Repo> deploy key
    
    This deployment key will be used by Jenkins to push modifications to the repository, in the case of releases or when generating a new dev env
    
  * _genericCreds_ :
    * _Kind_ : Username with Password
    * _Description_ : Service Account
    * _ID_ : genericCreds
    
    Credentials of the service account that will be used to deploy on your server, scan credentials on sgithub and connect to XLD.
    
6. On GitHub, in the settings of your *organisation* (not repo), add a hook :
   * Payload url : _https://${itbox-jenkins-bl}.fr.world.socgen/github-webhook_
   * Content type : _x-www-form-urlencoded_
   * Select individual events :
     * Pull Request
     * Push
     * Repository
     
7. Launch the job generateEnv with the host on which to deploy on dev, and the folder where to deploy

8. Your pipeline will automatically be launched !

## Setting up the Slave

Check https://sgithub.fr.world.socgen/clecoint062112/slave-auto-setup


## Jenkins Master Admin notes

Don't do this if you're a trainee, this is just to set everything up outside GTS

Plugins required :
* GitHub Organisation Folder
* Pipeline
* mask-password
* Job DSL
* Sonar

Do not forget to :
* Declare a sgithub API endpoint (for the GitHub plugin not to hit Github.com)
* Include the shared libraries [here](https://sgithub.fr.world.socgen/CenterOfCompetency/groovy-libraries) as global shared libraries. :warning: This is done because at the time of writing some plugins are not available. If you can remove this dependency, please do !

## Detailed presentation

### Code

The _sample_ folder contains the code of the server

The _setup.py_ file contains application metadata

_requirements.txt_ contains the dependencies of your application

_.bumpversion.cfg_ contains version configuration

### Jenkins jobs

The _jenkins_ folder contains :
  * Pipeline descriptions (*Jenkinsfile-xxx*)
  * Job generation (*seedJobs.groovy*)
  * Variable file (*job.properties*)

The _Jenkinsfile_ at the root is the declaration for the Organisation Folder job

### XLD configuration

_pom.xml_ contains the description of the DAR deployed.

_The jenkins/job.properties_ file contains some variables for the _pom.xml_

_config_ and _script_ folders contains the config for the server + launch scripts, delivered by XLD

The _puppet_ folder contains :
  * The puppet recipe describing the XLD env
  * Description of env and conf : *hiera/dev.yaml*

## Deploying on a server

The server is great to check, but you probably want to deploy it on a real server with workers and conf and stuff

For this, on your target machine, make sure you have a [recent Python interpreter](https://sgithub.fr.world.socgen/CenterOfCompetency/python-configuration/blob/master/README.md#on-linux) installed, and then :

```
pip install gunicorn
```

Now, retrieve the app and run :
```
gunicorn manage:app -c config.py
```

Tada ! Your app is running !

You can adapt the conf as you wish in _config.py_

For more infos about conf and [Gunicorn](http://gunicorn.org/#docs)

# That's hard. I need help

Sure thing, contact the Center of Competency via [JIRA](http://go.fr.world.socgen/cochd). We'll help you set everything up.

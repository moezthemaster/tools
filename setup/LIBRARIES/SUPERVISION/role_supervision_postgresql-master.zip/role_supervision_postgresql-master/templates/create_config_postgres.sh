#!/bin/bash


#Creation de la configuration de Patrol pour Apache
#envoi des info en paramètre
#creation du fichier de config
#envoi de la configuration a l'agent Patrol
#restart de l'agent Patrol
###
###
#   Process : 
#   LABEL - JAVAHOME - postgresHOME - PORT - USERNAME - PASSWORD
#
#
####################
cd /produits/patrol/PATROL_AGT
. ./patrolrc.sh

PATROL_DIR=/produits/patrol/PATROL_AGT/config

LOG=${PATROL_DIR}/config_postgres.log
postgres_file_default=${PATROL_DIR}/config_standard_postgres


check_agent(){

    if [ `ps -ef |grep PatrolAgent |grep -v grep | grep -c 14451` != 1 ]
    then 
        sudo systemctl start patrol.service
    fi
    cpt=0
    while [ `pconfig +tcp +get -p 14451 | wc -l ` == 1 ] && [ $cpt != 6 ]
    do 
        sleep 10
        ((cpt++))
    done 
}

make_postgres () {


echo "Modification du fichier de configuration postgres" >>$LOG

}

add_postgres () {
  
  check_agent
	echo "Apply postgres configuration" >> $LOG 
	pconfig +tcp -p 14451 $postgres_file >> $LOG

}

restart_agt () {

  check_agent
	echo "Patrol Agent restarting" >> $LOG 
	pconfig +tcp -p 14451 +RESTART
}


rm_postgres () {

    echo "Modification du fichier de configuration postgres" >>$LOG

	sed -i -e "s/REPLACE.*}/DELETE }/g" $postgres_file
	sed -i -e "s/MERGE/DELETE/g" $postgres_file


}

USAGE ()
{
  echo
  echo "Usage: $progname <action> <args>*"
  echo "        action: Add ou Remove"
  echo "        args: "
  echo
  exit 1
}

echo `date` >>$LOG
echo "Launching script.." >>$LOG



while test -n "$1"; do
    case "$1" in
        --usage|-u)
            USAGE
            exit 0
            ;;
        -ACT)
            action_config=$2
            echo "Action : $action_config" >>$LOG 
            shift
            ;;
        *)
            echo "Argument inconnu: $1"
            print_usage
            exit 3
            ;;
    esac
    shift
done

postgres_file="${postgres_file_default}"

case ${action_config} in 
	Add)
        
		#Initialisation des fichiers de conf
		rm -f ${postgres_file} 
		cp ${postgres_file_default}.save ${postgres_file}	
		make_postgres
		add_postgres
		restart_agt
		;;
	Remove) 
		rm_postgres
		add_postgres
		restart_agt
		;;
	*)	 
		USAGE
        ;;
esac


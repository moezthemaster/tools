<h1> Role Syslog-ng Edge </h1>

 This ansible role allows you to :

  * Install package Syslog-ng, Open Source Edition (OSE)
  * Start the service
  * Send System logs to a Syslog-ng Gateway
  * Remove the installation




<h2> Requirements </h2>

  * Facts gathering shouldn't be disabled.
  * Target servers must be RHEL or CentOS 7.



<h2> Variables </h2>


<h3>state</h3>

<code>`required: True`</code>   <code>`default: "present"`</code>

    Action requested.

List of possible values :

|   State   | Description |
|:---------:|:-------- |
|  present  | Install Open version of Syslog-ng package   |
|  absent   | Remove current install   |
|   start   | Start Syslog-ng service   |
|   stop    | Stop the service   |
|  status   | Display status of the Syslog-ng service   |



<h3>hostname</h3>

<code>`required: True`</code>

    Name of the Hostname

    example value :
      hostname: "dsfalx001"



<h3>code_irt</h3>

<code>`required: True`</code>

    Code IRT



<h3>trigramme</h3>

<code>`required: True`</code>

    Trigram of the project.

    Code IRT and trigramme are concatenated and used by Kafka to store Logs in the DataLake of the BigData.



<h3>syslogng_version</h3>

<code>`required: False`</code>   <code>`default: "3.5.6-3.el7"`</code>

    Version of the package to install

    Version supported :
      * 3.5.6-3.el7 : Open Source Version from EPEL repository



<h3>enseigne</h3>

<code>`required: False`</code>   <code>`default: "bddf"`</code>

    Name of Client concerned.
    Used to configure the target Gateway that will receive messages.

 Values supported :

  * "bddf"
  * "cdn"



<h3>app_env</h3>

<code>`required: False`</code>   <code>`default: "dev"`</code>

    Environment where the Syslog-ng Client should be installed.
    Used to identify the target Gateway that will receive messages.

List of possible values :

|   Value   | Description |
|:---------:|:-------- |
|   "dev"   | Development  |
|   "hml"   | Homologation |
|   "prd"   | Production   |





<h2> Example Playbook </h2>

An example to execute all possible states on Syslog-ng role :

    - hosts: localhost
      connection: local
      gather_facts: yes

      roles:
        - { role: role_edge_syslog-ng, hostname: "dsfalx001", state: "present" }
        - { role: role_edge_syslog-ng, hostname: "dsfalx001", state: "start"   }
        - { role: role_edge_syslog-ng, hostname: "dsfalx001", state: "status"  }
        - { role: role_edge_syslog-ng, hostname: "dsfalx001", state: "stop"    }
        - { role: role_edge_syslog-ng, hostname: "dsfalx001", state: "absent"  }




<h2> Author Information </h2>

EDGE RET Automation Feature Team

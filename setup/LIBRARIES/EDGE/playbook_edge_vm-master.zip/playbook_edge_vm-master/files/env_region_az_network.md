Tableau de correspondance entre les paramètres ENV - REGION - AZ - NETWORK
-----------

| app_env  | vm_region                 | vm_az         |    vm_network    |
|:-------: |---------------------------|:-----:        |------------------|
|  dev     | EU France (Greater Paris) | eu-fr-paris-1 | CDN              |
|          |                           |               | CITS             |
|          |                           |               | CITS_2           |
|          |                           | eu-fr-paris-2 | CDN              |
|          |                           |               | CITS             |
|          |                           |               | FRONT_CCELL_LOW_BSC      |
|          |                           |               | TECH_CCELL_LOW_BSC       |
|          |                           |               | APP_FRONT_CCELL_LOW_ITIM |
|          |                           |               | TECH_CCELL_LOW_ITIM      |
|          | EU France (North)         | eu-fr-north-1 | CDN              |
|          |                           |               | CITS             |
|  hml     | EU France (Greater Paris) | eu-fr-paris-1 | CDN_HOB          |
|          |                           |               | CDN_HOT          |
|          |                           |               | L1_BACKEND       |
|          |                           |               | L1_COMMON        |
|          |                           |               | L1_SPECIFIC      |
|          |                           |               | L1_TECHNICAL     |
|          |                           |               | LEGACY_CDN       |
|          |                           |               | SHARED_SERVICES  |
|          |                           | eu-fr-paris-2 | APP_CCELL_LOW_ITIM       |
|          |                           |               | TECH_CCELL_LOW_ITIM      |
|          | EU France (North)         | eu-fr-north-1 | CDN_HOB          |
|          |                           |               | CDN_HOT          |
|          |                           |               | L1_BACKEND       |
|          |                           |               | L1_COMMON        |
|          |                           |               | L1_SPECIFIC      |
|          |                           |               | L1_TECHNICAL     |
|  prd     | EU France (Greater Paris) | eu-fr-paris-1 | CDN              |
|          |                           |               | L1_BACKEND       |
|          |                           |               | L1_COMMON        |
|          |                           |               | L1_SPECIFIC      |
|          |                           |               | L1_TECHNICAL     |
|          |                           |               | LEGACY_CDN       |
|          |                           |               | APP_BACK_CCELL_LOW_BSC   |
|          |                           |               | TECH_CCELL_LOW_BSC       |
|          |                           |               | APP_BACK_CCELL_LOW_ITIM  |
|          |                           |               | TECH_CCELL_LOW_ITIM      |
|          | EU France (North)         | eu-fr-north-1 | CDN              |
|          |                           |               | L1_BACKEND       |
|          |                           |               | L1_COMMON        |
|          |                           |               | L1_SPECIFIC      |
|          |                           |               | L1_TECHNICAL     |
|          |                           |               | LEGACY_CDN       |
|          |                           |               | SHARED_SERVICES  |

from edge.network.networkhelper import NetworkHelper
from edge.exception import EdgeException
import time


class TestNetworkHelper(object):
    def test_update_etc_host_ok(self):
        network_helper = NetworkHelper()
        reponse = ""
        try:
            reponse = network_helper.update_etc_host(ip_address='111.80.12.192', network_id='CDN')
        except EdgeException as e:
            assert e.args[0] == "dpgalx5900"
        assert reponse == "OK"

    def test_update_config_dns_ok(self):
        network_helper = NetworkHelper()
        reponse = ""
        try:
            reponse = network_helper.update_dns_config(ip_address='111.80.12.192', network_id='CDN',
                                                       geo_domain='ppr.cdn.socgen', network_envi='dev')
        except EdgeException as e:
            print(e.args[0])
        except Exception as e:
            print(e.args[0])
        assert reponse == "OK"

    def test_config_ntp_ok(self):
        network_helper = NetworkHelper()
        reponse = ""
        try:
            reponse = network_helper.configure_ntp(ip_address='111.80.12.192', network_id='CDN')
        except EdgeException as e:
            print(e.args[0])
        except Exception as e:
            print(e.args[0])
        assert reponse == "OK"

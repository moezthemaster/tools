#!/usr/bin/python
# -*- coding: utf-8 -*-

class WhatsError(Exception):
    def __init__(self, message, details=''):
        super(WhatsError, self).__init__('{} {}'.format(message, details))
        self.details = details


class ImproperlyConfigured(Exception):
    '''Whatsaw is somehow improperly configured'''
    pass


class RequestFailure(WhatsError):
    pass

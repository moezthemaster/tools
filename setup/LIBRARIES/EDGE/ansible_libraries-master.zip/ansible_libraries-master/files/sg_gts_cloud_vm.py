#!/usr/bin/env python
# -*- coding: utf-8 -*-

# (c) 2016, Danny AFAHOUNKO <danny.afahounko-ext@socgen.com>
#

DOCUMENTATION = '''
---
author: EDGE Automation - Feature team
        {
          Danny AFAHOUNKO
          Laurent VERBIESE
          Yanis BEKRAR
          Philippe GUFFROY
          Moez SELMI
          Hamouda LAYOUNI
          Hicham KASSAB
        }
module: sg_gts_cloud_vm
short_description: Manage GTS cloud vm
description:
  - This module creates or removes vm in GTS cloud.
version_added: "1.1"
options:

  name:
    description:
    - vm hostname
    required: true

  app_id:
    description:
    - vm trigram
    required: true

  app_env:
    description:
    - vm environment
    choices: ['dev','prd']
    default: prd
    required: false

  vm_profile:
    description:
    - vm size
    choices: ['Micro 1vCPU-1GB']
    default: Micro 1vCPU-1GB
    required: false

  ip_address:
    description:
    - vm ipv4 address
    required: true

  vm_subnet:
    description:
    - vm network
    required: true

  region:
    description:
    - vm region
    choices: ['EU France (Greater Paris)']
    default: EU France (Greater Paris) 
    required: false

  zone:
    description:
    - vm availability zone
    choices: ['eu-fr-paris-1']
    default: eu-fr-paris-1 
    required: false

  vm_desc:
    description:
    - vm description
    default: ''
    required: false

  vm_os:
    description:
    - vm operating system flavor
    choices: ['RHEL_7.2_x64-RET-EDGE','CENTOS_7.0_x64-RET-EDGE','RHEL_7.3_x64-RET-EDGE']
    default: RHEL_7.3_x64-RET-EDGE
    required: true

  vm_pubkey: 
      description:
      - add authorized keys
      default: ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEA43kkbWmmtCfZwjsXlmQbeTGOVMlDMA0njeo65Gs42VCElN1R8gHyQisgUZa6lWkWp3z0Asqzc0ApMQUODDUC2v+u7yU2y0zF8vVKxySm1ev0GlhbAG0Zowf5Q4I0XLEXsmOpMrXUG5GFMBuWSiMiWgPDyGCVgZjj7+MVjTrXIisjYTe40ZyUIGdtiboxkbBs1sbCG8vhha4VFUjTmkzkxiFgVzro08BCzlgZnACGSJWPFC88LE1NeOAGM/lfOmVuIC940zhJIxF09K4Prmd2HO7w2g3q/fSv9hHeX4loxPtOgbvQArLUyo/0aMf24BYgnYJoUqBw311hjKG+xLOpdw== x131489@PXPLUX20
      type: str
      required: False 
     
  data_disk:
    description:
    - vm data disk size
    default: '0'
    required: false

  state:
    choices: [ "present", "absent" ]
    default: present
    description:
    - Control if the vm exists or not.
    required: false

'''


EXAMPLES = '''
# Create a vm with the trigram CIN in DEV environment with ip address 192.88.68.140 within the subnet 192.88.64.0/21
- cloudvm: trigram=cin name=dcinlx099 ip=192.88.68.140 network=192.88.64.0/21 state=present

'''

# import module snippets
from ansible.module_utils.basic import *
import re
import json
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import ConfigParser
import time


##
import json
from collections import namedtuple
from ansible.parsing.dataloader import DataLoader
from ansible.vars import VariableManager
from ansible.inventory import Inventory
from ansible.playbook.play import Play
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.plugins.callback import CallbackBase
##


if "TREE_DIR" in os.environ.keys() : 
     ANSIBLE_MODULES_PATH = [
       './roles/ansible_libraries/files',  
       os.path.join(os.environ["TREE_DIR"], "library"),
        ]
else:
  ANSIBLE_MODULES_PATH = [
     './roles/ansible_libraries/files'
     ]
for path in ANSIBLE_MODULES_PATH:
  sys.path.append(path)

import sg_gts_tools.sg_gts_init

CONFIG_ROOT = '/etc/ansible'

GTS_CONFIG = 'gts_cloud_vm.cfg'


def default_config(params):


  isError, log, out = sg_gts_tools.sg_gts_init.read_settings(CONFIG_ROOT, GTS_CONFIG)

  global SETTINGS

  vOutput = {

    'url_root': out['TOKEN_urlroot'],
    'token_username': out['TOKEN_username'],
    'token_password': out['TOKEN_password'],
    'token_tenant': out['TOKEN_tenant'],
    'token_url': "{}{}" . format(out['TOKEN_urlroot'], out['TOKEN_urlsuffix']),
    'catalog_url': "{}{}" . format(out['TOKEN_urlroot'], out['CATALOG_catalogsuffix']),
    'catalog_consumer': "{}{}" . format(out['TOKEN_urlroot'], out['CATALOG_consumersuffix']),
    'catalog_query': "{}{}" . format(out['TOKEN_urlroot'], out['CATALOG_querysuffix']),
    'catalog_filter': out['CATALOG_filter'],
    'environment': params['app_env'],
  }

  SETTINGS.update( vOutput )

  vExtra = {

    'catalog_trigram': params['app_id'].upper(),
  }

  SETTINGS.update( vExtra )


  #SETTINGS.update( out )

  # RETURN
  return isError, log, out






def filter_bg_catalog_json(data):
  #Return BG catalog with value 'Get BG List From Trigram'
  vFilter={}
  vDetail={}
  vData=[]
  try:
    vJson = json.loads(json.dumps(data))
    for sItem in vJson['content']:
      catalogName = sItem['catalogItem']['name']
      #format catalog name
      catalogName = catalogName.replace(' ', '_').replace('_RET', '-RET').replace('_EDGE', '-EDGE').replace('_CLOUDCELL', '-CLOUDCELL')
      catalogId = sItem['catalogItem']['id']
      vDetail = {}
      for vItem in sItem['entitledOrganizations']:
        subtenantLabel = vItem['subtenantLabel']
        vDetail[subtenantLabel] = vItem

      vFilter[catalogName] = { 'id' : catalogId , 'subtenant': vDetail }

  except Exception, e:
    #pass
    vFilter={}

  return vFilter
      


def get_provider_json(data):

  vJson = []
  vProvider= {}
  try:
  
    for vData in data['values']['entries']:
      if vData['key'] == 'provider-BGResult':
        for bg in vData['value']['items']:
          vJson.append(bg['value'])
        vProvider['BGResult'] = vJson

      if vData['key'] == 'provider-__asd_requestedFor':
        vProvider['requestedFor'] = vData['value']['value']
  
      if vData['key'] == 'provider-__asd_requestedBy':
        vProvider['requestedBy'] = vData['value']['value']

      if vData['key'] == 'provider-trigram':
        vProvider['trigram'] = vData['value']['value']  

  except Exception, e:
    raise e

  return vProvider

def loop_until_successful(url, **kwargs):
  #
  #
  loopMax = 5
  
  sleepTime = 10

  headers = {'Content-type': 'application/json', 'Accept': 'application/json'}
  for key, value in kwargs.iteritems():
    headers.update({key:value})

  loopCount = 0
  data = {}
  requestCompletion = False

  while (not requestCompletion) or (loopCount < loopMax):
    try:

      codeStatus, output = sg_gts_tools.sg_gts_init.submit_url_json('get', url, data, **kwargs)

      if output['json']['requestCompletion']['requestCompletionState'] == "SUCCESSFUL":

        requestCompletion = True

    except Exception, e:
      pass

    loopCount +=1

    if loopCount >= loopMax:
      return codeStatus, output

    time.sleep(sleepTime)

  return codeStatus, output
    



def get_bg_catalog_json(**headerAuth):

  
  url = SETTINGS['catalog_url']
  data = {}

  statusCode, jsonOutput = sg_gts_tools.sg_gts_init.submit_url_json('get', url, data, **headerAuth)

  return filter_bg_catalog_json(jsonOutput['json'])



def get_vm_catalog_json(name, **headerAuth):

  
  url = SETTINGS['catalog_query']
  urlSuffix = "&$filter=(name%20eq%20'{}')" . format(name)
  data = {}

  url = "{}{}" . format(url, urlSuffix) 

  statusCode, jsonOutput = sg_gts_tools.sg_gts_init.submit_url_json('get', url, data, **headerAuth)

  return statusCode, jsonOutput['json']


def get_provider_bg_json(catalog, **headerAuth):
  
  

  url = SETTINGS['catalog_consumer']
  providerDefaultBusinessGroup = SETTINGS['catalog_filter']

  catalogItemRef = catalog[providerDefaultBusinessGroup]['id']
  subtenant = catalog[providerDefaultBusinessGroup]['subtenant'].keys()[0]
  subtenantRef = catalog[providerDefaultBusinessGroup]['subtenant'][subtenant]['subtenantRef']
  tenantRef = SETTINGS['token_tenant']
  trigram = SETTINGS['catalog_trigram']

  if 'prd' in SETTINGS['environment']:
    bg_env = "PRD"
  else:
    bg_env = "non-PRD"

  f=open("/tmp/toto", "w")
  f.write("bg env {}\n".format(bg_env))
  f.close()

  data = { "@type": "CatalogItemRequest", "catalogItemRef": { "id": catalogItemRef  },  "organization": {    "tenantRef": tenantRef,    "subtenantRef": subtenantRef  },  "state": "SUBMITTED",  "requestNumber": 0,  "requestData": {    "entries": [      {        "key": "provider-trigram",        "value": {          "type": "string",          "value": trigram }},{ "key": "provider-restrictedTo", "value": { "type": "string", "value": "RET" }},{ "key": "provider-environment", "value": { "type": "string", "value": bg_env } } ] }}

  statusCode, jsonOutput = sg_gts_tools.sg_gts_init.submit_url_json('post', url, data, **headerAuth)

  url = jsonOutput['headers']['location']

  statusCode, jsonOutput = loop_until_successful(url, **headerAuth)

  data = {}

  url = "{}/forms/details" . format(url)

  statusCode, jsonOutput = sg_gts_tools.sg_gts_init.submit_url_json('get', url, data, **headerAuth)

  provider = get_provider_json(jsonOutput['json'])


  return provider


def create_vm(params, catalog, provider, **headerAuth):

  descriptionPrefix = "[EDGE] "
  
  # Should come from ansible params

  providerOSName = params['vm_os']
  
  providerBusinessGroup = provider['BGResult'][0]
  catalogItemRef = catalog[providerOSName]['id']

  tenantRef = catalog[providerOSName]['subtenant'][providerBusinessGroup]['tenantRef']
  subtenantRef = catalog[providerOSName]['subtenant'][providerBusinessGroup]['subtenantRef']
  
  requestedFor = provider['requestedFor']
  providerOwner = provider['requestedBy']
  providerNbMachine = 1
  providerLeaseDays = 0
  providerTrigram = params['app_id'].upper()
  providerEnvironment = params['app_env'].upper().replace('HML', 'UAT')
  providerVMSize = params['vm_profile']
  providerDataDiskSize = params['data_disk']
  providerDescription = descriptionPrefix + params['vm_desc']
  providerHostname = params['vm_hostname']
  providerIP = params['ip_address']
  providerRegion = params['vm_region']
  providerAvailabilityZone = params['vm_az']
  providerNetwork = params['vm_subnet']
  providerReplication = params['vm_backup']


  url = SETTINGS['catalog_consumer']

  createVmInputs = { "@type": "CatalogItemRequest", "catalogItemRef": { "id": catalogItemRef },   "organization": {  "tenantRef": tenantRef,  "subtenantRef": subtenantRef   }, "requestedFor": requestedFor, "state": "SUBMITTED", "requestNumber": 0,  "requestData": {  "entries": [ { "key": "requestedFor", "value": { "type": "string",  "value": requestedFor }  }, { "key": "provider-Owner", "value": { "type": "string",  "value": providerOwner } }, { "key": "provider-BusinessGroup", "value": { "type": "string","value": providerBusinessGroup }},{"key": "provider-NbMachine","value": {"type": "decimal","value": providerNbMachine}},{ "key": "provider-LeaseDays", "value": {"type": "decimal","value": 0}},{"key": "provider-Trigram","value": {"type": "string","value": providerTrigram}},{"key": "provider-Environment","value": {"type": "string","value": providerEnvironment}},{"key": "provider-Backup","value": {"type": "string","value": "none"}},{"key": "provider-OSName","value": {"type": "string",  "value": providerOSName } },{"key": "provider-VMSize", "value": {"type": "string","value": providerVMSize } }, {"key": "provider-DataDiskSize", "value": { "type": "decimal", "value": providerDataDiskSize }},{"key": "provider-Description",  "value": {  "type": "string","value": providerDescription } }, { "key": "provider-Hostname", "value": { "type": "string",  "value": providerHostname } }, {  "key": "provider-IP", "value": {  "type": "string",  "value": providerIP }  },  {  "key": "provider-Region", "value": { "type": "string", "value": providerRegion } }, {  "key": "provider-AvailabilityZone","value": {  "type": "string", "value": providerAvailabilityZone } }, { "key": "provider-Customer", "value": { "type": "string",  "value": "RET" } }, { "key": "provider-Network", "value": {  "type": "string", "value": providerNetwork } }, { "key": "provider-Replication", "value": {  "type": "boolean", "value": providerReplication } }  ]   }}

  statusCode, jsonOutput = sg_gts_tools.sg_gts_init.submit_url_json('post', url, createVmInputs, **headerAuth)

  #LOGGING
  #jsonLog = data

  url = jsonOutput['headers']['location']


  #statusCode, jsonOutput = loop_until_successful(url, **headerAuth)


  return statusCode, jsonOutput['json'], createVmInputs, url


def get_vm_destroy_id(output):

  data = {}

  try:

    data['id'] = output['content'][0]['id']
    data['name'] = output['content'][0]['name']
    data['organization'] = output['content'][0]['organization']
    
    for sItem in output['content'][0]['operations']:

      if sItem['bindingId'] == "Infrastructure.Virtual.Action.Destroy":

        data['destroy'] = sItem

  except Exception, e:
    pass

  return data


def destroy_vm(data, **headerAuth):

  
  url = SETTINGS['catalog_consumer']

  try:
    
    vmId = data['id']
    operationId = data['destroy']['id']
    tenantRef = data['organization']['tenantRef']
    tenantLabel = data['organization']['tenantLabel']
    subtenantRef = data['organization']['subtenantRef']
    subtenantLabel = data['organization']['subtenantLabel']

    data = {
      "@type": "ResourceActionRequest",
      "resourceRef": {
        "id": vmId
      },
      "resourceActionRef": {
        "id": operationId
      },
      "organization": {
        "tenantRef": tenantRef,
        "tenantLabel": tenantLabel,
        "subtenantRef": subtenantRef,
        "subtenantLabel": subtenantLabel
      },
      "state": "SUBMITTED",
      "requestNumber": 0,
      "requestData": {
        "entries": []
      }

    }

    statusCode, jsonOutput = sg_gts_tools.sg_gts_init.submit_url_json('post', url, data, **headerAuth)

  except Exception, e:
    statusCode = 404
    jsonOutput = {}



  return statusCode, jsonOutput



def cloud_vm_present(params):


  result = {}
  isError = False
  hasChanged = False

  result['pubkey'] = params['vm_pubkey']

  #TOKEN
  token = { 'Authorization': "Bearer {}" . format(params['token']) }


  #GET VM CATALOG
  status, output = get_vm_catalog_json(params['vm_hostname'], **token)

  # IF VM exists then exit

  try:

    if int(output['metadata']['totalElements']) > 0:

      result['output'] = output
      result['url'] = SETTINGS['catalog_query']
      return isError, hasChanged, result

  except Exception, e:
    pass


  hasChanged = True

  #GET BG CATALOG
  allBusinessGroup = get_bg_catalog_json(**token)

  # GET BG PROVIDER
  providerBG = get_provider_bg_json(allBusinessGroup, **token)

  # CREATE VM
  status, output, logs, url = create_vm(params, allBusinessGroup, providerBG, **token)




  result['logs'] = logs
  result['output'] = output
  result['location'] = url
  result['url'] = SETTINGS['catalog_query']
  #result['BusinessGroup'] = providerBG  
  #result['Catalog'] = allBusinessGroup
  




  return isError, hasChanged, result


def cloud_vm_absent(params):

  
  result = {}
  isError = False
  hasChanged = False
  #$filter=(name%20eq%20'dcinlx95')

  #TOKEN
  token = { 'Authorization': "Bearer {}" . format(params['token']) }

  #GET VM CATALOG
  status, output = get_vm_catalog_json(params['vm_hostname'], **token)
  destroyOp = get_vm_destroy_id(output)

  tmpOutput = output

  hasChanged = True

  status, output = destroy_vm(destroyOp, **token)



  result['output'] = output
  result['url'] = SETTINGS['catalog_consumer']
  result['pubkey'] = params['vm_pubkey']
  result['logs'] = tmpOutput
  
  return isError, hasChanged, result





def main():

  fields = { 

     "token": {"required": True, "type": "str"},

     "app_id": {"required": True, "type": "str"},

     "vm_hostname": {"required": True, "type": "str"},
     
     "vm_desc": {
        "required": False, 
        "default": " ", 
        "type": "str"
      },

     "app_env": {
        "default": "prd",
        "choices": ['dev', 'hml', 'prd'],
        "type": "str",
        "required": False, 
     },

     "vm_profile": {
        "default": "Micro 1vCPU-1GB",
        "choices": ['Micro 1vCPU-1GB', 'Small 1vCPU-2GB', 'Small-mem4 1vCPU-4GB', 'Medium-mem2 2vCPU-2GB', 'Medium 2vCPU-4GB', 'Medium-mem8 2vCPU-8GB', 'Medium-mem16 2vCPU-16GB', 'Medium-mem32 2vCPU-32GB', 'Large 4vCPU-8GB', 'Large-mem16 4vCPU-16GB', 'Large-mem32 4vCPU-32GB', 'XLarge 8vCPU-16GB', 'XLarge-mem32 8vCPU-32GB', 'XLarge-mem64 8vCPU-64GB', 'XLarge-mem128 8vCPU-128GB'],
        "type": "str",
        "required": False, 
     },

     "ip_address": {"required": True, "type": "str"},

     "vm_subnet": {"required": True, "type": "str"},

     "vm_region": {
        "default": "EU France (Greater Paris)",
        "choices": ['EU France (Greater Paris)', 'EU France (North)'],
        "type": "str",
        "required": False, 
     },

     "vm_az": {
        "default": "eu-fr-paris-1",
        "choices": ['eu-fr-paris-1', 'eu-fr-paris-2', 'eu-fr-north-1'],
        "type": "str",
        "required": False, 
     },

     "vm_os": {
        "default": "RHEL_7.3_x64-RET-EDGE",
        "choices": ['RHEL_7.3_x64-RET-EDGE','RHEL_7.2_x64-RET-EDGE', 'RHEL_7.2_x64-CLOUDCELL-RET-EDGE', 'CENTOS_7.0_x64-RET-EDGE'],
        "type": "str",
        "required": False, 
     },

     "vm_pubkey": {
        "default": "",
        "type": "str",
        "required": False, 
     },

     "data_disk": {
        "default": 0,
        "type": "int",
        "choices": [0,20,60,160,300,500,750,1000,2000],
        "required": False, 
     },

     "vm_backup": {
        "default": False,
        "type": "bool",
        "required": False, 
     },

     "state": {
        "default": "present",
        "choices": ['present', 'absent'],
        "type": "str",
     },
  }


  choice_map = {
     "present": cloud_vm_present,
     "absent": cloud_vm_absent,
  }



  module = AnsibleModule(argument_spec=fields)

  #Config settings
  isError, logOutput, output = default_config(module.params)

  if isError:
    module.fail_json(msg=logOutput)


  #state  
  isError, hasChanged, result = choice_map.get( module.params['state'])(module.params)

  if not isError:
    module.exit_json(changed=hasChanged, meta=result)

  else:
    module.fail_json(msg="Error request cannot be completed", meta=result)


"""
"""
SETTINGS = {}

if __name__ == '__main__':
  main()


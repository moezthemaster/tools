#!/bin/bash
readonly PROGNAME=$(basename $0)

usage="${PROGNAME} virtualenv_user virtualenv_user_home playbook_version
where:
    -h, --help
        Show this help text
examples:
    ${PROGNAME} edgpadm /applis/edgp 8.0.0"

if [ $# -eq 0 ]; then
  echo "$usage"
  exit 1
fi
echo $1
echo $2
ansible-playbook deploy_virtualenv.yml -e "user_run=$1 user_home=$2 playbook_version=$3"
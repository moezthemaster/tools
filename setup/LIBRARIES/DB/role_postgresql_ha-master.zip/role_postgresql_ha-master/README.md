Role Postgresql HA
=========

Create a Postgresql Database Cluster and let you execute some admin tasks such as :
 * Creating a Postgresql Database Cluster. Version 9.4 & 9.5 are available.
 * Start / Stop / Reload Postgresql Service
 * Start / Stop Virtual IP adress
 * Start / Stop Pgbouncer connection pooler on the VIP
 * Switchover the master and standby nodes of the cluster
 * Start / Stop Repmgrd daemon for automatic failover
 * After a failover, reintegrate the old master as a standby in the cluster
 * Cleanup monitoring Repmgrd daemon table 
 * Backup your instance and purge WALs
 * Exporting all the cluster or a Database in a compressed dumpfile
 * Listing dumpfiles
 * Importing a Database from a dumpfile


For using this role you have to use TAGS to execute the following actions :
 1. __create__ : 
   * installing requested packages 
   * create Group and User Postgres
   * adding rights for user Postgres in sudoers
   * creating & enabling the Postgresql.service
   * installing repmgr
   * installing pgbouncer
   * creating and starting the virtual IP address

 2. __configure__ :
   * creating a Postgresql Cluster if it doesn't exists
   * creating a Host Based Authentication configuration file (pg_hba.conf)
   * creating a Postgresql configuration file (postgresql.conf)
   * starting the Postgresql Service
   * creating one or more Databases
   * remove the fact that any role is allowed to create object in Public Schema in the created Databases
   * granting all privileges to the applicative user under its database
   * creating a remote user that will only have Select privilege on the created Databases
   * adding extensions if they are specified for each Databases
   * creating the repmgr configuration
   * registering the master database in the cluster
   * cloning the slaves databases from the master
   * registering the slaves databases in the cluster
   * creating the pgbouncer configuration file 
   * creating the pgbouncer userlist
   * creating the backup script

 3. __start__ :
   * starting Postgresql service 
   * starting the virtual IP address
   * starting pgbouncer

 4. __start_repmgrd__ :
   * starting Repmgrd for automatic failover feature

 5. __stop__ :
   * stoping pgbouncer
   * stoping the virtual IP address
   * stoping Postgresql service 

 6. __stop_repmgrd__ :
   * stoping Repmgrd for automatic failover feature

 7. __reload__ :
   * reloading postgresql

 8. __status__ :
   * status of the postgresql instance

 9. __delete__ :
  * stopping Postgresql Service
  * removing directories under /bases/pgsql
  * removing packages that were installed

 10. __switchover__ :
   * switchover the master and the standby instances (standby become the new master and master become a standby)

 11. __convert_to_standby_old_master__ :
   * After a failover, once the old master is come back, convert it to a standby for following the new master

 12. __cleanup_repmgrd__ :
   * cleanup the monitoring table of repmgrd

 13. __export__ :
   * export all the cluster with pg_dumpall on the master
   * export a database of the cluster with pg_dump on the master
  
 14. __export_list__ :
   * list the export files on the master
   
 15. __export_remove__ :
   * remove an export file of the dump directory on all the cluster

 16. __configure_backup__ :
   * create the backup script
   * configure the backup externalize methode by creating the right script(s) ("dsmc", "had", "all")

 17. __create_supervision__ :
   * create the supervision script

This role is developped for SOFA, PAAP projects and Big Data. 
Some updates may have to be done for other needs, you could contact us by creating an issue, using our email: FR-FR-RET-ODB-L3@socgen.com, or Fork it and pulling a request.

If you want to collaborate, please read the following :  
[Contributing.md](CONTRIBUTING.md)
And
[Git best practices](https://sgithub.fr.world.socgen/GTSMKTSSB/GitBestPractices)

Requirements
------------
Facts gathering shouldn't be disabled.

Target servers must be RHEL7.


Role Variables
--------------

Here are the requested values for each TAG :

__create__
- postgresql_cluster_name
- postgresql_version ("9.4" or "9.5")

__configure__
- cluster_applicative_address
- cluster_vlan_prefix
- cluster_virtual_interface
- cluster_vlan_id
- db_list:
  - { db_name
      db_user
      db_password
      remote_db_password
      db_extensions
    }
- postgresql_cluster_name
- postgresql_encoding [(cf. Character Set Support)](https://www.postgresql.org/docs/9.5/static/multibyte.html)          
- postgresql_extensions
- postgresql_group
- postgresql_locale 
- postgresql_port           
- postgresql_user
- postgresql_user_home
- postgresql_version
- repmgr_failover ("automatic" or "manual")

- You can override these values :
  - db_extensions (default = "")
  - postgresql_max_connections (default = 100)
  - postgresql_shared_buffers (default = "256MB")  
  - postgresql_wal_keep_segments (default = 20)
  - repmgr_keep_history (default = 5)
  - repmgr_master_response_timeout (default = 10)
  - repmgr_monitor_interval_secs (default = 2)
  - repmgr_reconnect_attempts (default = 5)
  - repmgr_reconnect_interval (default = 8)
  - repmgr_version (default 3.2.1)

__configure_backup__
- postgresql_backup_path
- pg_backup_externalize_methode ("dsmc", "had", "all")
- pg_backup_path_to_externalize_backupfile ("had", "all")

__delete__
- postgresql_version
- You must overwrite this value to validate the decomissioning :
  - validate_decomissioning: yes (default = no)

__start__
- postgresql_version

__start_repmgrd__
- postgresql_version

__stop.yml__
- postgresql_version

__stop_repmgrd__
- postgresql_version

__switchover.yml__
- postgresql_version

__convert_to_standby_old_master__
- cluster_applicative_address
- postgresql_port
- postgresql_version

__cleanup_repmgrd__
- postgresql_port
- postgresql_version

__backup__
- postgresql_cluster_name
- postgresql_port
- postgresql_version

__export__
- postgresql_version
- postgresql_port
- pg_dump_type ( "all" or "database" )
- pg_dump_directory
- postgresql_cluster_name ( for all type )
- postgresql_db_name ( for database type )
- postgresql_db_user ( for database type )

__export_list__
- pg_dump_directory

__export_remove__
- pg_dump_directory
- pg_dump_filename


Dependencies
------------
None


Example Inventory
-----------------

`~/inventory/inventory.yml`:

```yml
[pg_cluster_ha:children]
pg_cluster_ha_master
pg_cluster_ha_slave

[pg_cluster_ha_master]
host01 node_num=1

[pg_cluster_ha_slave]
host02 node_num=2
```

Example Playbook 
----------------

`~/deploy_pg_cluster_ha.yml`:

```yml
  - hosts: pg_cluster_ha
    gather_facts: yes
    roles:
    - { role: role_postgresql_ha,
         postgresql_version: "{{ postgres_version }}",
         postgresql_cluster_name: "{{ cluster_name }}",
         postgresql_device_vg: "{{ vg_name }}",
         postgresql_cluster_install_size: "{{ cluster_install_size }}",
         postgresql_cluster_log_size: "{{ cluster_log_size }}",
         postgresql_cluster_wal_size: "{{ cluster_wal_size }}",
         postgresql_cluster_backup_size: "{{ cluster_backup_size }}",
         postgresql_encoding: "{{ cluster_encoding }}",
         postgresql_locale: "{{ cluster_locale }}",
         postgresql_extensions: "{{ db_extensions }}"
      }
```

Example variables
-----------------

Some example values that can be specified in a group_vars file : 
`~/group_vars/pg_cluster_ha.yml`

```yml
vg_name: "<AppliVG>"
cluster_name: "<ENV><TRI><ENV><TRI>"
cluster_install_size: "10g"
cluster_log_size: "3g"
cluster_wal_size: "5g"
cluster_backup_size: "10g"

postgres_version: "9.5"
cluster_encoding: "UTF8"
cluster_locale: "fr_FR.UTF8"

# specify the network interface ex : bond0.3292:0
cluster_vlan_prefix: "bond0."
cluster_vlan_id: "3292"
cluster_virtual_interface: "0"
cluster_applicative_address: "X.X.X.X"
cluster_network_subnet: "X.X.X.0"
cluster_netmask: "X.X.X.0"
cluster_gateway: "X.X.X.254"

# Specify extensions that will be loaded at DB startup (modules or extensions separated with a coma) ; 
# In case you want to use repmgrd for automatic failover, don't forget to add the repmgr_funcs extension
# example :

db_extensions: "plpgsql,pg_stat_statements,repmgr_funcs"

db_list:
  - { db_name: "db1",
      db_user: "user1",
      db_password: "xxxx",
      remote_db_password: "xxxx",
      db_extensions: ["plpgsql","pg_stat_statements"]
    }
  - { db_name: "db2",
      db_user: "user2",
      db_password: "xxxx",
      remote_db_password: "xxxx",
      db_extensions: ["plpgsql","pg_stat_statements"]
    }
  - { db_name: "db3",
      db_user: "user3",
      db_password: "xxxx",
      remote_db_password: "xxxx",
      db_extensions: ["plpgsql","pg_stat_statements"]
    }

```

Example script shell to execute the actions
-------------------------------------------
```bash
#!/bin/bash
ansible-playbook -i inventory/inventory.yml -c paramiko --tags "create,configure" deploy_pg_cluster_ha.yml
```

License
-------
[![CC0](https://www.usenix.org/legacy/events/usenix04/art/build_icons/bsd.gif)] (https://fr.wikipedia.org/wiki/Licence_BSD)

Author Information
------------------

AZEMA Mickael & GUFFROY Philippe & DELEFORTERIE Eric

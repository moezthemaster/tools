import os
import sys
import logging
import io
import datetime

if "TREE_DIR" in os.environ.keys():
    ANSIBLE_MODULES_PATH = [
        os.path.join(os.environ["TREE_DIR"], 'roles/edge'),
        os.path.join(os.environ["TREE_DIR"], 'roles/incubaw'),
        os.path.join(os.environ["TREE_DIR"], "library"),
        os.path.join(os.environ["TREE_DIR"], 'roles/py_edge_vault'),

    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/edge',
        './roles/incubaw',
        './roles/py_edge_vault'
    ]
for path in ANSIBLE_MODULES_PATH:
    sys.path.append(path)

from ansible.module_utils.basic import AnsibleModule

from incubaw.kataw import Kataw
from edge.kpi.elk import Loader
from edge.interfaces import Kat
from edge.kat.service import KatService


formatter = logging.Formatter(fmt='%(asctime)s %(levelname)-8s %(message)s',
                              datefmt='%Y-%m-%d %H:%M:%S')
logstream = io.StringIO()
handler = logging.StreamHandler(logstream)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.addHandler(handler)
logger.setLevel(logging.WARNING)


class KatImpl(Kat):
    def __init__(self):
        self.kataw = Kataw()

    def get_single_component_data(self, trigram, irt_code):
        return self.kataw.get_single_component_data(trigram, irt_code)


class KatServiceImpl(KatService, KatImpl):
    pass


FIELDS = {
    "app_id": {
        "required": False,
        "type": "str"
    },
    "code_irt": {
        "required": False,
        "type": "str"
    },
    "kpi_data": {
        "type": "dict"
    },
    "state": {
        "default": "present",
        "choices": ['present'],
        "type": "str"
    },
    "endClient": {
        "required": False,
        "type": "str"
    }
}

def index_error_kpi(kpi_data,kpi_start_time):
    try:
        kpi_end_time = datetime.datetime.now()
        kpi_data['duration'] = (kpi_end_time - kpi_start_time).seconds
        loader = Loader()
        loader.index_data(
            id_execution=kpi_data['id_execution'], timestamp=kpi_data['timestamp'], 
            duration=kpi_data['duration'], service="sg_gts_kat2",
            hostname=kpi_data['vm_hostname'], status="failure",
            category=kpi_data['category'], client=kpi_data['endClient'],
            trigram=kpi_data['app_id'], environment=kpi_data['app_env'],
            error=kpi_data['error'], playbook_version=kpi_data['playbook_version']
        )
    except Exception:
        pass

def main():
    module = AnsibleModule(argument_spec=FIELDS)
    if module._verbosity == 1:
        logger.setLevel(logging.INFO)
    if module._verbosity == 3:
        logger.setLevel(logging.DEBUG)
    logger.info('module sg_gts_kat2 called')
    kpi_start_time = datetime.datetime.now()
    try:
        trigram = module.params['app_id']
        irt_code = module.params['code_irt']
        default_client = module.params['endClient']
        kpi_data = module.params['kpi_data']
        ks = KatServiceImpl()
        client = ks.get_client(trigram, irt_code, default_client)
        module.exit_json(changed=False, meta=client, debug_out=logstream.getvalue())
    except Exception as e:
        if isinstance(kpi_data, dict):
            kpi_data["error"] = e.args[0]
            index_error_kpi(kpi_data,kpi_start_time)
        module.fail_json(msg=e.args[0], debug_out=logstream.getvalue())


if __name__ == '__main__':
    main()

#!/usr/bin/python
# -*- coding: utf-8 -*-

# (c) 2017, Yanis BEKRAR <yanis.bekrar@socgen.com>
#

DOCUMENTATION = '''
---


'''

EXAMPLES = '''
# Create 

'''

# import module snippets
from ansible.module_utils.basic import *
import re
import json
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from requests.auth import HTTPBasicAuth
import ConfigParser
import time
import datetime
import random
import string
import yaml


if "TREE_DIR" in os.environ.keys() : 
     ANSIBLE_MODULES_PATH = [
       './roles/ansible_libraries/files',  
       os.path.join(os.environ["TREE_DIR"], "library"),
        ]
else:
  ANSIBLE_MODULES_PATH = [
     './roles/ansible_libraries/files'
     ]

for path in ANSIBLE_MODULES_PATH:
  sys.path.append(path)

import sg_gts_tools.sg_gts_init

CONFIG_ROOT = "/etc/ansible"
for path in ANSIBLE_MODULES_PATH:
  if os.path.exists(os.path.join(path, 'config')):
       CONFIG_ROOT = os.path.join(path, 'config')
       
#CONFIG_ROOT = './roles/ansible_libraries/files/config'

GTS_CONFIG = 'gts_kat.cfg'




def default_config(params):


  isError, log, out = sg_gts_tools.sg_gts_init.read_settings(CONFIG_ROOT, GTS_CONFIG)
  global SETTINGS

  vOutput = {


    'catalog_url': "{}{}" . format(out['PRD_urlroot'], out['CATALOG_catalogsuffix']),
    'catalog_query': "{}{}" . format(out['PRD_urlroot'], out['CATALOG_querysuffix']),
    'catalog_login' : "{}" . format(out['AUTH_username']),

  }


  SETTINGS.update( vOutput )

  # RETURN
  return isError, log, out





def get_kat_info(params):


  result = {}
  isError = False
  hasChanged = False

  
  #GET KAT REQUEST CATALOG
  url = SETTINGS['catalog_query']
  url = url.replace(':tri',params['app_id'])
  url = url.replace(':irt',params['code_irt'])
  url = url.replace(':login',SETTINGS['catalog_login'])

  data = {}


  status, output = sg_gts_tools.sg_gts_init.submit_url_json('get', url, data)

  result['json'] = output
  result['code_status'] = status


  return isError, hasChanged, result




def main():

  fields = { 

     "app_id": {"required": False, "type": "str"},
     "code_irt": {"required": False, "type": "str"},
     
     "state": {
        "default": "present",
        "choices": ['present'],
        "type": "str"
     },
  }



  choice_map = {
     "present": get_kat_info,
  }



  module = AnsibleModule(argument_spec=fields)

  #Config settings
  isError, logOutput, output = default_config(module.params)
 # isError, logOutput, output = default_config("toto")

  if isError:
    module.fail_json(msg=logOutput)

  #state  
  isError, hasChanged, result = choice_map.get( module.params['state'])(module.params)

  if not isError:
    module.exit_json(changed=hasChanged, meta=result)

  else:
    module.fail_json(msg="Error request cannot be completed", meta=result)


"""
"""
SETTINGS = {}

if __name__ == '__main__':
  main()


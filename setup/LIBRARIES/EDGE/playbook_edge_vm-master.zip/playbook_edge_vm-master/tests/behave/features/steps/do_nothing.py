#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
import socket

@when('do nothing')
def step_impl(context):
      assert context.failed is False
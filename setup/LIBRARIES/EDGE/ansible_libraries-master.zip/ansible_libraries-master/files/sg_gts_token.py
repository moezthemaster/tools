#!/usr/bin/env python
# -*- coding: utf-8 -*-

# (c) 2016, Danny AFAHOUNKO <danny.afahounko-ext@socgen.com>
#

DOCUMENTATION = '''
---
author: EDGE Automation - Feature team
        {
          Danny AFAHOUNKO
          Laurent VERBIESE
          Yanis BEKRAR
          Philippe GUFFROY
          Moez SELMI
          Hamouda LAYOUNI
          Hicham KASSAB
        }
module: sg_gts_cloud_vm
short_description: Manage GTS cloud vm
description:
  - This module creates or removes vm in GTS cloud.
version_added: "1.1"
options:

  

  state:
    choices: [ "present", "absent" ]
    default: present
    description:
    - Control if the vm exists or not.
    required: false

'''


EXAMPLES = '''
# Create a vm with the trigram CIN in DEV environment with ip address 192.88.68.140 within the subnet 192.88.64.0/21
- cloudvm: trigram=cin name=dcinlx099 ip=192.88.68.140 network=192.88.64.0/21 state=present

'''

# import module snippets
from ansible.module_utils.basic import *
import re
import json
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import ConfigParser
import time


##
import json
from collections import namedtuple
from ansible.parsing.dataloader import DataLoader
from ansible.vars import VariableManager
from ansible.inventory import Inventory
from ansible.playbook.play import Play
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.plugins.callback import CallbackBase
##

if "TREE_DIR" in os.environ.keys() : 
     ANSIBLE_MODULES_PATH = [
       './roles/ansible_libraries/files',  
       os.path.join(os.environ["TREE_DIR"], "library"),
        ]
else:
  ANSIBLE_MODULES_PATH = [
     './roles/ansible_libraries/files'
     ]

for path in ANSIBLE_MODULES_PATH:
  sys.path.append(path)

import sg_gts_tools.sg_gts_init

CONFIG_ROOT = '/etc/ansible'

GTS_CONFIG = 'gts_cloud_vm.cfg'



def default_config(params):


  isError, log, out = sg_gts_tools.sg_gts_init.read_settings(CONFIG_ROOT, GTS_CONFIG)

  global SETTINGS

  vOutput = {

    'url_root': out['TOKEN_urlroot'],
    'token_username': out['TOKEN_username'],
    'token_password': out['TOKEN_password'],
    'token_tenant': out['TOKEN_tenant'],
    'token_url': "{}{}" . format(out['TOKEN_urlroot'], out['TOKEN_urlsuffix']),

  }

  SETTINGS.update( vOutput )

  #SETTINGS.update( out )

  # RETURN
  return isError, log, out




def get_token_json():

  isError = False
  token = "DEFAULT_NONE_VALID_TOKEN"

  # Get Token ID
  url = SETTINGS['token_url']
  data = { 
      "username" : SETTINGS['token_username'], 
      "password" : SETTINGS['token_password'], 
      "tenant" : SETTINGS['token_tenant'] 
    }

  statusCode, output = sg_gts_tools.sg_gts_init.submit_url_json('post', url, data)

  if statusCode == 200 :

    try:

      token = output['json']['id']
        
    except Exception, e:

      isError = True

  else:
    
    isError = True
        
  return isError, token



def destroy_token_json(token):

  isError = False

  # Get Token ID
  url = "{}/{}" .format(SETTINGS['token_url'], token)

  headerAuth = { 
      "Authorization" : "Bearer {}" . format(token),
      }

  statusCode, output = sg_gts_tools.sg_gts_init.submit_url_json('delete', url, {}, **headerAuth)

  if statusCode != 204 :

    isError = True


  return isError, output



def cloud_token_present(params):


  result = {}
  isError = False
  hasChanged = False


  #TOKEN
  isError, token = get_token_json()
  if isError:
    result['output'] = "Oops! Token request failed"
  else:
    hasChanged = True
    result['token'] = token
    result['headerAuth'] = { 'Authorization': "Bearer {}" . format(token) }
    #result['log'] = SETTINGS
   
    

  return isError, hasChanged, result


def cloud_token_absent(params):

  
  result = {}
  isError = False
  hasChanged = False


  #TOKEN
  isError, output = destroy_token_json(params['token'])

  if isError:
  
    result['output'] = "Oops! Cannot destroy the Token"
    result['debug'] = output
  
  else:
  
    hasChanged = True
    result['token'] = output
    
    
  return isError, hasChanged, result




def main():

  fields = { 

     "state": {
        "default": "present",
        "choices": ['present', 'absent'],
        "type": "str",
     },

     "token": {
        "default": "none",
        "required": False,
        "type": "str",
     },
  }


  choice_map = {
     "present": cloud_token_present,
     "absent": cloud_token_absent,
  }



  module = AnsibleModule(argument_spec=fields)

  #Config settings
  isError, logOutput, output = default_config(module.params)

  if isError:
    module.fail_json(msg=logOutput)


  #state  
  isError, hasChanged, result = choice_map.get( module.params['state'] )(module.params)

  if not isError:
    module.exit_json(changed=hasChanged, meta=result)

  else:
    module.fail_json(msg="Error - The request failed", meta=result)


"""
"""
SETTINGS = {}

if __name__ == '__main__':
  main()


# role_edge_vm_infos

This role displays OS version and system patch level of a virtual machine in the cloud.

Requirements
------------

The VM shoud exist in the cloud

Dependencies
------------
None

Example Playbook
----------------
```yaml
- hosts: your_server
  roles:
    - { role: role_edge_vm_infos }
```

result must be something like this:
```
TASK [role_edge_vm_infos : debug] **********************************************
ok: [your_server] => {
    "msg": "VM OS: CentOS 7.5.1804"
}

TASK [role_edge_vm_infos : debug] **********************************************
ok: [your_server] => {
    "msg": "VM patch level: 201822"
}

```

Author Information
------------------

Feature Team EDGE
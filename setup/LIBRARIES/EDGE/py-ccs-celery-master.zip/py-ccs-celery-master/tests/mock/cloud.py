#!/usr/bin/python
# -*- coding: utf-8 -*-
import uuid
import json


class VmDatabase(object):

    BG_LIST = [
        {
        "@type": "ConsumerEntitledCatalogItem",
        "catalogItem": {
            "callbacks": {
                "itemInformation": False,
                "itemInitialize": False,
                "rollback": False,
                "validate": False
            },
            "catalogItemTypeRef": {
                "id": "com.vmware.csp.core.designer.service.serviceblueprint",
                "label": "XaaS Blueprint"
            },
            "dateCreated": "2015-11-26T11:50:06.532Z",
            "description": "This workflow returns all the BGs associated to a trigram.",
            "forms": {
                "catalogRequestInfoHidden": True,
                "itemDetails": {
                    "formId": "com.vmware.csp.core.designer.service.serviceblueprint_ServiceBlueprint.Details",
                    "type": "external"
                },
                "requestDetails": {
                    "formId": "com.vmware.csp.core.designer.service.serviceblueprint_Request.Details",
                    "type": "external"
                },
                "requestFormScale": "BIG",
                "requestPostApproval": None,
                "requestPreApproval": None,
                "requestSubmission": {
                    "formId": "com.vmware.csp.core.designer.service.serviceblueprint_Request.Submit",
                    "type": "external"
                }
            },
            "iconId": "5e535eb1-0bd8-450d-b7de-214020eeee25",
            "id": "5e535eb1-0bd8-450d-b7de-214020eeee25",
            "isNoteworthy": False,
            "lastUpdatedDate": "2017-11-25T16:29:52.695Z",
            "name": "Get BG List From Trigram",
            "organization": {
                "subtenantLabel": None,
                "subtenantRef": None,
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            "outputResourceTypeRef": None,
            "providerBinding": {
                "bindingId": "sgcloud!::!0d02280f-06e4-4ab9-9199-0dc18938ef88",
                "providerRef": {
                    "id": "8b8ff6ef-86bb-423a-be30-8e7a65395d25",
                    "label": "XaaS"
                }
            },
            "quota": None,
            "requestable": True,
            "serviceRef": {
                "id": "36f963b4-db1d-4931-bae6-81e093ecca83",
                "label": "Advanced Services"
            },
            "status": "PUBLISHED",
            "statusName": "Published",
            "version": 4
        },
        "entitledOrganizations": [
            {
                "subtenantLabel": "BG_GTS-PAS-BAAS_PRD",
                "subtenantRef": "57883085-82f1-48c5-8803-7b0f587fcaeb",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSC-DAG",
                "subtenantRef": "2d5f3774-f08e-49ee-bf3c-ce56e36e3698",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-FIN-RSR",
                "subtenantRef": "0e1dd52b-0cf4-4713-aef1-51e622db694b",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PRF-BGD",
                "subtenantRef": "5b449d85-5397-4b8b-8ab7-68261234b666",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PPM-SSF_PRD",
                "subtenantRef": "22f0a0a0-6762-49b4-b9b2-8a5b12bbe43d",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DCO-OPE_PRD",
                "subtenantRef": "3f4bbd37-f6c8-4a45-ba0d-441925bcb037",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-ASI-SMP",
                "subtenantRef": "95353ec8-774b-4735-b761-793427c0316a",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSC-SCO_PRD",
                "subtenantRef": "5d163e20-76d0-49f6-aac1-ea094cd25bb4",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-RSC-CPL",
                "subtenantRef": "84c8ddaf-1b76-471e-8bf3-f316c1c580ec",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSB-DCP_PRD",
                "subtenantRef": "985c5779-92e0-47f6-81a2-3f0a621853dc",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DCO-ECM_PRD",
                "subtenantRef": "ba2fa0b6-bbb5-4f30-a194-ff8170828f34",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-SRO-ORM",
                "subtenantRef": "276b7f45-88a2-405c-868c-d81479215059",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSC-SCO",
                "subtenantRef": "f76bc010-9455-4f9b-ae54-3381d9fba40c",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-GTB-CMI",
                "subtenantRef": "06805c50-54b1-487d-a4ff-c8b05b0205eb",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DCO-CDE",
                "subtenantRef": "13d3a711-acc1-491a-ac0d-a5be6e609978",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_IBFS-TPS_PRD",
                "subtenantRef": "966f0c9d-f535-4e9a-ae62-728852e85fe1",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DAT-CRE",
                "subtenantRef": "bfc5ba47-7b45-4fc5-9f01-4c1aef1a269f",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-TRANSVERSE-RCR",
                "subtenantRef": "f05eb9af-f19d-453b-82a9-439806ad9aab",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_RET-TFO-HCS",
                "subtenantRef": "300d1033-46eb-4510-8c37-24a8bc7dd404",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSC-DCL_PRD",
                "subtenantRef": "97efaee9-1cbb-4d26-b586-f1ac7be49637",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-RSC-CRM_PRD",
                "subtenantRef": "0b5fe729-e740-4b5b-a9a7-87aa74ba0f87",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_SGEF-DSI",
                "subtenantRef": "25f3475a-b40b-4a54-b2e1-f99651bdcbb2",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-RSC-CRM",
                "subtenantRef": "5895a779-d0e4-4fb3-a76d-05fc0ea4a2f1",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSB-NBP_PRD",
                "subtenantRef": "11f56899-92ed-408a-80f1-83745375a5df",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-GSI-SFI",
                "subtenantRef": "51d39a60-a280-4f3a-a24c-5d4e37e31839",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-H2R-RHP",
                "subtenantRef": "c9af69c6-4abd-4d3a-8113-21a141fc853d",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-ASI-TST",
                "subtenantRef": "23f74937-a647-4fde-9540-f6119ab024d8",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DCO-WEB",
                "subtenantRef": "69c63dcb-e69d-4d38-b8aa-441bf0f256be",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-PAS-DVF",
                "subtenantRef": "dcf8f3d8-c77d-4bf8-8738-470afd9bc8c1",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PLT-CSD_PRD",
                "subtenantRef": "d320fd75-35f2-47ab-952a-fd15444e9a2b",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_TPS-SGC",
                "subtenantRef": "ac6bdd64-9718-4dbd-9bcd-8c37ac0fa443",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-SRO-ISE_PRD",
                "subtenantRef": "8b68cd8d-6789-4bb1-a850-0385ed82d151",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PPM-UVP",
                "subtenantRef": "89b69827-655e-414c-96cd-e56ca0e09460",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PPM-APR",
                "subtenantRef": "a1bc1915-4c79-4f44-a940-682287cd2d71",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DAT-REF_PRD",
                "subtenantRef": "408f691c-30d1-4d0d-a1e1-607af7b92d1b",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-GTB-APC",
                "subtenantRef": "f7385460-8814-4732-a2a7-78588d98d7b8",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PPM-PQC",
                "subtenantRef": "b2ab4c3e-256f-412a-a6e8-e410a1a59507",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSB-NBP",
                "subtenantRef": "8ba79b85-5fb8-4022-8bc4-b460bcf7907c",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSB-SPT",
                "subtenantRef": "7f5fe0db-e911-4d4f-8b5a-8a1825343b6b",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-ASI-SDC_PRD",
                "subtenantRef": "28ba3eb2-cd8b-4c49-96ca-47037bb12fe9",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PRF-MOD_PRD",
                "subtenantRef": "a47a083d-b6f9-4d30-ba58-75e5764537e3",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-FIN-PTP",
                "subtenantRef": "fc907511-bf8d-4f8c-9eb8-610532f9974c",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PRF-EBC_PRD",
                "subtenantRef": "d42e11fa-05f5-418b-b506-7fdd79286dae",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DCO-WEB_PRD",
                "subtenantRef": "2e22f450-c73e-47fe-97d5-a69b3d662ee2",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-ISA-SEC_PRD",
                "subtenantRef": "eff49f35-df83-482b-a468-0bd38c7535bd",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-FIN-PRJ",
                "subtenantRef": "89139415-666d-441b-8bb7-177a12c0b3f9",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-JVM-VDF",
                "subtenantRef": "05fe2780-5273-443d-943d-cdbd6ad59c96",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-PAS-BAAS",
                "subtenantRef": "5b9d6756-7765-432d-b6ed-0d201d544332",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DAT-AAD",
                "subtenantRef": "9c8e6a17-fb43-4466-90d5-d8e62ae4d111",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-PAS-BAASBEB_PRD",
                "subtenantRef": "2b6fa0ca-d84e-4142-b854-de12b8fc8032",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSB-DPE",
                "subtenantRef": "4c48dae5-1bea-4cf7-a0d3-0ed7a4fe8858",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-H2R-RHG",
                "subtenantRef": "d6d7a0ed-165b-4ca9-88ec-23cbde06cf43",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-RSC-OPR",
                "subtenantRef": "91d7b062-54c2-475f-8fb5-739b158b70a9",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-ISA-ARM",
                "subtenantRef": "875af659-9266-4288-9a25-74782f831131",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSB-DAC_PRD",
                "subtenantRef": "b9848485-96ba-42bd-9676-1dbff167d83c",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DAT-LIQ",
                "subtenantRef": "2df5c3ec-93ea-4ea9-b4c7-e550fb5f55c0",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-RSC-DCP_PRD",
                "subtenantRef": "da84c053-3a53-48b4-b086-a484d46dabcf",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-FIN-ACC",
                "subtenantRef": "55e167d4-9829-40e9-a882-0ed4f890f6e0",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PLT-EDI_PRD",
                "subtenantRef": "48a3f685-12fd-4cc5-b431-0afcbaaad4c6",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-STP_PRD",
                "subtenantRef": "3a563662-ca9c-4ad3-abc9-85cc538d7878",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PLT-GES",
                "subtenantRef": "7d1942f4-e3a7-4056-a892-e6c9aae50c12",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-ASI-ASE",
                "subtenantRef": "a8641376-33a8-4587-8e8f-886810eada53",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-JVM-VDF_PRD",
                "subtenantRef": "1f886a1d-83a4-4806-94c7-4a88e868ba7b",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PLT-COU",
                "subtenantRef": "c6b617e6-0873-4b80-8ef2-fcaf99bf74d9",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSM-VDI_PRD",
                "subtenantRef": "f635429b-45b9-4286-a7a4-e82caa27062a",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PLT-GES_PRD",
                "subtenantRef": "7747059e-eaad-4053-98f5-b852820c79da",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PIM-CCE",
                "subtenantRef": "7fa2214a-7026-459e-be87-e70453e37d19",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSB-ESA_PRD",
                "subtenantRef": "932b740a-82a8-4e12-b410-09d51a60b7cb",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DCO-ECM",
                "subtenantRef": "c5940842-4873-4262-86e8-7dccae5b375f",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-FIN-PRJ_PRD",
                "subtenantRef": "a5a5be0b-1217-4f08-bee8-64236d9da0c3",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PRF-RIC",
                "subtenantRef": "e075a8d9-f954-4d93-9351-2b58fb23546b",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-ASI-INO",
                "subtenantRef": "5a4403e7-3ecd-41ed-8dfa-b03eb7e2c1e2",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-FIN-PGR",
                "subtenantRef": "68750340-766a-467f-9429-8d161d18435a",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSM-ARC_PRD",
                "subtenantRef": "62df546a-a7c5-43a5-a3a6-72245d042fdb",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-MITS-EBS",
                "subtenantRef": "32b9c332-fb78-4657-9bb0-688fdce22320",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-FIN-PTP_PRD",
                "subtenantRef": "90440283-e33f-42e9-9fee-51d26033043d",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DCR-DCE",
                "subtenantRef": "0974beff-de1c-4ac9-a079-507a74d548e6",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-ISA-SEC",
                "subtenantRef": "e7069f9e-eb31-4697-b423-b7d38be730e6",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSB-CRE_PRD",
                "subtenantRef": "6e9cd1b2-8bac-49c6-b260-da4ce81c02a1",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PPM-PQC_PRD",
                "subtenantRef": "5e5d7233-2cd9-4e7a-8a1d-8fbfc21518ea",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PRF-RMP_PRD",
                "subtenantRef": "03b9495b-6fe7-463f-a7c7-f9191a4b288e",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-PAS-CAAS_PRD",
                "subtenantRef": "a2e3edd5-3803-43b4-bc8e-0d6afa69a46c",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PLT-CGD",
                "subtenantRef": "0262e22e-9ed6-48dd-8af5-37ec4d3dc954",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PPM-MON_PRD",
                "subtenantRef": "173d9869-47f8-483e-968f-2e3547d5a8d1",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-PAS-DVF_PRD",
                "subtenantRef": "f762d87c-4278-4f31-8ea0-e63727a2cec6",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PRF-MOD",
                "subtenantRef": "d0b16313-ff59-44d6-8e6e-9ddd1c113761",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-FIN-ALL_PRD",
                "subtenantRef": "623babd0-ee6e-4d9b-96ae-07b88643b0be",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-STP",
                "subtenantRef": "6c61a2d8-57b0-48b9-baee-d5d309dad04f",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-EUS",
                "subtenantRef": "225f7ece-3bb8-4c86-bcad-92e322eba9b2",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DAT-AAD_PRD",
                "subtenantRef": "c70b8fe5-1bc8-4fd4-8d53-a6e5773c1167",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PRF-FRP_PRD",
                "subtenantRef": "b9146f55-31a1-440e-81b6-73c0bf8df976",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSB-DCP",
                "subtenantRef": "fbbd6ad3-903f-4da6-8dba-1c8b83c07317",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PPM-UVP_PRD",
                "subtenantRef": "ef680701-d783-46a2-8e33-115222cb903b",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-RSC-E2P_PRD",
                "subtenantRef": "e454a3f4-2b0c-4206-8aee-99a2c15cfe77",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-PAS-DBAAS_PRD",
                "subtenantRef": "4427124c-363c-485e-a839-01b4e3def0f5",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSM-VDF_PRD",
                "subtenantRef": "789e6d34-e7dc-4de7-baf6-79d6d0ecd347",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-RSC-SGL_PRD",
                "subtenantRef": "6493785b-875c-4eb0-915d-5bb954e3654a",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-GTB-HUB_PRD",
                "subtenantRef": "ba107d1f-5b44-41c9-a119-d433434318d6",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-RSC-CRC_PRD",
                "subtenantRef": "b878da29-8773-47f8-9ac2-598517ca417e",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-RET",
                "subtenantRef": "7fc7be70-7251-4c52-8296-4414de8cf88c",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSB-DPE_PRD",
                "subtenantRef": "f33eae14-df6f-4a30-b1aa-6343fbf88f9b",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-RSC-CRC",
                "subtenantRef": "c2e0d967-d95f-4c4c-b55c-2e1308a1fe0f",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSC-SBA_PRD",
                "subtenantRef": "e7bbb77d-7377-40f4-8f81-fd89169553c0",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-GTB-BAN_PRD",
                "subtenantRef": "bbd8af20-755b-487c-9c40-91dc623531e1",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSB-DAC",
                "subtenantRef": "7bbf1270-cfd9-4e06-8f11-84ebf2cc67b8",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-RET-ASF_PRD",
                "subtenantRef": "12cdf4d4-1acf-495e-96df-fc2e3c673558",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-RSC-DCP",
                "subtenantRef": "9d3fcf12-a788-4dc1-a011-d4ae094e84a6",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-TRANSVERSE-RCR_PRD",
                "subtenantRef": "f552b785-975c-4146-852f-729d5430617a",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSM-ARC",
                "subtenantRef": "cf299811-8260-486e-b178-ceac08b0b09f",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-FIN-ACC_PRD",
                "subtenantRef": "8e74aa91-2751-4772-8cb0-7af7a6e51226",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-GSI-SFI_PRD",
                "subtenantRef": "9093a9d6-7fde-4c56-9cc6-d68123a5f270",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-GTB-CMI_PRD",
                "subtenantRef": "6910e1ee-3221-4b5a-a4be-fba683aeb6c3",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-IT2-PRM",
                "subtenantRef": "448097f4-2846-4cbd-a3fb-c2f6f71988e5",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-H2R-ACH",
                "subtenantRef": "22f0f630-7662-43e3-a8c0-75bfcff7753e",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PLT",
                "subtenantRef": "17509cf9-8aa7-45c5-a014-40ab14c3adfc",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-ASI-ASE_PRD",
                "subtenantRef": "c7ba398f-3ff4-4add-9cf2-1f532a45bcdf",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-RET_PRD",
                "subtenantRef": "ae17a1da-2003-4d57-a9da-13577cf06809",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PRF-FRP",
                "subtenantRef": "eed5380a-7f96-4890-b01a-dab913a1a82c",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DAT-REF",
                "subtenantRef": "d44c1bf3-5d0c-42ca-9ebf-5bdfda6c1047",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-JVM-STR_PRD",
                "subtenantRef": "c2a10521-4d59-4796-8cf2-a3eb9cd14c87",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PRF-RMP",
                "subtenantRef": "4bfc91a5-14a1-4797-a671-50a036ad8c5e",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PPM-MON",
                "subtenantRef": "9b05f14f-7879-436b-951a-9bb9b878cfc9",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSM_PRD",
                "subtenantRef": "84f471cb-a0df-4aa9-b088-49588455b227",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PLT-CSD",
                "subtenantRef": "bbc2f92c-ddaf-4e2c-9094-b0ec44f2f746",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DAT-E2P",
                "subtenantRef": "944175cd-31e9-41b8-9f05-f326cb1b80c7",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-ISA-ARM_PRD",
                "subtenantRef": "50957a48-141e-425a-afcc-b74d040bf61e",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-ASI-SMP_PRD",
                "subtenantRef": "3ed4aaf5-f162-4101-8b67-568337abd04c",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-H2R-IMM_PRD",
                "subtenantRef": "b5b1333c-1a9d-4294-af15-fd214d03916d",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-SRO-ORM_PRD",
                "subtenantRef": "b77d5bc3-f0fa-4d11-a33a-8793f2a920ec",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-H2R-RHP_PRD",
                "subtenantRef": "1348b822-7785-4ac1-81e4-e4964ed04de5",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSM",
                "subtenantRef": "aed1abd8-d6db-4146-a58b-8096f6493b34",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-EUS_PRD",
                "subtenantRef": "bac6d98b-a132-40fc-8a88-b134bce162d6",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PLT-IMP_PRD",
                "subtenantRef": "c9c483b6-e250-43d3-8eff-05380330991f",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-GSI-PFI_PRD",
                "subtenantRef": "8fa20341-aa41-494c-a074-81950dc07e61",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-FIN-RSR_PRD",
                "subtenantRef": "b12b07ac-56d8-4508-8eeb-33581c3ab013",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DAT-LIQ_PRD",
                "subtenantRef": "eb9fa771-2d1f-480b-ba3d-27f5b0f02130",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-FIN-ALL",
                "subtenantRef": "ddc40149-5124-4d1f-8d84-a81fcd52e908",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-RET-ASF",
                "subtenantRef": "4622b1f1-8470-4508-a7bb-0e83906797b2",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-H2R-ACH_PRD",
                "subtenantRef": "270de90f-96f4-453b-9b2a-e13c8a8091f5",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-GSI-PFI",
                "subtenantRef": "49494272-d5a0-48e2-a0b0-e998e27fbd50",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-ASI-INO_PRD",
                "subtenantRef": "3e369bc2-7d96-474e-aef0-8fa3de9c2eea",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-RSC-CPL_PRD",
                "subtenantRef": "ad55b706-55b5-4e48-b691-bc3102d93310",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-GTB-APC_PRD",
                "subtenantRef": "d2c26ae9-6234-47ae-a07d-a97f36918ee3",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PRF-CPP_PRD",
                "subtenantRef": "2aa1276f-ff50-416d-87aa-6545df71083d",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-GTB-TRA_PRD",
                "subtenantRef": "46ac6e5a-aa1e-4b14-b5e9-63b3580a3372",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-RETSTAGING",
                "subtenantRef": "a1320f59-47bc-42bd-a11f-fe8959865a24",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PRF-RIC_PRD",
                "subtenantRef": "c198eb0d-bfa1-47af-82bb-39f58c8aed99",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-GSI-CES_PRD",
                "subtenantRef": "40d72c3b-dbdb-441e-8182-8a1d136a742f",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PRF-BGD_PRD",
                "subtenantRef": "cb41634f-b3c9-4a23-aec2-6911fa6e8934",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-H2R-IMM",
                "subtenantRef": "77361f8a-a32a-4230-ac77-f78a47a490e0",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-RSC-E2P",
                "subtenantRef": "3be94d8b-b205-4597-8eb9-57ae5bf8ca7b",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GSC-SMA-DIR",
                "subtenantRef": "4bfae5de-8776-480f-a7ec-ec977476902b",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-SRO-SEC",
                "subtenantRef": "6afa18a2-b2f2-485c-82a9-981d7881f44e",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSB-CRE",
                "subtenantRef": "73d6b772-d670-44fd-b2fb-d59ed49c9bc0",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-SRO-SEC_PRD",
                "subtenantRef": "459c2978-25df-4b0b-941c-eb47c69115c5",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DAT-E2P_PRD",
                "subtenantRef": "5aaf2a59-29a3-416f-808a-31b0344e09bc",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-H2R-ITT",
                "subtenantRef": "93162f64-61a9-4886-99d7-da00e3b4a422",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-SRO-ISE",
                "subtenantRef": "dc3c3bab-5694-4bb6-b021-447b66a7d0fb",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-GTB-HUB",
                "subtenantRef": "d61bb51f-c078-4d45-bd05-b674e50445c6",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-FIN-PGR_PRD",
                "subtenantRef": "3005d990-ef84-41c7-b546-e1944eccb4ba",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-PAS-CAAS",
                "subtenantRef": "d6775fff-78dd-4ab0-830e-5612ad4daf89",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-RSC-SGL",
                "subtenantRef": "6a75dbdb-a123-4098-91d4-dd4110276f48",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PLT-IMP",
                "subtenantRef": "df948753-6416-451b-9641-5d2b2aac7753",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_IBFS-TPS",
                "subtenantRef": "1d8d697c-f3c0-48bc-968a-4f87c2612c56",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DCO-MOB",
                "subtenantRef": "52c85649-6e8a-4a76-8a72-d708a7a052b8",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-IT2-PRM_PRD",
                "subtenantRef": "0c8b8107-b477-4a63-aee6-807bad93d331",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSB-ESA",
                "subtenantRef": "44698852-9f20-4294-9696-43acd7d568fc",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-PAS-BAASRTD_PRD",
                "subtenantRef": "f3888a5c-9fda-43bf-b009-85459f0aeeb7",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-PAS-BAASRTD",
                "subtenantRef": "d4382f31-6648-44ca-9308-3b46755b167f",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-H2R-E2P",
                "subtenantRef": "285c90e2-def0-4f8d-867a-935c80388e56",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-GTB-BAN",
                "subtenantRef": "6bdeb41f-928e-4013-90fa-3b6aa217d5ac",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-RSC-OPR_PRD",
                "subtenantRef": "3e83129a-82d1-4211-b19b-73db333e86ac",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PRF-EBC",
                "subtenantRef": "bbed8317-7db4-4339-9951-c096cdb9fe1d",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PPM-SSF",
                "subtenantRef": "2246d14f-2c25-47fc-b727-cfd46b7b7535",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PLT-CGD_PRD",
                "subtenantRef": "5e5fbefc-fdc4-49bf-bab9-c0890c3bc5e8",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DAT-OPE",
                "subtenantRef": "603065c8-222a-491c-ba59-8a33720168ac",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-SRO-VLK_PRD",
                "subtenantRef": "5c92b7b4-49bd-4f8f-89b6-17cceb015833",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSM-OGD_PRD",
                "subtenantRef": "f65a6f6c-e8e8-4dfa-ba42-d47faeaba1d3",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PLT-COU_PRD",
                "subtenantRef": "4251d01a-614b-48b6-a1e7-8847b5c408af",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSC-DCL",
                "subtenantRef": "fa0a2786-622a-4e4b-8330-83407e0670af",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DCO-MOB_PRD",
                "subtenantRef": "b57c813d-07f5-4e97-8232-ce00fb394c2b",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-SRO-VLK",
                "subtenantRef": "ca06bfb1-28cd-44b7-94f9-4441bb9063ad",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-POB-MOP",
                "subtenantRef": "95ec71d1-b2fb-499c-87f7-6cdcb9eff2a6",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-GSI-CES",
                "subtenantRef": "bb3c12c4-d8e1-4e9d-876d-9deca45c6905",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GSC-SMA-DIR_PRD",
                "subtenantRef": "6c3c512a-f1fb-4650-a907-13c0860382d3",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSC-SBA",
                "subtenantRef": "ef67c59b-1666-4ffe-b8bb-d74b7a896ddc",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DAT-DEX",
                "subtenantRef": "9c1d60b9-999d-42f3-991e-17150349ccfc",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PRF-CPP",
                "subtenantRef": "4b41d1d5-ae40-4a2c-8aa3-18ea95ab57f5",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PLT-EDI",
                "subtenantRef": "955cb3f2-df99-4c48-85fc-7f567acfcd8b",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-ASI-TST_PRD",
                "subtenantRef": "7c54d485-d246-4c5c-98fd-eaad50553bd2",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSB-SPT_PRD",
                "subtenantRef": "0c3f01ad-609f-4409-af30-15a20f2f656d",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_RET-TFO-HCS_PRD",
                "subtenantRef": "40fdd46b-6915-49fd-bab2-21b843f42458",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PLT_PRD",
                "subtenantRef": "2d448d8a-0e95-4760-a02b-e3f60c0aef2b",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSM-VDI",
                "subtenantRef": "d596911c-c003-4a10-9177-613a2587c945",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-H2R-RHG_PRD",
                "subtenantRef": "4428cbf8-4606-40f5-a1b5-52e72ce6d615",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-PAS-BAASBEB",
                "subtenantRef": "8fb0ce51-ad42-4515-9909-e4283e34a646",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_SGEF-DSI_PRD",
                "subtenantRef": "89c1ae2a-be9f-4d6d-8eb0-cd6cb4bcb6b6",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-FIN-CFG_PRD",
                "subtenantRef": "b11dda60-050a-410b-805b-d5490c9bd275",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-ASI-SDC",
                "subtenantRef": "5e220e03-65cc-48dd-acd1-118c5d80a38f",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_GTS-PAS-DBAAS",
                "subtenantRef": "bec82e92-2196-4494-b247-5b531d5338e8",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSM-VDF",
                "subtenantRef": "8f483423-60e3-4676-aba3-b4a7d557ca6b",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-MITS-EBS_PRD",
                "subtenantRef": "7c832faa-46a5-4850-a54f-821361800213",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DCR-DCE_PRD",
                "subtenantRef": "e8d78438-0bc5-4754-b82d-5131ccb98632",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DAT-DEX_PRD",
                "subtenantRef": "519edec7-be69-4356-945c-6ce9fe5d8a93",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DCO-CDE_PRD",
                "subtenantRef": "e3e9776d-722a-4c93-b6c4-c133a9e9c431",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-GTB-TRA",
                "subtenantRef": "cbc7dd97-d844-4d84-8f24-a908bc477e7f",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSM-OGD",
                "subtenantRef": "e5e734fb-196c-49ca-b935-b0f3f5dd8714",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DCO-OPE",
                "subtenantRef": "f87964d3-e6a4-4a6f-bbaa-7a42dc98b733",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-FIN-CFG",
                "subtenantRef": "4e20705f-de30-4fef-83cc-2ac14efa1b0c",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-JVM-STR",
                "subtenantRef": "137eeff0-d287-4660-8230-7009c7c31aec",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PIM-CCE_PRD",
                "subtenantRef": "b9160261-7b49-4d53-afec-e880ba0ad229",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-H2R-ITT_PRD",
                "subtenantRef": "96b521e4-fcf8-4845-b577-81453ffa7438",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-PPM-APR_PRD",
                "subtenantRef": "2e634d1e-c079-4a75-914c-be805ef2cac4",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DAT-OPE_PRD",
                "subtenantRef": "605ac005-81c0-4392-afd3-288b01dbd9bc",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-H2R-E2P_PRD",
                "subtenantRef": "6e9f6543-3530-463e-a816-220ad9572f1d",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_TPS-SGC_PRD",
                "subtenantRef": "70e8b5de-8fa7-4ddc-9900-13f20c2eafb1",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-POB-MOP_PRD",
                "subtenantRef": "8278fb6e-abce-4f35-9009-c949f35a7eac",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_BSC-DAT-CRE_PRD",
                "subtenantRef": "2dfb5bfe-fbdf-485e-98ea-aa793fb96634",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            },
            {
                "subtenantLabel": "BG_ITIM-CSC-DAG_PRD",
                "subtenantRef": "131b6d71-b614-4393-a542-8d92f3f84641",
                "tenantLabel": "sgcloud",
                "tenantRef": "sgcloud"
            }
        ]
    }
    ]
    TRIGRAM_LIST = ('pga',)

    def __init__(self, shared_database=None, shared_database_ssh=None):
        if isinstance(shared_database, list):
            self.vm_database = shared_database
            self.vm_database_ssh = shared_database_ssh
        else:
            self.vm_database = []
            self.vm_database_ssh = []

    def add_vm(self, vm):
        found = list(filter(lambda x: x["name"] == vm["name"], self.vm_database))
        if found:
            raise Exception("vm {} already exists...".format(vm["name"]))
        self.vm_database.append(vm)
        for entry in vm['resourceData']['entries']:
            if entry['key'] == 'ip_address':
                ip = entry['value']['value']
                self.vm_database_ssh.append(
                    {"hostname": vm["name"], "ip": ip, "sshd": True, "rdp": False, "pubkey": False}
                )
        return True

    def search_vm(self, string, by_id=None):
        if string == 'Get BG List From Trigram':
            return VmDatabase.BG_LIST
        try:
            if by_id:
                index = list(map(lambda x: x["id"], self.vm_database)).index(by_id)
            else:
                index = list(map(lambda x: x["name"], self.vm_database)).index(string)
        except ValueError:
            return None
        vm = self.vm_database[index]
        return [vm]

    def del_vm(self, by_id):
        try:
            index = list(map(lambda x: x["id"], self.vm_database)).index(by_id)
        except ValueError:
            raise Exception("vm {} not exists...".format(by_id))
        self.vm_database.pop(index)
        self.vm_database_ssh.pop(index)
        return True


class MockedCloudVra(VmDatabase):

    def __init__(self, **kwargs):
        VmDatabase.__init__(self, **kwargs)

    def get_vra_resource_data(self, filter_sentence):
        if filter_sentence.startswith("(name eq"):
            key_search = filter_sentence.split()[-1].replace("'", "").replace(")", "")
            return self.search_vm(key_search)

    def get_vra_catalog(self, filter_sentence):
        key_search = filter_sentence.split("eq")[-1].replace("'", "").replace(")", "")[1:]
        return [
            {
                "@type": "ConsumerEntitledCatalogItem",
                "catalogItem": {
                    "callbacks": {
                        "itemInformation": False,
                        "itemInitialize": False,
                        "rollback": False,
                        "validate": False
                    },
                    "catalogItemTypeRef": {
                        "id": "com.vmware.csp.core.designer.service.serviceblueprint",
                        "label": "XaaS Blueprint"
                    },
                    "dateCreated": "2017-02-06T15:43:39.363Z",
                    "description": "",
                    "forms": {
                        "catalogRequestInfoHidden": True,
                        "itemDetails": {
                            "formId": "com.vmware.csp.core.designer.service.serviceblueprint_ServiceBlueprint.Details",
                            "type": "external"
                        },
                        "requestDetails": {
                            "formId": "com.vmware.csp.core.designer.service.serviceblueprint_Request.Details",
                            "type": "external"
                        },
                        "requestFormScale": "BIG",
                        "requestPostApproval": None,
                        "requestPreApproval": None,
                        "requestSubmission": {
                            "formId": "com.vmware.csp.core.designer.service.serviceblueprint_Request.Submit",
                            "type": "external"
                        }
                    },
                    "iconId": "6675fc19-d01d-4de6-a13b-420a315ae1a0",
                    "id": "6675fc19-d01d-4de6-a13b-420a315ae1a0",
                    "isNoteworthy": False,
                    "lastUpdatedDate": "2017-11-25T16:30:04.118Z",
                    "name": key_search,
                    "organization": {
                        "subtenantLabel": None,
                        "subtenantRef": None,
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    "outputResourceTypeRef": None,
                    "providerBinding": {
                        "bindingId": "sgcloud!::!0c23f31e-d152-49e4-bb24-0560c694e811",
                        "providerRef": {
                            "id": "8b8ff6ef-86bb-423a-be30-8e7a65395d25",
                            "label": "XaaS"
                        }
                    },
                    "quota": None,
                    "requestable": True,
                    "serviceRef": {
                        "id": "68bb0048-2bbe-4f83-afe6-afe4768dec76",
                        "label": "Linux"
                    },
                    "status": "PUBLISHED",
                    "statusName": "Published",
                    "version": 12
                },
                "entitledOrganizations": [
                    {
                        "subtenantLabel": "BG_ITIM-GSI-CES",
                        "subtenantRef": "bb3c12c4-d8e1-4e9d-876d-9deca45c6905",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-GTB-HUB",
                        "subtenantRef": "d61bb51f-c078-4d45-bd05-b674e50445c6",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_RET-TFO-HCS_PRD",
                        "subtenantRef": "40fdd46b-6915-49fd-bab2-21b843f42458",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PRF-CPP",
                        "subtenantRef": "4b41d1d5-ae40-4a2c-8aa3-18ea95ab57f5",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-MITS-EBS_PRD",
                        "subtenantRef": "7c832faa-46a5-4850-a54f-821361800213",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-ASI-TST_PRD",
                        "subtenantRef": "7c54d485-d246-4c5c-98fd-eaad50553bd2",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-GTB-APC_PRD",
                        "subtenantRef": "d2c26ae9-6234-47ae-a07d-a97f36918ee3",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PRF-RIC_PRD",
                        "subtenantRef": "c198eb0d-bfa1-47af-82bb-39f58c8aed99",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-RSC-CRC",
                        "subtenantRef": "c2e0d967-d95f-4c4c-b55c-2e1308a1fe0f",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-RSC-E2P",
                        "subtenantRef": "3be94d8b-b205-4597-8eb9-57ae5bf8ca7b",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PRF-CPP_PRD",
                        "subtenantRef": "2aa1276f-ff50-416d-87aa-6545df71083d",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_GTS-STP",
                        "subtenantRef": "6c61a2d8-57b0-48b9-baee-d5d309dad04f",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-RSC-DCP",
                        "subtenantRef": "9d3fcf12-a788-4dc1-a011-d4ae094e84a6",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-H2R-ACH_PRD",
                        "subtenantRef": "270de90f-96f4-453b-9b2a-e13c8a8091f5",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PPM-MON_PRD",
                        "subtenantRef": "173d9869-47f8-483e-968f-2e3547d5a8d1",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_GTS-RET-ASF",
                        "subtenantRef": "4622b1f1-8470-4508-a7bb-0e83906797b2",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-GTB-BAN_PRD",
                        "subtenantRef": "bbd8af20-755b-487c-9c40-91dc623531e1",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-H2R-IMM",
                        "subtenantRef": "77361f8a-a32a-4230-ac77-f78a47a490e0",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSM-OGD_PRD",
                        "subtenantRef": "f65a6f6c-e8e8-4dfa-ba42-d47faeaba1d3",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-GTB-TRA_PRD",
                        "subtenantRef": "46ac6e5a-aa1e-4b14-b5e9-63b3580a3372",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DAT-E2P_PRD",
                        "subtenantRef": "5aaf2a59-29a3-416f-808a-31b0344e09bc",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_GTS-RET-ASF_PRD",
                        "subtenantRef": "12cdf4d4-1acf-495e-96df-fc2e3c673558",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSM-ARC",
                        "subtenantRef": "cf299811-8260-486e-b178-ceac08b0b09f",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-SRO-SEC",
                        "subtenantRef": "6afa18a2-b2f2-485c-82a9-981d7881f44e",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-ASI-INO",
                        "subtenantRef": "5a4403e7-3ecd-41ed-8dfa-b03eb7e2c1e2",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PRF-EBC",
                        "subtenantRef": "bbed8317-7db4-4339-9951-c096cdb9fe1d",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-RSC-OPR_PRD",
                        "subtenantRef": "3e83129a-82d1-4211-b19b-73db333e86ac",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-POB-MOP_PRD",
                        "subtenantRef": "8278fb6e-abce-4f35-9009-c949f35a7eac",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_IBFS-TPS",
                        "subtenantRef": "1d8d697c-f3c0-48bc-968a-4f87c2612c56",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DCO-OPE",
                        "subtenantRef": "f87964d3-e6a4-4a6f-bbaa-7a42dc98b733",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-MITS-EBS",
                        "subtenantRef": "32b9c332-fb78-4657-9bb0-688fdce22320",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-GSI-PFI",
                        "subtenantRef": "49494272-d5a0-48e2-a0b0-e998e27fbd50",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DAT-REF",
                        "subtenantRef": "d44c1bf3-5d0c-42ca-9ebf-5bdfda6c1047",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-FIN-PTP_PRD",
                        "subtenantRef": "90440283-e33f-42e9-9fee-51d26033043d",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-ISA-SEC",
                        "subtenantRef": "e7069f9e-eb31-4697-b423-b7d38be730e6",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DAT-CRE_PRD",
                        "subtenantRef": "2dfb5bfe-fbdf-485e-98ea-aa793fb96634",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DAT-E2P",
                        "subtenantRef": "944175cd-31e9-41b8-9f05-f326cb1b80c7",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-H2R-E2P",
                        "subtenantRef": "285c90e2-def0-4f8d-867a-935c80388e56",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-ISA-ARM_PRD",
                        "subtenantRef": "50957a48-141e-425a-afcc-b74d040bf61e",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PIM-CCE_PRD",
                        "subtenantRef": "b9160261-7b49-4d53-afec-e880ba0ad229",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PRF-RMP_PRD",
                        "subtenantRef": "03b9495b-6fe7-463f-a7c7-f9191a4b288e",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-GSI-SFI_PRD",
                        "subtenantRef": "9093a9d6-7fde-4c56-9cc6-d68123a5f270",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DAT-AAD_PRD",
                        "subtenantRef": "c70b8fe5-1bc8-4fd4-8d53-a6e5773c1167",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSM",
                        "subtenantRef": "aed1abd8-d6db-4146-a58b-8096f6493b34",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-H2R-RHP_PRD",
                        "subtenantRef": "1348b822-7785-4ac1-81e4-e4964ed04de5",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSM-OGD",
                        "subtenantRef": "e5e734fb-196c-49ca-b935-b0f3f5dd8714",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-RSC-E2P_PRD",
                        "subtenantRef": "e454a3f4-2b0c-4206-8aee-99a2c15cfe77",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PLT-IMP_PRD",
                        "subtenantRef": "c9c483b6-e250-43d3-8eff-05380330991f",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_GTS-PAS-BAASRTD",
                        "subtenantRef": "d4382f31-6648-44ca-9308-3b46755b167f",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSC-DCL",
                        "subtenantRef": "fa0a2786-622a-4e4b-8330-83407e0670af",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSM_PRD",
                        "subtenantRef": "84f471cb-a0df-4aa9-b088-49588455b227",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSM-VDI",
                        "subtenantRef": "d596911c-c003-4a10-9177-613a2587c945",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-POB-MOP",
                        "subtenantRef": "95ec71d1-b2fb-499c-87f7-6cdcb9eff2a6",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PPM-UVP",
                        "subtenantRef": "89b69827-655e-414c-96cd-e56ca0e09460",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_GTS-RETSTAGING",
                        "subtenantRef": "a1320f59-47bc-42bd-a11f-fe8959865a24",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-FIN-ALL",
                        "subtenantRef": "ddc40149-5124-4d1f-8d84-a81fcd52e908",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PLT-EDI",
                        "subtenantRef": "955cb3f2-df99-4c48-85fc-7f567acfcd8b",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-ASI-SDC",
                        "subtenantRef": "5e220e03-65cc-48dd-acd1-118c5d80a38f",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-RSC-CRM",
                        "subtenantRef": "5895a779-d0e4-4fb3-a76d-05fc0ea4a2f1",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_GTS-STP_PRD",
                        "subtenantRef": "3a563662-ca9c-4ad3-abc9-85cc538d7878",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DAT-CRE",
                        "subtenantRef": "bfc5ba47-7b45-4fc5-9f01-4c1aef1a269f",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PPM-APR_PRD",
                        "subtenantRef": "2e634d1e-c079-4a75-914c-be805ef2cac4",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-FIN-CFG_PRD",
                        "subtenantRef": "b11dda60-050a-410b-805b-d5490c9bd275",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PRF-MOD_PRD",
                        "subtenantRef": "a47a083d-b6f9-4d30-ba58-75e5764537e3",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-JVM-VDF_PRD",
                        "subtenantRef": "1f886a1d-83a4-4806-94c7-4a88e868ba7b",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-JVM-STR",
                        "subtenantRef": "137eeff0-d287-4660-8230-7009c7c31aec",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSC-DAG_PRD",
                        "subtenantRef": "131b6d71-b614-4393-a542-8d92f3f84641",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSB-CRE",
                        "subtenantRef": "73d6b772-d670-44fd-b2fb-d59ed49c9bc0",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DAT-DEX_PRD",
                        "subtenantRef": "519edec7-be69-4356-945c-6ce9fe5d8a93",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-SRO-ORM_PRD",
                        "subtenantRef": "b77d5bc3-f0fa-4d11-a33a-8793f2a920ec",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSB-CRE_PRD",
                        "subtenantRef": "6e9cd1b2-8bac-49c6-b260-da4ce81c02a1",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-ASI-SDC_PRD",
                        "subtenantRef": "28ba3eb2-cd8b-4c49-96ca-47037bb12fe9",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PLT-CGD_PRD",
                        "subtenantRef": "5e5fbefc-fdc4-49bf-bab9-c0890c3bc5e8",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSC-SCO_PRD",
                        "subtenantRef": "5d163e20-76d0-49f6-aac1-ea094cd25bb4",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DAT-OPE_PRD",
                        "subtenantRef": "605ac005-81c0-4392-afd3-288b01dbd9bc",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSB-DPE",
                        "subtenantRef": "4c48dae5-1bea-4cf7-a0d3-0ed7a4fe8858",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DCO-CDE_PRD",
                        "subtenantRef": "e3e9776d-722a-4c93-b6c4-c133a9e9c431",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_GTS-PAS-BAASRTD_PRD",
                        "subtenantRef": "f3888a5c-9fda-43bf-b009-85459f0aeeb7",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-FIN-RSR",
                        "subtenantRef": "0e1dd52b-0cf4-4713-aef1-51e622db694b",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-RSC-CPL",
                        "subtenantRef": "84c8ddaf-1b76-471e-8bf3-f316c1c580ec",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-FIN-ACC",
                        "subtenantRef": "55e167d4-9829-40e9-a882-0ed4f890f6e0",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-FIN-PGR_PRD",
                        "subtenantRef": "3005d990-ef84-41c7-b546-e1944eccb4ba",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSC-SCO",
                        "subtenantRef": "f76bc010-9455-4f9b-ae54-3381d9fba40c",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-SRO-VLK",
                        "subtenantRef": "ca06bfb1-28cd-44b7-94f9-4441bb9063ad",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DCO-OPE_PRD",
                        "subtenantRef": "3f4bbd37-f6c8-4a45-ba0d-441925bcb037",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-ISA-ARM",
                        "subtenantRef": "875af659-9266-4288-9a25-74782f831131",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-IT2-PRM_PRD",
                        "subtenantRef": "0c8b8107-b477-4a63-aee6-807bad93d331",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSB-ESA",
                        "subtenantRef": "44698852-9f20-4294-9696-43acd7d568fc",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-SRO-SEC_PRD",
                        "subtenantRef": "459c2978-25df-4b0b-941c-eb47c69115c5",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSC-SBA",
                        "subtenantRef": "ef67c59b-1666-4ffe-b8bb-d74b7a896ddc",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PPM-SSF",
                        "subtenantRef": "2246d14f-2c25-47fc-b727-cfd46b7b7535",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_GSC-SMA-DIR_PRD",
                        "subtenantRef": "6c3c512a-f1fb-4650-a907-13c0860382d3",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DCO-MOB_PRD",
                        "subtenantRef": "b57c813d-07f5-4e97-8232-ce00fb394c2b",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSC-DAG",
                        "subtenantRef": "2d5f3774-f08e-49ee-bf3c-ce56e36e3698",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-GTB-BAN",
                        "subtenantRef": "6bdeb41f-928e-4013-90fa-3b6aa217d5ac",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-FIN-RSR_PRD",
                        "subtenantRef": "b12b07ac-56d8-4508-8eeb-33581c3ab013",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSB-SPT",
                        "subtenantRef": "7f5fe0db-e911-4d4f-8b5a-8a1825343b6b",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_SGEF-DSI",
                        "subtenantRef": "25f3475a-b40b-4a54-b2e1-f99651bdcbb2",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-ASI-TST",
                        "subtenantRef": "23f74937-a647-4fde-9540-f6119ab024d8",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-RSC-CRM_PRD",
                        "subtenantRef": "0b5fe729-e740-4b5b-a9a7-87aa74ba0f87",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-SRO-ISE_PRD",
                        "subtenantRef": "8b68cd8d-6789-4bb1-a850-0385ed82d151",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_TPS-SGC",
                        "subtenantRef": "ac6bdd64-9718-4dbd-9bcd-8c37ac0fa443",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSB-SPT_PRD",
                        "subtenantRef": "0c3f01ad-609f-4409-af30-15a20f2f656d",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PLT-CSD_PRD",
                        "subtenantRef": "d320fd75-35f2-47ab-952a-fd15444e9a2b",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-RSC-SGL_PRD",
                        "subtenantRef": "6493785b-875c-4eb0-915d-5bb954e3654a",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PLT_PRD",
                        "subtenantRef": "2d448d8a-0e95-4760-a02b-e3f60c0aef2b",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DAT-LIQ",
                        "subtenantRef": "2df5c3ec-93ea-4ea9-b4c7-e550fb5f55c0",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-FIN-CFG",
                        "subtenantRef": "4e20705f-de30-4fef-83cc-2ac14efa1b0c",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DCO-WEB_PRD",
                        "subtenantRef": "2e22f450-c73e-47fe-97d5-a69b3d662ee2",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSB-DPE_PRD",
                        "subtenantRef": "f33eae14-df6f-4a30-b1aa-6343fbf88f9b",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DCR-DCE_PRD",
                        "subtenantRef": "e8d78438-0bc5-4754-b82d-5131ccb98632",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSM-VDF_PRD",
                        "subtenantRef": "789e6d34-e7dc-4de7-baf6-79d6d0ecd347",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PPM-PQC",
                        "subtenantRef": "b2ab4c3e-256f-412a-a6e8-e410a1a59507",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-RSC-CRC_PRD",
                        "subtenantRef": "b878da29-8773-47f8-9ac2-598517ca417e",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PPM-APR",
                        "subtenantRef": "a1bc1915-4c79-4f44-a940-682287cd2d71",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-FIN-PTP",
                        "subtenantRef": "fc907511-bf8d-4f8c-9eb8-610532f9974c",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_GTS-PAS-BAAS",
                        "subtenantRef": "5b9d6756-7765-432d-b6ed-0d201d544332",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_TPS-SGC_PRD",
                        "subtenantRef": "70e8b5de-8fa7-4ddc-9900-13f20c2eafb1",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSM-VDI_PRD",
                        "subtenantRef": "f635429b-45b9-4286-a7a4-e82caa27062a",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSM-VDF",
                        "subtenantRef": "8f483423-60e3-4676-aba3-b4a7d557ca6b",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-GTB-TRA",
                        "subtenantRef": "cbc7dd97-d844-4d84-8f24-a908bc477e7f",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PLT-EDI_PRD",
                        "subtenantRef": "48a3f685-12fd-4cc5-b431-0afcbaaad4c6",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-RSC-DCP_PRD",
                        "subtenantRef": "da84c053-3a53-48b4-b086-a484d46dabcf",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-GTB-APC",
                        "subtenantRef": "f7385460-8814-4732-a2a7-78588d98d7b8",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_GTS-RET_PRD",
                        "subtenantRef": "ae17a1da-2003-4d57-a9da-13577cf06809",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-JVM-VDF",
                        "subtenantRef": "05fe2780-5273-443d-943d-cdbd6ad59c96",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSB-DAC_PRD",
                        "subtenantRef": "b9848485-96ba-42bd-9676-1dbff167d83c",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DAT-AAD",
                        "subtenantRef": "9c8e6a17-fb43-4466-90d5-d8e62ae4d111",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PLT",
                        "subtenantRef": "17509cf9-8aa7-45c5-a014-40ab14c3adfc",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-H2R-E2P_PRD",
                        "subtenantRef": "6e9f6543-3530-463e-a816-220ad9572f1d",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_GTS-PAS-BAAS_PRD",
                        "subtenantRef": "57883085-82f1-48c5-8803-7b0f587fcaeb",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-SRO-ORM",
                        "subtenantRef": "276b7f45-88a2-405c-868c-d81479215059",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DCO-MOB",
                        "subtenantRef": "52c85649-6e8a-4a76-8a72-d708a7a052b8",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-GSI-SFI",
                        "subtenantRef": "51d39a60-a280-4f3a-a24c-5d4e37e31839",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSB-DCP_PRD",
                        "subtenantRef": "985c5779-92e0-47f6-81a2-3f0a621853dc",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DCO-ECM",
                        "subtenantRef": "c5940842-4873-4262-86e8-7dccae5b375f",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-H2R-ITT_PRD",
                        "subtenantRef": "96b521e4-fcf8-4845-b577-81453ffa7438",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PPM-SSF_PRD",
                        "subtenantRef": "22f0a0a0-6762-49b4-b9b2-8a5b12bbe43d",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-ASI-ASE_PRD",
                        "subtenantRef": "c7ba398f-3ff4-4add-9cf2-1f532a45bcdf",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-ASI-SMP",
                        "subtenantRef": "95353ec8-774b-4735-b761-793427c0316a",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PLT-COU_PRD",
                        "subtenantRef": "4251d01a-614b-48b6-a1e7-8847b5c408af",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSC-DCL_PRD",
                        "subtenantRef": "97efaee9-1cbb-4d26-b586-f1ac7be49637",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DAT-DEX",
                        "subtenantRef": "9c1d60b9-999d-42f3-991e-17150349ccfc",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-SRO-VLK_PRD",
                        "subtenantRef": "5c92b7b4-49bd-4f8f-89b6-17cceb015833",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_GTS-PAS-DBAAS_PRD",
                        "subtenantRef": "4427124c-363c-485e-a839-01b4e3def0f5",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-GTB-CMI",
                        "subtenantRef": "06805c50-54b1-487d-a4ff-c8b05b0205eb",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_SGEF-DSI_PRD",
                        "subtenantRef": "89c1ae2a-be9f-4d6d-8eb0-cd6cb4bcb6b6",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSB-NBP_PRD",
                        "subtenantRef": "11f56899-92ed-408a-80f1-83745375a5df",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-H2R-RHG_PRD",
                        "subtenantRef": "4428cbf8-4606-40f5-a1b5-52e72ce6d615",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_GTS-RET",
                        "subtenantRef": "7fc7be70-7251-4c52-8296-4414de8cf88c",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-ASI-ASE",
                        "subtenantRef": "a8641376-33a8-4587-8e8f-886810eada53",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-H2R-RHP",
                        "subtenantRef": "c9af69c6-4abd-4d3a-8113-21a141fc853d",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-ISA-SEC_PRD",
                        "subtenantRef": "eff49f35-df83-482b-a468-0bd38c7535bd",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSC-SBA_PRD",
                        "subtenantRef": "e7bbb77d-7377-40f4-8f81-fd89169553c0",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-ASI-INO_PRD",
                        "subtenantRef": "3e369bc2-7d96-474e-aef0-8fa3de9c2eea",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-GTB-HUB_PRD",
                        "subtenantRef": "ba107d1f-5b44-41c9-a119-d433434318d6",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-SRO-ISE",
                        "subtenantRef": "dc3c3bab-5694-4bb6-b021-447b66a7d0fb",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DAT-LIQ_PRD",
                        "subtenantRef": "eb9fa771-2d1f-480b-ba3d-27f5b0f02130",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-RSC-OPR",
                        "subtenantRef": "91d7b062-54c2-475f-8fb5-739b158b70a9",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PRF-BGD_PRD",
                        "subtenantRef": "cb41634f-b3c9-4a23-aec2-6911fa6e8934",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSB-DAC",
                        "subtenantRef": "7bbf1270-cfd9-4e06-8f11-84ebf2cc67b8",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-IT2-PRM",
                        "subtenantRef": "448097f4-2846-4cbd-a3fb-c2f6f71988e5",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DAT-REF_PRD",
                        "subtenantRef": "408f691c-30d1-4d0d-a1e1-607af7b92d1b",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-GSI-CES_PRD",
                        "subtenantRef": "40d72c3b-dbdb-441e-8182-8a1d136a742f",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-H2R-IMM_PRD",
                        "subtenantRef": "b5b1333c-1a9d-4294-af15-fd214d03916d",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-GTB-CMI_PRD",
                        "subtenantRef": "6910e1ee-3221-4b5a-a4be-fba683aeb6c3",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DCO-ECM_PRD",
                        "subtenantRef": "ba2fa0b6-bbb5-4f30-a194-ff8170828f34",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-H2R-ACH",
                        "subtenantRef": "22f0f630-7662-43e3-a8c0-75bfcff7753e",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DAT-OPE",
                        "subtenantRef": "603065c8-222a-491c-ba59-8a33720168ac",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-FIN-PRJ",
                        "subtenantRef": "89139415-666d-441b-8bb7-177a12c0b3f9",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_GSC-SMA-DIR",
                        "subtenantRef": "4bfae5de-8776-480f-a7ec-ec977476902b",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PRF-FRP",
                        "subtenantRef": "eed5380a-7f96-4890-b01a-dab913a1a82c",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-FIN-ACC_PRD",
                        "subtenantRef": "8e74aa91-2751-4772-8cb0-7af7a6e51226",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSB-NBP",
                        "subtenantRef": "8ba79b85-5fb8-4022-8bc4-b460bcf7907c",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-H2R-RHG",
                        "subtenantRef": "d6d7a0ed-165b-4ca9-88ec-23cbde06cf43",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PRF-RMP",
                        "subtenantRef": "4bfc91a5-14a1-4797-a671-50a036ad8c5e",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PIM-CCE",
                        "subtenantRef": "7fa2214a-7026-459e-be87-e70453e37d19",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PLT-COU",
                        "subtenantRef": "c6b617e6-0873-4b80-8ef2-fcaf99bf74d9",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PLT-CSD",
                        "subtenantRef": "bbc2f92c-ddaf-4e2c-9094-b0ec44f2f746",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PLT-IMP",
                        "subtenantRef": "df948753-6416-451b-9641-5d2b2aac7753",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSB-ESA_PRD",
                        "subtenantRef": "932b740a-82a8-4e12-b410-09d51a60b7cb",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DCR-DCE",
                        "subtenantRef": "0974beff-de1c-4ac9-a079-507a74d548e6",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSM-ARC_PRD",
                        "subtenantRef": "62df546a-a7c5-43a5-a3a6-72245d042fdb",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-RSC-SGL",
                        "subtenantRef": "6a75dbdb-a123-4098-91d4-dd4110276f48",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PLT-GES_PRD",
                        "subtenantRef": "7747059e-eaad-4053-98f5-b852820c79da",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PLT-GES",
                        "subtenantRef": "7d1942f4-e3a7-4056-a892-e6c9aae50c12",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_RET-TFO-HCS",
                        "subtenantRef": "300d1033-46eb-4510-8c37-24a8bc7dd404",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PLT-CGD",
                        "subtenantRef": "0262e22e-9ed6-48dd-8af5-37ec4d3dc954",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-JVM-STR_PRD",
                        "subtenantRef": "c2a10521-4d59-4796-8cf2-a3eb9cd14c87",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PRF-RIC",
                        "subtenantRef": "e075a8d9-f954-4d93-9351-2b58fb23546b",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-GSI-PFI_PRD",
                        "subtenantRef": "8fa20341-aa41-494c-a074-81950dc07e61",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-FIN-PRJ_PRD",
                        "subtenantRef": "a5a5be0b-1217-4f08-bee8-64236d9da0c3",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-FIN-PGR",
                        "subtenantRef": "68750340-766a-467f-9429-8d161d18435a",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PPM-MON",
                        "subtenantRef": "9b05f14f-7879-436b-951a-9bb9b878cfc9",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PRF-BGD",
                        "subtenantRef": "5b449d85-5397-4b8b-8ab7-68261234b666",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-H2R-ITT",
                        "subtenantRef": "93162f64-61a9-4886-99d7-da00e3b4a422",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-ASI-SMP_PRD",
                        "subtenantRef": "3ed4aaf5-f162-4101-8b67-568337abd04c",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_IBFS-TPS_PRD",
                        "subtenantRef": "966f0c9d-f535-4e9a-ae62-728852e85fe1",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PRF-FRP_PRD",
                        "subtenantRef": "b9146f55-31a1-440e-81b6-73c0bf8df976",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-CSB-DCP",
                        "subtenantRef": "fbbd6ad3-903f-4da6-8dba-1c8b83c07317",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-FIN-ALL_PRD",
                        "subtenantRef": "623babd0-ee6e-4d9b-96ae-07b88643b0be",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PRF-EBC_PRD",
                        "subtenantRef": "d42e11fa-05f5-418b-b506-7fdd79286dae",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PPM-PQC_PRD",
                        "subtenantRef": "5e5d7233-2cd9-4e7a-8a1d-8fbfc21518ea",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DCO-CDE",
                        "subtenantRef": "13d3a711-acc1-491a-ac0d-a5be6e609978",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-RSC-CPL_PRD",
                        "subtenantRef": "ad55b706-55b5-4e48-b691-bc3102d93310",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_BSC-DCO-WEB",
                        "subtenantRef": "69c63dcb-e69d-4d38-b8aa-441bf0f256be",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PPM-UVP_PRD",
                        "subtenantRef": "ef680701-d783-46a2-8e33-115222cb903b",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    },
                    {
                        "subtenantLabel": "BG_ITIM-PRF-MOD",
                        "subtenantRef": "d0b16313-ff59-44d6-8e6e-9ddd1c113761",
                        "tenantLabel": "sgcloud",
                        "tenantRef": "sgcloud"
                    }
                ]
            }
        ]

    def vra_create_vm(self, wait, machine_item, vm_config, requested_for, provider_owner, business_group):
        data = {
            "@type": "CatalogResource",
            "id": str(uuid.uuid1()),
            "iconId": "Infrastructure.CatalogItem.Machine.Virtual.vSphere",
            "resourceTypeRef": {
                "id": "Infrastructure.Virtual",
                "label": "Virtual Machine"
            },
            "name": vm_config.hostname,
            "description": "[EDGE]",
            "status": "ACTIVE",
            "catalogItem": None,
            "requestId": "72e57688-3f03-4eed-a4de-904f5f0cb323",
            "requestState": "SUCCESSFUL",
            "providerBinding": {
                "bindingId": "cf1640d5-0420-4088-9eff-9400063b226f",
                "providerRef": {
                    "id": "ea3f4a9f-ed7c-4e05-a516-5784f2b87ab3",
                    "label": "Infrastructure Service"
                }
            },
            "owners": [
                {
                    "tenantName": "sgcloud",
                    "ref": provider_owner,
                    "type": "USER",
                    "value": "Generic Account"
                }
            ],
            "organization": {
                "tenantRef": "sgcloud",
                "tenantLabel": "sgcloud",
                "subtenantRef": "f552b785-975c-4146-852f-729d5430617a",
                "subtenantLabel": business_group
            },
            "dateCreated": "2018-06-01T08:56:40.071Z",
            "lastUpdated": "2018-06-01T08:58:06.494Z",
            "hasLease": True,
            "lease": {
                "start": "2018-06-01T08:51:42.939Z",
                "end": None
            },
            "leaseForDisplay": None,
            "hasCosts": True,
            "costs": None,
            "costToDate": None,
            "totalCost": None,
            "expenseMonthToDate": None,
            "parentResourceRef": {
                "id": "41f7203e-def7-4e57-81e6-f82474dbbda4",
                "label": "RHEL_7.3_x64-TRANSVERSE-RCR-76687518"
            },
            "hasChildren": False,
            "operations": [
                {
                    "name": "Add Storage",
                    "description": "Add or extend a disk linked to a VM",
                    "iconId": "6d0a5fc3-e443-497c-9611-a0d965aebccf_icon",
                    "type": "ACTION",
                    "id": "ecbceb62-0e6c-45a1-b894-bb75d61aa912",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.core.designer.service",
                    "bindingId": "sgcloud!::!b4ffdfd5-940a-4790-87d0-dff9fdabd6e1",
                    "hasForm": True,
                    "formScale": "BIG"
                },
                {
                    "name": "Add Tags To VM",
                    "description": "REST API function to add a tag to an instance (Get the type and name from the id)",
                    "iconId": "d5d4fa0a-247e-49af-83e8-531f33429071_icon",
                    "type": "ACTION",
                    "id": "3d1c69ff-bf7b-4fbb-bf40-f66c3038dd25",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.core.designer.service",
                    "bindingId": "sgcloud!::!078c39b3-cdd1-49d0-bd9e-90f51ab1dd30",
                    "hasForm": True,
                    "formScale": "BIG"
                },
                {
                    "name": "Change Lease",
                    "description": "Change the lease for a machine. Leave empty for indefinite.",
                    "iconId": "machineChangeLease.png",
                    "type": "ACTION",
                    "id": "3a7c6419-e6e8-463b-86b7-8f9c9e09ee12",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.iaas.blueprint.service",
                    "bindingId": "Infrastructure.Machine.Action.ChangeLease",
                    "hasForm": True,
                    "formScale": "SMALL"
                },
                {
                    "name": "Change VM Backup Policy",
                    "description": "",
                    "iconId": "1b8e8265-238c-4f26-a5fa-7f4d340e8b04_icon",
                    "type": "ACTION",
                    "id": "f79df9f5-ffc3-4133-9b6b-243ba48ef539",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.core.designer.service",
                    "bindingId": "sgcloud!::!ddf08847-a146-495b-a83f-61938ee1bdd1",
                    "hasForm": True,
                    "formScale": "BIG"
                },
                {
                    "name": "Change VM Description",
                    "description": "",
                    "iconId": "b6204ee0-7515-421f-b358-3c5e01cef573_icon",
                    "type": "ACTION",
                    "id": "52def6a2-80cd-409c-97dc-490fdad540eb",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.core.designer.service",
                    "bindingId": "sgcloud!::!035e941e-bea0-4178-b3f7-19792b5f3883",
                    "hasForm": True,
                    "formScale": "BIG"
                },
                {
                    "name": "Change VM Model",
                    "description": "",
                    "iconId": "b415e0ad-644c-4875-9308-6892e7f35740",
                    "type": "ACTION",
                    "id": "b415e0ad-644c-4875-9308-6892e7f35740",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.core.designer.service",
                    "bindingId": "sgcloud!::!2e1eedff-5da5-495e-9396-0321d5ee2b8f",
                    "hasForm": True,
                    "formScale": "BIG"
                },
                {
                    "name": "Change VM Owner",
                    "description": "",
                    "iconId": "f2b31ac5-2924-4ed6-9657-d641a3d97f11",
                    "type": "ACTION",
                    "id": "f2b31ac5-2924-4ed6-9657-d641a3d97f11",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.core.designer.service",
                    "bindingId": "sgcloud!::!9b569182-731c-401b-bd0a-908fef4480e9",
                    "hasForm": True,
                    "formScale": "BIG"
                },
                {
                    "name": "Create Snapshot",
                    "description": "Create a snapshot for this machine.",
                    "iconId": "virtualCreateSnapshot.png",
                    "type": "ACTION",
                    "id": "dbb3fd3b-9f90-41ad-bc96-03f9b5b07738",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.iaas.blueprint.service",
                    "bindingId": "Infrastructure.Virtual.Action.CreateSnapshot",
                    "hasForm": True,
                    "formScale": "SMALL"
                },
                {
                    "name": "Destroy",
                    "description": "Destroy a virtual machine.",
                    "iconId": "virtualDestroy.png",
                    "type": "ACTION",
                    "id": "cea15550-4a48-4896-8c7c-3b21eef2772e",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.iaas.blueprint.service",
                    "bindingId": "Infrastructure.Virtual.Action.Destroy",
                    "hasForm": False,
                    "formScale": None
                },
                {
                    "name": "Get All VM Information",
                    "description": "",
                    "iconId": "ad98563e-4dc4-4abf-a80a-4a18639a42a1_icon",
                    "type": "ACTION",
                    "id": "548ac3a3-13a7-444e-a61d-70fa68d21712",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.core.designer.service",
                    "bindingId": "sgcloud!::!7efaedc9-35ca-4a12-b675-308342c235eb",
                    "hasForm": True,
                    "formScale": "BIG"
                },
                {
                    "name": "Get Security Groups",
                    "description": "List the Security groups applied to a given VM",
                    "iconId": "ce69b997-bc87-49ce-aa05-cce0cdca0f52_icon",
                    "type": "ACTION",
                    "id": "ccf1a0c3-75fd-4b36-baaf-0e48de8a77f3",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.core.designer.service",
                    "bindingId": "sgcloud!::!c7611d7d-ae0b-4c6d-8ffb-befe6d591651",
                    "hasForm": True,
                    "formScale": "BIG"
                },
                {
                    "name": "Get Tags From VM",
                    "description": "REST API function to add a tag to an instance (Get the type and name from the id)",
                    "iconId": "b582dca7-ab08-4d1b-bfcc-b9ac6e481dd0_icon",
                    "type": "ACTION",
                    "id": "b2df7865-7e94-4f45-8304-90e59a2e447d",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.core.designer.service",
                    "bindingId": "sgcloud!::!442ec744-7a42-4377-b34e-a4f62774ad84",
                    "hasForm": True,
                    "formScale": "BIG"
                },
                {
                    "name": "Get VM Information",
                    "description": "",
                    "iconId": "eeb0d977-1e6d-49f8-8b9f-d81f118d471d_icon",
                    "type": "ACTION",
                    "id": "a1a2245a-b6dd-4487-9a53-e720a5eeaf80",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.core.designer.service",
                    "bindingId": "sgcloud!::!cb328c51-92a7-4809-b887-5cd8d5cdcd10",
                    "hasForm": True,
                    "formScale": "BIG"
                },
                {
                    "name": "Get VM SG Attributes",
                    "description": "This workflow returns the list of All available custom properties of a VM listed in ASD_CONFIG.",
                    "iconId": "cafe_default_icon_genericResourceOperation",
                    "type": "ACTION",
                    "id": "d452ff16-0172-4288-9da6-2c3d5343226b",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.core.designer.service",
                    "bindingId": "sgcloud!::!c55610bb-6c39-47f9-953a-e1f568868e65",
                    "hasForm": True,
                    "formScale": "BIG"
                },
                {
                    "name": "RA - Force restart VM",
                    "description": "",
                    "iconId": "45cb9d09-6806-4159-bab8-92bab36f46ac_icon",
                    "type": "ACTION",
                    "id": "2917a439-137e-4f7b-8a37-876b3fe0e5e6",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.core.designer.service",
                    "bindingId": "sgcloud!::!611b13f3-d4d3-43fb-bd79-292803b93dd5",
                    "hasForm": True,
                    "formScale": "BIG"
                },
                {
                    "name": "Remove All Tags From VM",
                    "description": "Function to update the tags on a VLB from the portal.",
                    "iconId": "fbcd02fd-0e62-4d73-b9a0-92f653596253_icon",
                    "type": "ACTION",
                    "id": "24e7468c-2a69-426a-aed7-838939dd4592",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.core.designer.service",
                    "bindingId": "sgcloud!::!043cf543-3131-4275-8fd4-6669d352936e",
                    "hasForm": True,
                    "formScale": "BIG"
                },
                {
                    "name": "Remove Tags From VM",
                    "description": "Function to update the tags on a VLB from the portal.",
                    "iconId": "afc82a1c-d34b-4e1f-a33a-01e332014006_icon",
                    "type": "ACTION",
                    "id": "9f2110f9-fa2b-40c3-a39b-a763a2acc2ec",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.core.designer.service",
                    "bindingId": "sgcloud!::!5607985b-e71b-40bf-b9f6-8216b5f1b198",
                    "hasForm": True,
                    "formScale": "BIG"
                },
                {
                    "name": "Restart VM",
                    "description": "Restart a Virtual Machine",
                    "iconId": "72bbc884-fb76-4cd2-8228-87c406f5c858_icon",
                    "type": "ACTION",
                    "id": "134d6742-a802-43ea-a828-d6d2d175dc98",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.core.designer.service",
                    "bindingId": "sgcloud!::!46cf5de7-07c1-4981-9ccc-08bc872dd5bc",
                    "hasForm": True,
                    "formScale": "BIG"
                },
                {
                    "name": "Update Tags From VM",
                    "description": "Function to update the tags on an object from the portal.",
                    "iconId": "fa8ab11e-bcfa-4e9f-8f4f-c03cf0bbdb29_icon",
                    "type": "ACTION",
                    "id": "15dbd19b-29e0-41d5-abff-880f206576c6",
                    "extensionId": None,
                    "providerTypeId": "com.vmware.csp.core.designer.service",
                    "bindingId": "sgcloud!::!0a8ac7a0-a260-4ceb-a2c7-0d4245a31a6e",
                    "hasForm": True,
                    "formScale": "BIG"
                }
            ],
            "forms": {
                "catalogResourceInfoHidden": True,
                "details": {
                    "type": "extension",
                    "extensionId": "csp.places.iaas.item.details",
                    "extensionPointId": None
                }
            },
            "resourceData": {
                "entries": [
                    {
                        "key": "ConnectViaSsh",
                        "value": {
                            "type": "boolean",
                            "value": True
                        }
                    },
                    {
                        "key": "MachineGuestOperatingSystem",
                        "value": None
                    },
                    {
                        "key": "MachineMemory",
                        "value": {
                            "type": "integer",
                            "value": 1024
                        }
                    },
                    {
                        "key": "DISK_VOLUMES",
                        "value": {
                            "type": "multiple",
                            "elementTypeId": "COMPLEX",
                            "items": [
                                {
                                    "type": "complex",
                                    "componentTypeId": "com.vmware.csp.component.iaas.proxy.provider",
                                    "componentId": None,
                                    "classId": "dynamicops.api.model.DiskInputModel",
                                    "typeFilter": None,
                                    "values": {
                                        "entries": [
                                            {
                                                "key": "DISK_INPUT_ID",
                                                "value": {
                                                    "type": "string",
                                                    "value": "DISK_INPUT_ID1"
                                                }
                                            },
                                            {
                                                "key": "DISK_CAPACITY",
                                                "value": {
                                                    "type": "integer",
                                                    "value": 40
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "key": "MachineBlueprintName",
                        "value": {
                            "type": "string",
                            "value": "RHEL_7.3_x64-TRANSVERSE-RCR"
                        }
                    },
                    {
                        "key": "Suspend",
                        "value": {
                            "type": "boolean",
                            "value": True
                        }
                    },
                    {
                        "key": "MachineInterfaceType",
                        "value": {
                            "type": "string",
                            "value": "vSphere"
                        }
                    },
                    {
                        "key": "MachineCPU",
                        "value": {
                            "type": "integer",
                            "value": 1
                        }
                    },
                    {
                        "key": "MachineExpirationDate",
                        "value": None
                    },
                    {
                        "key": "PowerOff",
                        "value": {
                            "type": "boolean",
                            "value": True
                        }
                    },
                    {
                        "key": "ConnectViaNativeVmrc",
                        "value": {
                            "type": "boolean",
                            "value": True
                        }
                    },
                    {
                        "key": "IS_COMPONENT_MACHINE",
                        "value": {
                            "type": "boolean",
                            "value": False
                        }
                    },
                    {
                        "key": "ChangeLease",
                        "value": {
                            "type": "boolean",
                            "value": True
                        }
                    },
                    {
                        "key": "endpointExternalReferenceId",
                        "value": {
                            "type": "string",
                            "value": "26bc5616-895e-4ec1-afe9-e393fc1df2e2"
                        }
                    },
                    {
                        "key": "MachineInterfaceDisplayName",
                        "value": {
                            "type": "string",
                            "value": "vSphere (vCenter)"
                        }
                    },
                    {
                        "key": "VirtualMachine.Admin.UUID",
                        "value": {
                            "type": "string",
                            "value": "502bbe14-bd27-168c-8087-5a697476e3a5"
                        }
                    },
                    {
                        "key": "Destroy",
                        "value": {
                            "type": "boolean",
                            "value": True
                        }
                    },
                    {
                        "key": "MachineReservationName",
                        "value": {
                            "type": "string",
                            "value": "BG_GTS-TRANSVERSE-RCR_PRD-Res-49"
                        }
                    },
                    {
                        "key": "NETWORK_LIST",
                        "value": {
                            "type": "multiple",
                            "elementTypeId": "COMPLEX",
                            "items": [
                                {
                                    "type": "complex",
                                    "componentTypeId": "com.vmware.csp.component.iaas.proxy.provider",
                                    "componentId": None,
                                    "classId": "dynamicops.api.model.NetworkViewModel",
                                    "typeFilter": None,
                                    "values": {
                                        "entries": [
                                            {
                                                "key": "NETWORK_ADDRESS",
                                                "value": {
                                                    "type": "string",
                                                    "value": vm_config.ip_address
                                                }
                                            },
                                            {
                                                "key": "NETWORK_NAME",
                                                "value": {
                                                    "type": "string",
                                                    "value": "MKT_192-163-224-0_21"
                                                }
                                            },
                                            {
                                                "key": "NETWORK_MAC_ADDRESS",
                                                "value": {
                                                    "type": "string",
                                                    "value": "00:50:56:ab:92:8c"
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "key": "Component",
                        "value": {
                            "type": "string",
                            "value": "RHEL_7.3_x64-TRANSVERSE-RCR"
                        }
                    },
                    {
                        "key": "Reset",
                        "value": {
                            "type": "boolean",
                            "value": True
                        }
                    },
                    {
                        "key": "ConnectViaVmrc",
                        "value": {
                            "type": "boolean",
                            "value": True
                        }
                    },
                    {
                        "key": "SNAPSHOT_LIST",
                        "value": {
                            "type": "multiple",
                            "elementTypeId": "COMPLEX",
                            "items": []
                        }
                    },
                    {
                        "key": "InstallTools",
                        "value": {
                            "type": "boolean",
                            "value": True
                        }
                    },
                    {
                        "key": "MachineStatus",
                        "value": {
                            "type": "string",
                            "value": "On"
                        }
                    },
                    {
                        "key": "MachineType",
                        "value": {
                            "type": "string",
                            "value": "Virtual"
                        }
                    },
                    {
                        "key": "MachineStorage",
                        "value": {
                            "type": "integer",
                            "value": 40
                        }
                    },
                    {
                        "key": "EXTERNAL_REFERENCE_ID",
                        "value": {
                            "type": "string",
                            "value": "vm-723606"
                        }
                    },
                    {
                        "key": "MachineGroupName",
                        "value": {
                            "type": "string",
                            "value": business_group
                        }
                    },
                    {
                        "key": "ip_address",
                        "value": {
                            "type": "string",
                            "value": vm_config.ip_address
                        }
                    },
                    {
                        "key": "Reboot",
                        "value": {
                            "type": "boolean",
                            "value": True
                        }
                    },
                    {
                        "key": "ChangeOwner",
                        "value": {
                            "type": "boolean",
                            "value": True
                        }
                    },
                    {
                        "key": "Expire",
                        "value": {
                            "type": "boolean",
                            "value": True
                        }
                    },
                    {
                        "key": "machineId",
                        "value": {
                            "type": "string",
                            "value": "cf1640d5-0420-4088-9eff-9400063b226f"
                        }
                    },
                    {
                        "key": "MachineName",
                        "value": {
                            "type": "string",
                            "value": "ptrvlxcelery002"
                        }
                    },
                    {
                        "key": "MachineDestructionDate",
                        "value": None
                    },
                    {
                        "key": "Shutdown",
                        "value": {
                            "type": "boolean",
                            "value": True
                        }
                    },
                    {
                        "key": "Reconfigure",
                        "value": {
                            "type": "boolean",
                            "value": True
                        }
                    },
                    {
                        "key": "Reprovision",
                        "value": {
                            "type": "boolean",
                            "value": True
                        }
                    },
                    {
                        "key": "CreateSnapshot",
                        "value": {
                            "type": "boolean",
                            "value": True
                        }
                    },
                    {
                        "key": "MachineDailyCost",
                        "value": {
                            "type": "decimal",
                            "value": 0.0
                        }
                    }
                ]
            },
            "destroyDate": None
        }
        self.add_vm(
            data
        )

    def vra_destroy_vm(self, wait, hostname_id, operation_id, organization):
        if operation_id == 'cea15550-4a48-4896-8c7c-3b21eef2772e':
            self.del_vm(hostname_id)
            return {
                        "layout": {
                            "pages": [
                                {
                                    "id": None,
                                    "label": "Request Information",
                                    "state": {
                                        "dependencies": [],
                                        "facets": []
                                    },
                                    "sections": [
                                        {
                                            "id": None,
                                            "label": None,
                                            "state": {
                                                "dependencies": [],
                                                "facets": []
                                            },
                                            "rows": [
                                                {
                                                    "items": [
                                                        {
                                                            "type": "field",
                                                            "size": 4,
                                                            "id": "description",
                                                            "label": "Description",
                                                            "description": "Tell us what you are requesting",
                                                            "orderIndex": None,
                                                            "dataType": {
                                                                "type": "primitive",
                                                                "typeId": "STRING"
                                                            },
                                                            "displayAdvice": "TEXTBOX",
                                                            "permissibleValues": None,
                                                            "state": {
                                                                "dependencies": [],
                                                                "facets": [
                                                                    {
                                                                        "type": "mandatory",
                                                                        "value": {
                                                                            "type": "constant",
                                                                            "value": {
                                                                                "type": "boolean",
                                                                                "value": True
                                                                            }
                                                                        }
                                                                    },
                                                                    {
                                                                        "type": "readOnly",
                                                                        "value": {
                                                                            "type": "constantClause",
                                                                            "value": {
                                                                                "type": "boolean",
                                                                                "value": True
                                                                            }
                                                                        }
                                                                    }
                                                                ]
                                                            },
                                                            "labelSize": None,
                                                            "detailLayout": None,
                                                            "extensionRendererContext": None,
                                                            "isMultiValued": False,
                                                            "columns": []
                                                        }
                                                    ]
                                                },
                                                {
                                                    "items": [
                                                        {
                                                            "type": "field",
                                                            "size": 4,
                                                            "id": "reasons",
                                                            "label": "Reasons",
                                                            "description": "Tell us why you are requesting it",
                                                            "orderIndex": None,
                                                            "dataType": {
                                                                "type": "primitive",
                                                                "typeId": "STRING"
                                                            },
                                                            "displayAdvice": "TEXTAREA",
                                                            "permissibleValues": None,
                                                            "state": {
                                                                "dependencies": [],
                                                                "facets": [
                                                                    {
                                                                        "type": "mandatory",
                                                                        "value": {
                                                                            "type": "constant",
                                                                            "value": {
                                                                                "type": "boolean",
                                                                                "value": False
                                                                            }
                                                                        }
                                                                    },
                                                                    {
                                                                        "type": "readOnly",
                                                                        "value": {
                                                                            "type": "constantClause",
                                                                            "value": {
                                                                                "type": "boolean",
                                                                                "value": True
                                                                            }
                                                                        }
                                                                    }
                                                                ]
                                                            },
                                                            "labelSize": None,
                                                            "detailLayout": None,
                                                            "extensionRendererContext": None,
                                                            "isMultiValued": False,
                                                            "columns": []
                                                        }
                                                    ]
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        },
                        "values": {
                            "entries": [
                                {
                                    "key": "description",
                                    "value": None
                                },
                                {
                                    "key": "reasons",
                                    "value": None
                                }
                            ]
                        },
                        "fieldPrefixes": None
                    }
        elif operation_id == 'a1a2245a-b6dd-4487-9a53-e720a5eeaf80':
            if self.search_vm("", by_id=hostname_id):
                return {
                    "fieldPrefixes": None,
                "layout": {
                    "pages": [
                        {
                            "id": None,
                            "label": "General",
                            "sections": [
                                {
                                    "id": None,
                                    "label": "VRO Workflow Execution Details",
                                    "rows": [
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": None,
                                                    "extensionRendererContext": None,
                                                    "id": "provider-vco.execution.state",
                                                    "isMultiValued": False,
                                                    "label": "State",
                                                    "labelSize": 1,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 8,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "derivedValue",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "string",
                                                                        "value": "completed"
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        },
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": None,
                                                    "extensionRendererContext": None,
                                                    "id": "provider-vco.execution.workflow.name",
                                                    "isMultiValued": False,
                                                    "label": "Name",
                                                    "labelSize": 1,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 8,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "derivedValue",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "string",
                                                                        "value": "RA - Get VM Information"
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        },
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": None,
                                                    "extensionRendererContext": None,
                                                    "id": "provider-vco.execution.workflow.token.id",
                                                    "isMultiValued": False,
                                                    "label": "Token Id",
                                                    "labelSize": 1,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 8,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "derivedValue",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "string",
                                                                        "value": "4020d0df64a3f6c50164d7bd7c0c54e6"
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        },
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": None,
                                                    "extensionRendererContext": None,
                                                    "id": "provider-vco.execution.business.state",
                                                    "isMultiValued": False,
                                                    "label": "Business State",
                                                    "labelSize": 1,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 8,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "derivedValue",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "string",
                                                                        "value": " "
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        },
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": None,
                                                    "extensionRendererContext": None,
                                                    "id": "provider-vco.execution.current.activity.name",
                                                    "isMultiValued": False,
                                                    "label": "Current Activity",
                                                    "labelSize": 1,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 8,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "derivedValue",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "string",
                                                                        "value": " "
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        },
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "DATE_TIME"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": None,
                                                    "extensionRendererContext": None,
                                                    "id": "provider-vco.execution.start.date",
                                                    "isMultiValued": False,
                                                    "label": "Start date",
                                                    "labelSize": 1,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 8,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "derivedValue",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "dateTime",
                                                                        "value": "2018-07-26T17:57:46.803Z"
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        },
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "DATE_TIME"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": None,
                                                    "extensionRendererContext": None,
                                                    "id": "provider-vco.execution.end.date",
                                                    "isMultiValued": False,
                                                    "label": "End date",
                                                    "labelSize": 1,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 8,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "derivedValue",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "dateTime",
                                                                        "value": "2018-07-26T17:58:22.058Z"
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        },
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": None,
                                                    "extensionRendererContext": None,
                                                    "id": "provider-vco.execution.error.details",
                                                    "isMultiValued": False,
                                                    "label": "Error details",
                                                    "labelSize": 1,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 8,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "derivedValue",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "string",
                                                                        "value": " "
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        }
                                    ],
                                    "state": {
                                        "dependencies": [],
                                        "facets": []
                                    }
                                },
                                {
                                    "id": None,
                                    "label": None,
                                    "rows": [
                                        {
                                            "items": [
                                                {
                                                    "columns": [
                                                        {
                                                            "columns": [],
                                                            "dataType": {
                                                                "type": "primitive",
                                                                "typeId": "DATE_TIME"
                                                            },
                                                            "description": None,
                                                            "detailLayout": None,
                                                            "displayAdvice": None,
                                                            "extensionRendererContext": None,
                                                            "id": "timestamp",
                                                            "isMultiValued": False,
                                                            "label": "Timestamp",
                                                            "labelSize": None,
                                                            "orderIndex": None,
                                                            "permissibleValues": None,
                                                            "size": 2,
                                                            "state": {
                                                                "dependencies": [],
                                                                "facets": []
                                                            },
                                                            "type": "field"
                                                        },
                                                        {
                                                            "columns": [],
                                                            "dataType": {
                                                                "type": "primitive",
                                                                "typeId": "STRING"
                                                            },
                                                            "description": None,
                                                            "detailLayout": None,
                                                            "displayAdvice": None,
                                                            "extensionRendererContext": None,
                                                            "id": "user",
                                                            "isMultiValued": False,
                                                            "label": "User",
                                                            "labelSize": None,
                                                            "orderIndex": None,
                                                            "permissibleValues": None,
                                                            "size": 2,
                                                            "state": {
                                                                "dependencies": [],
                                                                "facets": []
                                                            },
                                                            "type": "field"
                                                        },
                                                        {
                                                            "columns": [],
                                                            "dataType": {
                                                                "type": "primitive",
                                                                "typeId": "STRING"
                                                            },
                                                            "description": None,
                                                            "detailLayout": None,
                                                            "displayAdvice": None,
                                                            "extensionRendererContext": None,
                                                            "id": "shortDescription",
                                                            "isMultiValued": False,
                                                            "label": "Short Description",
                                                            "labelSize": None,
                                                            "orderIndex": None,
                                                            "permissibleValues": None,
                                                            "size": 2,
                                                            "state": {
                                                                "dependencies": [],
                                                                "facets": []
                                                            },
                                                            "type": "field"
                                                        },
                                                        {
                                                            "columns": [],
                                                            "dataType": {
                                                                "type": "primitive",
                                                                "typeId": "STRING"
                                                            },
                                                            "description": None,
                                                            "detailLayout": None,
                                                            "displayAdvice": None,
                                                            "extensionRendererContext": None,
                                                            "id": "description",
                                                            "isMultiValued": False,
                                                            "label": "Long Description",
                                                            "labelSize": None,
                                                            "orderIndex": None,
                                                            "permissibleValues": None,
                                                            "size": 2,
                                                            "state": {
                                                                "dependencies": [],
                                                                "facets": []
                                                            },
                                                            "type": "field"
                                                        },
                                                        {
                                                            "columns": [],
                                                            "dataType": {
                                                                "type": "primitive",
                                                                "typeId": "STRING"
                                                            },
                                                            "description": None,
                                                            "detailLayout": None,
                                                            "displayAdvice": None,
                                                            "extensionRendererContext": None,
                                                            "id": "severity",
                                                            "isMultiValued": False,
                                                            "label": "Severity",
                                                            "labelSize": None,
                                                            "orderIndex": None,
                                                            "permissibleValues": None,
                                                            "size": 2,
                                                            "state": {
                                                                "dependencies": [],
                                                                "facets": []
                                                            },
                                                            "type": "field"
                                                        }
                                                    ],
                                                    "dataType": {
                                                        "classId": "asdExecutionLogs",
                                                        "componentId": None,
                                                        "componentTypeId": None,
                                                        "label": None,
                                                        "schema": None,
                                                        "type": "complex",
                                                        "typeFilter": None
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": "DATA_TABLE",
                                                    "extensionRendererContext": None,
                                                    "id": "provider-_asd.executionLogs_",
                                                    "isMultiValued": False,
                                                    "label": "Logs",
                                                    "labelSize": 1,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 8,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "defaultValue",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "elementTypeId": "COMPLEX",
                                                                        "items": [
                                                                            {
                                                                                "classId": "asdExecutionLogs",
                                                                                "componentId": None,
                                                                                "componentTypeId": None,
                                                                                "type": "complex",
                                                                                "typeFilter": None,
                                                                                "values": {
                                                                                    "entries": [
                                                                                        {
                                                                                            "key": "severity",
                                                                                            "value": {
                                                                                                "type": "string",
                                                                                                "value": "INFO"
                                                                                            }
                                                                                        },
                                                                                        {
                                                                                            "key": "description",
                                                                                            "value": {
                                                                                                "type": "string",
                                                                                                "value": "Workflow 'RA - Get VM Information' has completed"
                                                                                            }
                                                                                        },
                                                                                        {
                                                                                            "key": "shortDescription",
                                                                                            "value": {
                                                                                                "type": "string",
                                                                                                "value": "Workflow 'RA - Get VM Information' has completed"
                                                                                            }
                                                                                        },
                                                                                        {
                                                                                            "key": "user",
                                                                                            "value": {
                                                                                                "type": "string",
                                                                                                "value": "EAN_PRD_SVC@eur.msd.world.socgen"
                                                                                            }
                                                                                        },
                                                                                        {
                                                                                            "key": "timestamp",
                                                                                            "value": {
                                                                                                "type": "dateTime",
                                                                                                "value": "2018-07-26T17:58:11.662Z"
                                                                                            }
                                                                                        }
                                                                                    ]
                                                                                }
                                                                            },
                                                                            {
                                                                                "classId": "asdExecutionLogs",
                                                                                "componentId": None,
                                                                                "componentTypeId": None,
                                                                                "type": "complex",
                                                                                "typeFilter": None,
                                                                                "values": {
                                                                                    "entries": [
                                                                                        {
                                                                                            "key": "severity",
                                                                                            "value": {
                                                                                                "type": "string",
                                                                                                "value": "INFO"
                                                                                            }
                                                                                        },
                                                                                        {
                                                                                            "key": "description",
                                                                                            "value": {
                                                                                                "type": "string",
                                                                                                "value": "Workflow 'RA - Get VM Information' has started"
                                                                                            }
                                                                                        },
                                                                                        {
                                                                                            "key": "shortDescription",
                                                                                            "value": {
                                                                                                "type": "string",
                                                                                                "value": "Workflow 'RA - Get VM Information' has started"
                                                                                            }
                                                                                        },
                                                                                        {
                                                                                            "key": "user",
                                                                                            "value": {
                                                                                                "type": "string",
                                                                                                "value": "EAN_PRD_SVC@eur.msd.world.socgen"
                                                                                            }
                                                                                        },
                                                                                        {
                                                                                            "key": "timestamp",
                                                                                            "value": {
                                                                                                "type": "dateTime",
                                                                                                "value": "2018-07-26T17:57:57.953Z"
                                                                                            }
                                                                                        }
                                                                                    ]
                                                                                }
                                                                            }
                                                                        ],
                                                                        "type": "multiple"
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        }
                                    ],
                                    "state": {
                                        "dependencies": [],
                                        "facets": []
                                    }
                                }
                            ],
                            "state": {
                                "dependencies": [],
                                "facets": []
                            }
                        },
                        {
                            "id": None,
                            "label": "Step",
                            "sections": [
                                {
                                    "id": None,
                                    "label": None,
                                    "rows": [
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": None,
                                                    "extensionRendererContext": None,
                                                    "id": "provider-__ASD_PRESENTATION_INSTANCE",
                                                    "isMultiValued": False,
                                                    "label": None,
                                                    "labelSize": 0,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 2,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "visible",
                                                                "value": {
                                                                    "type": "constantClause",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": False
                                                                    }
                                                                }
                                                            },
                                                            {
                                                                "type": "editable",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        }
                                    ],
                                    "state": {
                                        "dependencies": [],
                                        "facets": [
                                            {
                                                "type": "visible",
                                                "value": {
                                                    "type": "constantClause",
                                                    "value": {
                                                        "type": "boolean",
                                                        "value": False
                                                    }
                                                }
                                            }
                                        ]
                                    }
                                },
                                {
                                    "id": None,
                                    "label": None,
                                    "rows": [
                                        {
                                            "items": [
                                                {
                                                    "id": None,
                                                    "size": 4,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": []
                                                    },
                                                    "type": "text",
                                                    "value": "Find below details on your virtual machine:"
                                                }
                                            ]
                                        }
                                    ],
                                    "state": {
                                        "dependencies": [],
                                        "facets": []
                                    }
                                },
                                {
                                    "id": None,
                                    "label": "General information",
                                    "rows": [
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": "TEXTBOX",
                                                    "extensionRendererContext": None,
                                                    "id": "provider-ServerName",
                                                    "isMultiValued": False,
                                                    "label": "Server name",
                                                    "labelSize": 2,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 2,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "readOnly",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            },
                                                            {
                                                                "type": "editable",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        },
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": "TEXTBOX",
                                                    "extensionRendererContext": None,
                                                    "id": "provider-LeaseExpirationInfo",
                                                    "isMultiValued": False,
                                                    "label": "Lease expiration",
                                                    "labelSize": 2,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 2,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "readOnly",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            },
                                                            {
                                                                "type": "editable",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        },
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": "TEXTBOX",
                                                    "extensionRendererContext": None,
                                                    "id": "provider-DescriptionInfo",
                                                    "isMultiValued": False,
                                                    "label": "Description",
                                                    "labelSize": 2,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 2,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "readOnly",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            },
                                                            {
                                                                "type": "editable",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        },
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": "TEXTBOX",
                                                    "extensionRendererContext": None,
                                                    "id": "provider-EnvironmentInfo",
                                                    "isMultiValued": False,
                                                    "label": "Environment",
                                                    "labelSize": 2,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 2,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "readOnly",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            },
                                                            {
                                                                "type": "editable",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        },
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": "TEXTBOX",
                                                    "extensionRendererContext": None,
                                                    "id": "provider-RegionInfo",
                                                    "isMultiValued": False,
                                                    "label": "Region",
                                                    "labelSize": 2,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 2,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "readOnly",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            },
                                                            {
                                                                "type": "editable",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        },
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": "TEXTBOX",
                                                    "extensionRendererContext": None,
                                                    "id": "provider-AvailabilityZoneInfo",
                                                    "isMultiValued": False,
                                                    "label": "AvailabilityZone",
                                                    "labelSize": 2,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 2,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "readOnly",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            },
                                                            {
                                                                "type": "refreshOnChange",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": False
                                                                    }
                                                                }
                                                            },
                                                            {
                                                                "type": "editable",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        },
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": "TEXTBOX",
                                                    "extensionRendererContext": None,
                                                    "id": "provider-ReplicationInfo",
                                                    "isMultiValued": False,
                                                    "label": "Replication",
                                                    "labelSize": 2,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 2,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "readOnly",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            },
                                                            {
                                                                "type": "editable",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        },
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": "TEXTBOX",
                                                    "extensionRendererContext": None,
                                                    "id": "provider-BackupInfo",
                                                    "isMultiValued": False,
                                                    "label": "Backup",
                                                    "labelSize": 2,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 2,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "readOnly",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            },
                                                            {
                                                                "type": "editable",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        },
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": "TEXTBOX",
                                                    "extensionRendererContext": None,
                                                    "id": "provider-IPInfo",
                                                    "isMultiValued": False,
                                                    "label": "IP",
                                                    "labelSize": 2,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 2,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "readOnly",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            },
                                                            {
                                                                "type": "editable",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        }
                                    ],
                                    "state": {
                                        "dependencies": [],
                                        "facets": []
                                    }
                                },
                                {
                                    "id": None,
                                    "label": "Machine access information",
                                    "rows": [
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": "TEXTBOX",
                                                    "extensionRendererContext": None,
                                                    "id": "provider-WinUserGroupInfo",
                                                    "isMultiValued": False,
                                                    "label": "User group",
                                                    "labelSize": 2,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 2,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "readOnly",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            },
                                                            {
                                                                "type": "editable",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        },
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": "TEXTBOX",
                                                    "extensionRendererContext": None,
                                                    "id": "provider-WinAdminGroupInfo",
                                                    "isMultiValued": False,
                                                    "label": "Admin group",
                                                    "labelSize": 2,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 2,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "readOnly",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            },
                                                            {
                                                                "type": "editable",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        },
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": "TEXTBOX",
                                                    "extensionRendererContext": None,
                                                    "id": "provider-LinAdZoneInfo",
                                                    "isMultiValued": False,
                                                    "label": "Active Directory Centrify zone",
                                                    "labelSize": 2,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 2,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "readOnly",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            },
                                                            {
                                                                "type": "editable",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        }
                                    ],
                                    "state": {
                                        "dependencies": [],
                                        "facets": []
                                    }
                                },
                                {
                                    "id": None,
                                    "label": "System information",
                                    "rows": [
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": "TEXTBOX",
                                                    "extensionRendererContext": None,
                                                    "id": "provider-SystemMonitoringInfo",
                                                    "isMultiValued": False,
                                                    "label": "System Monitoring",
                                                    "labelSize": 2,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 2,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "readOnly",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            },
                                                            {
                                                                "type": "editable",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        },
                                        {
                                            "items": [
                                                {
                                                    "columns": [],
                                                    "dataType": {
                                                        "type": "primitive",
                                                        "typeId": "STRING"
                                                    },
                                                    "description": None,
                                                    "detailLayout": None,
                                                    "displayAdvice": "TEXTBOX",
                                                    "extensionRendererContext": None,
                                                    "id": "provider-LinServerTypeInfo",
                                                    "isMultiValued": False,
                                                    "label": "Server type",
                                                    "labelSize": 2,
                                                    "orderIndex": None,
                                                    "permissibleValues": None,
                                                    "size": 2,
                                                    "state": {
                                                        "dependencies": [],
                                                        "facets": [
                                                            {
                                                                "type": "readOnly",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            },
                                                            {
                                                                "type": "editable",
                                                                "value": {
                                                                    "type": "constant",
                                                                    "value": {
                                                                        "type": "boolean",
                                                                        "value": True
                                                                    }
                                                                }
                                                            }
                                                        ]
                                                    },
                                                    "type": "field"
                                                }
                                            ]
                                        }
                                    ],
                                    "state": {
                                        "dependencies": [],
                                        "facets": []
                                    }
                                }
                            ],
                            "state": {
                                "dependencies": [],
                                "facets": []
                            }
                        }
                    ]
                },
                "values": {
        "entries": [
            {
                "key": "provider-WinUserGroup",
                "value": {
                    "type": "string",
                    "value": ""
                }
            },
            {
                "key": "provider-LinAdZone",
                "value": {
                    "type": "string",
                    "value": ""
                }
            },
            {
                "key": "reasons",
                "value": None
            },
            {
                "key": "provider-AvailabilityZone",
                "value": {
                    "type": "string",
                    "value": "eu-fr-paris-1"
                }
            },
            {
                "key": "description",
                "value": None
            },
            {
                "key": "provider-Backup",
                "value": {
                    "type": "string",
                    "value": "none"
                }
            },
            {
                "key": "provider-LeaseExpiration",
                "value": {
                    "type": "string",
                    "value": "Mon, 11 Oct 2027 15:01:44 GMT"
                }
            },
            {
                "key": "provider-Region",
                "value": {
                    "type": "string",
                    "value": "eu-fr-paris"
                }
            },
            {
                "key": "provider-IP",
                "value": {
                    "type": "string",
                    "value": "192.88.65.34"
                }
            },
            {
                "key": "provider-LinServerType",
                "value": {
                    "type": "string",
                    "value": ""
                }
            },
            {
                "key": "provider-Environment",
                "value": {
                    "type": "string",
                    "value": "DEV"
                }
            },
            {
                "key": "provider-SystemMonitoring",
                "value": {
                    "type": "string",
                    "value": "disabled"
                }
            },
            {
                "key": "provider-Description",
                "value": {
                    "type": "string",
                    "value": "[EDGE] DO_NOT_DELETE TESTS_PERSO_MSE"
                }
            },
            {
                "key": "provider-Replication",
                "value": {
                    "type": "string",
                    "value": "disabled"
                }
            },
            {
                "key": "provider-WinAdminGroup",
                "value": {
                    "type": "string",
                    "value": ""
                }
            }
        ]
    }
}

    def vra_workflow_request(self, wait, workflow_item, trigram, app_env):
        if trigram in self.TRIGRAM_LIST:
            return {
            "fieldPrefixes": None,
            "layout": {
                "pages": [
                    {
                        "id": None,
                        "label": "General",
                        "sections": [
                            {
                                "id": None,
                                "label": "VRO Workflow Execution Details",
                                "rows": [
                                    {
                                        "items": [
                                            {
                                                "columns": [],
                                                "dataType": {
                                                    "type": "primitive",
                                                    "typeId": "STRING"
                                                },
                                                "description": None,
                                                "detailLayout": None,
                                                "displayAdvice": None,
                                                "extensionRendererContext": None,
                                                "id": "provider-vco.execution.state",
                                                "isMultiValued": False,
                                                "label": "State",
                                                "labelSize": 1,
                                                "orderIndex": None,
                                                "permissibleValues": None,
                                                "size": 8,
                                                "state": {
                                                    "dependencies": [],
                                                    "facets": [
                                                        {
                                                            "type": "derivedValue",
                                                            "value": {
                                                                "type": "constant",
                                                                "value": {
                                                                    "type": "string",
                                                                    "value": "completed"
                                                                }
                                                            }
                                                        }
                                                    ]
                                                },
                                                "type": "field"
                                            }
                                        ]
                                    },
                                    {
                                        "items": [
                                            {
                                                "columns": [],
                                                "dataType": {
                                                    "type": "primitive",
                                                    "typeId": "STRING"
                                                },
                                                "description": None,
                                                "detailLayout": None,
                                                "displayAdvice": None,
                                                "extensionRendererContext": None,
                                                "id": "provider-vco.execution.workflow.name",
                                                "isMultiValued": False,
                                                "label": "Name",
                                                "labelSize": 1,
                                                "orderIndex": None,
                                                "permissibleValues": None,
                                                "size": 8,
                                                "state": {
                                                    "dependencies": [],
                                                    "facets": [
                                                        {
                                                            "type": "derivedValue",
                                                            "value": {
                                                                "type": "constant",
                                                                "value": {
                                                                    "type": "string",
                                                                    "value": "SVC - Get BG List From Trigram"
                                                                }
                                                            }
                                                        }
                                                    ]
                                                },
                                                "type": "field"
                                            }
                                        ]
                                    },
                                    {
                                        "items": [
                                            {
                                                "columns": [],
                                                "dataType": {
                                                    "type": "primitive",
                                                    "typeId": "STRING"
                                                },
                                                "description": None,
                                                "detailLayout": None,
                                                "displayAdvice": None,
                                                "extensionRendererContext": None,
                                                "id": "provider-vco.execution.workflow.token.id",
                                                "isMultiValued": False,
                                                "label": "Token Id",
                                                "labelSize": 1,
                                                "orderIndex": None,
                                                "permissibleValues": None,
                                                "size": 8,
                                                "state": {
                                                    "dependencies": [],
                                                    "facets": [
                                                        {
                                                            "type": "derivedValue",
                                                            "value": {
                                                                "type": "constant",
                                                                "value": {
                                                                    "type": "string",
                                                                    "value": "4020d0dd642bba8a01648e668d6e77e5"
                                                                }
                                                            }
                                                        }
                                                    ]
                                                },
                                                "type": "field"
                                            }
                                        ]
                                    },
                                    {
                                        "items": [
                                            {
                                                "columns": [],
                                                "dataType": {
                                                    "type": "primitive",
                                                    "typeId": "STRING"
                                                },
                                                "description": None,
                                                "detailLayout": None,
                                                "displayAdvice": None,
                                                "extensionRendererContext": None,
                                                "id": "provider-vco.execution.business.state",
                                                "isMultiValued": False,
                                                "label": "Business State",
                                                "labelSize": 1,
                                                "orderIndex": None,
                                                "permissibleValues": None,
                                                "size": 8,
                                                "state": {
                                                    "dependencies": [],
                                                    "facets": [
                                                        {
                                                            "type": "derivedValue",
                                                            "value": {
                                                                "type": "constant",
                                                                "value": {
                                                                    "type": "string",
                                                                    "value": " "
                                                                }
                                                            }
                                                        }
                                                    ]
                                                },
                                                "type": "field"
                                            }
                                        ]
                                    },
                                    {
                                        "items": [
                                            {
                                                "columns": [],
                                                "dataType": {
                                                    "type": "primitive",
                                                    "typeId": "STRING"
                                                },
                                                "description": None,
                                                "detailLayout": None,
                                                "displayAdvice": None,
                                                "extensionRendererContext": None,
                                                "id": "provider-vco.execution.current.activity.name",
                                                "isMultiValued": False,
                                                "label": "Current Activity",
                                                "labelSize": 1,
                                                "orderIndex": None,
                                                "permissibleValues": None,
                                                "size": 8,
                                                "state": {
                                                    "dependencies": [],
                                                    "facets": [
                                                        {
                                                            "type": "derivedValue",
                                                            "value": {
                                                                "type": "constant",
                                                                "value": {
                                                                    "type": "string",
                                                                    "value": " "
                                                                }
                                                            }
                                                        }
                                                    ]
                                                },
                                                "type": "field"
                                            }
                                        ]
                                    },
                                    {
                                        "items": [
                                            {
                                                "columns": [],
                                                "dataType": {
                                                    "type": "primitive",
                                                    "typeId": "DATE_TIME"
                                                },
                                                "description": None,
                                                "detailLayout": None,
                                                "displayAdvice": None,
                                                "extensionRendererContext": None,
                                                "id": "provider-vco.execution.start.date",
                                                "isMultiValued": False,
                                                "label": "Start date",
                                                "labelSize": 1,
                                                "orderIndex": None,
                                                "permissibleValues": None,
                                                "size": 8,
                                                "state": {
                                                    "dependencies": [],
                                                    "facets": [
                                                        {
                                                            "type": "derivedValue",
                                                            "value": {
                                                                "type": "constant",
                                                                "value": {
                                                                    "type": "dateTime",
                                                                    "value": "2018-07-12T12:10:41.436Z"
                                                                }
                                                            }
                                                        }
                                                    ]
                                                },
                                                "type": "field"
                                            }
                                        ]
                                    },
                                    {
                                        "items": [
                                            {
                                                "columns": [],
                                                "dataType": {
                                                    "type": "primitive",
                                                    "typeId": "DATE_TIME"
                                                },
                                                "description": None,
                                                "detailLayout": None,
                                                "displayAdvice": None,
                                                "extensionRendererContext": None,
                                                "id": "provider-vco.execution.end.date",
                                                "isMultiValued": False,
                                                "label": "End date",
                                                "labelSize": 1,
                                                "orderIndex": None,
                                                "permissibleValues": None,
                                                "size": 8,
                                                "state": {
                                                    "dependencies": [],
                                                    "facets": [
                                                        {
                                                            "type": "derivedValue",
                                                            "value": {
                                                                "type": "constant",
                                                                "value": {
                                                                    "type": "dateTime",
                                                                    "value": "2018-07-12T12:10:47.033Z"
                                                                }
                                                            }
                                                        }
                                                    ]
                                                },
                                                "type": "field"
                                            }
                                        ]
                                    },
                                    {
                                        "items": [
                                            {
                                                "columns": [],
                                                "dataType": {
                                                    "type": "primitive",
                                                    "typeId": "STRING"
                                                },
                                                "description": None,
                                                "detailLayout": None,
                                                "displayAdvice": None,
                                                "extensionRendererContext": None,
                                                "id": "provider-vco.execution.error.details",
                                                "isMultiValued": False,
                                                "label": "Error details",
                                                "labelSize": 1,
                                                "orderIndex": None,
                                                "permissibleValues": None,
                                                "size": 8,
                                                "state": {
                                                    "dependencies": [],
                                                    "facets": [
                                                        {
                                                            "type": "derivedValue",
                                                            "value": {
                                                                "type": "constant",
                                                                "value": {
                                                                    "type": "string",
                                                                    "value": " "
                                                                }
                                                            }
                                                        }
                                                    ]
                                                },
                                                "type": "field"
                                            }
                                        ]
                                    }
                                ],
                                "state": {
                                    "dependencies": [],
                                    "facets": []
                                }
                            },
                            {
                                "id": None,
                                "label": None,
                                "rows": [
                                    {
                                        "items": [
                                            {
                                                "columns": [
                                                    {
                                                        "columns": [],
                                                        "dataType": {
                                                            "type": "primitive",
                                                            "typeId": "DATE_TIME"
                                                        },
                                                        "description": None,
                                                        "detailLayout": None,
                                                        "displayAdvice": None,
                                                        "extensionRendererContext": None,
                                                        "id": "timestamp",
                                                        "isMultiValued": False,
                                                        "label": "Timestamp",
                                                        "labelSize": None,
                                                        "orderIndex": None,
                                                        "permissibleValues": None,
                                                        "size": 2,
                                                        "state": {
                                                            "dependencies": [],
                                                            "facets": []
                                                        },
                                                        "type": "field"
                                                    },
                                                    {
                                                        "columns": [],
                                                        "dataType": {
                                                            "type": "primitive",
                                                            "typeId": "STRING"
                                                        },
                                                        "description": None,
                                                        "detailLayout": None,
                                                        "displayAdvice": None,
                                                        "extensionRendererContext": None,
                                                        "id": "user",
                                                        "isMultiValued": False,
                                                        "label": "User",
                                                        "labelSize": None,
                                                        "orderIndex": None,
                                                        "permissibleValues": None,
                                                        "size": 2,
                                                        "state": {
                                                            "dependencies": [],
                                                            "facets": []
                                                        },
                                                        "type": "field"
                                                    },
                                                    {
                                                        "columns": [],
                                                        "dataType": {
                                                            "type": "primitive",
                                                            "typeId": "STRING"
                                                        },
                                                        "description": None,
                                                        "detailLayout": None,
                                                        "displayAdvice": None,
                                                        "extensionRendererContext": None,
                                                        "id": "shortDescription",
                                                        "isMultiValued": False,
                                                        "label": "Short Description",
                                                        "labelSize": None,
                                                        "orderIndex": None,
                                                        "permissibleValues": None,
                                                        "size": 2,
                                                        "state": {
                                                            "dependencies": [],
                                                            "facets": []
                                                        },
                                                        "type": "field"
                                                    },
                                                    {
                                                        "columns": [],
                                                        "dataType": {
                                                            "type": "primitive",
                                                            "typeId": "STRING"
                                                        },
                                                        "description": None,
                                                        "detailLayout": None,
                                                        "displayAdvice": None,
                                                        "extensionRendererContext": None,
                                                        "id": "description",
                                                        "isMultiValued": False,
                                                        "label": "Long Description",
                                                        "labelSize": None,
                                                        "orderIndex": None,
                                                        "permissibleValues": None,
                                                        "size": 2,
                                                        "state": {
                                                            "dependencies": [],
                                                            "facets": []
                                                        },
                                                        "type": "field"
                                                    },
                                                    {
                                                        "columns": [],
                                                        "dataType": {
                                                            "type": "primitive",
                                                            "typeId": "STRING"
                                                        },
                                                        "description": None,
                                                        "detailLayout": None,
                                                        "displayAdvice": None,
                                                        "extensionRendererContext": None,
                                                        "id": "severity",
                                                        "isMultiValued": False,
                                                        "label": "Severity",
                                                        "labelSize": None,
                                                        "orderIndex": None,
                                                        "permissibleValues": None,
                                                        "size": 2,
                                                        "state": {
                                                            "dependencies": [],
                                                            "facets": []
                                                        },
                                                        "type": "field"
                                                    }
                                                ],
                                                "dataType": {
                                                    "classId": "asdExecutionLogs",
                                                    "componentId": None,
                                                    "componentTypeId": None,
                                                    "label": None,
                                                    "schema": None,
                                                    "type": "complex",
                                                    "typeFilter": None
                                                },
                                                "description": None,
                                                "detailLayout": None,
                                                "displayAdvice": "DATA_TABLE",
                                                "extensionRendererContext": None,
                                                "id": "provider-_asd.executionLogs_",
                                                "isMultiValued": False,
                                                "label": "Logs",
                                                "labelSize": 1,
                                                "orderIndex": None,
                                                "permissibleValues": None,
                                                "size": 8,
                                                "state": {
                                                    "dependencies": [],
                                                    "facets": [
                                                        {
                                                            "type": "defaultValue",
                                                            "value": {
                                                                "type": "constant",
                                                                "value": {
                                                                    "elementTypeId": "COMPLEX",
                                                                    "items": [
                                                                        {
                                                                            "classId": "asdExecutionLogs",
                                                                            "componentId": None,
                                                                            "componentTypeId": None,
                                                                            "type": "complex",
                                                                            "typeFilter": None,
                                                                            "values": {
                                                                                "entries": [
                                                                                    {
                                                                                        "key": "severity",
                                                                                        "value": {
                                                                                            "type": "string",
                                                                                            "value": "INFO"
                                                                                        }
                                                                                    },
                                                                                    {
                                                                                        "key": "description",
                                                                                        "value": {
                                                                                            "type": "string",
                                                                                            "value": "Workflow 'SVC - Get BG List From Trigram' has completed"
                                                                                        }
                                                                                    },
                                                                                    {
                                                                                        "key": "shortDescription",
                                                                                        "value": {
                                                                                            "type": "string",
                                                                                            "value": "Workflow 'SVC - Get BG List From Trigram' has completed"
                                                                                        }
                                                                                    },
                                                                                    {
                                                                                        "key": "user",
                                                                                        "value": {
                                                                                            "type": "string",
                                                                                            "value": "EAN_PRD_SVC@eur.msd.world.socgen"
                                                                                        }
                                                                                    },
                                                                                    {
                                                                                        "key": "timestamp",
                                                                                        "value": {
                                                                                            "type": "dateTime",
                                                                                            "value": "2018-07-12T12:10:44.083Z"
                                                                                        }
                                                                                    }
                                                                                ]
                                                                            }
                                                                        },
                                                                        {
                                                                            "classId": "asdExecutionLogs",
                                                                            "componentId": None,
                                                                            "componentTypeId": None,
                                                                            "type": "complex",
                                                                            "typeFilter": None,
                                                                            "values": {
                                                                                "entries": [
                                                                                    {
                                                                                        "key": "severity",
                                                                                        "value": {
                                                                                            "type": "string",
                                                                                            "value": "INFO"
                                                                                        }
                                                                                    },
                                                                                    {
                                                                                        "key": "description",
                                                                                        "value": {
                                                                                            "type": "string",
                                                                                            "value": "Workflow 'SVC - Get BG List From Trigram' has started"
                                                                                        }
                                                                                    },
                                                                                    {
                                                                                        "key": "shortDescription",
                                                                                        "value": {
                                                                                            "type": "string",
                                                                                            "value": "Workflow 'SVC - Get BG List From Trigram' has started"
                                                                                        }
                                                                                    },
                                                                                    {
                                                                                        "key": "user",
                                                                                        "value": {
                                                                                            "type": "string",
                                                                                            "value": "EAN_PRD_SVC@eur.msd.world.socgen"
                                                                                        }
                                                                                    },
                                                                                    {
                                                                                        "key": "timestamp",
                                                                                        "value": {
                                                                                            "type": "dateTime",
                                                                                            "value": "2018-07-12T12:10:43.976Z"
                                                                                        }
                                                                                    }
                                                                                ]
                                                                            }
                                                                        }
                                                                    ],
                                                                    "type": "multiple"
                                                                }
                                                            }
                                                        }
                                                    ]
                                                },
                                                "type": "field"
                                            }
                                        ]
                                    }
                                ],
                                "state": {
                                    "dependencies": [],
                                    "facets": []
                                }
                            }
                        ],
                        "state": {
                            "dependencies": [],
                            "facets": []
                        }
                    },
                    {
                        "id": None,
                        "label": "Step",
                        "sections": [
                            {
                                "id": None,
                                "label": None,
                                "rows": [
                                    {
                                        "items": [
                                            {
                                                "columns": [],
                                                "dataType": {
                                                    "type": "primitive",
                                                    "typeId": "STRING"
                                                },
                                                "description": None,
                                                "detailLayout": None,
                                                "displayAdvice": None,
                                                "extensionRendererContext": None,
                                                "id": "provider-__ASD_PRESENTATION_INSTANCE",
                                                "isMultiValued": False,
                                                "label": None,
                                                "labelSize": 0,
                                                "orderIndex": None,
                                                "permissibleValues": None,
                                                "size": 2,
                                                "state": {
                                                    "dependencies": [],
                                                    "facets": [
                                                        {
                                                            "type": "visible",
                                                            "value": {
                                                                "type": "constantClause",
                                                                "value": {
                                                                    "type": "boolean",
                                                                    "value": False
                                                                }
                                                            }
                                                        }
                                                    ]
                                                },
                                                "type": "field"
                                            }
                                        ]
                                    }
                                ],
                                "state": {
                                    "dependencies": [],
                                    "facets": [
                                        {
                                            "type": "visible",
                                            "value": {
                                                "type": "constantClause",
                                                "value": {
                                                    "type": "boolean",
                                                    "value": False
                                                }
                                            }
                                        }
                                    ]
                                }
                            },
                            {
                                "id": None,
                                "label": None,
                                "rows": [
                                    {
                                        "items": [
                                            {
                                                "columns": [],
                                                "dataType": {
                                                    "type": "primitive",
                                                    "typeId": "STRING"
                                                },
                                                "description": "trigram",
                                                "detailLayout": None,
                                                "displayAdvice": None,
                                                "extensionRendererContext": None,
                                                "id": "provider-trigram",
                                                "isMultiValued": False,
                                                "label": "trigram",
                                                "labelSize": 2,
                                                "orderIndex": None,
                                                "permissibleValues": None,
                                                "size": 2,
                                                "state": {
                                                    "dependencies": [],
                                                    "facets": []
                                                },
                                                "type": "field"
                                            }
                                        ]
                                    },
                                    {
                                        "items": [
                                            {
                                                "columns": [],
                                                "dataType": {
                                                    "type": "primitive",
                                                    "typeId": "STRING"
                                                },
                                                "description": "restrictedTo",
                                                "detailLayout": None,
                                                "displayAdvice": None,
                                                "extensionRendererContext": None,
                                                "id": "provider-restrictedTo",
                                                "isMultiValued": False,
                                                "label": "restrictedTo",
                                                "labelSize": 2,
                                                "orderIndex": None,
                                                "permissibleValues": None,
                                                "size": 2,
                                                "state": {
                                                    "dependencies": [],
                                                    "facets": []
                                                },
                                                "type": "field"
                                            }
                                        ]
                                    },
                                    {
                                        "items": [
                                            {
                                                "columns": [],
                                                "dataType": {
                                                    "type": "primitive",
                                                    "typeId": "STRING"
                                                },
                                                "description": None,
                                                "detailLayout": None,
                                                "displayAdvice": "SEARCHER",
                                                "extensionRendererContext": None,
                                                "id": "provider-BGResult",
                                                "isMultiValued": True,
                                                "label": "BGResult",
                                                "labelSize": 2,
                                                "orderIndex": None,
                                                "permissibleValues": None,
                                                "size": 2,
                                                "state": {
                                                    "dependencies": [],
                                                    "facets": [
                                                        {
                                                            "type": "readOnly",
                                                            "value": {
                                                                "type": "constantClause",
                                                                "value": {
                                                                    "type": "boolean",
                                                                    "value": True
                                                                }
                                                            }
                                                        }
                                                    ]
                                                },
                                                "type": "field"
                                            }
                                        ]
                                    }
                                ],
                                "state": {
                                    "dependencies": [],
                                    "facets": []
                                }
                            }
                        ],
                        "state": {
                            "dependencies": [],
                            "facets": []
                        }
                    }
                ]
            },
            "values": {
                "entries": [
                    {
                        "key": "reasons",
                        "value": None
                    },
                    {
                        "key": "provider-trigram",
                        "value": {
                            "type": "string",
                            "value": trigram.lower()
                        }
                    },
                    {
                        "key": "provider-BGResult",
                        "value": {
                            "elementTypeId": "STRING",
                            "items": [
                                {
                                    "type": "string",
                                    "value": "BG_GTS-RET"
                                }
                            ],
                            "type": "multiple"
                        }
                    },
                    {
                        "key": "provider-restrictedTo",
                        "value": {
                            "type": "string",
                            "value": "RET"
                        }
                    },
                    {
                        "key": "description",
                        "value": None
                    },
                    {
                        "key": "provider-__asd_requestedBy",
                        "value": {
                            "type": "string",
                            "value": "EAN_PRD_SVC@eur.msd.world.socgen"
                        }
                    },
                    {
                        "key": "provider-__asd_requestedFor",
                        "value": {
                            "type": "string",
                            "value": "EAN_PRD_SVC@eur.msd.world.socgen"
                        }
                    },
                    {
                        "key": "provider-environment",
                        "value": {
                            "type": "string",
                            "value": "non-PRD" if app_env.lower() != "prd" else 'PRD'
                        }
                    }
                ]
            }
        }
        return {}

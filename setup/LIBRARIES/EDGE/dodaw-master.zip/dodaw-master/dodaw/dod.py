#!/usr/bin/python
# -*- coding: utf-8 -*-

#

DOCUMENTATION = '''
---


'''

EXAMPLES = '''

'''

import time
import logging
import requests
from random import randrange
from collections import Counter
from requests.auth import HTTPBasicAuth
from requests.packages.urllib3.exceptions import InsecureRequestWarning

from dodaw.conf import settings
from dodaw.credential import get_user_pwd
from dodaw.exception import DodError, NoRecordFound, LimitRowsExceeded

logging.basicConfig(level=logging.getLevelName(settings.LOGGER_LEVEL))
logger = logging.getLogger(__name__)


class DodWrapper(object):
    def __init__(self):
        assert settings.URL, 'no URL found in the settings'
        user, pwd = get_user_pwd(settings.CREDENTIALS_GROUP_RET)
        self.auth = HTTPBasicAuth(user, pwd)
        requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
        self.retry = Counter({'search_record': 1, 'create_record': 1, 'update_record': 1})

    def search_record(self, record_type, **kwargs):
        '''
        :param record_type: string , regexp is possible
        :param kwargs:
        :return: a list of records, a record is a dict
        '''
        params = dict(kwargs)
        params.update({
            'type': record_type,
            'method': 'record_search',
        })
        result_json = {}
        try:
            r = requests.get(settings.URL, auth=self.auth, params=params, verify=False)
        except requests.exceptions.RequestException as e:
            raise DodError(e.args[0])

        try:
            result_json = r.json()
        except Exception as e:
            raise DodError(e.args[0], r.text)

        try:
            r.raise_for_status()
        except Exception as e:
            if r.status_code == 500 and self.retry['search_record'] <= settings.MAX_RETRIES_ERROR_500:
                self.retry['search_record'] += 1
                time.sleep(randrange(1, 6))
                return self.search_record(record_type, **kwargs)
            elif r.status_code == 500 and self.retry['search_record'] > settings.MAX_RETRIES_ERROR_500:
                raise DodError("Maximum retries for Error 500 Dod <search_record>: {}".format(e.args[0]))
            raise DodError(e.args[0], result_json)

        records = result_json['Response']
        if isinstance(records, dict):
            if records['status_code'] == 404:
                return []
        assert isinstance(records, list)
        return records

    def create_record(self, dns_service, record_type, zone, view, hostname, **kwargs):
        '''
        :param dns_service:
        :param record_type:
        :param zone:
        :param view:
        :param hostname:
        :param kwargs:
        :return: a record which is a dictionary example:
            {u'zone': u'db.dns21-3.socgen', u'ip': u'111.80.17.209', u'hostname': u'dpgalx4000', u'comments': u'',
             u'class': u'IN', u'ttl': u'Default', u'type': u'A', u'id': 376351, u'view': u'production'}
        '''
        data = dict(kwargs)
        data.update({
            'dns_service': dns_service,
            'method': 'record_add',
            'type': record_type,
            'zone': zone,
            'view': view,
            'hostname': hostname,
        })
        result_json = {}
        try:
            r = requests.post(settings.URL, auth=self.auth, data=data, verify=False)
        except requests.exceptions.RequestException as e:
            raise DodError(e.args[0])

        try:
            result_json = r.json()
        except Exception as e:
            raise DodError(e.args[0], r.text)

        try:
            r.raise_for_status()
        except Exception as e:
            if r.status_code == 500 and self.retry['create_record'] <= settings.MAX_RETRIES_ERROR_500:
                self.retry['create_record'] += 1
                time.sleep(randrange(1, 6))
                return self.create_record(dns_service, record_type, zone, view, hostname, **kwargs)
            elif r.status_code == 500 and self.retry['create_record'] > settings.MAX_RETRIES_ERROR_500:
                raise DodError("Maximum retries for Error 500 Dod <create_record>: {}".format(e.args[0]))
            raise DodError(e.args[0], result_json)

        try:
            assert r.status_code == 200, "status code different than 200 in create_record: dodaw/dod.py"
        except AssertionError as e:
            raise DodError(repr(e))

        record = result_json['Response'][0]
        return record

    def delete_record(self, dns_service, id):
        '''
        :param dns_service:
        :param id:
        :return: None
        '''
        headers = {
            'Content-type': 'application/json',
            'Accept': 'application/json',
            'Accept-Charset': 'ISO-8859-1,utf-8;',
        }
        result_json = {}
        url = '%s/%s?dns_service=%s' % (settings.URL, id, dns_service)
        url = url.replace(' ', '%20')
        try:
            r = requests.delete(url, auth=self.auth, headers=headers, verify=False)
        except requests.exceptions.RequestException as e:
            raise DodError(e.args[0])

        try:
            result_json = r.json()
        except Exception as e:
            raise DodError(e.args[0], r.text)

        try:
            r.raise_for_status()
        except Exception as e:
            if r.status_code == 404:
                raise NoRecordFound(e.args[0], result_json)

            raise DodError(e.args[0], result_json)
        try:
            assert r.status_code == 200, "status code different than 200 in delete_record: dodaw/dod.py"
        except AssertionError as e:
            raise DodError(repr(e))

    def update_record(self, dns_service, id, record_type, zone, view, hostname, ip, **kwargs):

        data = dict(kwargs)
        data.update({
            'id': id,
            'dns_service': dns_service,
            'type': record_type,
            'zone': zone,
            'view': view,
            'hostname': hostname,
            'ip': ip,
        })
        result_json = {}
        url = '%s/%s?dns_service=%s' % (settings.URL, id, dns_service)
        url = url.replace(' ', '%20')
        try:
            r = requests.put(url, auth=self.auth, data=data, verify=False)
        except requests.exceptions.RequestException as e:
            raise DodError(e.args[0])

        try:
            result_json = r.json()
        except Exception as e:
            raise DodError(e.args[0], r.text)

        try:
            r.raise_for_status()
        except Exception as e:
            if r.status_code == 404:
                raise NoRecordFound(e.args[0], result_json)
            if r.status_code == 500 and self.retry['update_record'] <= settings.MAX_RETRIES_ERROR_500:
                self.retry['update_record'] += 1
                time.sleep(randrange(1, 6))
                return self.update_record(dns_service, id, record_type, zone, view, hostname, ip, **kwargs)
            elif r.status_code == 500 and self.retry['update_record'] > settings.MAX_RETRIES_ERROR_500:
                raise DodError("Maximum retries for Error 500 Dod <update_record>: {}".format(e.args[0]))
            raise DodError(e.args[0], result_json)

        try:
            assert r.status_code == 200, "status code different than 200 in update_record: dodaw/dod.py"
        except AssertionError as e:
            raise DodError(repr(e))

        record = result_json['Response']

        return record

    def search_and_update_conflict_records(self, dns_service, record_type, cause, limit_rows=settings.DELETE_LIMIT_ROWS,
                                           **kwargs):

        try:
            assert limit_rows <= 10, "limit rows to update is too high, it cannot exceed 10 in search_and_update_conflict_records: dodaw/dod.py"
        except AssertionError as e:
            raise DodError(repr(e))

        timestamp = time.time()
        records = self.search_record(record_type, dns_service=dns_service, **kwargs)
        if len(records) > limit_rows:
            raise LimitRowsExceeded
        response = []
        for record in records:
            id = record['id']
            hostname = "edge_conflict_{}_{}".format(cause, int(timestamp))
            record_type = record['type']
            zone = record['zone']
            view = record['view']
            ip = record['ip']
            try:
                result = self.update_record(dns_service, id, record_type, zone, view, hostname, ip)
                response.append("{} : {} - {}".format(id, hostname, ip))
            except NoRecordFound as e:
                pass
        return response

    def search_and_delete_records(self, dns_service, record_type, limit_rows=settings.DELETE_LIMIT_ROWS, **kwargs):
        '''
        raise an exception of the limit is reached
        :param dns_service:
        :param record_type:
        :param limit_rows: Integer
        :param kwargs:
        :return: list of ids corresponding to records deleted
        '''
        try:
            assert limit_rows <= 10, "limit rows to update is too high, it cannot exceed 10 in search_and_delete_records: dodaw/dod.py"
        except AssertionError as e:
            raise DodError(repr(e))

        records = self.search_record(record_type, dns_service=dns_service, **kwargs)
        if len(records) > limit_rows:
            raise LimitRowsExceeded
        response = []
        for record in records:
            id = record['id']
            try:
                self.delete_record(dns_service, id)
                response.append(id)
            except NoRecordFound as e:
                pass
        return response

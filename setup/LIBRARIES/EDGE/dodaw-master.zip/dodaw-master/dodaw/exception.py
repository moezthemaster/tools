
class DodError(Exception):
    def __init__(self, message, details=''):
        super(DodError, self).__init__("{} {} ".format(message, details))
        self.details = details


class NoRecordFound(DodError):
    pass


class ImproperlyConfigured(Exception):
    '''Dodaw is somehow improperly configured'''
    pass


class LimitRowsExceeded(Exception):
    pass


class DodClientError(Exception):
    pass
    
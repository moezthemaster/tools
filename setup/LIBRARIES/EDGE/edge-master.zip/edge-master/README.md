# Edge library

This repository contains all the intelligence of the creation of vm, it is mainly used by the FT Edge.
As the creation and configuration of vm is done through several steps, each step is highlighted in a separate library:

- [KAT](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge/tree/master/edge/kat)

Used to check client( irt-code, trigram) existence in the kat.
An exception is raised if no entry exist for the given code_irt and trigram.

- [DNS](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge/tree/master/edge/dns)

Used to manage (create,update, search and delete) dns records, and generate hostname if not specified. It supports the two versions of dod (dodv1 (for ex-mkt) and dodv2 (for ex-ret))

- [MANAGE_IP](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge/tree/master/edge/manage_ip)

Used to get IP address and minimize/raise ip conflicts (such as notifing user of ip conflict with another server, or error getting an ip address after several attemps)
It's also used to blacklist IP adress to avoid incidents.

- [CLOUD_VM](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge/tree/master/edge/cloud_vm)

Used to define some required methods of vm creation/destruction (create/destroy/get_infos/_get_provider_bg ...)

- [CONNECTION](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge/tree/master/edge/connection)

Used to check ssh/rdp connection with the newely created vm and to execute remote commands on servers

- [NETWORK](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge/tree/master/edge/network)

Used to set the network, dns and ntp configuration for newely created vms

- [MARLEY](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge/tree/master/edge/marley)

Used to run HPOO Flow, In order to register the VM in Marley referential

- [KPI](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge/tree/master/edge/kpi)

Used to extract kpi information of each execution and store them in elasticsearch

- [INVENTORY](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge/tree/master/edge/inventory)

Used to make an inventory of DOD and Cloud_vra. It helps us to detecte incoerrence and correcte/communicate them

- [FILESYSTEM](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge/tree/master/edge/filesystem)

Used to create/customize file systems

Beside those libraries, there is a [conf](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge/tree/master/edge/conf) directory, it contains 

- cloud_network.py

It's a mapping file, used to get network_cidr, dns_cname and dns_zone given (env, region_cloud, az_cloud, network_id). The method used for this is get_details. If an entry is wrong, an exception is raised with the message combination env="{}" region_cloud="{}" az_cloud="{}" network_id="{}" is not available in cloud_network mapping

- global_settings.py

Used for default default variables. To overide them, use the settings file .py pointed to by the EDGE_CONFIG_FILE environment variable

- kat_marley.py

A mapping file to handle new sigle ME, and map kat entries (sigle ME) with marley entries (endclient)

<h3>How to use this library ?</h3>
In order to use this library, some environment setups needs to be done. As mentionned above, this library uses some settings files to override those defined in global_settings file.

Suppose we're going to use a paroduction settings file, and we're going to make a unit execution of edge library, we need to copy settings_prod.cfg file from [files](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/playbook_edge_vm/tree/master/files), paste it in a costume path <strong>PATH</strong> and set EDGE_CONFIG_FILE environment variable

```
export EDGE_CONFIG_FILE=PATH/settings_prod.cfg
```

#!/usr/bin/env python
# -*- coding: utf-8 -*-

import ansible_play
from behave import *


@when('Run egde fs')
def step_impl(context):
    if context.params.get('fs_list', None) == None:
        assert context.failed is False

    become_user_password = 'foo-whatever'
    run_data = {
        'fs_list': context.params['fs_list'],
        'vm_hostname': context.params['vm_hostname'],
        'patrol_action': 'create',
        'pat_envi': context.params['app_env'],
        'system_trigram': context.params['app_id'],
        'module_vm_ip_address': context.params['vm_ipaddr'],
        'ip_address': context.params['vm_ipaddr']
    }

    runner = ansible_play.Runner(
        hostnames='localhost',
        playbook='run_edge_fs.yml',
        tags="",
        private_key_file=context.private_key,
        run_data=run_data,
        become_pass=become_user_password,
        verbosity=100,
        connection='local'
    )

    stats = runner.run()

    print(
    "VM {} created with following File_Systems: {}\n".format(context.params['vm_hostname'], context.params['fs_list']))
    print("VM {} Trigram is: {}\n".format(context.params['vm_hostname'], context.params['app_id']))
    return stats


import re
import os
import sys
import io
import logging
import datetime

if "TREE_DIR" in os.environ.keys():
    ANSIBLE_MODULES_PATH = [
        os.path.join(os.environ["TREE_DIR"], 'roles/edge'),
        os.path.join(os.environ["TREE_DIR"], "library"),
        os.path.join(os.environ["TREE_DIR"], 'roles/py_edge_vault'),

    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/edge',
        './roles/py_edge_vault'
    ]
for path in ANSIBLE_MODULES_PATH:
    sys.path.append(path)

from edge.kpi.elk import Loader
from edge.exception import EdgeException
from edge.connection.connectionhelper import ConnectionHelper
from ansible.module_utils.basic import AnsibleModule

formatter = logging.Formatter(fmt='%(asctime)s %(levelname)-8s %(message)s',
                              datefmt='%Y-%m-%d %H:%M:%S')
logstream = io.StringIO()
handler = logging.StreamHandler(logstream)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.addHandler(handler)
logger.setLevel(logging.WARNING)


class ConnectionHelperImp(ConnectionHelper):
    def __init__(self):
        ConnectionHelper.__init__(self)

    def set_pubkey(self, ip_address, remote_user, remote_group, pubkey):

        response = self.authorized_key(ip_address=ip_address, remote_user=remote_user, remote_group=remote_group,
                                       pubkey=pubkey)

        return response



PRESENT, STATUS = 'present', 'status'

FIELDS = {
    "ip": {"required": True, "type": "str"},
    "vm_hostname": {"required": True, "type": "str"},
    "remote_user": {"required": False, "type": "str", "default": "automation"},
    "remote_group": {"required": False, "type": "str", "default": "automation"},
    "pubkey": {
        "default": "ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAyLXUQ9eoPr8Akx+WeJzRgAOMyUbTQ3/RDu44N2svQTa7I0ZKzqelNrSqqsgSmNN7giQGRyIvx/XgUwi9UjrxFX0XRTvwjAcXNHV2pxybbhPb8/2jiAfFTCjkwQBwtoSTEL1I5noAIgapQDZghYFkv0GUiAkebKzl0A+cNqm5Zc2UPNTqsCtIAZ5Uid+XOdECHan29Iyow0f+O/2O6mZKBGvWFJbRLCokKLUrTmhbgWIiWgQGp/PnF0XVVPiQgRfbRz1xH08JNiQz1lnvZ4ME4BhQoxSK1O8QL+dQsSXhvQyjfO8yYI+X4X73Ie9yBfZpPiGAZLo3hTVha46veVfZGw== a373785@PXPLSV02",
        "required": False,
        "type": "str"},
    "state": {
        "default": "present",
        "choices": ['present', 'status'],
        "type": 'str'
    },
    "app_env": {
        "default": "prd",
        "choices": [
            'uat',
            'tst',
            'int',
            'dev',
            'hml',
            'prd'
        ],
        "type": "str",
        "required": False
    },
    "endClient": {
        "required": False,
        "type": "str"
    },
    "kpi_data": {
        "type": "dict"
    }
}


def index_error_kpi(kpi_data,kpi_start_time):
    try:
        kpi_end_time = datetime.datetime.now()
        kpi_data['duration'] = (kpi_end_time - kpi_start_time).seconds
        loader = Loader()
        loader.index_data(
            id_execution=kpi_data['id_execution'], timestamp=kpi_data['timestamp'], 
            duration=kpi_data['duration'], service=kpi_data['service'],
            hostname=kpi_data['vm_hostname'], status="failure",
            category=kpi_data['category'], client=kpi_data['endClient'],
            trigram=kpi_data['app_id'], environment=kpi_data['app_env'],
            error=kpi_data['error'], playbook_version=kpi_data['playbook_version']
        )
    except Exception:
        pass

def main():
    module = AnsibleModule(argument_spec=FIELDS)
    if module._verbosity == 1:
        logger.setLevel(logging.INFO)
    if module._verbosity == 3:
        logger.setLevel(logging.DEBUG)
    logger.info('module sg_gts_connection')
    kpi_data = module.params['kpi_data']
    kpi_start_time = datetime.datetime.now()

    try:
        state = module.params['state']
        if isinstance(kpi_data, dict):
            kpi_data['service'] = 'sg_gts_connection_{}'.format(state)
        cnxhelper = ConnectionHelperImp()

        if state == PRESENT:
            response = cnxhelper.set_pubkey(
                ip_address=module.params['ip'],
                remote_user=module.params['remote_user'],
                remote_group=module.params['remote_group'],
                pubkey=module.params['pubkey']
            )
            module.exit_json(changed=cnxhelper.has_changed, meta=response, debug_out=logstream.getvalue())

        elif state == STATUS:
            response = cnxhelper.check_ip_address(module.params['ip'])
            match_hostname = re.match(r'^({0}\..*)|({0})$'.format(module.params['vm_hostname']), response)
            if response == "No host responding in RDP" or match_hostname:
                module.exit_json(changed=cnxhelper.has_changed, meta="No IP conflict", debug_out=logstream.getvalue())
            else:
                if isinstance(kpi_data, dict):
                    kpi_data['error'] = response
                    index_error_kpi(kpi_data,kpi_start_time)
                module.fail_json(msg="Another host has been found for this IP address : {}".format(response), debug_out=logstream.getvalue())

    except Exception as e:
        if isinstance(kpi_data, dict):
            kpi_data['error'] = e.args[0]
            index_error_kpi(kpi_data,kpi_start_time)
        module.fail_json(msg=e.args[0], debug_out=logstream.getvalue())


if __name__ == '__main__':
    main()

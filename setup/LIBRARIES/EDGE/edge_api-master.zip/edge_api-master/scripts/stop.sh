#!/usr/bin/env bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PID_FILE=server.pid

cd ${DIR}/..

if [ ! -f ${PID_FILE} ]; then
    echo "The file ${PID_FILE} does not exists, it seems the server is already stopped."
    exit 0
fi

PID=`cat ${PID_FILE}`

kill -15 ${PID}
sleep 2
kill -0 ${PID}

if [ $? -eq 0 ]; then
    echo "Could not shut down the server in time. You better investigate this"
    exit 1
fi

rm -f ${PID_FILE}
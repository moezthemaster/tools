#!/usr/bin/python
# -*- coding: utf-8 -*-


DOCUMENTATION = '''
Mapping file to handle new sigle ME, and map kat entries (sigle ME) with marley entries (endclient)
'''

KAT_MRL = {
    'GTS' : 'GTS',
    'BSC' : 'BSC',
    'ITIM': 'ITIM',
    'ITEC': 'SGCIB',
}
#!/usr/bin/python
# -*- coding: utf-8 -*-

#

from json import dumps
from requests.models import Response

def mocked_client_token():
    result = {
        "request_id":"40611461-7495-588d-abf0-a6d778bfa650",
        "lease_id":"",
        "renewable":False,
        "lease_duration":0,
        "data":None,
        "wrap_info":None,
        "warnings":None,
        "auth":{
            "client_token":"4bb5f40d-0d2c-c50f-7035-3c804168c9c2",
            "accessor":"99d325f3-dc40-437a-34da-a753c915d368",
            "policies":["default","edge-001/edge-read"],
            "metadata":{
                "role_name":"edge-001-login-read"
            },
            "lease_duration":1200,
            "renewable":True
        }
    }
    resp = Response()
    resp.status_code = 200
    resp._content = dumps(result).encode()   
    return resp


def mocked_secret(context, env=None):
    resp = Response()

    if context == "test_context" and env == "uat":
        resp.status_code = 200
        result = {
            "request_id":"eebd540e-ced7-584b-8c5c-178e061ae05d",
            "lease_id":"",
            "renewable":False,
            "lease_duration":2764800,
            "data":{
                "password": "dummy",
                "username": "test"
            },
            "wrap_info":None,
            "warnings":None,
            "auth":None
        }
    else:
        resp.status_code = 404
        result = {"errors":[]}
    
    resp._content = dumps(result).encode()   
    return resp

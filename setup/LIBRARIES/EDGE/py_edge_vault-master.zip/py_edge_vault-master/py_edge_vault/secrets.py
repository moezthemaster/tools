#!/usr/bin/python
# -*- coding: utf-8 -*-

#

import os
import time
import requests
from random import randrange
from requests.compat import urljoin
from py_edge_vault.conf import settings
from py_edge_vault.exception import ImproperlyConfigured, VaultException

def get_secrets(context, env=None, retry=3):

    try:
        vault_url = settings.VAULT_URL
        role_id = settings.ROLE_ID
        application = settings.APPLICATION
    except:
        raise ImproperlyConfigured(
            'Requested settings, but settings are not configured. '
            'Please make sur the variables VAULT_URL, ROLE_ID and APPLICATION are well set in $VAULT_CONFIG_FILE'
        )
              
    if env is None:
        secret = '/'.join(['v1', 'secret', application, context])
    else:
        secret = '/'.join(['v1','secret', application, context, env])

    try:
        with open("/etc/ansible/gts_edge.cfg", "r") as file:
            parser = file.readlines()
            for ligne in parser:
                ligne_split = ligne.split("=")
                if ligne_split[0] == "secret_id":
                    secret_id = ligne_split[1].rstrip()
                    break
    except:
        raise ImproperlyConfigured(
            'Requested settings, but settings are not configured. '
            'You must define the vault secret_id /etc/ansible/gts_edge.cfg'
        )

    token = login(role_id, secret_id)

    try:
        headers = {"X-Vault-Token": token}
        url = urljoin(settings.VAULT_URL, secret)
    except Exception as e:
         raise VaultException(e)

    try:
        r = requests.get(url, headers=headers, verify=False)
    except Exception as e:
        raise VaultException(repr(e))

    try:
        r.raise_for_status()
    except Exception as e:
        if r.status_code == 500 and retry > 0:
            retry -= 1
            time.sleep(randrange(1, 6))
            return get_secrets(context, env, retry)
        elif r.status_code == 500 and retry == 0:
            raise VaultException("Maximum retries for Error 500 VAULT <get_secrets>: {}".format(repr(e)))
        elif r.status_code != 404:
            raise VaultException(repr(e))

    try:
        response = r.json()['data']
    except:
        raise VaultException('No data found in vault for the combination {}, {}'.format(context, env))

    return response

def login(role_id, secret_id, retry=3):

    login_data = {
        "secret_id":secret_id,
        "role_id": role_id
    }
    endpoint = 'v1/auth/approle/login'
    url = urljoin(settings.VAULT_URL, endpoint)

    try:        
        r = requests.post(url, json=login_data, verify=False)
    except Exception as e:
        raise VaultException(repr(e))
        
    try:        
        r.raise_for_status()
    except Exception as e:
        if r.status_code == 500 and retry > 0:
            retry -= 1
            time.sleep(randrange(1, 6))
            return login(role_id, secret_id, retry)
        elif r.status_code == 500 and retry == 0:
            raise VaultException("Maximum retries for Error 500 VAULT <login>: {}".format(repr(e)))
        raise VaultException(e)
    
    try:
        token = r.json()['auth']['client_token']
    except Exception as e:
        raise VaultException('Client_token is not generated !!')

    return token

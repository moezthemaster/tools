#!/usr/bin/python
# -*- coding: utf-8 -*-

from edge.exception import EdgeException
from edge.connection.connectionhelper import ConnectionHelper
import socket
import struct
def mocked_vault():
    return   {
        'user': 'UserX',
        'private_root_key': u"private_key"
    }


BLACKLIST_NETWORK_DB = ("192.36.65.0/24",)


def get_all_ip(subnet):
    """
    get all ip address for subnet
    eg:
    192.168.56.0/24 => yield 192.168.56.1 -> 192.168.56.254
    """
    (ip, cidr) = subnet.split("/")
    cidr = int(cidr)
    host_bits = 32 - cidr
    i = struct.unpack(">I", socket.inet_aton(ip))[0]
    start = (i >> host_bits) << host_bits
    end = i | ((1 << host_bits) - 1)
    for i in range(start, end):
        ip = socket.inet_ntoa(struct.pack(">I", i))
        if ip.endswith(".0") or ip.endswith(".255"):
            continue
        yield socket.inet_ntoa(struct.pack(">I", i))


class VmDatabase(object):

    def __init__(self, shared_database=None):
        if isinstance(shared_database, list):
            self.vm_database = shared_database
        else:
            self.vm_database = []

    def add_vm(self, vm):
        found = list(filter(lambda x: x["ip"] == vm["ip"], self.vm_database))
        if found:
            raise Exception("vm {} already exists...".format(vm["ip"]))
        self.vm_database.append(vm)
        return True

    def search_vm(self, ip):
        try:
            index = list(map(lambda x: x["ip"], self.vm_database)).index(ip)
        except ValueError:
            return None
        vm = self.vm_database[index]
        return vm

    def del_vm(self, ip):
        try:
            index = list(map(lambda x: x["ip"], self.vm_database)).index(ip)
        except ValueError:
            raise Exception("vm {} not exists...".format(ip))
        self.vm_database.remove(index)
        return True


class MockedConnectionHelper(VmDatabase):

    def __init__(self, shared_database=None, **kwargs):
        VmDatabase.__init__(self, shared_database, **kwargs)

    def authorized_key(self, ip_address,remote_user,remote_group,pubkey):
        vm = self.search_vm(ip_address)
        if vm is None:
            return "Unknown host, cannot copy the pubkey"
        else:
            if vm["pubkey"]:
                return (0, pubkey, "")
            else:
                index = list(map(lambda x: x["ip"], self.vm_database)).index(ip_address)
                self.vm_database[index]['pubkey'] = True
                return (0, vm['hostname'], "")

    def check_ip_address(self, ip_address):
        response = self.check_ssh_connection(ip_address)
        if response == "SSH connection KO":
           response = self.check_rdp_connection(ip_address)
        if response == "No host responding in RDP":
           response = self.check_ping(ip_address)
        return response

    def check_ping(self, ip_address):
        vm = self.search_vm(ip_address)
        if vm is None:
            return "No host responding to Ping"
        if vm.get("ping", None):
            raise Exception("Connexion Ping OK")
        else:
            return "No host responding to Ping"

    def check_ssh_connection(self, ip):
        for network in BLACKLIST_NETWORK_DB:
            ip_in_network = ip in list(get_all_ip(network))
            if ip_in_network:
                raise socket.timeout()

        vm = self.search_vm(ip)
        if vm is None:
            return "SSH connection KO"
        if vm.get('auth_failed', None):
            raise Exception("Unknown host : Authentification failed")
        if vm.get("sshd", None):
            return vm['hostname']
        else:
            return "SSH connection KO"

    def check_rdp_connection(self, ip_address):
        vm = self.search_vm(ip_address)
        if vm is None:
            return "No host responding in RDP"
        if vm.get("rdp", None):
            raise Exception("Connexion RDP OK")
        else:
            return "No host responding in RDP"

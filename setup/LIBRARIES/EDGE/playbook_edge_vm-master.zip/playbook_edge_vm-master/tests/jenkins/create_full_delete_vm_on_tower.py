import hvac
import json
import os
import requests
import sys
import urllib3
import warnings
from time import sleep

sys.path.append('./settings')
import config

RUN_STATUS = ['successful', 'failed']


def get_secrets(context, vault_url, application, role_id):
    """

    :param context:
    :param vault_url:
    :param application:
    :param role_id:
    :return:
    """
    warnings.simplefilter('ignore', urllib3.exceptions.SecurityWarning)
    secret = '/'.join(['/secret', application, context])
    try:
        secret_id = os.environ['SECRET_ID']
    except:
        raise
    try:
        client = hvac.Client(url=vault_url, verify=False)
        if not client.is_authenticated():
            client.token = client.auth_approle(role_id, secret_id)['auth']['client_token']
            data = client.read(secret)['data']
            return data
    except Exception:
        raise


def request_method(action):
    """

    :param action: takes create or delete
    :return: headers and base url to request method
    """

    headers = {"Content-type": "application/json", "Accept": "application/json"}
    if action == 'launch':
        url = config.ANSIBLE_TOWER_CONFIG['ansible_tower_base_url'] + "/job_templates/{}/launch/"
    elif action == 'check_job_status':
        url = config.ANSIBLE_TOWER_CONFIG['ansible_tower_base_url'] + "/jobs/{}"
    return headers, url


def submit_request(launch_job_url, headers, username, password):
    """

    :param launch_job_url:
    :param headers:
    :param username:
    :param password:
    :return:
    """
    warnings.simplefilter('ignore', urllib3.exceptions.SecurityWarning)
    try:
        r = requests.post(url=launch_job_url, verify=False, headers=headers, auth=(username, password))
    except Exception:
        raise
    return r.json()


def build(job_template_id):
    """

    :param job_template_id: job template id to launch(create or delete)
    :return:
    """
    try:
        credentials = get_secrets(context=config.VAULT_CONFIG['vault_context'],
                                  vault_url=config.VAULT_CONFIG['vault_url'],
                                  application=config.VAULT_CONFIG['application'],
                                  role_id=config.VAULT_CONFIG['role_id'])
    except Exception:
        raise

    try:
        request_parameters = request_method('launch')
        url = request_parameters[1].format(job_template_id)
        headers = request_parameters[0]
    except Exception:
        raise
    try:
        run = submit_request(url, headers, username=credentials['username'], password=credentials['password'])
        job_id = run['job']
    except Exception:
        raise

    job_status = ''
    count = 0

    while job_status not in RUN_STATUS and count < 90:
        try:
            sleep(30)
            request_parameters = request_method('check_job_status')
            url = request_parameters[1].format(job_id)
            run = submit_request(url, headers, username=credentials['username'], password=credentials['password'])
            job_status = run['status']
            count += 1
        except Exception:
            raise

    if job_status == 'successful':
        result = {"status": job_status, "job_id": job_id}
    elif job_status == 'failed':
        result = {"status": job_status, "job_id": job_id}
    return result


if __name__ == '__main__':
    try:
        if sys.argv[1] == 'create':
            job_template_id = config.ANSIBLE_TOWER_CONFIG['job_template_create_edge_vm']
        elif sys.argv[1] == 'delete':
            job_template_id = config.ANSIBLE_TOWER_CONFIG['job_template_delete_edge_vm']
    except Exception:
        raise
    run_build = build(job_template_id)
    print("{}".format(json.dumps(run_build)))

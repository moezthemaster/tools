Role MongoDB_fs
=========

Creating a FS for a MongoDB Database.

This role is a prerequisite of [![CC0](role_mongodb)] (https://sgithub.fr.world.socgen/GTS-RET-DBA-COMPOSANTS-EDGE/role_mongodb)

If no action is specified when calling this role, it will execute the following action :
 1. __create.yml__ :
   * creating Group & User "mongodb"
   * creating FS :
     * /bases/mongodb
     * /bases/mongodb/*cluster_name*
     * /bases/mongodb/*cluster_name*/data
     * /bases/mongodb/*cluster_name*/var
     * /bases/mongodb/*cluster_name*/admin
     * /bases/mongodb/*cluster_name*/backups
   


Here's a description of the other task that can be executed in this role, filling the *mongodb_action* with the name of the task requested :

 __delete.yml__ : removing MongoDB FS :
  * deleting Group & User "mongodb"
  * removing directories in /bases/mongodb (data, backups, admin & logs)
  * removing FS /bases/mongodb


This role is developped for FastIT & PAAP projects. Some updates may have to be done for other needs : contact us :email: FR-FR-RET-ODB-L3@socgen.com, or Fork it.



Requirements
------------
Facts gathering shouldn't be disabled.

Target servers must be RHEL7.

When executing action "delete", a "delete" action should be executed from role role_mongodb.

Role Variables
--------------
Here are the requested values for each action :

__create.yml__
- mongodb_device_vg
- mongodb_cluster_name 
- mongodb_cluster_install_size (increasing the size will be taken into account, decreasing it will failed)
- mongodb_cluster_log_size (default = "2G")
- mongodb_cluster_backup_size (default = "5G")

__delete.yml__
- mongodb_device_vg
- mongodb_cluster_name 
- "validate_decomissioning == 'yes'"



Dependencies
------------
None


Example Playbook
----------------

    - hosts: servers
      gather_facts: yes
      roles:
      - { role: role_mongodb_fs,
           mongodb_action: "create",
           mongodb_device_vg: "{{ vg_name }}",
           mongodb_cluster_name: "{{ mongodb_instance_name }}",
           mongodb_cluster_install_size: "{{ mongodb_install_size }}"
        }


Some example values that can be specified in a group_vars file : `~/group_vars/example.yml`
```yml
vg_name: "BdddVg"
mongodb_instance_name: "dfsfsofa"
mongodb_install_size: "5g"
```



License
-------
[![CC0](https://www.usenix.org/legacy/events/usenix04/art/build_icons/bsd.gif)] (https://fr.wikipedia.org/wiki/Licence_BSD)

Author Information
------------------

ANSQUIN Olivier & GUFFROY Philippe


#!/bin/bash
################################################################################
#
# File          : zbx_postgresql.sh
#
# Date          : 14-05-2018
#
# Authors       : Emmanuel TELECHEA - RESG/GTS/MKT/OPM
#               : Arnauld FRACHE
# Purpose       : Script used to check PostgreSQL from Zabbix user parameter
#
################################################################################
#
# History       :
#
# ET : 14-05-2018 : Creation
# AF : 24-08-2018 : Add variables
#
################################################################################
#
# Modify according to your needs
#
CLUSTER_NAME=$1
export CLUSTER_NAME
PGSQL_PORT=$2
DBUSER=$3
TOOLPATH=$4
#
#
# Dedicated env variables
export PGENV_ASK=NO
. /usr/local/bin/pgenv 2>/dev/null 1>/dev/null
# ex retail
. /produits/pgsql/env/env_$CLUSTER_NAME 2>/dev/null 1>/dev/null
#

ACTION=$5

case ${ACTION} in
        commitratio)
                perl ${TOOLPATH}/check_postgres.pl --dbuser=${DBUSER} --dbname=postgres --port=${PGSQL_PORT} --action commitratio --output=simple
                ;;
        connection)
                perl ${TOOLPATH}/check_postgres.pl --dbuser=${DBUSER} --dbname=postgres --port=${PGSQL_PORT} --action connection --output=simple
                ;;
        locks)
                perl ${TOOLPATH}/check_postgres.pl --dbuser=${DBUSER} --dbname=postgres --port=${PGSQL_PORT} --action locks --critical="total=200:waiting=5:exclusive=20"
                # perl ${TOOLPATH}/check_postgres.pl --dbuser=${DBUSER} --dbname=postgres --port=${PGSQL_PORT} --action locks --output=simple
                ;;
        wal_files)
                perl ${TOOLPATH}/check_postgres.pl --dbuser=${DBUSER} --dbname=postgres --port=${PGSQL_PORT} --action wal_files --output=simple
                ;;
        backends)
                perl ${TOOLPATH}/check_postgres.pl --dbuser=${DBUSER} --dbname=postgres --port=${PGSQL_PORT} --action backends
                # perl ${TOOLPATH}/check_postgres.pl --dbuser=${DBUSER} --dbname=postgres --port=${PGSQL_PORT} --action backends --output=simple
                ;;
        # FROM RETAIL CORE
        hitratio)
                perl ${TOOLPATH}/check_postgres.pl --dbuser=${DBUSER} --dbname=postgres --port=${PGSQL_PORT} --action hitratio --output=simple
                ;;
        sequence)
                perl ${TOOLPATH}/check_postgres.pl --dbuser=${DBUSER} --dbname=postgres --port=${PGSQL_PORT} --action sequence --output=simple
                ;;
                *)
                echo ZBX_NOTSUPPORTED
esac

# END zbx_postgresql.sh ########################################################





import os
import edge
from socket import timeout

import unittest
try:
    from unittest import mock
except ImportError:
    import mock


from edge.exception import EdgeException

from tests.mock.vm_session import MockVmSession
from edge.connection.connectionhelper import ConnectionHelper
from tests.mock.connectionhelper import MockedConnectionHelper


SHARED_DATABASE_SSH = [
    {"hostname": "dpgalx5900", "ip": "192.88.65.34", "sshd": True, "rdp": False, "pubkey": False},
    {"hostname": "pspvtm01", "ip": "192.13.74.21", "sshd": False, "rdp": True, "pubkey": False},
    {"hostname": "dpgalx1001", "ip": "192.64.3.2", "sshd": True, "rdp": False, "auth_failed": True, "ping": True}
]


# class MockedHelper(MockedConnectionHelper):
#     def __init__(self, shared_database=None):
#         MockedConnectionHelper.__init__(self, shared_database)


class MockedVmSession(MockVmSession):

    def __init__(self, ip_address, shared_database=SHARED_DATABASE_SSH):
        MockVmSession.__init__(self, ip_address, shared_database)


class TestConnectionHelper(unittest.TestCase):

    @mock.patch.object(edge.connection.connectionhelper, 'VmSessionSsh', MockedVmSession)
    def test_connection_to_host_ok(self):
        ssh_helper = ConnectionHelper()
        reponse = ssh_helper.check_ssh_connection("192.88.65.34")
        assert reponse == "dpgalx5900"

    @mock.patch.object(edge.connection.connectionhelper, 'VmSessionSsh', MockedVmSession)
    def test_connection_to_host_nok(self):
        try:
            ssh_helper = ConnectionHelper()
            reponse = ssh_helper.check_ssh_connection("192.36.65.1")
        except timeout:
            assert True

    @mock.patch.object(edge.connection.connectionhelper, 'VmSessionSsh', MockedVmSession)
    def test_new_Pubkey(self):
        ssh_helper = ConnectionHelper()
        pubkey = "ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAyLXUQ9eoPr8Akx+WeJzRgAOMyUbTQ3/RDu44N2svQTa7I0ZKzqelNrSqqsgSmNN7giQGRyIvx/XgUwi9UjrxFX0XRTvwjAcXNHV2pxybbhPb8/2jiAfFTCjkwQBwtoSTEL1I5noAIgapQDZghYFkv0GUiAkebKzl0A+cNqm5Zc2UPNTqsCtIAZ5Uid+XOdECHan29Iyow0f+O/2O6mZKBGvWFJbRLCokKLUrTmhbgWIiWgQGp/PnF0XVVPiQgRfbRz1xH08JNiQz1lnvZ4ME4BhQoxSK1O8QL+dQsSXhvQyjfO8yYI+X4X73Ie9yBfZpPiGAZLo3hTVha46veVfZGw== a373785@PXPLSV02"
        reponse = ssh_helper.authorized_key(
            ip_address="192.88.65.34",
            remote_user="automation",
            remote_group="automation",
            pubkey=pubkey
        )
        assert reponse == "dpgalx5900"

    @mock.patch.object(edge.connection.connectionhelper, 'VmSessionSsh', MockedVmSession)
    def test_pubkey_already_there(self):
        ssh_helper = ConnectionHelper()
        pubkey = "ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAyLXUQ9eoPr8Akx+WeJzRgAOMyUbTQ3/RDu44N2svQTa7I0ZKzqelNrSqqsgSmNN7giQGRyIvx/XgUwi9UjrxFX0XRTvwjAcXNHV2pxybbhPb8/2jiAfFTCjkwQBwtoSTEL1I5noAIgapQDZghYFkv0GUiAkebKzl0A+cNqm5Zc2UPNTqsCtIAZ5Uid+XOdECHan29Iyow0f+O/2O6mZKBGvWFJbRLCokKLUrTmhbgWIiWgQGp/PnF0XVVPiQgRfbRz1xH08JNiQz1lnvZ4ME4BhQoxSK1O8QL+dQsSXhvQyjfO8yYI+X4X73Ie9yBfZpPiGAZLo3hTVha46veVfZGw== a373785@PXPLSV02"
        reponse = ssh_helper.authorized_key(ip_address="192.88.65.34",remote_user="automation",remote_group="automation",pubkey=pubkey)
        assert reponse == pubkey

    @mock.patch.object(edge.connection.connectionhelper, 'VmSessionSsh', MockedVmSession)
    def test_connection_to_host_doesn_t_exist(self):
        ssh_helper = ConnectionHelper()
        try:
            reponse=ssh_helper.check_ssh_connection("192.88.254.252")
        except Exception as e :
            assert "SSH connection KO" in e.args[0]

    @mock.patch.object(edge.connection.connectionhelper, 'VmSessionSsh', MockedVmSession)
    def test_connection_to_host_with_authentification_failed(self):
        ssh_helper = ConnectionHelper()
        try:
            reponse=ssh_helper.check_ssh_connection('192.64.3.2')
        except Exception as e :
            assert "Authentification failed" in e.args[0]

    @mock.patch.object(edge.connection.connectionhelper, 'VmSessionSsh', MockedVmSession)
    def test_connection_to_host_rdp_nok(self):
        rdp_helper = ConnectionHelper()
        response=rdp_helper.check_rdp_connection("192.64.3.2")
        assert response == "No host responding in RDP"

    @mock.patch.object(edge.connection.connectionhelper, 'VmSessionSsh', MockedVmSession)
    def test_connection_to_host_rdp_ok(self):
        rdp_helper = ConnectionHelper()
        try:
            response = rdp_helper.check_rdp_connection("pspvtm01")
        except Exception as e :
            assert "Connexion RDP OK" in e.args[0]

    @mock.patch.object(edge.connection.connectionhelper, 'VmSessionSsh', MockedVmSession)
    @mock.patch.object(edge.connection.connectionhelper.os, 'system', lambda x: 1)
    def test_connection_to_host_ping_nok(self):
        ping_helper = ConnectionHelper()
        response = ping_helper.check_ping("1.1.1.2")
        assert response == "No host responding to Ping"

    @mock.patch.object(edge.connection.connectionhelper, 'VmSessionSsh', MockedVmSession)
    @mock.patch.object(edge.connection.connectionhelper.os, 'system', lambda x: 0)
    def test_connection_to_host_ping_ok(self):
        ping_helper = ConnectionHelper()
        try:
            response = ping_helper.check_ping("192.64.3.2")
        except EdgeException as e :
            assert "Connexion Ping OK" in e.args[0]
            return
        assert False

import multiprocessing

bind = '{{ bind_address }}'
workers = multiprocessing.cpu_count() * 2 + 1
daemon = True
logfile = 'server.logs'

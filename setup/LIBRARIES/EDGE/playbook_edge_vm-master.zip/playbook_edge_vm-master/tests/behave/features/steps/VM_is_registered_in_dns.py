#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
import socket

@then('VM is registered in DNS')
def step_impl(context):
    print("Check DNS for VM {}, IP {}\n".format(context.params['vm_hostname'], context.params['vm_ipaddr']))
    addr = socket.gethostbyname(context.params['vm_hostname'])    
    if addr == context.params['vm_ipaddr']:
      assert context.failed is False
    else:
      assert context.failed is True


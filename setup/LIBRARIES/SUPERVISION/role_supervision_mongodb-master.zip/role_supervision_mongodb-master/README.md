Role_supervision_mongodb
=========

Monitor a mongodb using the Patrol or/and Zabbix Agent.

This role is an applicative monitoring role

If no action is specified when calling this role, it will execute the following action :

**create.yml** : Installing the mongodb KM use by Patrol Agent

* Starting Patrol Agent
* Sending system stantard monitoring configuration for mongodb to Patrol Agent
* Restarting the Patrol Agent

Here's a description of the other task that can be executed in this role, filling the *patrol_action* with the name of the task requested :

**configure.yml**: Configuring Patrol Agent to monitore the mongodb

* Starting Patrol Agent
* Sending system stantard monitoring configuration for mongodb to Patrol Agent
* Restarting the Patrol Agent


**delete.yml** : Removing the mongodb monitoring from Patrol Agent

* Removing mongodb monitoring from Patrol agent


This role is developped for **FastIT & PAAP projects**. Some updates may have to be done for other needs : contact us :email: List.FR-Admin-Monitoring-L3@socgen.com, or Fork it.

# Installation

```
ansible-galaxy install git+https://sgithub.fr.world.socgen/GTS-MFI-COMPOSANTS-EDGE/role_supervision_mongodb.git,1.0.0 -p roles -f
```

This above command will install role_supervision_mongodb with its dependencies in the specified folder roles of current folder

Requirements
------------

Facts gathering shouldn't be disabled.

Target servers must be Linux.

Patrol Agent should be install and add to the monitoring infra.

You must create an ansible.cfg file on same folder with the playbook which will be launched.

libray is the location ansible looks to find modules for role_supervision_mongodb.

  ```
    [defaults]
    library        = ./roles/edge_ansible_modules/files
  ```
edge_ansible_modules is one of dependencies for role_supervision_mongodb. he contains modules that edge_ansible_modules looks for its operation

You have to specify an inventory file containing localhost as hostname.

NOTE: This role can only be executed through A4C or Ansible Tower platform.

Role Variables
--------------

Here are the requested values for each action :

**create.yml**


**configure.yml**

- `pat_instance: Instance name of the mongodb file(ie. mymongodb)` **Required**
- `pat_port : port of the mongodb` **Required**
- `pat_mongo_user : patrol will use this user to connect to the mongodb and monitore it (need read & clusterMonitor's right required)` **optional**
- `pat_mongo_pwd : password for pat_mongo_user` **optional**
- `pat_mongo_arbitor_ip : arbitror's ip address` **optional**

**delete.yml**

- `pat_instance : Instance name of the mongodb (ie. mymongodb)`


Example Playbook monitoring with zabbix
---------------------------------------

```yaml
- hosts: target
  roles:
    - { role: role_supervision_mongodb, patrol_action: 'create' }
    - {role: role_supervision_mongodb,
             patrol_action: 'configure',
             pat_instance: 'mymongo',
             pat_port: '27017',
             zabbix_template: 'SG_MongoDB_EDGE',
             pat_mongo_user: 'mongo_monitor',
             pat_mongo_pwd: 'password'
             }

```

Example Playbook monitoring with patrol
---------------------------------------

```yaml
- hosts: target
  gather_facts: yes
  roles:
    - {role: role_supervision_mongodb, patrol_action: 'create',
       }
    - {role: role_supervision_mongodb, patrol_action: 'configure',
              pat_instance: 'mymongo',
              pat_port: '12500',
       }
```


Thresholds
-----------

| CLASS       | Parametre  | Unité   | Homo     | Prod              | 
|:-----------:|:----------:|:-------:|:--------:|:-----------------:| 
| MONGO_CONFIG_SERVER | ConnectionStatus | 0=Down</br>1=Up | ≠ 1 :Alarm after 5 min   | ≠ 1 :Alarm after 5 min | 
| MONGO_REPLICA_SET | Availability | %  | ≠ 100 :Alarm after 5 min | ≠ 100 :Alarm after 5 min | 
| MONGO_MEMBER | Status | 0=Down</br>1=Up | ≠ 1 :Alarm after 5 min | ≠ 1 :Alarm after 5 min   | 
| MONGO_MEMBER_STATISTICS | LagInReplicating | sec | < 300 :Warn | < 300 :Warn | 
| MONGO_MEMBER_STATISTICS | OpLogLength      | hours | < 72 :Warn | < 72 :Warn | 



Generated Alarms
----------------

      # host			|objectClass		|object				|parameter		|parameterValue			|message
      # KM MONGODB
      *				|MONGO_MEMBER 					|*		|Status				|*		|[MONGODB] The Member of replicat set %mc_object% is down| -
      *				|MONGO_MEMBER_STATISTICS        |*		|OpLogLength		|*		|[MONGODB] The retention time of the oplogs for the MONGO Member %mc_object% is greater than %mc_parameter_value% | -
      *				|MONGO_MEMBER_STATISTICS		|*		|LagInReplicating	|*		|[MONGODB] The lag in replicating for the  Member %mc_object% is greater than %mc_parameter_value% | -
      *				|MONGO_REPLICA_SET				|*		|Availability		|*		|[MONGODB] The Replicat set %mc_object% is degraded %mc_parameter_value% | -


License
-------

BSD

Author Information
------------------

Yanis BEKRAR

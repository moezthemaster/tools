#!/usr/bin/env python
# -*- coding: utf-8 -*-

import ansible_play
from behave import *


@when('Get vm extended informations')
def step_impl(context):
    if context.params.get('fs_list', None) == None:
        assert context.failed is False

    become_user_password = 'foo-whatever'
    run_data = {

        'vm_hostname': context.params['vm_hostname'],
        # 'vm_hostname': 'ppgalx018',
    }

    runner = ansible_play.Runner(
        hostnames='localhost',
        playbook='run_vm_informations.yml',
        tags="",
        private_key_file=context.private_key,
        run_data=run_data,
        become_pass=become_user_password,
        verbosity=100,
        connection='ssh'
    )

    stats = runner.run()
    context.params['business_group'] = runner.get_var('VM_BG')
    context.params['vm_environment'] = runner.get_var('VM_ENV')

    return stats

#!/bin/ksh -x

# This script renames the "root" Python package of the repository.

usage() {
    print "usage:"
    print "\t$(basename $0) new_package_name"
}

[[ $# -ne 1 ]] && usage && exit 1
root=$( cd -P -- "$(dirname -- "$(command -v -- "$0")")/.." && pwd -P )
new_pkg_name=$1
old_pkg_name=$(find $root -maxdepth 2 -name __init__.py \
		| awk -F/ '{ print $(NF-1)}')

# Rename the package directory
mv $root/$old_pkg_name $root/$new_pkg_name || exit 1

# Renaming inside setup.py
sed -i'' -E "s/name='$old_pkg_name',/name='$new_pkg_name',/" $root/setup.py || exit 1
print "Please review information inside setup.py"

# Jenkins stuff
sed -i'' -E "s/appName=(<CHANGEIT )?[^>]*(>)?/appName=$new_pkg_name/" $root/jenkins/job.properties || exit 1
sed -i'' -E "s/stringParam\('APPLI', '[^']*'\)/stringParam('APPLI', '$new_pkg_name')/" $root/jenkins/seedJobs.groovy || exit 1

# manage.py
sed -i'' -E "s/from $old_pkg_name.app import create_app/from $new_pkg_name.app import create_app/" $root/manage.py || exit 1

# MANIFEST.IN
sed -i'' -E "s/recursive-include $old_pkg_name\/static \*/recursive-include $new_pkg_name\/static \*/" $root/MANIFEST.in || exit 1
sed -i'' -E "s/recursive-include $old_pkg_name\/templates \*/recursive-include $new_pkg_name\/templates \*/" $root/MANIFEST.in || exit 1

# pom.xml
sed -i'' -E "s/$old_pkg_name/$new_pkg_name/g" $root/pom.xml || exit 1

# iml
mv $root/$old_pkg_name.iml $root/$new_pkg_name.iml || exit 1

# code
find $root/$new_pkg_name -type f -name '*.py' \
    | xargs -t sed -i'' -E "s/$old_pkg_name\./$new_pkg_name./g" || exit 1

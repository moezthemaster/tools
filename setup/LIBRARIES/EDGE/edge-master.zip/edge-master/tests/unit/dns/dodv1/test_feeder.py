#!/usr/bin/python
# -*- coding: utf-8 -*-

import logging
from threading import Thread

from tests.mock.mockdodv1 import MockDod
from edge.dns.dodv1.feeder import DnsFeeder
from tests.mock.mock import MockDod as MockDodv2

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

LIST_HOSTNAMES = ("dtrvlxvm1", "dtrvlxvm2", "dtrvlxvm3", "dtrvlxvm4")


class MockedFeeder(MockDod, MockDodv2, DnsFeeder):

    def __init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname):
        MockDod.__init__(self, share_database=True)
        MockDodv2.__init__(self, tuple(), hostname=None, share_database=True)
        DnsFeeder.__init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname)


class Task(Thread):

    def __init__(self, feeder):
        Thread.__init__(self)
        self.feeder = feeder

    def run(self):
        self.feeder.run()


class TestDnsFeeder:

    def test_feed_dns_with_hostname_to_be_recorded(self):
        feeder = MockedFeeder(
            "DEV", "EU France (Greater Paris)", "eu-fr-paris-1", "ITEC_CLOUD_DEV_DC2_03", "trv", LIST_HOSTNAMES[0]
        )
        response = feeder.run()
        assert feeder.changed
        assert response["output"][0]["hostname"] == LIST_HOSTNAMES[0]

    def test_feed_dns_with_hostname_already_exists(self):
        feeder = MockedFeeder(
            "DEV", "EU France (Greater Paris)", "eu-fr-paris-1", "ITEC_CLOUD_DEV_DC2_03", "trv", LIST_HOSTNAMES[0]
        )
        search = feeder.host_search_infos(LIST_HOSTNAMES[0])
        response = feeder.run()
        assert search[0].infos.ip == response["output"][0]["ip"]
        assert not feeder.changed

    def test_if_alias_exists_in_dodv2(self):
        host = MockedFeeder(
            "DEV", "EU France (Greater Paris)", "eu-fr-paris-1", "ITEC_CLOUD_DEV_DC2_03", "trv", LIST_HOSTNAMES[0]
        )
        assert host._search_cname()[0]["alias"] == host.hostname

    def test_feed_dns_with_cidr_which_does_not_exist_in_mkt(self):
        try:
            feeder = MockedFeeder(
                "DEV", "EU France (Greater Paris)", "eu-fr-paris-1", "CDN", "trv", LIST_HOSTNAMES[1]
            )
            feeder.run()
        except Exception as err:
            assert 'combination env=DEV, region_cloud=EU France (Greater Paris), az_cloud=eu-fr-paris-1,' \
                    ' network_id=CDN is not a network mkt' == err.args[0]
            return
        assert False

    def test_feed_dns_with_two_hostnames_when_both_get_same_ip(self):
        feeder1 = MockedFeeder(
            "DEV", "EU France (Greater Paris)", "eu-fr-paris-1", "ITEC_CLOUD_DEV_DC2_03", "trv", LIST_HOSTNAMES[1]
        )
        feeder2 = MockedFeeder(
            "DEV", "EU France (Greater Paris)", "eu-fr-paris-1", "ITEC_CLOUD_DEV_DC2_03", "trv", LIST_HOSTNAMES[2]
        )
        thread_1 = Task(feeder1)
        thread_2 = Task(feeder2)
        thread_1.start()
        thread_2.start()
        thread_1.join()
        thread_2.join()
        search_result1 = feeder1.host_search_infos(feeder1.hostname)
        search_result2 = feeder2.host_search_infos(feeder2.hostname)
        assert search_result1[0].ip != search_result2[0].ip
        logger.debug("ip for hostname={} is {}".format(feeder1.hostname, search_result1[0].ip))
        logger.debug("ip for hostname={} is {}".format(feeder2.hostname, search_result2[0].ip))

    def test_feed_dns_with_no_ip_available(self):
        feeder = MockedFeeder(
            "DEV", "EU France (Greater Paris)", "eu-fr-paris-1", "SGCIB_DEV2", "trv", LIST_HOSTNAMES[3]
        )
        try:
            feeder.run()
        except Exception as err:
            assert "ip not found" in err.args[0]
            return
        assert False

    def test_feed_dns_with_empty_hostname(self):
        try:
            MockedFeeder(
                "DEV", "EU France (Greater Paris)", "eu-fr-paris-1", "SGCIB_DEV2", "trv", ""
            )
        except Exception as err:
            assert " must match this regex '^(d|h|p)trv[a-zA-Z0-9_-]+$'" == err.args[0]
            return
        assert False

#!/usr/bin/python
# -*- coding: utf-8 -*-

import logging

from tests.mock.mockdodv1 import MockDod
from edge.dns.dodv1.feeder import DnsFeeder
from edge.dns.dodv1.cleaner import DnsCleaner
from tests.mock.mock import MockDod as MockDodv2

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

LIST_HOSTNAMES = ["dtrvhost192160721", "dtrvlx10000"]


class MockedCleaner(MockDod, MockDodv2, DnsCleaner):

    def __init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname):
        MockDod.__init__(self, share_database=True)
        MockDodv2.__init__(self, tuple(), hostname=None, share_database=True)
        DnsCleaner.__init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname)


class MockedFeeder(MockDod, MockDodv2, DnsFeeder):

    def __init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname):
        MockDod.__init__(self, share_database=True)
        MockDodv2.__init__(self, tuple(), hostname=None, share_database=True)
        DnsFeeder.__init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname)


class TestDnsCleaner:

    def test_clean_dns_with_alias(self):
        feeder = MockedFeeder(
            "DEV", "EU France (Greater Paris)", "eu-fr-paris-1", "ITEC_CLOUD_DEV_DC2_03", "trv", LIST_HOSTNAMES[1]
        )
        feeder.run()
        assert feeder.changed
        cleaner = MockedCleaner(
            "DEV", "EU France (Greater Paris)", "eu-fr-paris-1", "ITEC_CLOUD_DEV_DC2_03", "trv", LIST_HOSTNAMES[1]
        )
        assert cleaner.search_dns_record(
            '^CNAME$', hostname="{}.{}.".format(LIST_HOSTNAMES[1], "fr.world.socgen"),
            dns_service="dummy", view="dummy"
        )[0]["alias"] == LIST_HOSTNAMES[1]
        cleaner.create_dns_record(
            record_type="^CNAME$",
            alias="test_alias",
            hostname="{}.{}.".format(LIST_HOSTNAMES[1], "fr.world.socgen"),
            zone="dns21.socgen",
            dns_service="dummy",
            view="dummy"
        )
        assert len(
            cleaner.search_dns_record(
                '^CNAME$', hostname="{}.{}.".format(LIST_HOSTNAMES[1], "fr.world.socgen"),
                dns_service="dummy", view="dummy"
            )
        ) == 2
        response = cleaner.run()
        assert cleaner.changed
        assert cleaner.search_dns_record(
            '^CNAME$', hostname="{}.{}.".format(LIST_HOSTNAMES[1], "fr.world.socgen"),
            dns_service="dummy", view="dummy"
        ) == []
        assert response["msg"] == "record A, PTR for hostname=dtrvlx10000 have been deleted"

    def test_clean_dns(self):
        cleaner = MockedCleaner(
            "DEV", "EU France (Greater Paris)", "eu-fr-paris-1", "SGCIB_DEV2", "trv", LIST_HOSTNAMES[0]
        )
        response = cleaner.run()
        assert cleaner.changed
        assert response["msg"] == "record A, PTR for hostname=dtrvhost192160721 have been deleted"

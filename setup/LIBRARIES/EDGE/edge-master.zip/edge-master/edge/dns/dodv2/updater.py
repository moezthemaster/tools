#!/usr/bin/python
# -*- coding: utf-8 -*-

#

DOCUMENTATION = '''




'''

EXAMPLES = '''
    see test_dns_feeder.py
'''

import logging

import edge.interfaces
from edge.conf import settings
from edge.dns.dodv2.hostname import is_valide_hostname


KWARGS_SEARCH = {
    'dns_service':settings.DOD_DNS_SERVICE,
    'view': 'production',
}
A='A'
DEFAULT_IP_ADDRESS = '127.0.0.1'
DEFAULT_FQDN = 'localhost.localdomain'


logger = logging.getLogger(__name__)


class DnsUpdater(edge.interfaces.Dod):
    def __init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname):
        is_valide_hostname(trigram, hostname)
        self.hostname = hostname
        cloud_network_dict = edge.conf.cloud_network.get_details(env, region_cloud, az_cloud, network_id)
        self.network_cidr = cloud_network_dict['network_cidr'] #other name: vm_subnet
        self.dns_zone = cloud_network_dict['dns_zone']
        self.changed = False

    def run(self,cause):
        '''
        When VM is updated, update A record, and delete PTR and CNAME.
        If error when VM is updated, roll back DNS removed previously.
        :return: dict
        '''
        types_hosts = [
            ('CNAME', '^%s.%s.$' % (self.hostname, self.dns_zone)),
            ('PTR', '^%s$' % self.hostname),
        ]
        updated = self.search_and_update_conflict_dns_records(
                record_type='^A$',
                dns_service=settings.DOD_DNS_SERVICE,
                cause=cause,
                hostname='^%s$' % self.hostname,
                view='production', 
                
            )
        if updated:
                self.changed = True
        for record_type, host in types_hosts:
            logger.debug('Updating record type {} for hostname {}'.format(record_type, host))
            deleted = self.search_and_delete_dns_records(
                record_type='^{}$'.format(record_type),
                dns_service=settings.DOD_DNS_SERVICE,
                hostname=host,
                view='production'
            )
        return updated
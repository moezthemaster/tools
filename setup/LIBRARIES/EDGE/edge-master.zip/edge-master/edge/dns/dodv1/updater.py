#!/usr/bin/python
# -*- coding: utf-8 -*-

import logging

from edge.conf import settings
from edge.conf.cloud_network import get_details
from edge.dns.dodv2.hostname import is_valide_hostname
from edge.exception import EdgeException

from . import mixins

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


class DnsUpdater(mixins.Mixin):

    def __init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname, new_hostname):
        is_valide_hostname(trigram, hostname)
        self.env = env
        self.trigram = trigram
        self.hostname = hostname
        self.new_hostname = new_hostname
        cloud_network_dict = get_details(
            env, region_cloud, az_cloud, network_id)
        if cloud_network_dict.get("network_tag", None) != "mkt":
            raise EdgeException(
                "combination env={}, region_cloud={}, az_cloud={}, network_id={} is not a network mkt".format(
                    env, region_cloud, az_cloud, network_id
                )
            )
        self.domain = cloud_network_dict["dns_zone"]
        self.newIp = ""
        self.newTTL = ""
        self.newDomain = ""
        self.fqdn = "{}.{}.".format(self.hostname, self.domain)
        self.force = False
        self.changed = False

    def _delete_all_cname(self):
        try:
            records = self._search_cname()
            if len(records) >= 10:
                raise Exception('Too many cname for deleting for hostname={} in DodV2'.format(self.hostname))
            for record in records:
                if record:
                    self.delete_dns_record(
                        dns_service=settings.DOD_DNS_SERVICE, id=record['id']
                    )
        except Exception as err:
            logger.error(
                "Cannot delete all cname for hostname={}: {}".format(
                    self.hostname, err.args[0]
                )
            )
            raise EdgeException(
                "Cannot delete all cname for hostname={}: {}".format(
                    self.hostname, err.args[0]
                )
            )

    def _update_dns(self, retries=5):
        self._delete_all_cname()
        for num in range(1, (retries + 1)):
            try:
                logger.debug("try to update old hostname={} to new hostname={}".format(
                    self.hostname, self.new_hostname)
                )
                search = self.host_search_infos(self.hostname)
                if not search:
                    raise EdgeException("hostname={} not found in DodV1".format(self.hostname))
                update = self.host_update(
                    self.hostname, search[0].ip, self.domain, self.new_hostname
                )
                if update:
                    logger.debug("Success to update old hostname={} to new hostname={}".format(
                        self.hostname, self.new_hostname)
                    )
                    result = self.host_search_infos(self.new_hostname)
                    host_infos = dict()
                    host_infos["output"] = [
                        {
                            "ip": result[0].infos.ip,
                            "hostname": result[0].infos.hostname,
                            "domain": result[0].infos.domain,
                            "reverse": result[0].infos.reverse,
                            "map_filename": result[0].infos.map_filename
                        }
                    ]
                    self.changed = True
                    return host_infos
            except Exception as err:
                raise EdgeException(err.args[0])
        raise EdgeException(
            "Maximum attempts for updating dns for hostname={}".format(
                self.hostname
            )
        )

    def run(self):
        return self._update_dns()

#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
from time import sleep
import testinfra 

@then('VM flexera is installed')
def step_impl(context):

    print("Test user flexera is created and Flexera Agent is well installed\n")
    
    server=testinfra.get_host('ssh://automation@'+context.params['vm_ipaddr'])

    # Test if user flexera is created
    user=server.user('flexera').exists

    if user:
      assert context.failed is False
    else:
      assert context.failed is True

    # Test if group flexera is created
    group=server.group('flexera').exists

    if group:
      assert context.failed is False
    else:
      assert context.failed is True

    # Test if flexera agent is running
    commande="ps -edf | grep -i /opt/managesoft/libexec/ndtask | grep -vc grep"
    started=server.run(commande) 
    
    if int(started.stdout) == 1 :
      assert context.failed is False
    else:
      assert context.failed is True

    # Test if flexera is registred on the Infra Server
    commande="sudo grep -c 'successfully installed the merged deployment policy' /var/opt/managesoft/log/policy.log"

    reg=server.run(commande) 
    
    if int(reg.stdout) > 0 :
      assert context.failed is False
    else:
      assert context.failed is True

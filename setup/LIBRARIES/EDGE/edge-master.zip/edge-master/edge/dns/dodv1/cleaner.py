#!/usr/bin/python
# -*- coding: utf-8 -*-

import logging

from edge.conf import settings
from edge.conf.cloud_network import get_details
from edge.dns.dodv2.hostname import is_valide_hostname
from edge.exception import EdgeException

from . import mixins


logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


class DnsCleaner(mixins.Mixin):

    def __init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname):
        is_valide_hostname(trigram, hostname)
        self.hostname = hostname
        cloud_network_dict = get_details(env, region_cloud, az_cloud, network_id)
        self.domain = cloud_network_dict["dns_zone"]
        self.subnet = cloud_network_dict["network_cidr"]
        self.ip = ""
        self.inA = True
        self.inPTR = True
        self.fqdn = "{}.{}.".format(self.hostname, self.domain)
        self.changed = False

    def _check_if_record_exists(self, hostname):
        results = self.host_search_infos('{}'.format(hostname))
        if results:
            return True
        return False

    def _delete_all_cname(self):
        try:
            records = self._search_cname()
            if len(records) >= 10:
                raise Exception('Too many cname for deleting for hostname={} in DodV2'.format(self.hostname))
            for record in records:
                if record:
                    self.delete_dns_record(
                        dns_service=settings.DOD_DNS_SERVICE, id=record['id']
                    )
        except Exception as err:
            logger.error(
                "Cannot delete all cname for hostname={}: {}".format(
                    self.hostname, err.args[0]
                )
            )
            raise EdgeException(
                "Cannot delete all cname for hostname={}: {}".format(
                    self.hostname, err.args[0]
                )
            )

    def _clean_dns(self, retries=5):
        self._delete_all_cname()
        for num in range(1, (retries + 1)):
            logger.debug("Essay num°{}: try to delete fields={} for hostname={}".format(
                num, self._get_fields(), self.hostname)
            )
            if self._check_if_record_exists(self.hostname):
                self.host_delete(self.hostname, self.domain, ip=self.ip, inA=self.inA, inPTR=self.inPTR)
            else:
                logger.debug("Essay num°{}: success to delete fields={} for hostname={}".format(
                    num, self._get_fields(), self.hostname)
                )
                self.changed = True
                return {"msg": "record A, PTR for hostname={} have been deleted".format(self.hostname)}
        logger.error("Maximum attempts for deleting dns's records for hostname={}".format(self.hostname))
        raise EdgeException(
            "Maximum attempts for deleting dns's records for hostname={}".format(
                self.hostname
            )
        )

    def run(self):
        return self._clean_dns()

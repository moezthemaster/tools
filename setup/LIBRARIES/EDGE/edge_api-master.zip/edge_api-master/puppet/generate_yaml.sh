#!/usr/bin/env bash
set -e

export FACTER_linux_hostname=$1
export FACTER_linux_username=$2
export FACTER_linux_password=$(${HOME}/bin/eyaml encrypt --pkcs7-public-key=/${HOSTNAME^^}/work/tools/keys/public_key.pkcs7.pem -o string -s $3)
if [ -z "$FACTER_linux_password" ]; then exit 1; fi
export FACTER_deployment_folder=$4
export FACTER_app_root=$5
export FACTER_xld_url=$6
export FACTER_workspace=${WORKSPACE}

cd ${WORKSPACE}/puppet

puppet apply --hiera_config ${WORKSPACE}/puppet/hiera.yaml --modulepath=. -e "include xld_yaml"

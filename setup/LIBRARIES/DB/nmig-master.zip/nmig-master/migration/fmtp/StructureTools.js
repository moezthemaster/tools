/*
 * This file is a part of "NMIG" - the database migration tool.
 *
 * Copyright (C) 2016 - 2017 Anatoly Khaytovich <anatolyuss@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program (please see the "LICENSE.md" file).
 * If not, see <http://www.gnu.org/licenses/gpl.txt>.
 *
 * @author Eric Deleforterie <eric@deleforterie.com>
 */
'use strict';

/**
 * Get table's name depending of the configuration.
 *
 * @param {Conversion} self
 * @param {String}     objectName
 * @param {String}     stringToManage
 *
 * @returns {String}
 */
module.exports.getObjectName = (self, objectName, stringToManage) => {
    if(typeof self === 'undefined'){
        console.log('getObjectName : self is undefined')
        var stack = new Error().stack
        console.log( stack )
    }
    if(typeof objectName === 'undefined'){
        console.log('getObjectName : objectName is undefined')
        var stack = new Error().stack
        console.log( stack )
    }

    let stringToReturn = (typeof stringToManage === 'undefined')? objectName : stringToManage;    
    if (self._behaviorAboutStructure !== null) {
        // If no object match we will use the default behavior configuration
        if(!(objectName in self._behaviorAboutStructure)){
            objectName = "default_behavior_about_structure";
        }
        if ("keep_case_sensitive" in self._behaviorAboutStructure[objectName] && self._behaviorAboutStructure[objectName].keep_case_sensitive) {
            stringToReturn = '"' + stringToReturn + '"';        
        }
        if ("convert_structure_to_lower" in self._behaviorAboutStructure[objectName] && self._behaviorAboutStructure[objectName].convert_structure_to_lower) {
            stringToReturn = stringToReturn.toLowerCase();
        }
        else if ("convert_structure_to_upper" in self._behaviorAboutStructure[objectName] && self._behaviorAboutStructure[objectName].convert_structure_to_upper) {
            stringToReturn = stringToReturn.toUpperCase();
        }
    }
    return stringToReturn;
};
#!/usr/bin/python
# -*- coding: utf-8 -*-
from difflib import Differ

file = "file1.j2"
check_sudo = "check_sudo.j2"  # file with good sudo user
# file = "/etc/sudoers.d/btxxx_group"


def update_sudo():
    try:
        list_tempo = _check_sudo_user(file, check_sudo)
        f1 = open(file, "w")
        f1.seek(0)
        for line in list_tempo:
            if "^" not in line:
                f1.writelines(line)
        return True
    except OSError as e:
        print "strerror : {}; errno : {}; filename : {}".format(e.strerror, e.errno, e.filename)
        return False


def _check_sudo_user(file, check_sudo):
    try:
        list_tempo = []
        with open(file, "r+") as f1, open(check_sudo, "r+") as f2:
            differ = Differ()
            for line in differ.compare(f1.readlines(), f2.readlines()):
                if not line.startswith(" "):
                    if len(line[2:]) > 10:
                        list_tempo.append(line[2:])
                else:
                    list_tempo.append(line[2:])
    except Exception as e:
        try:
            # if error = 2 no find file (no exist)
            if e.errno == 2:
                with open(check_sudo, "r+") as f2:
                    list_tempo.append(f2.readlines())
        except Exception as e:
            print "strerror : {}; errno : {}; filename : {}".format(e.strerror, e.errno, e.filename)
    list_tempo.append("\n")  # add line for not parse error
    return list_tempo


update_sudo()

from random import randint

from tests.mock.marley_hpoo import MockedMarleyHPOO
from edge.marley.manage_asset import MarleyLoader


class MockedMarleyLoader(MarleyLoader, MockedMarleyHPOO):
    pass


class TestManageAsset(object):

    def test_invoc_step_marley_v5(self):
        hostname = "dpgalxmarleytest00120" + str(randint(0, 100))
        marley = MockedMarleyLoader()
        response = marley.invoc_step_marley_v5(
            vm_hostname=hostname,
            vm_os="RHEL_7.3_x64-RET-EDGE",
            vm_profile="Large-mem16 4vCPU-16GB",
            disk_size="20",
            marley_operation="create",
            code_irt="A7048",
            endClient="GTS",
            app_env="dev",
            vm_backup="none"
        )
        assert response



import re
import subprocess

from edge.conf import settings
from edge.tools.tools import VmSessionSsh
from edge.zabbix.rollback import Rollback

__all__ = ("ZbxCtrl",)


def get_zabbix_url_tag(hostname):
    try:
        cmd = "nslookup {} | grep 'Name'".format(hostname)
        fqdn = subprocess.check_output("{}".format(cmd), shell=True)
        if "fr.world.socgen" in fqdn:
            return "ZBXAPIURLMKT"
        else:
            return "ZBXAPIURLRET"
    except Exception as e:
        raise ZbxCtrlError(
            'Error while getting url of infra zabbix for hostname={}, err_msg={}.'.format(hostname, e.args[0])
        )


class ZbxCtrlError(Exception):
    pass


class ZbxCtrlInterface(object):

    def zbxGetHosts(self, hostname):
        raise NotImplementedError

    def zbxGetTemplateId(self, name):
        raise NotImplementedError

    def zbxLinkHostToTemplate(self, host_id, template_id):
        raise NotImplementedError

    def zbxUnlinkHostToTemplate(self, host_id, template_id):
        raise NotImplementedError

    def zbxGetTemplatesLinkedToHostid(self, host_id):
        raise NotImplementedError

    def zbx_user_macro_create(self, **kwargs):
        raise NotImplementedError

    def zbx_user_macro_update(self, **kwargs):
        raise NotImplementedError

    def zbx_get_user_macros(self, host_id):
        raise NotImplementedError

    def zbx_delete_user_macros(self, macroid):
        raise NotImplementedError

    def zbx_get_hostgroup(self, group_name):
        raise NotImplementedError

    def zbx_hostgroup_msadd(self, group_id, host_id):
        raise NotImplementedError

    def zbx_hostgroup_msremove(self, group_id, host_id):
        raise NotImplementedError

    def zbx_get_interfaces(self, host_id):
        raise NotImplementedError

    def zbx_create_item(self, **params):
        raise NotImplementedError

    def zbx_search_item(self, host_id, search_data=None, params_data=None):
        raise NotImplementedError

    def zbx_delete_item(self, item_id):
        raise NotImplementedError

    def zbx_create_trigger(self, params):
        raise NotImplementedError

    def zbx_search_trigger(self, host_id, search_by_desc):
        raise NotImplementedError

    def zbx_delete_trigger(self, trigger_id):
        raise NotImplementedError

    def zbx_create_application(self, host_id, name):
        raise NotImplementedError

    def zbx_search_application(self, host_id, search_by_name):
        raise NotImplementedError

    def zbx_delete_application(self, application_id):
        raise NotImplementedError


class ZbxCtrl(ZbxCtrlInterface):

    TRIGGER_SEVERITY_MAP = {
        "not classified": 0,
        "information": 1,
        "warning": 2,
        "average": 3,
        "critical": 4,
        "high": 4,
        "disaster": 5
    }

    def __init__(self, hostname):
        # self.zabbix_api_url is used to instanciate with zbx wrapper class
        # ugly but it is due of delivery time constraint :)
        self.zabbix_api_url = getattr(settings, get_zabbix_url_tag(hostname))
        self._data = None

    def _delete_item(self, host_id, item_name):
        search = self.zbx_search_item(host_id, {"name": item_name})['result']
        if len(search) != 0:
            item_id = search[0]['itemid']
            result_delete_item = self.zbx_delete_item(item_id)
            try:
                assert len(result_delete_item['result']['itemids']) == 1
                return True
            except AssertionError:
                raise ZbxCtrlError(
                    "Error during suppression of Item {} for host={}".format(item_name, self._data["host"])
                )
        return True

    def _get_application_id(self, host_id, application_name):
        search = self.zbx_search_application(host_id, application_name)['result']
        if len(search) == 0:
            result_create_application = self.zbx_create_application(host_id, application_name)
            try:
                assert len(result_create_application['result']['applicationids']) == 1
                return result_create_application['result']['applicationids'][0]
            except AssertionError:
                raise ZbxCtrlError(
                    "Error during creation of Application {} for host={}".format(application_name, self._data["host"])
                )
        else:
            return search[0]['applicationid']

    def _search_and_delete_trigger(self, host_id, trigger_name):
        search = self.zbx_search_trigger(host_id, trigger_name)['result']
        if len(search) != 0:
            trigger_id = search[0]['triggerid']
            result_delete_trigger = self.zbx_delete_trigger(trigger_id)
            try:
                assert len(result_delete_trigger['result']['triggerids']) == 1
                return True
            except AssertionError:
                raise ZbxCtrlError(
                    "Error during suppression of Trigger {} for host={}".format(trigger_name, self._data["host"])
                )
        return True

    def _delete_application(self, host_id, application_name, not_raised_if_more_items=False):
        search = self.zbx_search_application(host_id, application_name)['result']
        if len(search) != 0:
            application_id = search[0]['applicationid']
            search_items = self.zbx_search_item(host_id, params_data={"applicationids": application_id})
            if len(search_items["result"]) != 0:
                if not not_raised_if_more_items:
                    raise ZbxCtrlError(
                        "Cannot delete Application {application_name} for host={host}, "
                        "{application_name} has one or more items...".format(
                            application_name=application_name, host=self._data["host"]
                        )
                    )
                return True
            try:
                result_delete_application = self.zbx_delete_application(application_id)
                assert len(result_delete_application['result']['applicationids']) == 1
                return True
            except AssertionError:
                raise ZbxCtrlError(
                    "Error during suppression of Application {} for host={}".format(
                        application_name, self._data["host"]
                    )
                )
        return True

    def run(self, data):
        # ugly too
        try:
            self._host_id = self.get_host_id(data["host"])
        except IndexError:
            raise ZbxCtrlError("Can't get host_id of {} in Zbx Infra...".format(data["host"]))
        with Rollback(onError=True) as rollback:
            self._data = data
            if data.get("link_host_tpl", None):
                if not data.get("host", None):
                    raise ZbxCtrlError(
                        'Missing key host in data={} for key=link_host_tpl'.format(data)
                    )
                if not data.get("tpl", None):
                    raise ZbxCtrlError(
                        'Missing key tpl in data={} for key=link_host_tpl'.format(data)
                    )
                else:
                    if data["tpl"] == 'SG_MongoDB_EDGE':
                        if not data.get("dbhost", None):
                            raise ZbxCtrlError('Missing key dbhost in data={} for tpl=SG_MongoDB_EDGE'.format(data))
                        if not data.get("dbport", None):
                            raise ZbxCtrlError('Missing key dbport in data={} for tpl=SG_MongoDB_EDGE'.format(data))
                        if not data.get("dbusername", None):
                            raise ZbxCtrlError('Missing key dbusername in data={} for tpl=SG_MongoDB_EDGE'.format(data))
                        if not data.get("dbpassword", None):
                            raise ZbxCtrlError('Missing key dbpassword in data={} for tpl=SG_MongoDB_EDGE'.format(data))
                        if not data.get("dbinstance", None):
                            raise ZbxCtrlError('Missing key dbinstance in data={} for tpl=SG_MongoDB_EDGE'.format(data))
                        host_id = self._host_id
                        macros = [
                            {
                                "hostid": host_id,
                                "macro": "{$DBM_HOST}",
                                "value": data["dbhost"]
                            },
                            {
                                "hostid": host_id,
                                "macro": "{$DBM_PORT}",
                                "value": data["dbport"]
                            },
                            {
                                "hostid": host_id,
                                "macro": "{$DBM_USERNAME}",
                                "value": data["dbusername"]
                            },
                            {
                                "hostid": host_id,
                                "macro": "{$DBM_PASSWORD}",
                                "value": data["dbpassword"]
                            },
                            {
                                "hostid": host_id,
                                "macro": "{$DBM_INSTANCE}",
                                "value": data["dbinstance"]
                            },

                        ]
                        try:
                            user_macros = self.get_user_macro(host_id)['result']
                            if len(user_macros) == 0:
                                for macro in macros:
                                    self.create_user_macro(**macro)
                            else:
                                for macro in user_macros:
                                    self.delete_user_macro(macro['hostmacroid'])
                                for macro in macros:
                                    self.create_user_macro(**macro)

                        except Exception as err:
                            raise ZbxCtrlError(err.args[0])
                        try:
                            get_host_group_id = self.get_host_group('SG_SGDB/SG_MGDB_EDGE')
                            host_group_id = get_host_group_id['result'][0]['groupid']
                            self.insert_in_hostgroup(group_id=host_group_id, host_id=host_id)
                        except Exception as err:
                            raise ZbxCtrlError(err.args[0])
                    elif data["tpl"] == 'SG_MongoDB_EDGE_ARBITER':
                        if not data.get("dbhost", None):
                            raise ZbxCtrlError('Missing key dbhost in data={} for tpl=SG_MongoDB_EDGE_ARBITER'.format(data))
                        if not data.get("dbinstance", None):
                            raise ZbxCtrlError('Missing key dbhost in data={} for tpl=SG_MongoDB_EDGE_ARBITER'.format(data))
                        host_id = self._host_id
                        macros = [
                            {
                                "hostid": host_id,
                                "macro": "{$DBM_HOST_A}",
                                "value": data["dbhost"]
                            },
                            {
                                "hostid": host_id,
                                "macro": "{$DBM_INSTANCE_A}",
                                "value": data["dbinstance"]
                            }
                        ]

                        try:
                            user_macros = self.get_user_macro(host_id)['result']
                            if len(user_macros) == 0:
                                for macro in macros:
                                    self.create_user_macro(**macro)
                            else:
                                for macro in user_macros:
                                    self.delete_user_macro(macro['hostmacroid'])
                                for macro in macros:
                                    self.create_user_macro(**macro)

                        except Exception as err:
                            raise ZbxCtrlError(err.args[0])
                        try:
                            get_host_group_id = self.get_host_group('SG_SGDB/SG_MGDB_EDGE_ARB')
                            host_group_id = get_host_group_id['result'][0]['groupid']
                            self.insert_in_hostgroup(group_id=host_group_id, host_id=host_id)
                        except Exception as err:
                            raise ZbxCtrlError(err.args[0])
                host_id = self._host_id
                template_id = self.get_template_id(data["tpl"])
                output = self.link_host_to_template(host_id, template_id)
                if output['hostids'][0] == host_id:
                    return {
                        "changed": True,
                        "result": "tpl={} has been linked on host={}".format(data["tpl"], data["host"])
                    }
                else:
                    try:
                        error = str(output)
                    except Exception:
                        error = None
                    raise ZbxCtrlError(
                        "Error while linking host={} with template={}, err={}".format(data["host"], data["tpl"], error)
                    )
            elif data.get("unlink_host_tpl", None):
                if not data.get("host", None):
                    raise ZbxCtrlError('Missing key host in data={} for key=unlink_host_tpl'.format(data))
                if not data.get("tpl", None):
                    raise ZbxCtrlError('Missing key tpl in data={} for key=unlink_host_tpl'.format(data))
                else:
                    if data["tpl"] == 'SG_MongoDB_EDGE' or data["tpl"] == 'SG_MongoDB_EDGE_ARBITER':
                        host_id = self._host_id
                        try:
                            if data["tpl"] == 'SG_MongoDB_EDGE':
                                get_host_group_id = self.get_host_group('SG_SGDB/SG_MGDB_EDGE')
                                host_group_id = get_host_group_id['result'][0]['groupid']
                                self.remove_from_hostgroup(group_id=host_group_id, host_id=host_id)
                            elif data["tpl"] == 'SG_MongoDB_EDGE_ARBITER':
                                get_host_group_id = self.get_host_group('SG_SGDB/SG_MGDB_EDGE_ARB')
                                host_group_id = get_host_group_id['result'][0]['groupid']
                                self.remove_from_hostgroup(group_id=host_group_id, host_id=host_id)
                        except Exception as err:
                            raise ZbxCtrlError(err.args[0])
                host_id = self._host_id
                template_id = self.get_template_id(data["tpl"])
                templates = self.get_templates_linked_to_host(host_id)
                if template_id not in templates:
                    return {
                        "changed": True,
                        "result": "tpl={} has been unliked on host={}".format(data["tpl"], data["host"])
                    }
                else:
                    output = self.unlink_host_to_template(host_id, template_id)
                    if output['hostids'][0] == host_id:
                        return {
                            "changed": True,
                            "result": "tpl={} has been unliked on host={}".format(data["tpl"], data["host"])
                        }
                    else:
                        try:
                            error = str(output)
                        except Exception:
                            error = None
                        raise ZbxCtrlError(
                            "Error while unlinking host={} with template={}, err={}".format(data["host"], data["tpl"], error)
                        )
            elif data.get("add_item", None):
                for v in ("host", "name", "item_type"):
                    if not data.get(v, None):
                        raise ZbxCtrlError(
                            'Missing key {} in data={} for key=add_item'.format(v, data)
                        )
                host_id = self._host_id
                interface_id = self.zbx_get_interfaces(host_id)['result'][0]['interfaceid']
                if data["item_type"] == "proc.num":
                    for v in ('process_min', 'process_max'):
                        if not data.get(v, None):
                            raise ZbxCtrlError(
                                'Missing key {} in data={} for item_type={}'.format(v, data, data["item_type"])
                            )
                    if not int(data['process_min']) <= int(data['process_max']):
                        raise ZbxCtrlError(
                            'process_min={} must be less than or equal to process_max={}'.format(
                                data['process_min'], data['process_max']
                            )
                        )
                    application_name = "Proc"
                    item_name = "Proc {}".format(data["name"])
                    application_id = self._get_application_id(host_id, application_name)
                    rollback.addStep(
                        self._delete_application, host_id, application_name, not_raised_if_more_items=True
                    )
                    sup_datas = (
                        (
                            "Proc {}".format(data["name"]),
                            {
                                "name": "Proc {}".format(data["name"]),
                                "key_": "proc.num[,{},{},{}]".format(
                                    data.get("users", ""),
                                    data.get("state", ""),
                                    data["cmdline"]
                                ),
                                "hostid": host_id,
                                "type": 7,
                                "value_type": 3,
                                "interfaceid": interface_id,
                                "delay": "1m",
                                "applications": [application_id]
                            },
                            ("SG_TRIGGER~PROCESS~PROC_NUM~{name}~{severity_level}~"
                             "nb instances < {process_min} or nb instances > {process_max}").format(
                                name=data["name"], severity_level=data.get('severity_level', "high").upper(),
                                process_min=data['process_min'], process_max=data['process_max']
                            ),
                            {
                                "description": ("SG_TRIGGER~PROCESS~PROC_NUM~{name}~{severity_level}~"
                                    "nb instances < {process_min} or nb instances > {process_max}").format(
                                    name=data["name"], severity_level=data.get('severity_level', "high").upper(),
                                    process_min=data['process_min'], process_max=data['process_max']
                                ),
                                "expression": (
                                    "{{{host}:{proc_call_expression}.count(#{collect_num},{process_min},lt)}}={collect_num} "
                                    "or {{{host}:{proc_call_expression}.count(#{collect_num},{process_max},gt)}}={collect_num}").format(
                                    host=data["host"],
                                    proc_call_expression="proc.num[,{},{},{}]".format(
                                        data.get("users", ""),
                                        data.get("state", ""),
                                        data["cmdline"]
                                    ),
                                    process_min=data['process_min'],
                                    process_max=data['process_max'],
                                    collect_num=data.get('collect_num', 3)
                                ),
                                "priority": self.TRIGGER_SEVERITY_MAP[data.get('severity_level', "high")]
                            }
                        ),
                    )
                elif data["item_type"] == "log":
                    for v in ("file", "regexp"):
                        if not data.get(v, None):
                            raise ZbxCtrlError(
                                'Missing key {} in data={} for item_type={}'.format(v, data, data["item_type"])
                            )
                    application_name = "Log"
                    item_name = "Log {}".format(data["name"])
                    application_id = self._get_application_id(host_id, application_name)
                    rollback.addStep(
                        self._delete_application, host_id, application_name, not_raised_if_more_items=True
                    )
                    if re.search(r"^[-_./a-zA-Z0-9]+$", data["file"]):
                        sup_datas = (
                            (
                                "Log {}".format(data["name"]),
                                {
                                    "name": "Log {}".format(data["name"]),
                                    "key_": "log[{},{},{},{},{},{},{}]".format(
                                        data["file"],
                                        data["regexp"],
                                        "", # encoding,
                                        "10",
                                        data.get("mode", "skip"),
                                        "",
                                        data.get("maxdelay", ""),
                                    ),
                                    "hostid": host_id,
                                    "type": 7,
                                    "value_type": 4,
                                    "interfaceid": interface_id,
                                    "delay": "{}m".format(data["polling_update"]),
                                    "applications": [application_id]
                                },
                                "SG_TRIGGER~LOG~{name}~{severity_level}~regexp('{regexp}')".format(
                                    name=data["name"], severity_level=data.get('severity_level', "high").upper(),
                                    regexp=data["regexp"]
                                ),
                                {
                                    "description": "SG_TRIGGER~LOG~{name}~{severity_level}~regexp('{regexp}')".format(
                                    name=data["name"], severity_level=data.get('severity_level', "high").upper(),
                                    regexp=data["regexp"]
                                    ),
                                    "expression": "{{{host}:{trigger_function}}}=1 ".format(
                                        host=data["host"], trigger_function="log[{},{},{},{},{},{},{}].regexp({regexp})".format(
                                            data["file"],
                                            data["regexp"],
                                            "", # encoding,
                                            "10",
                                            data.get("mode", "skip"),
                                            "",
                                            data.get("maxdelay", ""),
                                            regexp=data["regexp"]
                                        )
                                    ),
                                    "priority": self.TRIGGER_SEVERITY_MAP[data.get('severity_level', "high")]
                                }
                            ),
                            (
                                "File {}".format(data["name"]), # item_name =
                                {
                                    "name": "File {}".format(data["name"]),
                                    "key_": "vfs.file.exists[{}]".format(data["file"]),
                                    "hostid": host_id,
                                    "type": 7,
                                    "value_type": 0,
                                    "interfaceid": interface_id,
                                    "delay": "1m",
                                    "applications": [application_id]
                                }, # params_item =
                                "SG_TRIGGER~VFS~VFS_FILE_EXISTS{name}~{severity_level}~file {file} exists".format(
                                    name=data["name"], severity_level=data.get('severity_level', "high").upper(),
                                    file=data["file"]
                                ), # trigger_name
                                {
                                    "description": "SG_TRIGGER~VFS~VFS_FILE_EXISTS{name}~{severity_level}~file {file} exists".format(
                                        name=data["name"], severity_level=data.get('severity_level', "high").upper(),
                                        file=data["file"]
                                    ),
                                    "expression": "{{{host}:{trigger_function}}}=0".format(
                                        host=data["host"], trigger_function="vfs.file.exists[{}].last()".format(data["file"]),
                                    ),
                                    "priority": self.TRIGGER_SEVERITY_MAP[data.get('severity_level', "high")]
                                } # params_trigger
                            )
                        )
                    else:
                        sup_datas = (
                            (
                                "Log {}".format(data["name"]),
                                {
                                    "name": "Log {}".format(data["name"]),
                                    "key_": "logrt[\"{}\",{},{},{},{},{},{}]".format(
                                        data["file"],
                                        data["regexp"],
                                        "", # encoding,
                                        "10",
                                        data.get("mode", "skip"),
                                        "",
                                        data.get("maxdelay", ""),
                                    ),
                                    "hostid": host_id,
                                    "type": 7,
                                    "value_type": 4,
                                    "interfaceid": interface_id,
                                    "delay": "{}m".format(data["polling_update"]),
                                    "applications": [application_id]
                                },
                                "SG_TRIGGER~MULTIPLE_LOG~{name}~{severity_level}~regexp('{regexp}')".format(
                                    name=data["name"], severity_level=data.get('severity_level', "high").upper(),
                                    regexp=data["regexp"]
                                ),
                                {
                                    "description": "SG_TRIGGER~MULTIPLE_LOG~{name}~{severity_level}~regexp('{regexp}')".format(
                                    name=data["name"], severity_level=data.get('severity_level', "high").upper(),
                                    regexp=data["regexp"]
                                    ),
                                    "expression": "{{{host}:{trigger_function}}}=1".format(
                                        host=data["host"],
                                        trigger_function="logrt[\"{}\",{},{},{},{},{},{}].regexp({regexp})".format(
                                            data["file"],
                                            data["regexp"],
                                            "", # encoding,
                                            "10",
                                            data.get("mode", "skip"),
                                            "",
                                            data.get("maxdelay", ""),
                                            regexp=data["regexp"]
                                        )
                                    ),
                                    "priority": self.TRIGGER_SEVERITY_MAP[data.get('severity_level', "high")]
                                }
                            ),
                        )
                elif data["item_type"] == "web.page.regexp":
                    try:
                        assert int(data['port'])
                    except KeyError:
                        pass
                    except ValueError:
                        raise ZbxCtrlError("port {} must be integer".format(data['port']))
                    application_name = "URL"
                    item_name = "URL {}".format(data["name"])
                    application_id = self._get_application_id(host_id, application_name)
                    rollback.addStep(
                        self._delete_application, host_id, application_name, not_raised_if_more_items=True
                    )
                    sup_datas = (
                        (
                            "URL {}".format(data["name"]),
                            {
                                "name": "URL {}".format(data["name"]),
                                "key_": "web.page.regexp[{},{},{},{},100,]".format(
                                    data["hostname"],
                                    data.get("url", ""),
                                    data.get("port", "80"),
                                    data.get("expression", "200 OK"),
                                ),
                                "hostid": host_id,
                                "type": 0,
                                "value_type": 4,
                                "interfaceid": interface_id,
                                "delay": "1m",
                                "applications": [application_id]
                            },
                            "SG_TRIGGER~WEB~WEB_PAGE~{name}~{severity_level}~regexp({expression})".format(
                                name=data["name"], severity_level=data.get('severity_level', "high").upper(),
                                expression=data['expression']
                            ),
                            {
                                "description":
                                    "SG_TRIGGER~WEB~WEB_PAGE~{name}~{severity_level}~regexp({expression})".format(
                                    name=data["name"], severity_level=data.get('severity_level', "high").upper(),
                                    expression=data['expression']
                                ),
                                "expression": "{{{host}:{proc_call_expression}.str({expression})}}=0".format(
                                    host=data["host"], proc_call_expression="web.page.regexp[{},{},{},{},100,]".format(
                                        data["hostname"],
                                        data.get("url", ""),
                                        data.get("port", "80"),
                                        data.get("expression", "200 OK"),
                                    ),
                                    expression=data['expression']
                                ),
                                "priority": self.TRIGGER_SEVERITY_MAP[data.get('severity_level', "high")]
                            }
                        ),
                    )
                else:
                    raise ZbxCtrlError("Item {} not implemented".format(data["item_type"]))
                for item_name, params_item, trigger_name, params_trigger in sup_datas:
                    # this conditionnal statement is for item_type=='log', overwrite in case you have to implement
                    # a full feature supervision with item function == 'vfs.file.exists' or you need to use it with
                    # another item as log in the present case here.
                    if not (item_name == "File {}".format(data["name"]) and data["no_alert_on_missing_file"] == "true"):
                        search_item = self.zbx_search_item(host_id, {"name": item_name})['result']
                        if len(search_item) > 0:
                            if search_item[0]["key_"] != params_item["key_"]:
                                self._delete_item(host_id, item_name)
                                result_create_item = self.zbx_create_item(**params_item)
                                if not result_create_item.get('result', None):
                                    raise ZbxCtrlError("Item {} has not added for host={}. data_returned={}".format(
                                        item_name, data["host"], result_create_item
                                    ))
                                rollback.addStep(
                                    self.zbx_delete_item, result_create_item['result']['itemids'][0]
                                )
                        else:
                            result_create_item = self.zbx_create_item(**params_item)
                            if not result_create_item.get('result', None):
                                raise ZbxCtrlError("Item {} has not added for host={}. data_returned={}".format(
                                    item_name, data["host"], result_create_item
                                ))
                            rollback.addStep(
                                self.zbx_delete_item, result_create_item['result']['itemids'][0]
                            )
                        if self._search_and_delete_trigger(host_id, trigger_name):
                            try:
                                result_create_trigger = self.zbx_create_trigger(params_trigger)
                                assert len(result_create_trigger['result']['triggerids']) == 1
                            except AssertionError:
                                raise ZbxCtrlError(
                                    "Error during creation of Trigger {} for host={}, data_returned={}".format(
                                        trigger_name, data["host"], result_create_trigger
                                    )
                                )
                            except Exception as err:
                                raise ZbxCtrlError(
                                    "Error during creation of Trigger {} for host={}, err={}".format(
                                        trigger_name, data["host"], err.args[0]
                                    )
                                )
                return {
                    "changed": True,
                    "result": "Item {} has been added for host={}".format(item_name, data["host"])
                }
            elif data.get("del_item", None):
                for v in ("host", "name", "item_type"):
                    if not data.get(v, None):
                        raise ZbxCtrlError(
                            'Missing key {} in data={} for key=del_item'.format(v, data)
                        )
                host_id = self._host_id
                if data["item_type"] == "proc.num":
                    item_name = "Proc {}".format(data["name"])
                    application_name = "Proc"
                elif data["item_type"] == "log":
                    application_name = "Log"
                    item_name = "Log {}".format(data["name"])
                    try:
                        item_id = self.zbx_search_item(host_id, {"name": "File {}".format(
                            data["name"]
                        )})['result'][0]['itemid']
                        self.zbx_delete_item(item_id)
                    except IndexError:
                        pass
                elif data["item_type"] == "web.page.regexp":
                    item_name = "URL {}".format(data["name"])
                    application_name = "URL"
                else:
                    raise ZbxCtrlError("Item {} not implemented".format(data["item_type"]))
                self._delete_application(host_id, application_name, not_raised_if_more_items=True)
                if len(self.zbx_search_item(host_id, {"name": item_name})['result']) == 0:
                    return {
                        "changed": False,
                        "result": "Item {} had removed for host={}".format(item_name, data["host"])
                    }
                else:
                    item_id = self.zbx_search_item(host_id, {"name": item_name})['result'][0]['itemid']
                    result = self.zbx_delete_item(item_id)
                    try:
                        assert len(result['result']['itemids']) == 1
                    except AssertionError:
                        raise ZbxCtrlError("Error during suppression of Item {} for host={}".format(item_name, data["host"]))
                    return {
                        "changed": True,
                        "result": "Item {} has been removed for host={}".format(item_name, data["host"])
                    }
            elif data.get("test_agent_zbx", None):
                if not data.get("host", None):
                    raise ZbxCtrlError('Missing key host in data={} for key=test_agent_zbx'.format(data))
                if not data.get("ip_address", None):
                    raise ZbxCtrlError('Missing key ip_address in data={} for key=test_agent_zbx'.format(data))
                session = VmSessionSsh(data["ip_address"])
                try:
                    cmd = "systemctl is-active zabbix-agent.service"
                    code, out, err = session.execute_cmd(cmd, type="static")
                    out = out.decode("utf-8")
                    err = err.decode("utf-8")
                    if code != 0:
                        raise Exception(
                            "Error while checking if Zabbix service is started, cmd='{}',"
                            "stdout='{}', stderr='{}', more informations may be found in logs".format(cmd, out, err)
                        )
                except Exception as err:
                    raise ZbxCtrlError(err.args[0])
                try:
                    cmd = "id -u walle"
                    code, out, err = session.execute_cmd(cmd, type="static")
                    out = out.decode("utf-8")
                    err = err.decode("utf-8")
                    if code != 0:
                        raise Exception(
                            "Error while checking presence of User walle, cmd='{}',"
                            "stdout='{}', stderr='{}', more informations may be found in logs".format(cmd, out, err)
                        )
                except Exception as err:
                    raise ZbxCtrlError(err.args[0])
                try:
                    int(self._host_id)
                except Exception as err:
                    raise ZbxCtrlError(
                        "Error while checking if {} is present in Zabbix infra, err={}".format(data["host"], err.args[0])
                    )
                return {
                    "changed": True,
                    "result": "Tests zabbix are OK for host={}".format(data["host"])
                }

#!/usr/bin/python
# -*- coding: utf-8 -*-

#

DOCUMENTATION = '''

'''

EXAMPLES = '''

'''

import logging
import re

import edge.interfaces
from edge.conf import settings
from edge.exception import EdgeException

logging.basicConfig(level=logging.getLevelName(settings.LOGGER_LEVEL))
logger = logging.getLogger(__name__)

class Idm(edge.interfaces.Whats):
    def __init__(self):
        self.has_changed = False
        
    def create_whats(self, whats_trigram, whats_ip, whats_hostname):
        response = self.enroller(hostname=whats_hostname, ip_address=whats_ip, trigram=whats_trigram)
        response["idm_realm"] = self.get_realm()
        response["idm_domain"] = self.get_domain()
        if response["error"] is None:
            self.has_changed = True
        return response

    def delete_whats(self, whats_hostname):
        response = self.host_checker(hostname=whats_hostname)
        if response['error'] is None:
            response = self.unroller(hostname=whats_hostname)
            if response["error"] is None:
                self.has_changed = True        
        else:
            self.has_changed = False
        return response

    def check_whats(self, whats_ip, whats_hostname):
        response_hostname = self.host_checker(hostname=whats_hostname)
        result = {}
        if response_hostname['error'] is None:
            if response_hostname['result'] is not None and response_hostname['result']['additional']['arecord'][0] == whats_ip:
                 result = {'status': 200, 'msg': 'The hostname {} ({}) is well assigned'.format(whats_hostname, whats_ip)}
            else:
                 result = {'status': 202, 'msg': response_hostname}
        elif response_hostname['error']["code"] == 4001:
            response_ip = self.ip_checker(hostname=whats_hostname, ip_address=whats_ip)
            if response_ip["error"] is not None and response_ip["error"]["code"] == 4001:
                result = {'status': 200, 'msg': 'The hostname {} ({}) is not assigned in this domain'.format(whats_hostname, whats_ip)}
            else:
                result = {'status': 201, 'msg': response_ip}
        return result

    def check_hostname(self, whats_hostname):
        response_hostname = self.host_checker(hostname=whats_hostname)
        result = {}
        if response_hostname['error'] is None:
             result = {'status': 200, 'msg': 'The hostname {} is assigned {}'.format(whats_hostname, response_hostname)}
        else:
             result = {'status': 202, 'msg': response_hostname}
        return result

    def check_ip(self, whats_hostname, whats_ip):
        response_ip = self.ip_checker(hostname=whats_hostname, ip_address=whats_ip)
        result = {}
        if response_ip['error'] is None:
             result = {'status': 200, 'msg': 'The hostname {} is assigned {}'.format(whats_ip, response_ip)}
        else:
             result = {'status': 202, 'msg': response_ip}
        return result


#!/usr/bin/python
# -*- coding: utf-8 -*-

import json
import time
import requests
import urlparse
import logging
from datetime import datetime, timedelta
from sg_gts_tools.read_settings import read_settings

DEFAULT_CONFIG_FILE = "gts_cloud_api.cfg"

# Exception related to GtsCloudApi
class GtsCloudApiError(Exception):
    def __init__(self, msg, original):
        super(GtsCloudApiError, self).__init__(msg + (": %s" % original))
        self.original = original


# Main class to handle dialog with GTS Cloud
class GtsCloudApi(object):

    def __init__(self, api_env = "", config_file = DEFAULT_CONFIG_FILE):
        logger = logging.getLogger()
        logger.debug("GtsCloudApi constructor")
        self.config = read_settings(config_file)
        self.credentials = read_settings(self.config["VRA_CONFIG_credential_file"])
        if api_env == "":
           self.api_env = self.config["VRA_CONFIG_default_environment"]
        else:
           self.api_env = api_env
        self.token = None

    def __del__(self):
        self.delete_vra_token()

    def get_config_value(self, field_name):
        return self.config['VRA_{}_{}'.format(self.api_env, field_name)]

    def get_credentials_value(self, field_name):
        return self.credentials['VRA_{}_CREDENTIALS_{}'.format(self.api_env, field_name)]

    def get_vra_token(self):
        logger = logging.getLogger()
        logger.debug("Trying to get token from VRA")

        # check if we have a token and if it is still valid
        if self.token and len(self.token["id"]) >= 0:
            token_expiration = datetime.strptime(self.token["expires"], "%Y-%m-%dT%H:%M:%S.%fZ")
            # we want at least half an hour validity on the token
            if token_expiration > datetime.now() + timedelta(minutes = 30):
                return self.token
            else:
                self.delete_vra_token()
        # else we need a new token
        url = urlparse.urljoin(self.get_config_value("url"), self.get_config_value("token"))
        headers = {'content-type': 'application/json', 'Accept': 'application/json'}
        data = { "username": self.get_credentials_value('username'), 
                 "password": self.get_credentials_value('password'),
                 "tenant": self.get_config_value('tenant') }
        try: 
            r = requests.post(url, data=json.dumps(data), headers=headers)
            if r.status_code < 200 or r.status_code >= 300:
                self.token = None
                raise GtsCloudApiError("Unable to get token", None)        
        except Exception, e:
            self.token = None
            raise GtsCloudApiError("Unable to get token", e)

        self.token = r.json()
        return r.json()


    def delete_vra_token(self):
        logger = logging.getLogger()
        logger.debug("Delete token")

        if not self.token or len(self.token["id"]) == 0:
           return

        logger.debug("Found a token to delete : {}".format(self.token))
        url = urlparse.urljoin(self.get_config_value("url"),
                               self.get_config_value("token"))
        url = urlparse.urljoin(url, self.token["id"])
        headers = {'content-type': 'application/json', 'Accept': 'application/json',
                   'Authorization': 'Bearer {}'.format(self.token["id"])}
        try:
            r = requests.delete(url, headers=headers)
            if r.status_code < 200 or r.status_code >= 300:
                raise GtsCloudApiError("Unable to delete token", None)
        except Exception, e:
            raise GtsCloudApiError("Unable to delete token", e)


    def get_vra_catalog(self):
        logger = logging.getLogger()
        logger.debug("Get VRA catalog")

        self.get_vra_token()

        url = urlparse.urljoin(self.get_config_value("url"), 
                               self.get_config_value("catalog"))
        headers = {'content-type': 'application/json', 'Accept': 'application/json', 
                   'Authorization': 'Bearer {}'.format(self.token["id"]) }

        try:        
            r = requests.get(url, headers=headers)
            if r.status_code < 200 or r.status_code >= 300:
                raise GtsCloudApiError("Impossible to get catalog", None)
        except Exception, e:
            raise GtsCloudApiError("Impossible to get catalog {}", e)
        
        return r.json()
    

    def get_tenant_from_catalog(self, catalog, bg, id ):
        logger = logging.getLogger()
        logger.debug("Get tenant from catalog")

        # Browse the catalog until we find the requested id
        for item in catalog['content']:
            if id == item["catalogItem"]["id"]:
                for organization in item["entitledOrganizations"]:
                    # if we find the requested tenant label, we return tenant and subtenant refs
                    if organization ["subtenantLabel"] == bg:
                        return organization["tenantRef"], organization["subtenantRef"]
        return None,None
       
 
    def run_request_from_catalog_item(self, id, trigram, env, tenant, subtenant):
        logger = logging.getLogger()
        logger.debug("Run request from catalog item")

        url = urlparse.urljoin(self.get_config_value("url"), self.get_config_value("consumer"))
        headers = {'content-type': 'application/json', 'Accept': 'application/json',
                   'Authorization': 'Bearer {}'.format(self.token["id"])}

        if 'PRD' in env.upper():
           vra_env = 'PRD'
        else:
           vra_env = 'non-PRD'

        body = {
                 "@type": "CatalogItemRequest",
                 "catalogItemRef": {
                     "id": id
                 },
                 "organization": { "tenantRef": tenant, "subtenantRef": subtenant },
                 "state": "SUBMITTED", "requestNumber": 0,
                 "requestData": {
                     "entries": [ { "key": "provider-trigram", "value": { "type": "string", "value": trigram } },
                                  { "key": "provider-restrictedTo","value": { "type": "string", "value": self.get_config_value("domain") } },
                                  { "key": "provider-environment", "value": { "type": "string", "value": vra_env } } ] 
                                } 
                }
        try:
            r = requests.post(url, headers=headers, json=body)
            if r.status_code < 200 or r.status_code >= 300:
                raise GtsCloudApiError("Impossible to get request from catalog", None)
            return r.headers['location']
        except requests.RequestException, e:
            raise GtsCloudApiError("Impossible to get request from catalog", e)
 
        # useless return ?
        return None

    def get_request_status(self, location ):
        logger = logging.getLogger()
        logger.debug("Get request status")
 
        headers = {'content-type': 'application/json', 'Accept': 'application/json',
                   'Authorization': 'Bearer {}'.format(self.token["id"])}
        try:
            r = requests.get(location, headers=headers)
            if r.status_code < 200 or r.status_code >= 300:
                raise GtsCloudApiError("Impossible to retrieve request status", None)
        except Exception, e:
            raise GtsCloudApiError("Impossible to retrieve request status {}", e)
        
        return r.json()["state"]


    def get_catalog_item_from_name(self, catalog, name):
        logger = logging.getLogger()
        logger.debug("Get catalog item from name ")
        
        if len(catalog) == 0:
            return None
        if name == '':
            raise GtsCloudApiError("Filter name is incorrect")
        
        for item in catalog['content']:
            
            if name == item["catalogItem"]["name"]:
                return item["catalogItem"]["id"]
        return None

    def get_next_url(self, response):
        try:
            for link in response.json()['links']:
                if link['rel'] == 'next':
                    return link['href']
            return None
        except KeyError:
            return None

    def get_vra_vm_list_from_trigram(self, id, trigram):
        logger = logging.getLogger()
        logger.debug("Get VRA VM list from trigram")

        url = urlparse.urljoin(self.get_config_value("url"), 
                               self.get_config_value("query"))
        url = urlparse.urljoin(url, "?limit=40&%24filter=%28%28organization%2FsubTenant%2Fid%20eq%20%27{}%27%29%20and%20substringof%28%27{}lx%27%2Cname%29%29".format(id, str(trigram).lower()))
        headers = {'content-type': 'application/json', 'Accept': 'application/json', 
                   'Authorization': 'Bearer {}'.format(self.token["id"]) }

        try:        
            r = requests.get(url, headers=headers)
            if r.status_code < 200 or r.status_code >= 300:
                raise GtsCloudApiError("Impossible to get VM list", None)
            content = r.json()['content']
            next_page_url = self.get_next_url(r)
            while next_page_url and next_page_url != "":
               r_next = requests.get(next_page_url, headers=headers)
               if r_next.status_code < 200 or r_next.status_code >= 300:
                   raise GtsCloudApiError("Impossible to get VM list", None)
               content += r_next.json()['content']
               next_page_url = self.get_next_url(r_next)

        except Exception, e:
            raise GtsCloudApiError("Impossible to get VM list {}", e)
        
        return content


    def wait_for_request(self, location):
        logger = logging.getLogger()
        logger.debug("Wait for request ")

        waiting_status = ["IN_PROGRESS", "SUBMITTED", "PRE_APPROVED", "POST_APPROVED","PROVIDER_COMPLETED"]
        status = self.get_request_status(location)

        while status in waiting_status:
            time.sleep(float(self.get_config_value("request_delay")))
            status = self.get_request_status(location)

        return status
        

    def get_request_details(self, location):
        logger = logging.getLogger()
        logger.debug("Get request details")

        url = location + self.get_config_value("request_detail")
        headers = {'content-type': 'application/json', 'Accept': 'application/json', 
                   'Authorization': 'Bearer {}'.format(self.token["id"]) }

        try:
            r = requests.get(url, headers=headers)
            if r.status_code < 200 or r.status_code >= 300:
                raise GtsCloudApiError("Impossible to get request detail {}".format(r.status_code), None)
        except Exception, e:
            raise GtsCloudApiError("Impossible to get request detail", e)
        
        return r.json()


    def extract_bg_from_details(self, details):
        logger = logging.getLogger()
        logger.debug("Extract BG from details")

        if not details["values"] or not details["values"]["entries"]:
            raise GtsCloudApiError("Could not find BG for trigram ", None)

        for entry in details["values"]["entries"]:
            if entry["key"] == "provider-BGResult":
                if len(entry["value"]["items"]) > 0:
                    return entry["value"]["items"][0]["value"]
                else:
                    return None

        raise GtsCloudApiError("Could not find BG for trigram ", None)



    def get_vm_list_from_trigram(self, trigram, env):
        logger = logging.getLogger()
        logger.debug("Get VM List from Trigram {} in {}".format(trigram, env))

        #get catalog from VRA
        catalog = self.get_vra_catalog()
        
        # Get id of the BG corresponding to trigram
        # First, we search id of request get_BG_List_From_Trigram in catalog
        id = self.get_catalog_item_from_name(catalog, self.get_config_value("get_bg_request"))

        # We call this request with the correct tenant and subtenant
        tenant, subtenant = self.get_tenant_from_catalog(catalog, self.get_config_value("edge_bg") , id )

        # And wait for completion
        location = self.run_request_from_catalog_item(id, trigram, env, tenant, subtenant)
        status = self.wait_for_request(location)
        if status == "SUCCESSFUL":
            # get request results 
            details = self.get_request_details(location)
            # and extract the 1st provider  
            provider = self.extract_bg_from_details(details)
            if not provider:
                return []
            # get subtenant id of this provider
            tenant, subtenant = self.get_tenant_from_catalog(catalog, provider , id )
            # and run the real request
            vm_list = self.get_vra_vm_list_from_trigram(subtenant, trigram)
            return vm_list 

if __name__ == '__main__':
    pass

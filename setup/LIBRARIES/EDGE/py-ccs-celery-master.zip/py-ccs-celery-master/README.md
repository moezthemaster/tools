py-ccs-celery
===============================

https://sgithub.fr.world.socgen/GTSMKTCLD/py-ccs-celery/wiki/How-to-create-EDGE-VM-through-a-celery-worker-%3F

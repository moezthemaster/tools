from logzero import logger

from .whats_inventory_dev import WhatsInventory as WhatsInventoryDev
from .whats_inventory_hml import WhatsInventory as WhatsInventoryHml
from .whats_inventory_prd import WhatsInventory as WhatsInventoryPrd


class WhatsInventory(object):
    def __init__(self):
        logger.debug("__init__")
        self._inv_dev = WhatsInventoryDev()
        self._inv_hml = WhatsInventoryHml()
        self._inv_prd = WhatsInventoryPrd()
        self._inventory = {}
        self._reverse = {}
        self._envs = {'d': 'dev', 'h': 'hml', 'p': 'prd'}

    def add_infos(self, whats_host, whats_ip, whats_env):
        if whats_ip in self._reverse:
            self._reverse[whats_ip].append(
                {'host': whats_host, 'env': whats_env})
        else:
            self._reverse[whats_ip] = [{'host': whats_host, 'env': whats_env}]

        if whats_host in self._inventory:
            self._inventory[whats_host].append(
                {'ip': whats_ip, 'env': whats_env})
        else:
            self._inventory[whats_host] = [{'ip': whats_ip, 'env': whats_env}]

    def add_entries(self, whats_entries, env):
        for (host, entries) in whats_entries.iteritems():
            for entry in entries:
                self.add_infos(host, entry, env)

    def get_infos(self, vra_inv, dod_inv):
        logger.debug("get_infos")
        # Search in each idm servers for hostname or ips
        list_hosts = vra_inv._inventory.keys()
        list_hosts = list(set(list_hosts + dod_inv._inventory.keys()))
        ip_list_vra = [val['ip']
                       for hostname in vra_inv._inventory.keys()
                       for val in vra_inv._inventory[hostname]]
        list_ips = list(set(dod_inv._reverse.keys() + ip_list_vra))

        whats_entries = self._inv_dev.check_in_whats(list_hosts, list_ips)
        self.add_entries(whats_entries, "dev")
        whats_entries = self._inv_hml.check_in_whats(list_hosts, list_ips)
        self.add_entries(whats_entries, "hml")
        whats_entries = self._inv_prd.check_in_whats(list_hosts, list_ips)
        self.add_entries(whats_entries, "prd")


    def check_status(self, status_inventory):
        logger.debug("check status")
        for (hostname, entries) in self._inventory.iteritems():
            status_host = status_inventory.check_status(hostname)
            for entry in entries:
                status_ip = status_inventory.check_status(entry["ip"])
                entry['status_host'] = status_host
                entry['status_ip'] = status_ip


    def output(self):
        for (key, entries) in sorted(self._inventory.iteritems()):
            for entry in entries:
                print("{} : {}".format(key, entry))
        for (key, entries) in sorted(self._reverse.iteritems()):
            for entry in entries:
                print("{} : {}".format(key, entry))

    def check_records(self, vra_inventory):
        logger.debug("Check entries")

        for (key, entries) in sorted(self._inventory.iteritems()):
            if len(entries) != 1:
                print(
                    "{}:WTS:Too many entries:{}".
                    format(key, ",".join(
                        [entry['ip'] for entry in self._inventory[key]])))
            elif key in vra_inventory._inventory:
                if entries[0]['env'] != self._envs[key[0]]:
                    print(
                        "{}:WTS:Registered in wrong domain:{}:{}".
                        format(key,
                               entries[0]['env'],
                               vra_inventory._inventory[key][0]['env']))

    def check_ghost_records(self, vra_inventory):
        logger.debug("Check ghost entries")

        for (key, entries) in sorted(self._inventory.iteritems()):
            if key not in vra_inventory._inventory:
                for entry in entries:
                    if entry['status_host']['alive'] != 'Alive':
                        print("{}:WTS:Ghost entry:{}:{}".
                              format(key,
                                  ",".join(
                                      [entry['ip'] for entry in self._inventory[key]]),
                                  ",".join(
                                      [entry['env'] for entry in self._inventory[key]])))

    def check_incorrect_records(self, vra_inventory):
        logger.debug("Check incorrect entries")

        for (key, entries) in sorted(vra_inventory._inventory.iteritems()):
            if key not in self._inventory:
                print("{}:WTS:Not registered:{}".format(
                    key, vra_inventory._inventory[key][0]['ip']))
            elif vra_inventory._inventory[key][0]['ip'] != self._inventory[key][0]['ip']:
                print("{}:WTS:Wrong IP registered:{}:{}".format(
                    key,
                    self._inventory[key][0]['ip'],
                    vra_inventory._inventory[key][0]['ip']))

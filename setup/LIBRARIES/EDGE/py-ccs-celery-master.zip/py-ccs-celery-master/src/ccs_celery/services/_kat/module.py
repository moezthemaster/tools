
from incubaw.kataw import Kataw
from edge.interfaces import Kat
from edge.kat.service import KatService


class KatImpl(Kat):
    def __init__(self):
        self.kataw = Kataw()

    def get_single_component_data(self, trigram, irt_code):
        return self.kataw.get_single_component_data(trigram, irt_code)


class KatServiceImpl(KatService, KatImpl):
    pass


def kat_module(trigram, irt_code, default_client):
    ks = KatServiceImpl()
    client = ks.get_client(trigram, irt_code, default_client)
    return client

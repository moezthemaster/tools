
import os
import sys

sys.path.append(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
)

from files.sg_gts_kat2 import KatServiceImpl


class TestKat(object):
    def test_client_itim(self):
        ks = KatServiceImpl()
        client = ks.get_client('pga', 'A7048')
        assert client == 'GTS'

import logging
import sys
import os

if "TREE_DIR" in os.environ.keys():
    ANSIBLE_MODULES_PATH = [
        os.path.join(os.environ["TREE_DIR"], 'roles/edge'),
        os.path.join(os.environ["TREE_DIR"], "library"),
        os.path.join(os.environ["TREE_DIR"], 'roles/py_edge_vault'),
    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/edge',
        './roles/py_edge_vault'
    ]
for path in ANSIBLE_MODULES_PATH:
    sys.path.insert(0, path)

from ansible.module_utils.basic import AnsibleModule

import edge.filesystem.filesystem

logger = logging.getLogger(__name__)

PRESENT, ABSENT, INFOS, CHECK = 'present', 'absent', 'infos', 'check'

FIELDS = {
    "module_vm_ip_address": {
        "type": "str",
        "default": None
    },
    "module_fs_list": {
        "type": "list",
    },
    "module_action": {
        "default": INFOS,
        "choices": [PRESENT, ABSENT, INFOS, CHECK],
        "type": "str",
    },

}

REQUIRED_FIELDS = [
    ["module_action", PRESENT, ["module_vm_ip_address", "module_fs_list"]],
    ["module_action", ABSENT, ["module_vm_ip_address", "module_fs_list"]],
    ["module_action", INFOS, ["module_vm_ip_address"]],
    ["module_action", CHECK, ["module_vm_ip_address", "module_fs_list"]]
]


def main():
    module = AnsibleModule(argument_spec=FIELDS, required_if=REQUIRED_FIELDS)
    ip_address = module.params['module_vm_ip_address']
    state = module.params['module_action']
    fs_list = module.params['module_fs_list']

    try:
        if state == PRESENT:
            changed, res = edge.filesystem.filesystem.create_fs_list(fs_list, ip_address)
        elif state == ABSENT:
            changed, res = edge.filesystem.filesystem.delete_fs_list(fs_list, ip_address)
        elif state == CHECK:
            changed, res = edge.filesystem.filesystem.test_fs_list(fs_list, ip_address)
        elif state == INFOS:
            changed, res = edge.filesystem.filesystem.get_fs_list(ip_address)

        module.exit_json(changed=changed, meta=res)

    except Exception as e:
        module.fail_json(msg=e.args[0])


if __name__ == '__main__':
    main()

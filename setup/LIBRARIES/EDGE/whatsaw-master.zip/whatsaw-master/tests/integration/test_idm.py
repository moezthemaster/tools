import time
import logging

from whatsaw.idm import IdmWrapper

TRIGRAM = 'pga'

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


class TestIdm(object):
    def setup_method(self, method):
        print("\n{}:{}".format(type(self).__name__, method.__name__))

    def test_enrole_hostname_in_idm(self, HOSTNAME, IP_ADDRESS):
        """

        :return:
        """
        idm = IdmWrapper(HOSTNAME)
        request = idm.enroller(HOSTNAME, IP_ADDRESS, TRIGRAM)
        idm.destroy_token()
        time.sleep(30)
        print(request)
        assert request['error'] is None

    def test_enrole_hostname_already_in_idm(self, HOSTNAME, IP_ADDRESS):
        """

        :return:
        """
        idm = IdmWrapper(HOSTNAME)
        request = idm.enroller(HOSTNAME, IP_ADDRESS, TRIGRAM)
        idm.destroy_token()
        print(request)
        assert request['error']['code'] == 4002

    def test_check_whats_ip_exists(self, HOSTNAME, IP_ADDRESS):
        idm = IdmWrapper(HOSTNAME)
        request = idm.ip_checker(idm.environment, IP_ADDRESS)
        idm.destroy_token()
        print(request)
        assert request["result"]["value"] == IP_ADDRESS

    def test_check_whats_hostname_exists(self, HOSTNAME):
        idm = IdmWrapper(HOSTNAME)
        request = idm.host_checker(HOSTNAME)
        idm.destroy_token()
        print(request)
        assert request["result"]["value"] == HOSTNAME + '.' + idm.get_domain()

    def test_unrole_hostname_from_idm(self, HOSTNAME):
        idm = IdmWrapper(HOSTNAME)
        request = idm.unroller(HOSTNAME)
        idm.destroy_token()
        time.sleep(30)
        print(request)
        assert request['error'] is None

    # def test_unrole_an_unknow_hostname_from_idm(self, HOSTNAME):
    #     idm = IdmWrapper(HOSTNAME)
    #     request = idm.unroller(HOSTNAME)
    #     idm.destroy_token()
    #     time.sleep(30)
    #     print(request)
    #     assert request['error']['code'] == 4001

    def test_check_whats_ip_doesnt_exist(self, HOSTNAME, IP_ADDRESS):
        idm = IdmWrapper(HOSTNAME)
        request = idm.ip_checker(idm.environment, IP_ADDRESS)
        idm.destroy_token()
        print(request)
        assert request["error"]["code"] == 4001

    def test_check_whats_hostname_doesnt_exist(self, HOSTNAME):
        idm = IdmWrapper(HOSTNAME)
        request = idm.host_checker(HOSTNAME)
        idm.destroy_token()
        print(request)
        assert request["error"]["code"] == 4001

#!/usr/bin/env python
# -*- coding: utf-8 -*-

import testinfra
from time import sleep
from behave import *

@then('One disk is added to vm')
def step_impl(context):
    reboot_command="sudo reboot"
    server=testinfra.get_host('ssh://automation@' + context.params['vm_hostname'])
    get_disk_size_added="lsblk -r -d -e 11,2,1 -o SIZE -n | sed 's/G//' | sed -n '$p' "
#   lsblk:
#    -r, --raw            use raw output format
#    -d, --nodeps         don't print slaves or holders
#    -e, --exclude <list> exclude devices by major number (default: RAM disks)
#    -o, --output <list>  output columns
#    -n, --noheadings     don't print headings
#   ... | we remove "G"igabyte caracter | we only want the last disk

    print("\n")
    print("###########################################################################################")
    print("#                             Rebooting machine. Waiting.....                             #")
    print("###########################################################################################")
    print("\n")
    server.run(reboot_command)
    sleep(30)

    print("\n")
    print("###########################################################################################")
    print("#                 Test if a disk of {}Go has been added on VM {}                  #".format(context.params['disk_size'],context.params['vm_hostname']))
    print("###########################################################################################")
    print("\n")
    cmd_disk = server.run(get_disk_size_added)

    if int(cmd_disk.stdout) == context.params['disk_size'] :
        assert context.failed is False
    else:
        print("\nSomething's wrong, disk added wasn't detected : disk size requested {}Go / last disk size detected {}Go.\n\n".format(context.params['disk_size'],int(cmd_disk.stdout)))
        assert context.failed is True

 

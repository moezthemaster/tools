#!/usr/bin/env bash
set -e

mkdir -p ${WORKSPACE}/puppet/modules

echo 'Gathering puppet modules'

curl -k https://itbox-nexus-arc.fr.world.socgen/nexus-arc/service/local/repositories/sgcib-iac-maven2-hosted-releases/content/xebialabs/community-plugins/deployit-puppet-module/1.0.0/deployit-puppet-module-1.0.0-PatchHttps.zip -o ${WORKSPACE}/puppet/modules/puppet.zip
unzip -oqq ${WORKSPACE}/puppet/modules/puppet.zip -d ${WORKSPACE}/puppet/modules

export FACTER_xlduser=$1
export FACTER_xldpassword=$2
export FACTER_keyspath="/${HOSTNAME^^}/work/tools/keys"

cd ${WORKSPACE}/puppet

puppet apply ${WORKSPACE}/puppet/cis.pp --modulepath ${WORKSPACE}/puppet/modules --hiera_config ${WORKSPACE}/puppet/hiera.yaml --parser=future

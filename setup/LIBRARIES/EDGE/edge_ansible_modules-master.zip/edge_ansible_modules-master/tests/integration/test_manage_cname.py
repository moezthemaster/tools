#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import sys
import logging

sys.path.append(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
)

from files.sg_gts_alias_dns import ManageCnameImpl
from files.sg_gts_manage_ip import DnsFeederAdapter, DnsCleanerAdapter

logging.basicConfig(level=logging.DEBUG)

logger = logging.getLogger(__name__)

HOSTNAME = 'dpgalxtestmanagecname'


class TestManageCname(object):

    def test_add_delete_cname_with_cloud_infos(self):
        # record field A for CNAME test
        feeder = DnsFeederAdapter(
            'dev',
            'EU France (Greater Paris)',
            'eu-fr-paris-1',
            'CDN',
            trigram='pga',
            hostname=HOSTNAME
        )
        cleaner = DnsCleanerAdapter(
            'dev',
            'EU France (Greater Paris)',
            'eu-fr-paris-1',
            'CDN',
            trigram='pga',
            hostname=HOSTNAME
        )
        cleaner.run()
        feeder.run()
        assert feeder.changed

        # record CNAME
        manage_cname = ManageCnameImpl(
            env='dev', region_cloud='EU France (Greater Paris)', az_cloud='eu-fr-paris-1', network_id='CDN',
            hostname=HOSTNAME, alias="dpgalxtestmanagecnamealias", alias_zone="dns21.socgen"
        )
        manage_cname.record_cname()
        assert manage_cname.changed

        # delete CNAME
        manage_cname = ManageCnameImpl(
            env='dev', region_cloud='EU France (Greater Paris)', az_cloud='eu-fr-paris-1', network_id='CDN',
            hostname=HOSTNAME, alias="dpgalxtestmanagecnamealias", alias_zone="dns21.socgen"
        )
        manage_cname.delete_cname()
        assert manage_cname.changed

        # delete previous field A created for test
        cleaner = DnsCleanerAdapter(
            'dev',
            'EU France (Greater Paris)',
            'eu-fr-paris-1',
            'CDN',
            trigram='pga',
            hostname=HOSTNAME
        )
        cleaner.run()
        assert cleaner.changed

    def test_add_delete_cname_without_cloud_infos(self):
        # record field A for CNAME test
        feeder = DnsFeederAdapter(
            'dev',
            'EU France (Greater Paris)',
            'eu-fr-paris-1',
            'CDN',
            trigram='pga',
            hostname=HOSTNAME
        )
        cleaner = DnsCleanerAdapter(
            'dev',
            'EU France (Greater Paris)',
            'eu-fr-paris-1',
            'CDN',
            trigram='pga',            
            hostname=HOSTNAME
        )
        cleaner.run()
        feeder.run()
        assert feeder.changed

        # record CNAME
        manage_cname = ManageCnameImpl(
            hostname=HOSTNAME, alias="dpgalxtestmanagecnamealias", alias_zone="dns21.socgen"
        )
        manage_cname.record_cname()
        assert manage_cname.changed

        # delete CNAME
        manage_cname = ManageCnameImpl(
            hostname=HOSTNAME, alias="dpgalxtestmanagecnamealias", alias_zone="dns21.socgen"
        )
        manage_cname.delete_cname()
        assert manage_cname.changed

        # delete previous field A created for test
        cleaner = DnsCleanerAdapter(
            'dev',
            'EU France (Greater Paris)',
            'eu-fr-paris-1',
            'CDN',
            trigram='pga', 
            hostname=HOSTNAME
        )
        cleaner.run()
        assert cleaner.changed

import unittest
try:
    from unittest import mock
except ImportError:
    import mock
from tests.mock.zabbix import mock_vault
from zabaw.credential import get_credentials


class TestVault(unittest.TestCase):

    @mock.patch('py_edge_vault.secrets.get_secrets')
    def test_get_credentials(self, mock_creds):
        result = {
            "username": "zbx_user",
            "password": "zbx_pass"
        }
        mock_creds.return_value = mock_vault()
        response = get_credentials()

        assert (response[0], response[1]) == (result['username'], result['password'])
        result = {
            "username": "zbx_username",
            "password": "zbx_password"
        }
        assert not (response[0], response[1]) == (result['username'], result['password'])

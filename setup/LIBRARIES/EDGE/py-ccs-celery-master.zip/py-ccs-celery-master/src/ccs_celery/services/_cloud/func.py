
import time

from ccs_celery.tools import ret_or_mkt
from ccs_celery.abstract import TaskServiceManager
from ccs_celery.services._dod.module import dod_module
from ccs_celery.services.rollback import RollBackMixins
from ccs_celery.services._cloud.module import cloud_module


class CloudTask(TaskServiceManager, RollBackMixins):

    def __init__(self, data):
        super().__init__("Cloud", data)

    def on_failure(self, exc, kwargs, excinfo):
        try:
            self.rollback()
        except Exception as err:
            self.logger.error("Rollback for {} module has failded".format(str(err)))
        finally:
            self.data.services[self._task_name]["finished_at"] = time.time()
            self.data.services[self._task_name]["status"] = "FAILED"
            self.data.services[self._task_name]["exception_class"] = str(type(exc))
            self.data.services[self._task_name]["exception_msg"] = str(exc)
            self.data.services[self._task_name]["exception_traceback"] = str(excinfo)

    def on_success(self, result, kwargs):
        self.data.services[self._task_name]["finished_at"] = time.time()
        self.data.services[self._task_name]["status"] = "SUCCESS"
        self.data.services[self._task_name]["return_value"] = result

    def _set_up(self):
        self.data.services[self._task_name] = {
            "changed": False,
            "launch_at": time.time(),
            "service_kwargs": {}
        }
        self.data.services[self._task_name]["service_kwargs"]["app_id"] = self.data.shared_data["app_id"]
        self.data.services[self._task_name]["service_kwargs"]["vm_hostname"] = self.data.shared_data["vm_hostname"]
        self.data.services[self._task_name]["service_kwargs"]["ip_address"] = self.data.shared_data["vm_ip"]
        self.data.services[self._task_name]["service_kwargs"]["vm_subnet"] = self.data.shared_data["vm_subnet"]
        self.data.services[self._task_name]["service_kwargs"]["vm_desc"] = self.data.shared_data["vm_desc"]
        self.data.services[self._task_name]["service_kwargs"]["app_env"] = self.data.shared_data["app_env"]
        self.data.services[self._task_name]["service_kwargs"]["vm_profile"] = self.data.shared_data["vm_profile"]
        self.data.services[self._task_name]["service_kwargs"]["vm_region"] = self.data.shared_data["vm_region"]
        self.data.services[self._task_name]["service_kwargs"]["vm_az"] = self.data.shared_data["vm_az"]
        self.data.services[self._task_name]["service_kwargs"]["vm_os"] = self.data.shared_data["vm_os"]
        self.data.services[self._task_name]["service_kwargs"]["data_disk"] = self.data.shared_data["data_disk"]
        self.data.services[self._task_name]["service_kwargs"]["vm_backup"] = self.data.shared_data["vm_backup"]
        self.data.services[self._task_name]["service_kwargs"]["vm_replication"] = self.data.shared_data["vm_replication"]
        self.data.services[self._task_name]["service_kwargs"]["state"] = self.data.shared_data["state"]

    def task(self):
        self._set_up()
        self.logger.info("Invoke {} module with kwargs={}".format(
            self._task_name,
            self.data.services[self._task_name]["service_kwargs"])
        )
        result = cloud_module(**self.data.services[self._task_name]["service_kwargs"])
        if self.data.shared_data["state"] in ("present", "absent"):
            self.data.services[self._task_name]["rollback_kwargs"] = dict(
                state=self.nor_state(self.data.shared_data["state"]),
                **{x: self.data.services[self._task_name]["service_kwargs"][x] \
                   for x in self.data.services[self._task_name]["service_kwargs"].keys() if x != "state"}
            )
        self.data.services[self._task_name]["changed"] = result[0]
        # record cname in case of vm in mkt
        try:
            if self.data.shared_data["state"] == "present" and self.data.shared_data["network_index"] == "mkt":
                self.logger.info("_cloud record cname in _dod for mkt...")
                dod_module(
                    **self.data.services["Dod"]["service_kwargs"]
                )
        except:
            pass
        return result


class CloudInfosTask(TaskServiceManager, RollBackMixins):

    class CloudInfosTaskError(Exception):
        pass

    def __init__(self, data):
        super().__init__("CloudInfos", data)

    def on_failure(self, exc, kwargs, excinfo):
        try:
            self.rollback()
        except Exception as err:
            self.logger.error("Rollback for {} module has failded".format(str(err)))
        finally:
            self.data.services[self._task_name]["finished_at"] = time.time()
            self.data.services[self._task_name]["status"] = "FAILED"
            self.data.services[self._task_name]["exception_class"] = str(type(exc))
            self.data.services[self._task_name]["exception_msg"] = str(exc)
            self.data.services[self._task_name]["exception_traceback"] = str(excinfo)

    def on_success(self, result, kwargs):
        self.data.services[self._task_name]["finished_at"] = time.time()
        self.data.services[self._task_name]["status"] = "SUCCESS"
        self.data.services[self._task_name]["return_value"] = result

    def _set_up(self):
        self.data.services[self._task_name] = {
            "changed": False,
            "launch_at": time.time(),
            "service_kwargs": {}
        }
        self.data.services[self._task_name]["service_kwargs"]["vm_hostname"] = self.data.shared_data["vm_hostname"]
        self.data.services[self._task_name]["service_kwargs"]["extended_infos"] = True
        self.data.services[self._task_name]["service_kwargs"]["state"] = "infos"

    def task(self):
        self._set_up()
        self.logger.info("Invoke {} module with kwargs={}".format(
            self._task_name,
            self.data.services[self._task_name]["service_kwargs"])
        )
        result = cloud_module(**self.data.services[self._task_name]["service_kwargs"])
        self.data.services[self._task_name]["changed"] = result[0]
        if result[1]["ip_address"] == "N/A":
            raise CloudInfosTask.CloudInfosTaskError("{} doesn't exists".format(self.data.kwargs["vm_hostname"]))
        self.data.shared_data["vm_template"] = result[1]["vm_os"]
        self.data.shared_data["vm_desc"] = result[1]["vm_desc"]
        self.data.shared_data["vm_profile"] = self.data.kwargs["vm_profile"]
        self.data.shared_data["vm_ip"] = result[1]["ip_address"]
        self.data.shared_data["vm_subnet"] = result[1]["vm_subnet"]
        self.data.shared_data["vm_region"] = result[1]["vm_region"]
        self.data.shared_data["vm_az"] = result[1]["vm_az"]
        self.data.shared_data["vm_network"] = result[1]["vm_network"]
        self.data.shared_data["dns_zone"] = result[1]["vm_zone"]
        self.data.shared_data["dns_publish"] = result[1]["dns_publish"]
        self.data.shared_data["vm_provider"] = result[1]["vm_bg"]
        self.data.shared_data["vm_backup"] = result[1].get("vm_backup", None)
        self.data.shared_data["vm_replication"] = result[1].get("vm_replication", None) or False
        if self.data.shared_data["vm_replication"] == 'disabled':
            self.data.shared_data["vm_replication"] = False
        self.data.shared_data["data_disk"] = 20
        try:
            self.data.shared_data["app_env"] = result[1]["vm_env"].lower()
            self.data.shared_data["network_index"] = ret_or_mkt(
                self.data.shared_data["app_env"],
                self.data.shared_data["vm_region"],
                self.data.shared_data["vm_az"],
                self.data.shared_data["vm_network"]
            )
        except:
            self.data.shared_data["app_env"] = result[1]["vm_env"].lower().replace('uat', 'hml')
            self.data.shared_data["network_index"] = ret_or_mkt(
                self.data.shared_data["app_env"],
                self.data.shared_data["vm_region"],
                self.data.shared_data["vm_az"],
                self.data.shared_data["vm_network"]
            )
        return result

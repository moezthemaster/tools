""" Mock classes """
from faker import Faker


faker = Faker()


class MockTokenInfo(object):
    """ Mocking class sg_connect_client"""

    def __init__(self, mail="myemail@sg.com", ad="mylogin"):
        self.email = mail
        self.ad_name = ad

    def get(self, blah):
        if hasattr(self, blah):
            return getattr(self, blah)
        return None

    def mail(self):
        return self.email

    def login_ad(self):
        return self.ad_name


def mock_get_token_info(tokenstr, **options):
    if len(tokenstr) == 32:
        return MockTokenInfo(**options)
    return None


def fake_header():
    fake_token = "splitted " + faker.pystr(min_chars=32, max_chars=32)
    header = {"Content-Type": "application/json", "Authorization": fake_token}
    return header

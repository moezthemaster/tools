#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import sys
import logging


if "TREE_DIR" in os.environ.keys():
    ANSIBLE_MODULES_PATH = [
        os.path.join(os.environ["TREE_DIR"], 'roles/edge'),
        os.path.join(os.environ["TREE_DIR"], 'roles/dodaw'),
        os.path.join(os.environ["TREE_DIR"], "library"),
        os.path.join(os.environ["TREE_DIR"], 'roles/py_edge_vault'),

    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/edge',
        './roles/dodaw',
        './roles/py_edge_vault'
    ]
for path in ANSIBLE_MODULES_PATH:
    sys.path.insert(0, path)

from ansible.module_utils.basic import AnsibleModule


from edge.interfaces import DodV1
from dodaw.dodv1 import DodWrapper
from edge.dns.dodv1.feeder import DnsFeeder
from edge.dns.dodv1.cleaner import DnsCleaner


logger = logging.getLogger(__name__)


class DodImpl(DodV1):
    def __init__(self):
        self.dod_wrapper = DodWrapper()

    def get_next_free_ip(self, *args, **kwargs):
        return self.dod_wrapper.get_next_free_ip(*args, **kwargs)

    def host_add(self, *args, **kwargs):
        return self.dod_wrapper.host_add(*args, **kwargs)

    def host_search_infos(self, *args, **kwargs):
        return self.dod_wrapper.host_search_infos(*args, **kwargs)

    def host_delete(self, *args, **kwargs):
        return self.dod_wrapper.host_delete(*args, **kwargs)


class DnsFeederImpl(DnsFeeder, DodImpl):
    def __init__(self, env, region_cloud, az_cloud, network_id, hostname):
        DodImpl.__init__(self)
        DnsFeeder.__init__(self, env, region_cloud, az_cloud, network_id, hostname)


class DnsCleanerImpl(DnsCleaner, DodImpl):
    def __init__(self, env, region_cloud, az_cloud, network_id, hostname):
        DodImpl.__init__(self)
        DnsCleaner.__init__(self, env, region_cloud, az_cloud, network_id, hostname)


PRESENT, ABSENT = 'present', 'absent'

FIELDS = {
    "vm_hostname": {
        "required": True,
        "type": "str"
    },
    "vm_network": {
        "required": True,
        "type": "str"
    },
    "vm_subnet": {
        "required": False,
        "type": "str"
    },
    "dns_zone": {
        "required": False,
        "type": "str"
    },
    "vm_region": {
        "default": "EU France (Greater Paris)",
        "choices": [
            'EU France (Greater Paris)',
            'EU France (North)'
        ],
        "type": "str",
        "required": False,
    },
    "vm_az": {
        "default": "eu-fr-paris-1",
        "choices": [
            'eu-fr-paris-1',
            'eu-fr-paris-2',
            'eu-fr-north-1'
        ],
        "type": "str",
        "required": False,
    },
    "app_env": {
        "type": "str",
        "choices": [
            'uat',
            'tst',
            'int',
            'dev',
            'hml',
            'prd'
        ],
        "default": "prd",
    },
    "state": {
        "default": PRESENT,
        "choices": [
            PRESENT,
            ABSENT,
        ],
        "type": "str",
    },
}


def main():
    module = AnsibleModule(argument_spec=FIELDS)
    hostname = module.params['vm_hostname']
    state = module.params['state']
    region_cloud = module.params['vm_region']
    az_cloud = module.params['vm_az']
    network_id = module.params['vm_network']
    env = module.params['app_env']

    try:
        if state == PRESENT:
            feeder = DnsFeederImpl(env, region_cloud, az_cloud, network_id, hostname)
            response = feeder.run()
            module.exit_json(changed=feeder.changed, meta=response)
        elif state == ABSENT:
            cleaner = DnsCleanerImpl(env, region_cloud, az_cloud, network_id, hostname)
            response = cleaner.run()
            module.exit_json(changed=cleaner.changed, meta=response)
    except Exception as e:
        module.fail_json(msg=e.args[0])


if __name__ == '__main__':
  main()


from ccs_celery.run_tasks.tasks import create_vm, delete_vm, hello

__all__ = (create_vm, delete_vm, hello)

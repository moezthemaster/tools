""" apps.shared.models """
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

#!/usr/bin/python
# -*- coding: utf-8 -*-

#

DOCUMENTATION = '''
---


'''

EXAMPLES = '''
# Create 
- dodv2: name=dcinlx099 subnet=192.88.64.0/21 zone=dns21-3.socgen publish=dns21.socgen state=present"
'''

# import module snippets
from ansible.module_utils.basic import *
import re
import json
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from requests.auth import HTTPBasicAuth
import ConfigParser
import time
import datetime
import random
import string
import yaml
import tempfile


if "TREE_DIR" in os.environ.keys() : 
     ANSIBLE_MODULES_PATH = [
       './roles/ansible_libraries/files',  
       os.path.join(os.environ["TREE_DIR"], "library"),
        ]
else:
  ANSIBLE_MODULES_PATH = [
     './roles/ansible_libraries/files'
     ]

for path in ANSIBLE_MODULES_PATH:
  sys.path.append(path)

import sg_gts_tools.sg_gts_init

CONFIG_ROOT = '/etc/ansible'

DOD_CONFIG = 'gts_dod.cfg'

DOD_NETWORK = 'gts_cloud_network_mapping.yml'



def default_config(params):


  isError, log, out = sg_gts_tools.sg_gts_init.read_settings(CONFIG_ROOT, DOD_CONFIG)

  global SETTINGS

  vOutput = {

    'dod_username': out['DOD_username'],
    'dod_password': out['DOD_password'],
    'dod_urlRoot' : out['DOD_urlroot'],
    'dod_urlSuffix': out['DOD_urlsuffix'],
    'dod_dnsService': out['DOD_dnsservice'],
  }

  SETTINGS.update( vOutput )

  #SETTINGS.update( out )

  # RETURN
  return isError, log, out



def network_mapping(params):

  global NETWORK_MAPPING

  isError = False
  ipblock = "0.0.0.0/32"
  zone = "localhost.localdomain"
  publish = "localhost.localdomain"
  availability_zone = "eu-fr-paris-1"
  region = "EU France (Greater Paris)"

  conf_path = "{}/{}" . format(CONFIG_ROOT, DOD_NETWORK)


  if not os.path.exists(conf_path):
    conf_path = "{}/{}" . format(os.path.dirname(os.path.realpath(__file__)), DOD_NETWORK)

  if os.path.exists(conf_path):

    try:

      stream = open(conf_path, "r")

      NETWORK_MAPPING = yaml.load(stream)



      vm_network = params['vm_network'].upper()
      vm_az = params['vm_az']
      vm_region = params['vm_region']
      app_env = params['app_env'].upper()

      zone = NETWORK_MAPPING[app_env][vm_region][vm_az][vm_network]['zone']
      ipblock = NETWORK_MAPPING[app_env][vm_region][vm_az][vm_network]['ipblock']
      publish = NETWORK_MAPPING[app_env][vm_region][vm_az][vm_network]['publish']
      

    except Exception, e:

      NETWORK_MAPPING = {}

      isError = True

  else:

    isError = True

  # RETURN
  return isError, ipblock, zone, publish


def search_url_json(data):

    url = "{}{}?{}={}" . format(SETTINGS['dod_urlRoot'], SETTINGS['dod_urlSuffix'], "dns_service", SETTINGS['dod_dnsService'])
    url = url.replace(' ', '%20')

    return_json = {}

    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

    url = "{}&{}".format(url, '&'.join(['%s=%s' % (key, value) for (key, value) in data.items()]))

    try:

      r = requests.get(url, auth=HTTPBasicAuth(SETTINGS['dod_username'], SETTINGS['dod_password']), verify=False)
      
      return_json = r.json()

      return_json.update({"isError": False})



    except Exception, e:
      #return_json = r
      #return_json = r.headers
      #pass
      return_json.update({"isError": True})
      return 0, return_json


    return r.status_code, return_json


def post_url_json(data):


    url = "{}{}" . format(SETTINGS['dod_urlRoot'], SETTINGS['dod_urlSuffix'])
    #url = url.replace(' ', '%20')

    hasChanged = False

    return_json = {}

    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

    #url = "{}&{}".format(url, '&'.join(['%s=%s' % (key, value) for (key, value) in data.items()]))

    try:

      r = requests.post(url, data=data, auth=HTTPBasicAuth(SETTINGS['dod_username'], SETTINGS['dod_password']), verify=False)
      
      return_json = r.json()

      return_json.update({"isError": False})
      return_json.update({"url": url})

      hasChanged = True



    except Exception, e:
      #return_json = r.headers
      #pass
      return_json.update({"isError": True})
      return_json.update({"url": url})


    return hasChanged, r.status_code, return_json


def delete_url_json(id):

    url = "{}{}/{}?dns_service={}" . format(SETTINGS['dod_urlRoot'], SETTINGS['dod_urlSuffix'], id, SETTINGS['dod_dnsService'])
    url = url.replace(' ', '%20')

    return_json = {}

    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

    headers = {'Content-type': 'application/json', 'Accept': 'application/json', "Accept-Charset": "ISO-8859-1,utf-8;",}

    try:

      r = requests.delete(url, data={}, headers=headers, auth=HTTPBasicAuth(SETTINGS['dod_username'], SETTINGS['dod_password']), verify=False)
      
      return_json = r.json()

      return_json.update({"isError": False})
      return_json.update({"url": url})


    except Exception, e:

      return_json.update({"isError": True})
      return_json.update({"url": url})


    return r.status_code, return_json


def result_output(statusCode, output, params):

  result = {}
  ipAddr = "127.0.0.1"
  recordId = params.get('A_id', "")
  fqdn = "localhost.localdomain"


  if not output['isError']:
    
    try:

      for row in output['Response']:
        if str(recordId) == "":
           recordId = row.get('id', '')
           ipAddr = row.get('ip', '127.0.0.1')
           fqdn = row.get('hostname_fqdn', 'localhost.localdomain')
        elif str(recordId) == row.get('id', ''):
           ipAddr = row.get('ip', '127.0.0.1')
           fqdn = row.get('hostname_fqdn', 'localhost.localdomain')

    except Exception, e:
      pass

  result['output'] = output

  result['id'] = recordId
  result['ip_address'] = ipAddr
  result['subnet'] = params['vm_subnet']
  result['fqdn'] = fqdn
  result['status'] = statusCode
  #result['mapping'] = NETWORK_MAPPING
  result['logs'] = params

  return result


def delete_record(data):

  statusCode = 500
  output = {}
  recordId = 0
  hasChanged = False

  
  data.update({'method': 'record_search'})

  statusCode, output = search_url_json(data)

  if not output['isError']:
    
    recordId = output['Response'][0]['id']

    statusCode, output = delete_url_json(recordId)

    hasChanged = True

  return hasChanged, recordId, statusCode, output


def delete_record_by_type(vm_hostname, record_type):

  recordId = 0

  # Check for record
  data = {
           "method": "record_exist",
           "type": record_type,
           "hostname":"^{}$".format(vm_hostname),
           "view": "production",
          }
  statusCode, output = search_url_json(data)

  # If record exists, find corresponding ID
  if output['Response']:
    hasChanged, recordId, statusCode, output = delete_record(data)


def delete_created_records(vm_hostname, dns_zone, record_id):

  # we treat CNAME first for dependencies
  if record_id['CNAME'] != "":
    delete_url_json(record_id['CNAME'])

  for key in record_id.keys():
    if record_id[key] != "":
      if key != "CNAME":
        delete_url_json(record_id[key])

def dod_generate_hostname(env, trigram):
 #tmpfile = tempfile.NamedTemporaryFile(prefix="dod_debug.", dir="/tmp", delete=False)
  # store prefix based on trigram and env  in vm_hostname (ex. dpgalx)
  prefix = "{}{}lx".format (env, trigram)

  # get all servers for trigram and environment declared in DNS
  data = {
         "method": "record_search",
         "type": "^A$",
         "hostname":"^{}".format(prefix[:6]),
         "view": "production",
        }
  statusCode, output = search_url_json(data)
  if statusCode != 200:
    return None

 #tmpfile.write("list {}\n".format(output))
  # sort the list and loop over it to find 1st free slot
  try:
    if output['Response'][0]:
      host_regexp = "^" + prefix + "([0-9]{3,4})$"
      search_regexp = re.compile(host_regexp).search
     #tmpfile.write("list {}\n".format(host_regexp))
      list_increments = [ int(host.group(1)) for record in output['Response'] for host in (search_regexp(record['hostname']),) if host ]  
      #list_increments = [ int(x['hostname'].split('.')[0][6:]) for x in output['Response'] ]
      list_increments.sort()
     #tmpfile.write("list {}\n".format(list_increments))
      previous_increment = 0
      empty_increment = 1
      for increment in list_increments:
        if previous_increment + 1 < increment :
          empty_increment = previous_increment + 1
          break
        empty_increment = increment + 1
        previous_increment = increment

      generated_hostname = prefix + "{:03d}".format(empty_increment)
  except KeyError, e:
    # no server found in DNS for prefix, we need to create 001
   #tmpfile.write("KeyError {}\n".format(e))
    generated_hostname = prefix + '001'

  return generated_hostname

def dod_record_present(params):
 
 #tmpfile = tempfile.NamedTemporaryFile(prefix="dod_debug.", dir="/tmp", delete=False) 
  result = {}
  isError = False
  hasChanged = False
  record_id = { 
      'A': "",
      'PTR': "",
      'CNAME' : "",
  }

  ipAddr = "127.0.0.1"
  fqdn = "localhost.localdomain"
  recordId = 0
  record_exists = False

  # if hostname is provided, check for existance of an A record
  if not params['vm_hostname'].lower() in ["none", ""]:
   #tmpfile.write("Hostname is provided {}, we check DNS\n".format(params['vm_hostname']))
    data = { 
           "method": "record_exist",
           "type": "A",
           "hostname":"^{}$" . format(params['vm_hostname']),
           "view": "production",
           }  

    statusCode, output = search_url_json(data)
    if statusCode != 200:
      isError = True
      hasChanged = False
      result = output
      return isError, hasChanged, result      

    # if no record found, we create it
    if not bool(output['Response']):
      data = {
           "dns_service": SETTINGS['dod_dnsService'],
           "method": "record_add",
           "hostname": "{}".format(params['vm_hostname']),
           "type": "A",
           "view": "production",
           "zone": "{}" . format(params['dns_zone']),
           "ip_subnet": "{}" . format(params['vm_subnet']),
           "ip_range":"server",
           "inA": True,
           "inPTR":True,
          }
      hasChanged, statusCode, output = post_url_json(data)
      if statusCode != 200:
        isError = True
        hasChanged = False
        result = output
        return isError, hasChanged, result

      record_id['A'] = output['Response'][0]['id']

  else:
    # no hostname provided, we loop until generated hostname is OK
   #tmpfile.write("Hostname not provided {}, we create one\n".format(params['vm_hostname']))

    retries = 0

    while record_exists == False:
      generated_hostname = dod_generate_hostname(params['app_env'][0], params['app_id'])

      if not generated_hostname:
        isError = True
        hasChanged = False
        result = "Impossible to generated hostname"
        return isError, hasChanged, result
 
     #tmpfile.write("Hostname generated {}\n".format(generated_hostname))
      #raise ValueError
      # try to add the new A record to DNS for hostname
      data = { 
           "dns_service": SETTINGS['dod_dnsService'],
           "method": "record_add",
           "hostname": "{}".format(generated_hostname),
           "type": "A",
           "view": "production",
           "zone": "{}" . format(params['dns_zone']),
           "ip_subnet": "{}" . format(params['vm_subnet']),
           "ip_range":"server",
           "inA": True,
           "inPTR":True,
          }
      hasChanged, statusCode, output = post_url_json(data)
      if statusCode != 200 and statusCode != 400 or retries >= 5:
        isError = True
        hasChanged = False
        result = output
        return isError, hasChanged, result
     
      if statusCode == 400:
        retries = retries + 1
 
     #tmpfile.write("A record created {}\n".format(output))

      record_id['A'] = output['Response'][0]['id']

      # check if concurrent access detected (multiple A records in output)
      data = {
           "method": "record_search",
           "type": "A",
           "hostname":"^{}$" . format(generated_hostname),
           "view": "production",
          }

      statusCode, output = search_url_json(data)
      if statusCode != 200:
          delete_created_records(params['vm_hostname'], params['dns_zone'], record_id)
          isError = True
          hasChanged = False
          result = output
          return isError, hasChanged, result

     #tmpfile.write("{}\n".format(output))
      record_exists = True
      if len(output['Response']) > 1:
       #tmpfile.write("Wrong : {} A record !!\n".format(len(output['Response'])))
       #tmpfile.write("        {} \n".format(output['Response']))
        # we check if we have a superior id
        for r in output['Response']:
          if int(r['id']) < int(record_id['A']):
           #tmpfile.write("someone took it first !!, deleting entry {}\n".format(record_id['A']))
            delete_url_json(record_id['A'])
            record_id['A'] = ""
            record_exists = False
            break

      if record_exists == True:
        params['vm_hostname'] = generated_hostname

  # endif creation of A record if missing

  # Check if now A record is present 
  data = {
           "method": "record_search",
           "type": "A",
           "hostname":"^{}$" . format(params['vm_hostname']),
           "view": "production",
          }

  statusCode, output = search_url_json(data)
  if statusCode != 200:
      delete_created_records(params['vm_hostname'], params['dns_zone'], record_id)
      isError = True
      hasChanged = False
      result = output
      return isError, hasChanged, result

 #tmpfile.write("A record is present {}\n".format(output))

  # Specify our id if we just created it to be sure in case there are 2 entries
  if record_id['A'] != "":
      params['A_id'] = record_id['A']

  # And extract informations from output (ip_address,...)
  result = result_output(statusCode, output, params)

  # lookup DNS for the corresponding PTR entry
  data = { 
            "method": "record_exist",
            "type": "PTR",
            "hostname":"^{}$" . format(params['vm_hostname']),
            "view": "production",
          }  
  statusCode, output = search_url_json(data)
  if statusCode != 200:
      delete_created_records(params['vm_hostname'], params['dns_zone'], record_id)
      isError = True
      hasChanged = False
      result = output
      return isError, hasChanged, result

  inaddr = bool(output['Response'])
 
  # add the PTR record if not found
  if not inaddr:
   #tmpfile.write("PTR record not present \n")
    data = { 
             "dns_service": SETTINGS['dod_dnsService'],
             "method": "record_add",
             #"hostname": "{}.{}." . format(params['vm_hostname'], params['dns_zone']),
             "hostname": "{}" . format(params['vm_hostname']),
             "type": "PTR",
             "view": "production",
             "zone": "{}" . format(params['dns_zone']),
             "ip": "{}" . format(result['ip_address']),
             "inA": True,
             "inPTR":True,
            }

    hasChanged, statusCode, output = post_url_json(data)
    if statusCode != 200:
      delete_created_records(params['vm_hostname'], params['dns_zone'], record_id)
      isError = True
      hasChanged = False
      result = output
      return isError, hasChanged, result
      
    record_id['PTR'] = output['Response'][0]['id']
   #tmpfile.write("PTR record created {}\n".format(output))

  # lookup DNS for CNAME entry
  data = { 
            "method": "record_exist",
            "type": "CNAME",
            "alias":"{}" . format(params['vm_hostname']),
            "view": "production",
          }  
  statusCode, output = search_url_json(data)
 #tmpfile.write("statusCode {}\n".format(data['alias']))
 #tmpfile.write("statusCode {} {}\n".format(statusCode, output))
  if statusCode != 200:
      delete_created_records(params['vm_hostname'], params['dns_zone'], record_id)
      isError = True
      hasChanged = False
      result = output
      return isError, hasChanged, result

  cname = bool(output['Response'])
  # Existing CNAME record, we check if it is in the correct zone
  if cname:
      # lookup DNS for CNAME entry
      data = {
            "method": "record_search",
            "type": "CNAME",
            "alias":"{}" . format(params['vm_hostname']),
            "view": "production",
          }
      statusCode, output = search_url_json(data)
     #tmpfile.write("existing CNAME alias {}\n".format(data['alias']))
     #tmpfile.write("existing CNAME {} {}\n".format(statusCode, output))
      if statusCode != 200:
        delete_created_records(params['vm_hostname'], params['dns_zone'], record_id)
        isError = True
        hasChanged = False
        result = output
        return isError, hasChanged, result
      
     #tmpfile.write("output[Response][0][hostname]: {}\n".format(output['Response'][0]['hostname']))
     #tmpfile.write("output[Response][0][hostname].split: {}\n".format(output['Response'][0]['hostname'].split('.')[0]))
     #tmpfile.write("params[hostname]: {}\n".format(params['vm_hostname']))


      fqdn_to_add = "{}.{}.".format(params['vm_hostname'], params['dns_zone'])

      if output['Response'][0]['hostname'] != fqdn_to_add and output['Response'][0]['hostname'].split('.')[0] == params['vm_hostname']:
        delete_created_records(params['vm_hostname'], params['dns_zone'], record_id)
        isError = True
        hasChanged = False
        result = { "error" : "CNAME record for {} already created for different zone ({})".format(params['vm_hostname'], output['Response'][0]['hostname']) } 
       #tmpfile.write("error CNAME fqdn {}\n".format(fqdn_to_add))
       #tmpfile.write("error CNAME {} {}\n".format(statusCode, result))
        return isError, hasChanged, result
      if output['Response'][0]['hostname'].split('.')[0] != params['vm_hostname']: #resolve bug [RET-444]
       #tmpfile.write("different CNAME {} {}\n".format(output['Response'][0]['hostname'],params['vm_hostname']))
        data = { 
             "dns_service": SETTINGS['dod_dnsService'],
             "method": "record_add",
             "hostname": "{}.{}." . format(params['vm_hostname'], params['dns_zone']),
             "alias": "{}" . format(params['vm_hostname']),
             "type": "CNAME",
             "view": "production",
             "zone": "{}" . format(params['dns_publish']),
             "ip": "{}" . format(result['ip_address']),
             "inA": True,
             "inPTR":True,
            }
        hasChanged, statusCode, output = post_url_json(data)
        if statusCode != 200:
          try:
            record_id['CNAME'] = output['Response'][0]['id']
          except TypeError:
            pass 
          delete_created_records(params['vm_hostname'], params['dns_zone'], record_id)
          isError = True
          hasChanged = False
          result = output
          return isError, hasChanged, result
        
        record_id['CNAME'] = output['Response'][0]['id']
  # add CNAME entry if it is not present
  else:
    data = { 
             "dns_service": SETTINGS['dod_dnsService'],
             "method": "record_add",
             "hostname": "{}.{}." . format(params['vm_hostname'], params['dns_zone']),
             "alias": "{}" . format(params['vm_hostname']),
             "type": "CNAME",
             "view": "production",
             "zone": "{}" . format(params['dns_publish']),
             "ip": "{}" . format(result['ip_address']),
             "inA": True,
             "inPTR":True,
            }
    hasChanged, statusCode, output = post_url_json(data)
    if statusCode != 200:
      try:
        record_id['CNAME'] = output['Response'][0]['id']
      except TypeError:
        pass 
      delete_created_records(params['vm_hostname'], params['dns_zone'], record_id)
      isError = True
      hasChanged = False
      result = output
      return isError, hasChanged, result
    
    record_id['CNAME'] = output['Response'][0]['id']


  # lookup for A entry in DNS
  data = { 
             "method": "record_search",
             "type": "A",
             "hostname":"^{}$" . format(params['vm_hostname']),
             "view": "production",
            }
  statusCode, output = search_url_json(data)
  if statusCode != 200:
      delete_created_records(params['vm_hostname'], params['dns_zone'], record_id)
      isError = True
      hasChanged = False
      result = output
      return isError, hasChanged, result

  result = result_output(statusCode, output, params)
  hasChanged = any(created != "" for created in record_id.itervalues())
 #tmpfile.write("{} => {}\n".format(record_id, hasChanged))
  return isError, hasChanged, result


def dod_record_absent(params):
  result = {}
  isError = False
  hasChanged = False

  ipAddr = "127.0.0.1"
  fqdn = "localhost.localdomain"
  recordId = 0

  # CHECK CNAME

  data = { 
           "method": "record_exist",
           "type": "CNAME",
           "hostname":"^{}.{}.$" . format(params['vm_hostname'], params['dns_zone']),
           "view": "production",
          }  
  statusCode, output = search_url_json(data)

  # IF CNAME EXISTS COLLECT RECORD ID 

  if output['Response']:
    hasChanged, recordId, statusCode, output = delete_record(data)


  # CHECK PTR

  data = { 
           "method": "record_exist",
           "type": "PTR",
           "hostname":"^{}$" . format(params['vm_hostname']),
           "view": "production",
          }  

  statusCode, output = search_url_json(data)

  # IF IN-ADDR.ARPA EXISTS COLLECT RECORD ID 

  if output['Response']:
    hasChanged, recordId, statusCode, output = delete_record(data)


  # CHECK A RECORD

  data = { 
           "method": "record_exist",
           "type": "A",
           "hostname":"^{}$" . format(params['vm_hostname']),
           "view": "production",
          }  

  statusCode, output = search_url_json(data)

  # IF A RECORD EXISTS COLLECT RECORD ID 

  if output['Response']:
    hasChanged, recordId, statusCode, output = delete_record(data)

  # GET FINAL A RECORD
  data = { 
             "method": "record_exist",
             "type": "A",
             "hostname":"^{}$" . format(params['vm_hostname']),
             "view": "production",
            }
  
  statusCode, output = search_url_json(data)

  result = result_output(statusCode, output, params)


  return isError, hasChanged, result




def main():

  fields = { 
     "vm_hostname": {"required": False, "type": "str", "default": "none"},

     "vm_network": {"required": True, "type": "str"},
     "vm_subnet": {"required": False, "type": "str"},
     "dns_zone": {"required": False, "type": "str"},
     "dns_publish": {"required": False, "type": "str"},  
     "vm_region": {
        "default": "EU France (Greater Paris)",
        "choices": ['EU France (Greater Paris)', 'EU France (North)'],
        "type": "str",
        "required": False, 
     },
     "vm_az": {
        "default": "eu-fr-paris-1",
        "choices": ['eu-fr-paris-1', 'eu-fr-paris-2', 'eu-fr-north-1'],
        "type": "str",
        "required": False, 
     },
     "app_id": {"required": True, "type": "str"},
     "app_env": { 
        "type": "str",
        "choices": ['dev', 'hml', 'prd'],
        "default": "prd",
        },
     "state": {
        "default": "present",
        "choices": ['present', 'absent'],
        "type": "str"
     },
  }



  choice_map = {
     "present": dod_record_present,
     "absent": dod_record_absent,
  }



  module = AnsibleModule(argument_spec=fields)

  #Config settings
  isError, logOutput, output = default_config(module.params)
  if isError:
    module.fail_json(msg=logOutput)

  #network mapping settings
  isError, vm_subnet, dns_zone, dns_publish = network_mapping(module.params)

  module.params['vm_subnet'] = vm_subnet
  module.params['dns_zone'] = dns_zone
  module.params['dns_publish'] = dns_publish

  if isError:
    module.fail_json(msg="Specified network does not exist")


  #state  
  isError, hasChanged, result = choice_map.get( module.params['state'])(module.params)

  if not isError:
    module.exit_json(changed=hasChanged, meta=result)

  else:
    module.fail_json(msg="Error request cannot be completed", meta=result)


"""
"""
SETTINGS = {}

if __name__ == '__main__':
  main()


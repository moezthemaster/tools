#!/usr/bin/env bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PID_FILE=server.pid

if [ ! -f ${PID_FILE} ]; then
    echo "The server is stopped."
    exit 0
fi

kill -0 `cat ${PID_FILE}`

if [ $? -eq 0 ]; then
    echo "The server is up."
    exit 0
elif [ $? -eq 1 ]; then
    echo "The server is unexpectedly down !"
    exit 1
else
    echo "Something went wrong"
    exit 1
fi

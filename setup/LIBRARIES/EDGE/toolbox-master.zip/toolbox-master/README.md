ToolBox
====

This playbook allows you to configure your sandbox.

and

use "inventaire.py" [README OF INVENTAIRE](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/toolbox/blob/master/tools/inventories/README.md)

```

Configuration
-------------
### Requirements
Sandbox must be downloaded and installed (https://sgithub.fr.world.socgen/ITIM-TRANS-PAAP/paap-sandbox).

### Playbook Variables

Here are the requested values:


**username**

Your SG ID (axxxxxx)

**usermail**

Your SG mail address (john.dupond@socgen.com)

How it works
------------
1- connect to your sandbox using an ssh client: 127.0.0.1:2222

        vagrant ssh
        username: vagrant
        password: vagrant

2- clone the toolbox in /vagrant directory:
    
        cd /vagrant
        git clone https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/toolbox.git

3- go to toolbox directory and update the Playbook postInstallSandbox.yml setting your own username and mail adress :

        cd toolbox
        ansible-galaxy install --force -r requirements.yml -p roles
        vi postInstallSandbox.yml 
        
        ---
        - hosts: localhost
          connection: local
          become: true
          vars:

            user: "axxxxxx"
            mail: "john.dupond@socgen.com"

          tasks:

3- run the playbook (as automation):

        sudo -su automation
        sudo ansible-playbook postInstallSandbox.yml --ask-vault-pass


Licence
------------
BSD

Author
------------
GTS FEATURE TEAM

TODO
--------
Re 'vaulter' les fichiers de conf à copier dans /etc/ansible, les fichiers actuels ne sont pas les bons


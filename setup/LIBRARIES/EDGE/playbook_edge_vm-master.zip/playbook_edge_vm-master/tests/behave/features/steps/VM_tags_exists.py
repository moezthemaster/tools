#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
import testinfra

@given('VM tags exists')
def vm_tags_exists(context):

    print("Check that VM dpgalxtag0001 exist.")
    assert context.vm_hostname == 'dpgalxtag0001'
    server=testinfra.get_host('ssh://automation@'+context.vm_hostname)

    print("verif server exist {} \n".format(server))

    assert context.failed is (context.vm_hostname == '' )




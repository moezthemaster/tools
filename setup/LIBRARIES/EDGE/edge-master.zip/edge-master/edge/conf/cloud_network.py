#!/usr/bin/python
# -*- coding: utf-8 -*-

#

DOCUMENTATION = '''




'''

import socket,struct
from edge.conf import settings
from edge.exception import CloudMappingError
from .network_mapping import MAPPING

def get_details(env, region_cloud, az_cloud, network_id):
    '''

    :param env:
    :param az:
    :return: dict - example: {
                    'network_cidr': '175.59.200.0/21',
                    'dns_cname': 'dns20.socgen',
                    'dns_zone': 'dns20-2.socgen'
                }
    '''
    try:
        result = MAPPING[env.upper()][region_cloud][az_cloud][network_id.upper()]
    except:
        raise CloudMappingError(
            'combination env="{}" region_cloud="{}" az_cloud="{}" network_id="{}" is not available in cloud_network mapping dict from Edge library'.format(
                env, region_cloud, az_cloud, network_id
            )
        )
    return result


def addressInNetwork(ip, net):
    ipaddr = int(''.join([ '%02x' % int(x) for x in ip.split('.') ]), 16)
    netstr, bits = net.split('/')
    netaddr = int(''.join([ '%02x' % int(x) for x in
    netstr.split('.') ]), 16)
    mask = (0xffffffff << (32 - int(bits))) & 0xffffffff
    return (ipaddr & mask) == (netaddr & mask)


def find_network_infos_by_zone(ip, zone):
    try:
        for env in MAPPING:
            for region_cloud in MAPPING[env]:
                for az_cloud in MAPPING[env][region_cloud]:
                    for network_id in MAPPING[env][region_cloud][az_cloud]:
                        if zone == MAPPING[env][region_cloud][az_cloud][network_id]['dns_zone'] and \
                            addressInNetwork(ip, MAPPING[env][region_cloud][az_cloud][network_id]['network_cidr']):
                                return env, region_cloud, az_cloud, network_id, \
                                    MAPPING[env][region_cloud][az_cloud][network_id]['network_cidr'], \
                                    MAPPING[env][region_cloud][az_cloud][network_id]['dns_zone'], \
                                    MAPPING[env][region_cloud][az_cloud][network_id].get("dns_cname", None)
        raise CloudMappingError(
            '{}, {} matches no subnet defined in cloud_network mapping dict from Edge library'.format(ip, zone)
        )

    except Exception:
        raise CloudMappingError(
            '{}, {} matches no subnet defined in cloud_network mapping dict from Edge library'.format(ip, zone)
        )


def find_network_infos(ip, vm_region=None, vm_az=None):
    try:
        for env in MAPPING:
            for region_cloud in MAPPING[env]:
                if region_cloud == vm_region or vm_region == None:
                    for az_cloud in MAPPING[env][region_cloud]:
                        if az_cloud == vm_az or vm_az == None: 
                            for network_id in MAPPING[env][region_cloud][az_cloud]:
                                if addressInNetwork(ip, MAPPING[env][region_cloud][az_cloud][network_id]['network_cidr']):
                                     return env, region_cloud, az_cloud, network_id, \
                                         MAPPING[env][region_cloud][az_cloud][network_id]['network_cidr'], \
                                         MAPPING[env][region_cloud][az_cloud][network_id]['dns_zone'], \
                                         MAPPING[env][region_cloud][az_cloud][network_id].get("dns_cname", None)
    except Exception:
        raise CloudMappingError(
            '{}/{}/{} matches no subnet defined in cloud_network mapping dict from Edge library'.format(ip, vm_region, vm_az)
        )

def get_blueprint_name(requested_bp, env, region_cloud, az_cloud, network_cidr, provider_bg):
    # First we transform BP based on network
    try:
        bp_map = {}
        env = env.upper()
        for network_id in  MAPPING[env][region_cloud][az_cloud]:
            if MAPPING[env][region_cloud][az_cloud][network_id]['network_cidr'] == network_cidr:
                bp_map =  MAPPING[env][region_cloud][az_cloud][network_id]['bp_names']
                break
        if requested_bp in bp_map:
            translated_bp = bp_map[requested_bp]
            if translated_bp == "null":
                raise CloudMappingError(
                    'The requested blueprint {} is not compatible with env="{}" region_cloud="{}" az_cloud="{}" network_id="{}"'.format(
                    requested_bp, env, region_cloud, az_cloud, network_id)
                    )
        else:
            translated_bp = requested_bp
            
    except CloudMappingError:
        raise
    except:
        if  MAPPING.get(env, None) == None:
            raise CloudMappingError(
                'Env "{}" not found in network mapping.'.format(env)
                )
        elif MAPPING[env].get(region_cloud, None) == None:
            raise CloudMappingError(
                'Region "{}" not found in network mapping for env "{}".'.format(region_cloud, env)
                )
        elif MAPPING[env][region_cloud].get(az_cloud, None) == None:
            raise CloudMappingError(
                'AZ "{}" not found in network mapping for env "{}", region "{}".'.format(az_cloud, env, region_cloud)
                )
        elif MAPPING[env][region_cloud][az_cloud].get(network_id, None) == None:
            raise CloudMappingError(
                'Network_cidr "{}" not found in network mapping for env "{}", region "{}", az "{}".'.format(network_cidr, env, region_cloud, az_cloud)
                )
        else:
            raise CloudMappingError(
                'Blueprint map "{}" not configured for env="{}" region_cloud="{}" az_cloud="{}" network_id="{}"'.format(
                bp_map, env, region_cloud, az_cloud, network_id)
                )


    # Then we check if bg is a TRANSVERSE one
    if provider_bg in settings.BG_ALLOWED_TO_DEPLOY_IN_MKT:
        split_name=translated_bp.split("-")
        if len(split_name) == 3 and split_name[-2:] == ['RET', 'EDGE']:
            translated_bp = "{}-TRANSVERSE-RCR".format(split_name[0])

    return translated_bp



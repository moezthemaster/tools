#!/bin/bash

trigrams="mps ecp eaa had ste"
for trigram in $trigrams
do
        nohup python rematche_marley.py $trigram &
done

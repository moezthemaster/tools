import ansible_play
import subprocess
from behave import *


@when('run sg gts storage present')
def step_impl(context):
    run_data = {
        'state': "present",
        'vm_hostname': context.params['vm_hostname'],
        'disk_size': context.params['disk_size']
    }

    runner = ansible_play.Runner(
        playbook='sg_gts_add_storage.yml',
        run_data=run_data,
        hostnames='localhost',
        tags=None,
        private_key_file='',
        become_pass='foo-whatever',
        verbosity=100,
        connection='ssh'
    )

    stats = runner.run()

#    print("A disk of {}Go has been added to VM {}\n".format(run_data['disk_size'],context.params['vm_hostname']))

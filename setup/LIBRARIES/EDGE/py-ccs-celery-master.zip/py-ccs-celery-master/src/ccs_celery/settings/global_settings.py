'''
Default settings. Override these with settings in the .py file pointed to
by the CCS_CELERY_CONFIG_FILE environment variable.
'''

LOGGER_LEVEL = 'DEBUG'
CCS_CELERY_LOG_FOLDER = '/var/log/ccs_celery/'

# Broker and Result_backend configuration
#
BROKER_URL = ''
BACKEND_RESULT_URL = ''

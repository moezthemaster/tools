""" Contact list API """
# pylint: disable=no-member
from flask import json
from faker import Faker
import pytest

from sample.apis.contacts import ContactList
from sample.resources.contact import Contact as ContactModel
from sample.apis import api
from sample.tests.mock_classes import fake_header

faker = Faker()


def fake_contact_dict():
    """ Return a fake contact dictionary """
    return {"team": faker.pystr(),
            "phone": faker.phone_number(),
            "mail": faker.email(),
            "impulse_group": faker.pystr(),
            "jive": faker.url(),
            "doc_url": faker.url()}


@pytest.mark.usefixtures("set_logger")
@pytest.mark.usefixtures("sg_connect_token")
class TestContacts(object):
    """ Test GET and POST of Contact class """

    def test_get_contact_list(self, mocker, flask_app_client):
        """ #GET contact list - return a set of contact list """
        mock_db_contact = mocker.patch("sample.apis.contacts.ContactModel")
        test_contact = ContactModel(fake_contact_dict())
        mock_db_contact.query.all.return_value = [test_contact]

        res = flask_app_client.get(api.url_for(ContactList),
                                   headers=fake_header())
        fields = res.json()["contacts"][0]
        assert res.status_code == 200
        for attr in fields.keys():
            assert fields[attr] == getattr(test_contact, attr)

    @pytest.mark.parametrize("payload, expected_code", [
        ("", 400),
        (json.dumps(fake_contact_dict()), 201)
    ])
    def test_post_contact_list(self, mocker, flask_app_client,
                               payload, expected_code):
        """ #POST contact list """
        mocker.patch("sample.apis.contacts.db.session")
        res = flask_app_client.post(api.url_for(ContactList),
                                    data=payload,
                                    headers=fake_header())
        assert res.status_code == expected_code

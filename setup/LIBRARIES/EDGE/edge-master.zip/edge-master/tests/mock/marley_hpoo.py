from edge.interfaces import MarleyHPOO


class MockedMarleyHPOO(MarleyHPOO):
    def marley_hpoo_execute(self, **params):
        return 'dummy_result'

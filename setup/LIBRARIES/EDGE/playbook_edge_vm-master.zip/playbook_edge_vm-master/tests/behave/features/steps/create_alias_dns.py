#!/usr/bin/env python
# -*- coding: utf-8 -*-

import ansible_play
from behave import *


@when('Create alias_dns')
def step_impl(context):
    become_user_password = 'foo-whatever'
    run_data = {
        'vm_hostname': context.params['vm_hostname'],
        'dns_alias_name': context.params['vm_hostname'] + 'testalias',
        'dns_alias_zone': context.params['dns_alias_zone'],
        'state': 'present'
    }

    runner = ansible_play.Runner(
        hostnames='localhost',
        playbook='run_alias_dns.yml',
        tags="",
        private_key_file=context.private_key,
        run_data=run_data,
        become_pass=become_user_password,
        verbosity=100,
        connection='smart',
    )

    context.params['dns_alias_name'] = run_data['dns_alias_name']
    context.params['dns_alias_zone'] = run_data['dns_alias_zone']

    stats = runner.run()

    print(
        "alias {} created for VM {} in zone {}\n".format(context.params['dns_alias_name'],
                                                         context.params['vm_hostname'],
                                                         context.params['dns_alias_zone']))
    return stats

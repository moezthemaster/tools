#!/usr/bin/python
# -*- coding: utf-8 -*-

#
from json import dumps
from requests.models import Response


def mock_vault():
    result = { 'username': 'userX', 'password': 'Pass' }
    return result


class DodDatabase(object):
    def __init__(self, shared_database=None):
        if isinstance(shared_database, list):
            self.database = shared_database
        else:
            self.database = []

    def search(self, data):
        for r in self.database:
            if ('id' in data and data['id'] == r['id']) or data['hostname'] == r['hostname']:
                return {'exists': True, 'content': [r], 'index': self.database.index(r)}
        else:
            return {'exists': False, 'content': [] }

    def insert(self, data):

        record = self.search(data)
        record_created = False
        if not record['exists']:
            record_to_insert = {
                u'domain': None,
                u'protocol': None,
                u'weight': None,
                u'zone': data['zone'],
                u'ip': data['ip'],
                u'hostname': data['hostname'],
                u'comments': data['comments'],
                u'class': data['class'],
                u'port': None,
                u'alias': None,
                u'service': None,
                u'text': None,
                u'preference': None,
                u'ttl': data['ttl'],
                u'hostname_fqdn': u'{}.dns21-3.socgen.'.format(data['hostname']),
                u'type': data['type'],
                u'id': data['id'],
                u'view': u'production'                
            }
            self.database.append(data)
            record_created = True
        return record_created
    
    def update_record(self, data):
        record_updated = False
        record = self.search(data)
        if record['exists']:
            self.database[record['index']].update(data)
            record_updated = True
        return record_updated

    def delete_record(self, id):
        data = {'id': id}
        record_deleted = False
        record = self.search(data)
        if record['exists']:
            del self.database[record['index']]
            record_deleted = True
        return record_deleted

def mock_request_get(shared_db=None, **kwargs):
    data = dict(kwargs)
    response = Response()
    dod_db = DodDatabase(shared_db)
    record = dod_db.search(data)
    if record['exists']:
        result = {u'Response': record['content']}
        response.status_code = 200
    else:
        result = {u'Response': {u'status_code': 404, u'error': u'No record found'}}
        response.status_code = 404
    response._content = dumps(result).encode()
    return response

def mock_request_post(hostname, shared_db=None):
    dod_db = DodDatabase(shared_db)
    result = {u'status_code': u'200', u'Response': [{u'zone': u'db.dns21-3.socgen', u'ip': u'111.80.18.187', u'hostname': hostname, u'comments': u'', u'class': u'IN', u'ttl': u'Default', u'type': u'A', u'id': 512511, u'view': u'production'}]}
    record_created = dod_db.insert(result['Response'][0])
    response = Response()
    if record_created:
        response.status_code = 200
        response._content = dumps(result).encode()
        return response
    else:
        raise Exception("Record already exists !")

def mock_request_put(shared_db=None, **kwargs):
    data = dict(kwargs['data'])
    dod_db = DodDatabase(shared_db)
    result = {u'status_code': 200, u'Response': [{u'zone': data['zone'], u'ip': data['ip'], u'hostname': data['hostname'], u'comments': u'', u'class': u'', u'ttl': u'ttl', u'type': data['record_type'], u'id': data['id'], u'view': u'production'}]}
    record_updated = dod_db.update_record(result['Response'][0])
    if record_updated:
        response = Response()
        response.status_code = 200
        response._content = dumps(result).encode()
        return response
    else:
        raise Exception("Record not updated !!")

def mock_request_delete(id, shared_db=None):
    dod_db = DodDatabase(shared_db)
    record_deleted = dod_db.delete_record(id)
    result = {u'status_code': u'200', u'Response': u'Record delete with id={}'.format(id)}
    if record_deleted:       
        response = Response()
        response.status_code = 200
        response._content = dumps(result).encode()
        return response
    else:
        raise Exception("Record not deleted !")
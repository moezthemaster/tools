#!/usr/bin/python
# -*- coding: utf-8 -*-

#

import re
import logging

from edge.exception import EdgeException

logger = logging.getLogger(__name__)

def free_slot(records, prefix):
    '''
    Sort the record list and loop over it to find 1st free slot
    :param records: a record list
    :param prefix:
    :return: increment as int
    '''
    host_regexp = "^" + prefix + "([0-9]{3,4})$"
    search_regexp = re.compile(host_regexp).search
    list_increments = []
    for record in records:
        host = search_regexp(record['hostname'])
        if host:
            list_increments.append(int(host.group(1)))
    list_increments = sorted(set(list_increments))
    response = first_free_increment(list_increments)
    return response


def first_free_increment(sorted_list_int):
    '''
    Determine the first integer not in the list
    If list is empty, returns 1
    :param list_int: list of integers
    :return: integer
    '''
    for pos, val in enumerate(sorted_list_int, 1):
        if pos < val:
            return pos
    response = len(sorted_list_int)+1
    return response


def is_valide_hostname(trigram, hostname):
    regex = r'(^(d|h|p){}[a-zA-Z0-9_-]+$)|(^edge_conflict_(ssh|rdp|whats)_[0-9]+$)'.format(trigram)
    try:
        assert re.search(regex, hostname)
        return True
    except:
        raise EdgeException(
            "{} must match this regex '{}'".format(
                hostname, r'^(d|h|p){}[a-zA-Z0-9_-]+$'.format(trigram)
            )
        )

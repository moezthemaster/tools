
import os
import sys
# import pytest
import logging

sys.path.append(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
)

# from cloudaw.exception import CloudError

from files.sg_gts_cloud_vm2 import VmImpl

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


class TestCloudVm(object):
    def test_build(self):
        vm = VmImpl(hostname='dpgalxtest999')
        response = vm.create(vm_os='RHEL_7.3_x64-RET-EDGE', trigram='pga', app_env='dev',
                             vm_profile='Micro 1vCPU-1GB',
                             data_disk='20', vm_desc='test from edge_ansible_modules', ip_address='192.88.72.249',
                             vm_region='EU France (Greater Paris)', vm_az='eu-fr-paris-1',
                             vm_subnet='192.88.72.0/21',
                             vm_backup='none', vm_replication=False)
        assert response[u'name'] == u"dpgalxtest999"
        assert response[u'status'] == u"ACTIVE"
        vm.token.delete()

    def test_destroy(self):
        vm = VmImpl(hostname='dpgalxtest999')
        response = vm.destroy()
        vm.token.delete()

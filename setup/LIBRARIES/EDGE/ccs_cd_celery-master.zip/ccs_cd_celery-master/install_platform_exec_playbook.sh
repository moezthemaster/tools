#!/bin/bash

if [ "$#" -lt 7 ]; then
    echo -e "\n Illegal number of parameters.\n \n Usage example: $0 prd edg 10G 20G master sdc celery_sandbox \n"

else
    sudo yum -y install gcc python-devel krb5-devel
    sudo yum -y --enablerepo=epel install  python-requests-kerberos
    sudo yum -y --enablerepo=epel install python2-pip-8.1.2-5.el7.noarch
    sudo yum -y --enablerepo=epel install ansible
    ansible-galaxy install --force -r requirements.yml -p roles/ --ignore-errors
    vault_token=`curl -k -X POST -d '{"role_id":"edge-001-login-write","secret_id":"c2dfb74b-d77a-d64d-23f9-d8c848c43694"}'  https://vault-prod.fr.world.socgen/v1/auth/approle/login | python -m json.tool | grep token | cut -d: -f2 | cut -f2 -d\"`
    curl -k -X GET -H "X-Vault-Token: $vault_token" https://vault-prod.fr.world.socgen/v1/secret/edge-001/automation/id_rsa_base64 | python -mjson.tool | grep "private_key_base64" | cut -f2 -d: | cut -f2 -d\" | base64 --decode > ~/.ssh/id_rsa
    chmod 600 ~/.ssh/id_rsa
    curl -k -X GET -H "X-Vault-Token: $vault_token" https://vault-prod.fr.world.socgen/v1/secret/edge-001/automation/ansible_vault | python -m json.tool | grep value | cut -d: -f2 | cut -d\" -f2 > ~/ansible_vault.tmp
    ansible-playbook deploy.yml --vault-password-file='~/ansible_vault.tmp' -e "env_run=$1 trigram=$2 fs_size_home=$3 fs_size_logs=$4 playbook_version=$5 disk_appli=$6 platform=$7"
    rm ~/ansible_vault.tmp
fi

---

Le playbook << force_delete.yml >> permet de forcer la suppression d'une VM qui a été créée depuis Ansible Tower ou Alien4Cloud avec une clé publique inconnue pour automation.

La clé de le Team EDGE est configurée sur la cible pour le user automation.
De plus, le playbook ne sort pas en erreur si la VM n'est pas créée ou si l'entrée DNS n'est pas trouvée.

Ce playbook ne doit pas être communiqué a l'extérieur de la Team EDGE et ne pas être sorti du repository privé toolbox

Si le playbook doit être mis à jour suite à des évolutions du delete.yml original, un fichier patch existe pour tenter de recréer le force_delete à partir du nouveau delete :

```
patch delete.yml -i force_delete.patch -o force_delete.yml
``` 

--------------
force_delete.yml :
--------------

1 - lancer configure_force_delete_check_status.yml. cela permet de configurer l'environnement d'execution du playbook force delete (regarder configure_force_delete_check_status.yml).

2 - lancer le playbook force_delete.yml sur une liste de vm a détruire ou sur une seule vm.

  - pour supprimer une liste de vms: mettre la liste dans le fichier liste.txt ( une vm par ligne), et lancer le script force_delete_on_list.sh
```
./force_delete_on_list.sh
```
  - pour supprimer une seule vm: passer le nom de vm a detruire en extra-vars.
```
ansible-playbook force_delete.yml -e @defaults/delete.yml -e"vm_hostname='dpgalx001'"
```

NB: n'oublier pas de modifier le fichier defaults/delete.yml en lui passant les bons parametres ou le cas échéant, les passer au playbook en extra-vars (app_id, code_irt)

```
ansible-playbook force_delete.yml -e"vm_hostname='dpgalx001' app_id='pga' code_irt='A7048'"
```

----------------------
configure_force_delete_check_status.yml
----------------------

ce playbook permet de preparer l'environnement d'execution du playbook force_delete.yml et/ou check_vm_status.yml.
Il va cloner le playbook_edge_vm et installer les dépendences du master, copie le force_delete.yml et check_vm_status.yml dans la racine du playbook edge vm.

```
Example, pour supprimer dpgalx001 :
ansible-playbook configure_force_delete_check_status.yml
cd playbook_edge_vm
ansible-playbook force_delete.yml -e @defaults/delete.yml -e"vm_hostname='dpgalx001'"
```

----------------------
check_vm_status.yml
----------------------

ce playbook permet d'avoir le statut d'une ou liste de vms sur le VRA. A la fin d'execution, il génére dans le répertoire /var/log/ansible des fichiers contenant la (les) vms selon le statut: 
    
   - vm_up.txt: liste des vms up
   - vm_down.txt: liste des vms eteintes
   - vm_unknown_status.txt: liste des vm's qui ont un statut indéfini (propablement pas présentes dans le cloud)
    
```
Example, pour avoir le statut de dpgalx001 :
ansible-playbook check_vm_status.yml -e"vm_hostname='dpgalx001'"
```

```
Example, pour avoir le statut d'une liste de vm's qui se touve dans /tmp/vm_list.txt :
ansible-playbook check_vm_status.yml -e"vm_hostname_list_src='/tmp/vm_list.txt'"
```
NB: Avant de lancer check_vm_status.yml, il faut lancer configure_force_delete_check_status.yml (voir section configure_force_delete_check_status.yml)

----------------------
sudo_tcpdump.yml
----------------------

ce playbook sert à donner les droits temporaires à un utilisateur sur la commande tcpdump :

```
ansible-playbook -i hostname, sudo_tcpdump.yml -e user_id=aXXXXXX -e "duration='30 days'"
```



----------------------
TO DO :
----------------------
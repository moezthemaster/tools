#!/usr/bin/env python
# -*- coding: utf-8 -*-

# (c) 2016, Danny AFAHOUNKO <danny.afahounko-ext@socgen.com>
#

DOCUMENTATION = '''
---
author: Danny AFAHOUNKO
module: sg_gts_cloud_vm
short_description: Manage GTS cloud vm
description:
  - This module creates or removes vm in GTS cloud.
version_added: "1.0"
options:

  name:
    description:
    - vm hostname
    required: true

  env:
    description:
    - vm environment
    choices: ['dev','prd']
    default: prd
    required: false

  ip:
    description:
    - vm ipv4 address
    required: true

  state:
    choices: [ "present", "absent" ]
    default: present
    description:
    - Control if the vm exists or not.
    required: false

'''

EXAMPLES = '''
#


'''

# import module snippets
from ansible.module_utils.basic import *
import re
import json
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import ConfigParser
import time

##
import json
from collections import namedtuple
from ansible.parsing.dataloader import DataLoader
from ansible.vars import VariableManager
from ansible.inventory import Inventory
from ansible.playbook.play import Play
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.plugins.callback import CallbackBase
##
import paramiko

if "TREE_DIR" in os.environ.keys() : 
     ANSIBLE_MODULES_PATH = [
       './roles/ansible_libraries/files',  
       os.path.join(os.environ["TREE_DIR"], "library"),
        ]
else:
  ANSIBLE_MODULES_PATH = [
     './roles/ansible_libraries/files'
     ]

for path in ANSIBLE_MODULES_PATH:
    sys.path.append(path)

import sg_gts_tools.sg_gts_init

CONFIG_ROOT = '/etc/ansible'

GTS_CONFIG = 'gts_cloud_pubkey.cfg'


def default_config(params):
    isError, log, out = sg_gts_tools.sg_gts_init.read_settings(CONFIG_ROOT, GTS_CONFIG)

    global SETTINGS

    vOutput = {

        'rootKey': out['ROOT_KEY_path'],
	'user' : out.get('ROOT_KEY_user', 'intadm')
    }

    SETTINGS.update(vOutput)

    # SETTINGS.update( out )

    # RETURN
    return isError, log, out


def authorized_key(params):
    isError = False
    hasChanged = True

    print (SETTINGS['rootKey'])

    # Create a paramiko Key from specified file
    key = paramiko.RSAKey.from_private_key_file(SETTINGS['rootKey'])

    # Open a SSH connection to VM
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname=params['ip'], username=SETTINGS['user'], pkey=key)
    result = {}
    
    try:
        cmd = 'sudo sh -c "grep \'^{user}:\' /etc/passwd | cut -d: -f6 | tail -1"'.format(user=params['remote_user'])
        stdin, stdout, stderr = client.exec_command(cmd)
        homedir=stdout.read().rstrip()
        if not homedir:
            client.close()
            isError = True
            hasChanged = False
            result['log'] = "User {} not found on server".format(params['remote_user'])
            return isError, hasChanged, result
    except paramiko.SSHException:
        client.close()
        isError = True
        hasChanged = False
        result['log'] = "SSHException"
        return isError, hasChanged, result  

    try:
        cmd = 'sudo sh -c "grep \'{pubkey}\' {hd}/.ssh/authorized_keys"'.format(pubkey=params['pubkey'], user=params['remote_user'], hd=homedir)
        stdin, stdout, stderr = client.exec_command(cmd)
        exit_code = stdout.channel.recv_exit_status()
    except paramiko.SSHException:
        client.close()
        isError = True
        hasChanged = False
        result['log'] = "SSHException"
        return isError, hasChanged, result

    try:
        if exit_code != 0:
            cmd = 'sudo -u automation sh -c "mkdir -p {hd}/.ssh; chmod 700 {hd}/.ssh; echo \'{pubkey}\' >>{hd}/.ssh/authorized_keys; chown {user}:{group} {hd}/.ssh/authorized_keys; chmod 600 {hd}/.ssh/authorized_keys"'.format(pubkey=params['pubkey'], user=params['remote_user'], group=params['remote_group'], hd=homedir)
            stdin, stdout, stderr = client.exec_command(cmd)
            exit_code = stdout.channel.recv_exit_status()
            if exit_code == 0:
                result['log'] = "OK : "+stdout.read()
            else:
                isError = False
                result['log'] = "KO : "+stderr.read()
        else:
          client.close()
          hasChanged = False
    except paramiko.SSHException:
        isError = True
        hasChanged = False
        result['log'] = "Error while adding user key" 

    client.close()
    return isError, hasChanged, result


def cloud_pubkey_present(params):
    result = {}
    isError = False
    hasChanged = False

    isError, hasChanged, result = authorized_key(params)

    return isError, hasChanged, result


def main():
    fields = {
        "env": {
            "default": "prd",
            "choices": ['dev', 'prd'],
            "type": "str",
            "required": False,
        },
        "ip": {"required": True, "type": "str"},
        "remote_user": {"required": False, "type": "str", "default": "automation"},
        "remote_group": {"required": False, "type": "str", "default": "automation"},
        "pubkey": {
            "default": "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAACAQCrpaK+KJIfCWNRmiWQFtkSAfbumk6ujhfFNAf2RMOtobOaFNogCsXH2W2AGlCVf0oumlhwOapmgmE40Dd9jvCaufPz1zpATTMIg5YskD+WB4LyLriZ0zlbhdYcmKLeF16OfXXXIuB9jPWhLUKHRKMrGjaOsqyhx3AURemXBYdF84KGoR68MzUeHD9+sPVVxIHeAM7NudDbq/1yppbKwi1LQkS2rbbvL2IT9wSpZCKyO88o0GKFRBk6Ahu4l4sV9zM7NB2gQRMo9Ey8EvC0Am1xxxZw5MR9AeWJxc8fEMS6Q48eltGRRN1SOSLC3GNKGZ19J1TvsVfq2nQdErGxepZSRxOQQmiuiZuY9BYJRJjvfqaR0Dk9lhkLM02SVSKzrH72E2XDlCi8MvfRnJnh5HMaJ/3380H4I1vptjIu/HsbkFNnamFHSQU6BE/QVLwhcEleyxih8eVXMwxBgmHlAhXBSlWbOP8L+VkF7/5shqfxs84zIWdIZwaygulM72IaO31HwcIuGL06p3IL14m+tkQyTQ7Bfb2zHc2tvNyvWJI8F/ECOYI1BQbmqCl679RvcB+SGMPKOG5eugp0Hfm42o9Xh4c4FaJxJczh4mB+I7CcPPAsHBWcA1Kx0um4OD1UBNDy9Vkb2c4w95/mLwFjlJ8+IFNI4dFhum9he3qTjgCwxQ== postinstall_edge",
            "required": False,
            "type": "str"},
    }

    choice_map = {
        "present": cloud_pubkey_present,
    }

    module = AnsibleModule(argument_spec=fields)

    # Config settings

    isError, logOutput, output = default_config(module.params)
    if isError:
        module.fail_json(msg=logOutput)

    # state
    isError, hasChanged, result = choice_map.get('present')(module.params)

    if not isError:
        module.exit_json(changed=hasChanged, meta=result)

    else:
        module.fail_json(msg=result.get('log', "Unknown Error"), meta=result)


"""
"""
SETTINGS = {}

if __name__ == '__main__':
    main()


from edge.flexera import flexera


class FlexeraModuleError(Exception):
    pass


def configure_flexera_agent(params):
    ip_address = params['flexera_ip_address']
    configure = flexera.FlexeraRequest(ip_address)
    request = configure.request_flexera_configuration()
    if request == 1:
        result = {'status': 'FAILURE', 'code': request}
        return True, False, result
    else:
        return False, True, {'status': 'SUCCESS', 'code': request}


def uninstall_flexera_agent(params):
    return False, False, {'status': 'SUCCESS', 'code': 0}


def flexera_module(vm_ip, state):
    choice_map = {
        "present": configure_flexera_agent,
        "absent": uninstall_flexera_agent,
    }

    is_error, has_changed, result = choice_map.get(state)(
        {
            "flexera_ip_address": vm_ip,
            "state": state
        }
    )
    if not is_error:
        return has_changed, result
    else:
        raise FlexeraModuleError("Could not install _flexera : {}".format(result))

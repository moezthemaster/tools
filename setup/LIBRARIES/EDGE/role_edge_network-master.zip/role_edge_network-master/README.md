EDGE Network config (DNS+NTP)
=============================

This role update /etc/hosts,  /etc/resolv.conf and ntp after vm instantiation in GTS Cloud.

Requirements
------------
  - role_create_gts_vm: https://sgithub.fr.world.socgen/GTS-RET-INF/role_create_gts_vm.git

Role Input Variables
--------------------

**NETWORK_ID**
`required: True`

      Network Identifier of the VM.
      choices:
        - CDN
        - CITS
        - CDN_HOB
        - CDN_HOT
        - L1_BACKEND
        - L1_COMMON
        - L1_SPECIFIC
        - L1_TECHNICAL
        - LEGACY_CDN
        - SHARED_SERVICES

**NETWORK_ENVIRONNEMENT**
`required: False`

     vm environment
     choices:
         - 'dev'
         - 'hml'
         - 'prd'

**NETWORK_HOST**
`required: True`

     vm name as requested by RET integration Rules and Standards


Role Output Variables
---------------------

none

Dependencies
------------

vm must be instantiated in GTS Cloud


Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:
```yaml
    - hosts: servers
      roles:
        - { role: role_edge_network, NETWORK_ID: "CDN", NETWORK_ENVIRONNEMENT: "DEVELOPPEMENT", NETWORK_HOST: "deallx405" }
```
or


```yaml
    ---
    - hosts: localhost
      connection: local
      vars:
         NETWORK_ID: "CDN"
         NETWORK_ENVIRONNEMENT: "DEVELOPPEMENT"
         NETWORK_HOST: "deallx405"
      roles:
         - { role: role_edge_network }
```
Author Information
------------------

hamouda.layouni@socgen.com
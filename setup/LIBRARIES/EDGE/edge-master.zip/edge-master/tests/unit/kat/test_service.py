import pytest

from tests.mock.kat import MockedKat
from edge.kat.service import KatService
from edge.exception import EdgeException


DUMMY_IRT_CODE = 'dummy' #not considered in the mock of Kat


class MockedKatService(KatService, MockedKat):
    pass

default_clients = ('', 'default_cli')


@pytest.fixture(params=default_clients)
def default_client(request):
    return request.param


class TestKatService(object):
    def test_client_found_is_itim(self, default_client):
        ks = MockedKatService()
        client = ks.get_client('CLD', DUMMY_IRT_CODE, default_client)
        assert client == 'ITIM'

    def test_client_found_is_bsc(self, default_client):
        ks = MockedKatService()
        client = ks.get_client('SFA', DUMMY_IRT_CODE, default_client)
        assert client == 'BSC'

    def test_client_found_is_gts(self, default_client):
        ks = MockedKatService()
        client = ks.get_client('PGA', DUMMY_IRT_CODE, default_client)
        assert client == 'GTS'

    def test_client_found_is_pta(self, default_client):
        ks = MockedKatService()
        client = ks.get_client('PTA', DUMMY_IRT_CODE, default_client)
        assert client == 'SGCIB'

    def test_client_not_found(self, default_client):
        ks = MockedKatService()
        with pytest.raises(EdgeException):
            client = ks.get_client('NOT_IN_KAT', DUMMY_IRT_CODE, default_client)

    def test_client_found_but_not_translated_with_default(self):
        ks = MockedKatService()
        client = ks.get_client('FOO', DUMMY_IRT_CODE, 'default_cli')
        assert client == 'default_cli'

    def test_client_found_but_not_translated_without_default(self):
        ks = MockedKatService()
        with pytest.raises(EdgeException):
            client = ks.get_client('FOO', DUMMY_IRT_CODE)


Ccs_cd_celery
====

install_platform_exec_playbook.sh
-------------

install_plaform_exec_playbook.sh aims to install and configure dependencies to use py_ccs_celery's workers to create/delete vm EDGE.

Tested on RHEL_7.3_x64-RET-EDGE
```
[automation@pedglx001 ~] git clone https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/ccs_cd_celery.git
Cloning into 'ccs_cd_celery'...
[automation@pedglx001 ~] cd ccs_cd_celery

Use case:

[automation@pedglx001 ccs_cd_celery]$ ./install_platform_exec_playbook.sh prd ccs 10G 20G master sdc celery_sandbox
- $1: env_run = vm environment [ dev, hml, prd ]
- $2: trigram = edg, ccs, trv ...
- $3: fs_size_home = 10G, 20G ...
- $4: fs_size_logs = 20G, 30G ...
- $5: playbook_version = [ tag, master, latest ]
- $6: disk_appli = sdb, sdc ...
- $7: platform = [ celery_sandbox, celery, ansible ]

NB:
When you meet this error "fatal: unable to access 'https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/ccs_cd_celery.git/': Peer's Certificate issuer is not recognized."
You can fix it with this command below :

git config --global http.sslVerify "false"

```

Licence
------------
BSD

Author
------------
EDGE TEAM



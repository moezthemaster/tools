import static sgcib.coc.bootcamp.Utils.*

properties = readProperties(this, 'jenkins/job.properties')
String slave = properties.slave

String xldCliPath = properties.slaveTools + properties.xldCliPath
String xldServer = properties.xldServer
String xldPort = properties.xldPort
String xldCreds = properties.xldCreds
String xldRoot = properties.xldRoot

node(slave) {
    stage('Download promotion script') {
        sh 'curl -Ok https://sgithub.fr.world.socgen/raw/deployment-factory/jython-common-tools/master/teams/promote-package.py'
    }

    stage('Promote package') {
        withCredentials([usernamePassword(credentialsId: xldCreds, passwordVariable: 'XLD_PASSWORD', usernameVariable: 'XLD_USER')]) {
            sh "${xldCliPath}/bin/cli.sh -host ${xldServer} -port ${xldPort} -username ${XLD_USER} -password ${XLD_PASSWORD} -secure -q -f ${WORKSPACE}/promote-package.py -- --src='Environments/${xldRoot}/${SOURCE}/${SOURCE}.env' --dst='Environments/${xldRoot}/${DESTINATION}/${DESTINATION}.env' --app='${APPLI}'"
        }
    }
}

"""A setuptools based setup module.

See:
https://packaging.python.org/en/latest/distributing.html
https://github.com/pypa/sampleproject
"""
import sys

# To use a consistent encoding
from codecs import open
from os import path

# Always prefer setuptools over distutils
from setuptools import setup, find_packages
from setuptools.command.test import test

here = path.abspath(path.dirname(__file__))

# Get the long description from the README file
with open(path.join(here, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

class PyTest(test):
    user_options = [('pytest-args=', 'a', "Arguments to pass to pytest")]

    def initialize_options(self):
        test.initialize_options(self)
        self.pytest_args = ''

    def run_tests(self):
        import shlex
        # import here, cause outside the eggs aren't loaded
        import pytest
        errno = pytest.main(shlex.split(self.pytest_args))
        sys.exit(errno)

setup(
    name='edge_ansible_modules',
    version='2.2.0',
    description="ansible modules used by A4C and Ansible Tower",
    author="GTS-RET-AUTOMATION-EDGE",
    author_email='list.fr-ret-edge-automation@socgen.com',
    license='MIT',
    url='https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/py-edge_ansible_modules',
    keywords='edge_ansible_modules',
    packages=find_packages(exclude=['tests', 'jenkins']),
    #package_dir={'': 'src'},
    package_data={'': ['README.md']},
    include_package_data=True,
    long_description=long_description,
    cmdclass={'test': PyTest},
    tests_require=['pytest'],
    install_requires=[],
    zip_safe=False,
    classifiers=['Development Status :: 3 - Alpha',
                 'Intended Audience :: Developers',
                 'Topic :: Software Development :: Build Tools',
                 'License :: OSI Approved :: MIT License',
                 'Programming Language :: Python :: 3',
                 'Programming Language :: Python :: 3.6', ],
)

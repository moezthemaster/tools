#!/bin/bash


#Creation de la configuration de Patrol pour Apache
#envoi des info en paramètre
#creation du fichier de config
#envoi de la configuration a l'agent Patrol
#restart de l'agent Patrol
###
###
#   Process : 
#   LABEL - COMMAND - MIN - MAX - OWNER
#
#   ISM : 
#   HOSTNAME
#   ADDRESSEWEB (HOSTNAME avec des _ a la place des .)
#   PORTWEB (port)
#   LABELURL (LABEL avec - a la place des _)
#   PROTOCOLE (HTTP / HTTPS)
#   ADRESSEIP
#   WEBURL  url
#   EXPRESSION par defaut 200 OK -> recherche dans la page
#
####################
cd /produits/patrol/PATROL_AGT
. ./patrolrc.sh

PATROL_DIR=/produits/patrol/PATROL_AGT/config

LOG=${PATROL_DIR}/config_apache.log
ism_file_default=${PATROL_DIR}/config_standard_ism
process_file_default=${PATROL_DIR}/config_standard_process
expression="200 OK"
make_process () {


echo "Modification du fichier de configuration Process" >>$LOG

sed -i -e "s#LABEL#$label#g" $process_file
sed -i -e "s#COMMAND#$cmd#g" $process_file
sed -i -e "s#MIN#$min#g" $process_file
sed -i -e "s#MAX#$max#g" $process_file
sed -i -e "s#OWNER#$owner#g" $process_file

}

make_ism () {


echo "Modification du fichier de configuration ISM" >>$LOG

sed -i -e "s#LABELURL#$labelurl#g" $ism_file
sed -i -e "s#LABEL#$label#g" $ism_file
sed -i -e "s#ADDRESSEWEB#$adresseweb#g" $ism_file
sed -i -e "s#PORTWEB#$port#g" $ism_file
sed -i -e "s#PROTOCOLE#$protocole#g" $ism_file
sed -i -e "s#WEBURL#$url#g" $ism_file
sed -i -e "s#HOSTNAME#$hostname#g" $ism_file
sed -i -e "s#EXPRESSION#$expression#g" $ism_file
sed -i -e "s#ADRESSEIP#$adresseip#g" $ism_file


}

add_process () {

	echo "Apply Process configuration" >> $LOG
	pconfig +tcp -p 14451 $process_file

}

add_ism () {

	echo "Apply ISM configuration" >> $LOG 
	pconfig +tcp -p 14451 $ism_file >> $LOG

}

restart_agt () {

	echo "Patrol Agent restarting" >> $LOG 
	pconfig +tcp -p 14451 +RESTART
}

rm_process () {

  echo "Modification du fichier de configuration Process" >>$LOG

  sed -i -e "s/REPLACE.*}/DELETE }/g" $process_file

}

rm_ism () {

    echo "Modification du fichier de configuration ISM" >>$LOG

	sed -i -e "s/REPLACE.*}/DELETE }/g" $ism_file
	sed -i -e "s/MERGE/DELETE/g" $ism_file


}

USAGE ()
{
  echo
  echo "Usage: $progname <action> <args>*"
  echo "        action: Add ou Remove"
  echo "        args: "
  echo
  exit 1
}

echo `date` >>$LOG
echo "Launching script.." >>$LOG



while test -n "$1"; do
    case "$1" in
        --usage|-u)
            USAGE
            exit 0
            ;;
        -HN)
            hostname=$2
            adresseweb=$(echo $hostname | sed 's/\./_/g')
            echo "$hostname & $adresseweb" >>$LOG
            shift
            ;;
        -IP)
            adresseip=$2
            echo $adresseip >>$LOG
            shift
            ;;
        -P)
            port=$2
            echo $port >>$LOG
            shift
            ;;
        -URL)
            url=$(echo $2 | sed 's/\//\\\//g') 
            echo $url >>$LOG
            shift
            ;;
        -PTL)
            protocole=`echo ${2^^}`
            echo $protocole >>$LOG
            shift
            ;;
        -EXP)
            if [ "$2" != "" ]
            then
            	expression=$2
            fi
            echo $expression >>$LOG
            shift
            ;;        
        -LBL)
            label=$(echo $2 | sed 's/ //g')
            labelurl=$(echo $label | sed 's/-/_/g')
            echo "$label : $labelurl" >>$LOG 
            shift
            ;;
        -CMD)
            cmd=$2
            echo $cmd >>$LOG
            shift
            ;;
        -MIN)
            min=$2
            echo "MIN: $min" >>$LOG
            shift
            ;;
  		-MAX)
			if [ $2 -lt 15 ] 
			then
				max=15
			else
            	max=$2
            fi
            echo "MAX : $max" >>$LOG
            shift
            ;;
        -OWN)
            owner=$2
            echo "Owner : $owner" >>$LOG
            shift
            ;;
        -SEV)
			severity=`echo ${2^^}`
			echo $severity >>$LOG
			shift
			;;
        -ACT)
            action_config=$2
            echo "Action : $action_config" >>$LOG 
            shift
            ;;
        *)
            echo "Argument inconnu: $1"
            print_usage
            exit 3
            ;;
    esac
    shift
done

if [ "$label" == "" ]
then
    USAGE
fi

case ${severity} in 
	CRITICAL|WARNING) 	
		process_file_standard="${process_file_default}_${severity}.save"
        process_file="${process_file_default}_${label}"
        ism_file="${ism_file_default}_${label}"
		echo $process_file >>$LOG
		;;
	*)	 
	 	if [ ${action_config} == "Add" ]
	 	then	
	 		USAGE
	 	fi
        ;;
esac

case ${action_config} in 
	Add)
		#Initialisation des fichiers de conf
		rm -f ${process_file} ${ism_file} 
	    cp ${process_file_standard} ${process_file}
		cp ${ism_file_default}.save ${ism_file} 	

		make_process
		make_ism
		add_process
		add_ism
		restart_agt
		;;
	Remove) 
        process_file="${process_file_default}_${label}"
        ism_file="${ism_file_default}_${label}"
		rm_process
		rm_ism
		add_process
		add_ism
		restart_agt
		;;
	*)	 
		USAGE
        ;;
esac


[![CC0](https://upload.wikimedia.org/wikipedia/fr/b/b7/Squid-cache_logo.jpg)] (http://www.squid-cache.org/)

# Squid
This role installs and configures Squid.


## Requirements
------------

This role requires Ansible 1.9 or higher.

Facts gathering shouldn't be disabled.

Target servers must be RHEL7 or CentOS7.


## Role Variables
--------------

### state
<code>`required: True`</code> <code>`default: "present"`</code>

    Action requested.

List of possible values :

|   State   | Description            |
|:---------:|:---------------------- |
|  present  | Install Squid on a VM  |
|  absent   | Remove Squid from a VM |


### squid_version
<code>`required: False`</code> <code>`default: ""`</code>

    Version requested to install.

Examples of selectable versions :

| Versions           | OS       | Repository            |
|:------------------:|:--------:|:--------------------- |
| 3.3.8-26.el7       | RHEL7    | rhel-7-server-current |
| 3.5.20-10.el7      | RHEL7    | rhel-7-server-rpms    |
| 3.5.20-2.el7_3.3   | CentOS7  | weekly                |


### squid_repository
<code>`required: False`</code> <code>`default: ""`</code>

    Specified repository will be enabled during install.

Description of what will be done with these two parameters above :

| squid_version   | squid_repository  | yum install description                                                      |
|:---------------:|:-----------------:|:---------------------------------------------------------------------------- |
| empty           | empty             | latest version will be installed                                             |
| defined         | empty             | version requested will be installed from enabled repositories                |
| empty           | defined           | latest version will be installed and specified repository will be enabled    |
| defined         | defined           | version requested will be installed and specified repository will be enabled |


### Managing Proxy:

| Name                                | Default                                                     | Description                                                                                            |
|:------------------------------------|:------------------------------------------------------------|:-------------------------------------------------------------------------------------------------------|
| squid_access_log                    | "daemon:/var/log/{{ squid_service_name }}/access.log squid" | Configures whether and how Squid logs HTTP and ICP transactions                                        |
| squid_acls                          | {}                                                          | List of ACL hashes (keys: name, type, argument)                                                        |
| squid_always_directs                | {}                                                          | List of always_direct options (keys: type, acl_name)                                                   |
| squid_cache_peers                   | {}                                                          | List of cache peers (keys: hostname, type, http_port, icp_port, options<list>)                         |
| squid_dns_v4_first                  | "off"                                                       | This option reverses the order of preference to make Squid contact dual-stack websites over IPv4 first |
| squid_forwarded_for                 | "on"                                                        | Set X-Forwarded-For header in HTTP requests                                                            |
| squid_http_access_allow_clients     | ["localhost"]                                               | List of clients to allow access                                                                        |
| squid_http_port                     | 3128                                                        | The port where Squid will listen for HTTP requests                                                     |
| squid_httpd_suppress_version_string | "off"                                                       | Suppress Squid version string info in HTTP headers and HTML error pages                                |
| squid_netdb_filename                | "stdio:stdio:/var/log/{{ squid_service_name }}/netdb.state" | Where Squid stores it's netdb journal                                                                  |
| squid_never_directs                 | {}                                                          | List of never_direct options (keys: type, acl_name)                                                    |
| squid_pinger_enable                 | "on"                                                        | Control whether the pinger is active at run-time                                                       |
| squid_proxy_only                    | false                                                       | If enabled, disables caching                                                                           |
| squid_tcp_outgoing_address          | ''                                                          | Map requests to different outgoing IP address                                                          |
| squid_via                           | "on"                                                        | If set (default), Squid will include a Via header in requests and replies are required by RFC2616      |
| squid_visible_hostname              | ''                                                          | If you want to present a special hostname in error messages, etc, define this                          |
| squid_append_domain                 | ''                                                          | Add domain prefix                                                                                      |


### Managing Log rotation:

| Name                                | Default                                                     | Description                                                                                                                                                 |
|:------------------------------------|:------------------------------------------------------------|:------------------------------------------------------------------------------------------------------------------------------------------------------------|
| squid_log_rotate                    | 'no'                                                        | If enabled, rotate logs                                                                                                                                     |
| squid_logfile_rotate                | '10'                                                        | Specifies the default number of logfile rotations to make when you type 'squid -k rotate'. The default is 10, which will rotate with extensions 0 through 9 |
| squid_log_rotation_time             | 'weekly'                                                    | Special time specification nickname. it takes: reboot, yearly, annually, monthly, weekly, daily, hourly                                                     |
| squid_log_name                      | 'squid rotate log'                                          | Description of a crontab entry or, if env is set, the name of environment variable. Required if state=absent                                                |


### Managing cache RAM

| Name                                | Default                                                     | Description                                                                                                      |
|:------------------------------------|:------------------------------------------------------------|:-----------------------------------------------------------------------------------------------------------------|
| squid_fqdncache_size                | '1024'                                                      | Maximum number of FQDN cache entries                                                                             |
| squid_cache_mem                     | '256 MB'                                                    | Specifies the ideal amount of memory to be used for: In-Transit objects, Hot Objects and Negative-Cached objects |
| squid_maximum_object_size_in_memory | '512 KB'                                                    | Objects greater than this size will not be attempted to kept in the memory cache                                 |
| squid_memory_cache_mode             | 'always'                                                    | Controls which objects to keep in the memory cache (cache_mem). It takes: always, disk, and network values       |
| squid_memory_replacement_policy     | 'lru'                                                       | Determines which objects are purged from memory when memory space is needed                                      |


### Managing cache disk

| Name                                | Default                                                     | Description                                                                                                                                        |
|:------------------------------------|:------------------------------------------------------------|:---------------------------------------------------------------------------------------------------------------------------------------------------|
| squid_cache_dir                     | 'no'                                                        | You can specify multiple cache_dir lines to spread the cache among different disk partitions (keys: type, path, size, L1, L2)                      |
| squid_store_dir_select_algorithm    | 'least-load'                                                | Define how Squid selects which cache_dir to use when the response object will fit into more than one. it takes least-load or round-robin algorithm |
| squid_refresh_pattern               | 'none'                                                      | Log rotation time                                                                                                                                  |
| squid_cache_swap_low                | '90'                                                        | The low-water mark for AUFS/UFS/diskd cache object eviction by the cache_replacement_policy algorithm                                              |
| squid_cache_swap_high               | '95'                                                        | The high-water mark for AUFS/UFS/diskd cache object eviction by the cache_replacement_policy algorithm                                             |


### Managing DNS

| Name                                | Default                                                     | Description                                                                                                                           |
|:------------------------------------|:------------------------------------------------------------|:------------------------------------------------------------------------------------------------------------------------------------- |
| squid_dns_nameservers               | ''                                                          | Use this if you want to specify a list of DNS name servers (IP addresses) to use instead of those given in your /etc/resolv.conf file |
| squid_positive_dns_ttl              | '6 hours'                                                   | Upper limit on how long Squid will cache positive DNS responses                                                                       |
| squid_negative_dns_ttl              | '1 minutes'                                                 | Time-to-Live (TTL) for negative caching of failed DNS lookups                                                                         |


### Managing basic_authentification

| Name                                 | Default                                                     | Description                                                                                                                                                       |
|:-------------------------------------|:------------------------------------------------------------|:------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| squid_basic_authentification         | 'no'                                                        | If enabled, manage basic authentification                                                                                                                         |
| squid_users_file                     | '/etc/squid/squid_users'                                    | User:password list file                                                                                                                                           |
| squid_auth_param_basic_children      | 'none'                                                      | The maximum number of authenticator processes to spawn                                                                                                            |
| squid_auth_param_basic_realm         | 'Squid proxy-caching web server'                            | Specifies the protection scope (aka realm name) which is to be reported to the client for the authentication scheme                                               |
| squid_auth_param_basic_credentialsttl| ''                                                          | Specifies how long squid assumes an externally validated username:password pair is valid for - in other words how often the helper program is called for that user|


## Dependencies
------------

None

## Example Playbook
----------------

Install Squid
```yaml
- hosts: all
  gather_facts: yes
  roles:
    - { role: role_squid, squid_version: "3.3.8-26.el7"}
```

Remove Squid
```yaml
- hosts: all
  roles:
    - { role: role_squid, state: "absent"}
```

License
-------

[![CC0](https://upload.wikimedia.org/wikipedia/commons/thumb/9/93/GPLv3_Logo.svg/langfr-220px-GPLv3_Logo.svg.png)] (https://fr.wikipedia.org/wiki/Licence_publique_g%C3%A9n%C3%A9rale_GNU)

Author Information
------------------

EDGE RET Automation Feature Team

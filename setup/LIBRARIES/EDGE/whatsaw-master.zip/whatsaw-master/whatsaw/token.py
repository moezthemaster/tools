#!/usr/bin/python
# -*- coding: utf-8 -*-


import time
import shlex
import logging
from whatsaw.conf import settings
from subprocess import Popen, PIPE
from whatsaw.exception import WhatsError
from whatsaw.credential import get_user_passwd
from whatsaw.switch import whats_env

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


def get_exitcode_stdout_stderr(cmd, password=None):
    """
    Execute the external command and get its exitcode, stdout and stderr.
    """
    args = shlex.split(cmd)
    if args[0] == 'kinit':
        proc = Popen(args, stdin=PIPE, stderr=PIPE, universal_newlines=True)
        proc.stdin.write(password)
    elif args[0] == 'kdestroy':
        proc = Popen(args, stdout=PIPE, stderr=PIPE)

    out, err = proc.communicate()
    exitcode = proc.returncode
    return exitcode, out, err


class Token(object):
    def __init__(self, environment):
        self.environment = environment
        self._token = self._generate_kerberos_ticket(self.environment)

    def get(self):
        return self._token

    @property
    def token(self):
        return self._token

    @token.setter
    def token(self, val):
        self._token = val

    def delete(self):
        return self._destroy_kerberos_ticket()

    def _generate_kerberos_ticket(self, environment, max_retries=settings.MAX_RETRIES):
        """
        :param environment:
        :return: valid Token to call IDM API
        """
        idm_user, idm_passwd = get_user_passwd(environment)

        idm_realm = getattr(settings, 'REALM_{}'.format(environment))
        try:
            cmd = "kinit {}@{}".format(idm_user, idm_realm)
            exitcode, out, err = get_exitcode_stdout_stderr(cmd, idm_passwd)
            if exitcode != 0:
                raise Exception(err)
        except Exception as err:
            logging.debug("generate_kerberos_ticket :: Retrying number : {}".format(5 - max_retries))
            if exitcode != 0 and max_retries > 0:
                time.sleep(settings.GENERATE_TOKEN_WAIT_TIME)
                return self._generate_kerberos_ticket(environment, max_retries=max_retries - 1)
            if exitcode != 0 and max_retries == 0:
                raise WhatsError(
                    "Maximum attemps for _generate_kerberos_ticket : {}; exitcode : {}; msg error : {} ".format(
                        settings.MAX_RETRIES, exitcode, err
                    )
                )

    def _destroy_kerberos_ticket(self):
        """
        :return: destroys toeken
        """
        try:
            exitcode, out, err = get_exitcode_stdout_stderr('kdestroy -A')
            if exitcode != 0:
                raise Exception(err)
        except Exception as err:
            raise WhatsError(err.args[0])

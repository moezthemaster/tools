#!/usr/bin/python
# -*- coding: utf-8 -*-
#

''' Module to recreate network mapping csv from python file.'''

from __future__ import print_function
from sets import Set
import json
import os,sys,inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0,parentdir) 
from network_mapping import MAPPING

EXTRA_ROWS = [ 'network_cidr', 'dns_zone', 'dns_cname', 'network_tag' ] 

def output_networks():
    extra_rows = Set([])

    for val_env in MAPPING.values():
        for region_val  in val_env.values():
            for az_val in region_val.values():
                for network_val in az_val.values():
                    extra_rows.update(network_val.keys())

    print("{};{};{};{}".format('env', 'region', 'az', 'network name'), end='')
    for r in sorted(extra_rows):
        print(";{}".format(r), end='')
    print('')
    for env, val_env in sorted(MAPPING.iteritems()):
        for region, region_val  in sorted(val_env.iteritems()):
            for az, az_val in sorted(region_val.iteritems()):
                for network, network_val in sorted(az_val.iteritems()):
                    print("{};{};{};{}".format(env, region, az, network), end='')
                    for r in sorted(extra_rows):
                        if r == 'bp_names':
                            print(";{}".format(json.dumps(network_val.get(r, ''))), end='')
                        else:
                            print(";{}".format(network_val.get(r, '')), end='')
                    print('')

if __name__ == '__main__':
    """ This is executed when run from the command line """

    output_networks()

#!/usr/bin/env python
# -*- coding: utf-8 -*-

import testinfra
import re
from behave import *
from time import sleep


def cool_print1():
    print("\n")
    print("###########################################################################################")
    print("#                           TEST PATROL RESTART AFTER VM REBOOT                           #")
    print("#                        Rebooting machine. Waiting for 30 seconds                        #")
    print("###########################################################################################")
    print("\n")


def cool_print2():
    print("\n")
    print("###########################################################################################")
    print("#                      TEST PATROL RESTART AFTER KILLING HIS PROCESS                      #")
    print("#                        Rebooting machine. Waiting for 30 seconds                        #")
    print("###########################################################################################")
    print("\n")


@then('patrol process restart automatically')
def step_impl(context):

    if context.params['vm_supervision'] == 'none':
        print("Skipping Patrol check as no supervision has been set\n")
        return

    reboot_command = 'sudo reboot'
    get_patrol_pid_command = 'systemctl status patrol'
    server = testinfra.get_host('ssh://automation@' + context.params['vm_ipaddr'])

    def get_patrol_pid():
        ch = "Main PID"
        patrol_status = server.run(get_patrol_pid_command).stdout.splitlines()
        for i in patrol_status:
            if re.search(ch, i) is not None:
                patrol_pid = i.split()[2]
                # print("Patrol PID is: {}".format(patrol_pid))
                return patrol_pid
            else:
                pass

    cool_print1()
    server.run(reboot_command)
    sleep(10)
    pid_before_kill = get_patrol_pid()

    count = 0

    while pid_before_kill is None and count < 6:
        try:
            sleep(10)
            pid_before_kill = get_patrol_pid()
            count += 1
        except Exception:
            raise Exception("Somethong goes wrong!")

    if pid_before_kill is None:
        print("Patrol automatic restart failed. PID is {}".format(pid_before_kill))
    else:
        print("Patrol restarted automatically after VM reboot and his PID is: {}".format(pid_before_kill))
    cool_print2()

    server.run("sudo kill -9 {}".format(pid_before_kill))
    sleep(30)

    pid_after_kill = get_patrol_pid()
    print("Patrol PID after kill: {}".format(pid_after_kill))

    if pid_before_kill != pid_after_kill and None not in [pid_before_kill, pid_after_kill]:
        assert context.failed is False
    else:
        assert context.failed is True

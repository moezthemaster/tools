import os
import sys
import logging
import io
import datetime

if "TREE_DIR" in os.environ.keys():
    ANSIBLE_MODULES_PATH = [
        os.path.join(os.environ["TREE_DIR"], 'roles/edge'),
        os.path.join(os.environ["TREE_DIR"], 'roles/whatsaw'),
        os.path.join(os.environ["TREE_DIR"], 'roles/py_edge_vault'),
        os.path.join(os.environ["TREE_DIR"], "library"),
    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/edge',
        './roles/whatsaw',
        './roles/py_edge_vault'
    ]
for path in ANSIBLE_MODULES_PATH:
    sys.path.append(path)

from ansible.module_utils.basic import AnsibleModule

from edge.kpi.elk import Loader
from whatsaw.conf import settings
from edge.whats.idm import Idm
from whatsaw.idm import IdmWrapper

formatter = logging.Formatter(fmt='%(asctime)s %(levelname)-8s %(message)s',
                              datefmt='%Y-%m-%d %H:%M:%S')
logstream = io.StringIO()
handler = logging.StreamHandler(logstream)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.addHandler(handler)
logger.setLevel(logging.WARNING)

class IdmImpl(Idm):
    def __init__(self, hostname):
        Idm.__init__(self)
        self.idm_wrapper = IdmWrapper(hostname)

    def get_realm(self):
        return self.idm_wrapper.get_realm()

    def get_domain(self):
        return self.idm_wrapper.get_domain()

    def destroy_token(self):
        return self.idm_wrapper.destroy_token()

    def enroller(self, hostname, ip_address, trigram):
        return self.idm_wrapper.enroller(hostname, ip_address, trigram)
        
    def unroller(self, hostname):
        return self.idm_wrapper.unroller(hostname)

    def ip_checker(self, hostname, ip_address):
        return self.idm_wrapper.ip_checker(hostname, ip_address)

    def host_checker(self, hostname):
        return self.idm_wrapper.host_checker(hostname)

PRESENT, ABSENT, STATUS, CHECK_HOSTNAME = 'present', 'absent', 'status', 'check_hostname'

FIELDS = {
    "whats_hostname": {"required": True, "type": "str"},
    "whats_ip": {"required": False, "type": "str"},
    "whats_trigram": {"required": False, "type": "str"},
    "state": {
        "default": "present",
        "choices": ['present', 'absent', 'status', 'check_hostname'],
        "type": 'str'
    },
    "kpi_data": {
        "type": "dict"
    },
}


def index_error_kpi(kpi_data,kpi_start_time):
    try:
        kpi_end_time = datetime.datetime.now()
        kpi_data['duration'] = (kpi_end_time - kpi_start_time).seconds
        loader = Loader()
        loader.index_data(
            id_execution=kpi_data['id_execution'], timestamp=kpi_data['timestamp'], 
            duration=kpi_data['duration'], service=kpi_data['service'],
            hostname=kpi_data['vm_hostname'], status="failure",
            category=kpi_data['category'], client=kpi_data['endClient'],
            trigram=kpi_data['app_id'], environment=kpi_data['app_env'],
            error=kpi_data['error'], playbook_version=kpi_data['playbook_version']
        )
    except Exception:
        pass


def main():
    module = AnsibleModule(argument_spec=FIELDS)
    if module._verbosity == 1:
        logger.setLevel(logging.INFO)
    if module._verbosity == 3:
        logger.setLevel(logging.DEBUG)
    logger.info('module sg_gts_whats')
    kpi_data = module.params['kpi_data']

    kpi_start_time = datetime.datetime.now()

    try:
        state = module.params['state']
        if isinstance(kpi_data, dict):
            kpi_data['service'] = 'sg_gts_whats_{}'.format(state)
        idm = IdmImpl(module.params['whats_hostname'])
        if state == PRESENT:
            response = idm.create_whats(
                whats_hostname=module.params['whats_hostname'],
                whats_ip=module.params['whats_ip'],
                whats_trigram=module.params['whats_trigram'],
            )
            if response['error'] is None or response["error"]["code"] == 4002:
                module.exit_json(changed=idm.has_changed, meta=response, debug_out=logstream.getvalue())
            else:
                if isinstance(kpi_data, dict):
                    kpi_data['error'] = response["error"]["message"]
                    index_error_kpi(kpi_data,kpi_start_time)
                module.fail_json(changed=idm.has_changed, msg=response, debug_out=logstream.getvalue())

        elif state == ABSENT:
            response = idm.delete_whats(module.params['whats_hostname'])
            if response['error'] is None or response["error"]["code"] == 4001:
                module.exit_json(changed=idm.has_changed, meta=response, debug_out=logstream.getvalue())
            else:
                if isinstance(kpi_data, dict):
                    kpi_data['error'] = response["error"]["message"]
                    index_error_kpi(kpi_data,kpi_start_time)
                module.fail_json(changed=idm.has_changed, msg=response, debug_out=logstream.getvalue())

        elif state == STATUS:
            response = idm.check_whats(whats_ip=module.params['whats_ip'],
                                       whats_hostname=module.params['whats_hostname'])
            if response["status"] == 200:
                module.exit_json(changed=idm.has_changed, meta=response, debug_out=logstream.getvalue())
            else:
                if isinstance(kpi_data, dict):
                    kpi_data['error'] = response["msg"]
                    index_error_kpi(kpi_data,kpi_start_time)
                module.fail_json(changed=idm.has_changed, msg=response, debug_out=logstream.getvalue())

        elif state == CHECK_HOSTNAME:
            response = idm.check_hostname(whats_hostname=module.params['whats_hostname'])
            if response["status"] == 200:
                module.exit_json(changed=idm.has_changed, meta=response, debug_out=logstream.getvalue())
            else:
                if isinstance(kpi_data, dict):
                    kpi_data['error'] = response["msg"]
                    index_error_kpi(kpi_data,kpi_start_time)
                module.fail_json(changed=idm.has_changed, msg=response, debug_out=logstream.getvalue())
    except Exception as e:
        if isinstance(kpi_data, dict):
            kpi_data['error'] = e.args[0]
            index_error_kpi(kpi_data,kpi_start_time)
        module.fail_json(msg=e.args[0], debug_out=logstream.getvalue())
    finally:
        try:
            idm.destroy_token()
        except NameError:
            pass

if __name__ == '__main__':
    main()

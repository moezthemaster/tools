#!groovy
import static sgcib.coc.bootcamp.Git.*
import static sgcib.coc.bootcamp.Maven.*
import static sgcib.coc.bootcamp.Utils.*

properties = readProperties(this, 'jenkins/job.properties')
String slave = properties.slave

node(slave){

    try{
        stage('init env'){
            checkout([$class: 'GitSCM',
            branches: [[name: 'master']],
            doGenerateSubmoduleConfigurations: false,
            extensions: [[$class: 'CleanCheckout']],
            submoduleCfg: [],
            userRemoteConfigs: [[credentialsId: 'genericCreds', url: 'https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/ccs_cd_celery.git']]
            ])
            sh ''' su - automation -c "cd ${WORKSPACE} && ./install_platform_exec_playbook.sh prd ccs 10G 20G master sdc celery_sandbox" '''
        }

        stage('create test and delete vm'){
            sh '''su - ccspadm -c ". virtualenv/py-ccs-celery/bin/activate && cd /applis/ccsp/py-ccs-celery/tests/integration/behave/features && behave create_delete_ccs_vm.feature --no-capture --no-logcapture" '''
        }

    } catch(err){
        error "Build failed"

    } finally {
        stage('cleaning home directory'){
            sh '''#su - ccspadm -c "rm -rf *" '''
        }
    }
}

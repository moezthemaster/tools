#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
from time import sleep
import testinfra 

@then('patrol is installed')
def step_impl(context):

    if context.params['vm_supervision'] == 'none':
        print("Skipping Patrol check as no supervision has been set\n")
        return

    print("Test FS /produits/patrol is mounted and user patrol is created and Patrol Agent is well installed\n")

    
    server=testinfra.get_host('ssh://automation@'+context.params['vm_ipaddr'])


    # Test if /produits/patrol  is mounted
    test=server.mount_point( '/produits/patrol' ).exists

    if test:
      assert context.failed is False
    else:
      assert context.failed is True

    # Test if user patrol is created
    user=server.user('patrol').exists

    if user:
      assert context.failed is False
    else:
      assert context.failed is True


    # Test if patrol agent is well configured
    commande="sudo su - patrol -c 'pconfig +get +tcp -p 14451| grep '/NTP_MAIN/source_commande' |wc -l'"
    config=server.run(commande) 
    count = 0
    
    while int(config.stdout[:-1]) != 1 and count < 30:
      count = count + 1
      sleep(5)
      config=server.run(commande)
    
    if int(config.stdout[:-1]) == 1:
      assert context.failed is False
    else:
      assert context.failed is True

    # Test if patrol is registred on the Infra Server
    commande="sudo su - patrol -c 'grep -c 'Connection established with Integration Service' /produits/patrol/PATROL_AGT/log/PatrolAgent-"+context.params['vm_hostname']+"*-14451.errs'"

    reg=server.run(commande) 
    count = 0
    while reg.stdout.strip().split()[-1] == 0 and count < 30:
      #print("Commande = {}, res = {}".format(commande, reg.stdout)) 
      #print("strip : {}",format(reg.stdout.strip()))
      #print("rstrip:{}",format(reg.stdout.rstrip('\n')))
      count = count + 1
      sleep(5)
      reg=server.run(commande)
     

    if count != 30:
      assert context.failed is False
    else:
        assert context.failed is True

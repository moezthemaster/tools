import re
import socket
import paramiko
from io import StringIO
from edge.conf import settings
from py_edge_vault import secrets
from edge.exception import EdgeException


class VmSessionSsh(object):
    def __init__(self, ip_address):
        self.ip_address = ip_address
        vault_secret = secrets.get_secrets(context=settings.PUBKEY_CREDENTIALS_GROUP)
        self.user = vault_secret['user']
        self.key = vault_secret['private_root_key']

    def _check_command(self, cmd_type, command):

        whitelist = secrets.get_secrets(context='whitelist')

        for item in whitelist[cmd_type]:
            regex = r'{}'.format(item)
            try:
                matche = re.search(regex, command)
                if matche:
                    return True
            except Exception as e:
                raise EdgeException(e)
        return False

    def execute_cmd(self, cmd, type, timeout=5, client=None):
        check = self._check_command(cmd_type=type, command=cmd)

        if not check:
            raise EdgeException("command {} is not allowed to be executed".format(cmd))

        key = paramiko.RSAKey.from_private_key(StringIO(self.key))

        if client is None:
            client = paramiko.SSHClient()

        try:
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(hostname=self.ip_address, username=self.user, pkey=key, timeout=timeout)
            _, _stdout, _stderr = client.exec_command(cmd)
            stdout = _stdout.read()
            code_status = _stdout.channel.recv_exit_status()
            stderr = _stderr.read()
            return code_status, stdout, stderr
        except paramiko.AuthenticationException as e:
            raise EdgeException(
                "Authentification error for {user} with the private key: {msg}".format(user=self.user, msg=e.args[0]))
        except paramiko.SSHException as e:
            raise EdgeException("SSHException: {}".format(e.args[0]))
        except socket.timeout as e:
            raise EdgeException("SSH Connection error: {}".format(e.args[0]))
        except Exception as e:
            raise EdgeException("Error when executing command {}: {}".format(cmd, e.args))
        finally:
            client.close()

    def check_if_host_contains_pub_key(self, network, pub_key=None):
        cmd = 'sudo cat /home/automation/.ssh/authorized_keys'
        code_status, stdout, stderr = self.execute_cmd(cmd, 'static')
        if network == 'ret':
            if code_status == 0:
                if re.match(r"^ssh-rsa AAAA[0-9A-Za-z+\\/]+[=]{0,3}\s*.*", stdout.strip()):
                    return True
                raise EdgeException("Error while checking vm pubkey...")
            raise EdgeException("Contact Team Edge, Check pub_key fails: {}...".format(stderr))
        elif network == 'mkt':
            if code_status == 0:
                try:
                    if pub_key.split()[1] in stdout:
                        return True
                except Exception as e:
                    raise EdgeException("Contact Team Edge, Check pub_key fails: {}...".format(e.args[0]))
            raise EdgeException("Contact Team Edge, Check pub_key fails: {}...".format(stderr))

    def check_user_existance(self, user):
        cmd = 'sudo sh -c "id -u {}"'.format(user)
        code_status, _stdout, stderr = self.execute_cmd(cmd, 'dynamic')
        if code_status == 0:
            return True
        raise EdgeException("Contact Team Edge, Check user {} fails: {}...".format(user, stderr))

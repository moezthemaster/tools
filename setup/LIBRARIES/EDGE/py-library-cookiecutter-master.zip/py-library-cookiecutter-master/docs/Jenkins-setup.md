# Jenkins Setup

The point of this setup is to create two Github Organization jobs, that will automatically create jobs for each branch on each repo of your orga,
provided that a Jenkinsfile is present.

### **This only need to be done once per Orga, not per repo, so if you already did it for another repo you don't have to do it again**

1. Connect to your Jenkins instance
2. If you don't have a folder for your team, create one (left side column, new item, folder)
1. In this folder :
    * Create two credentials
    ![Create credentials](resources/credentials.PNG)
    * Select the scope to have them limited to your folder (here, folder name is test) 
    ![Scope](resources/scope_folder.PNG)
    * Click on Global credentials, then Add Credentials
    *   __genericCreds__ :
        * User/password
        * :warning: ID : genericCreds
        * Used to connect to your orga, will need at least read access to private repos if you want to build them
    *   __artifactoryCreds__ :
        * User/password
        * :warning: ID : artifactoryCreds
        * Used to push to your Artifactory repo
3. In your folder, create a GitHub Organization Job (left side column, new item)
    *   __Name__ : Your Orga
    *   __API Endpoint__ : sgithub
    *   __Credentials__ : genericCreds
    *   __Owner__ : Your Orga
    *   __Max # of old items to keep__ : 5
    *   __Defaults are fine for the rest__
 4. On your GitHub orga (on sGitHub), create a hook triggered by _Push, Create, Repository and Pull Request_ events, and
point it to your Jenkins (https://itbox-jenkins-gts.fr.world.socgen/ghprbhook/). Make it x-www-form-encoded !
5. On your Sgithub repository, go to "*settings*->*Collbaorators & teams*" and add the **sgcloudops** team as admin and the account **s_fr_cldprd03** as Collaborators with write account.
      ![sgithub_authorization](resources/sgithub_authorization.PNG)

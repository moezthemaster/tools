#!/usr/bin/env python
# -*- coding: utf-8 -*-

import ansible_play
from behave import *


@then('Run playbook delete zabbix postgresql sup')
def step_impl(context):
    become_user_password = 'foo-whatever'

    run_data = {
        'vm_hostname': context.params['vm_hostname']
    }

    runner = ansible_play.Runner(
        hostnames='localhost',
        playbook="delete_zabbix_postgresql_sup.yml",
        tags="",
        private_key_file=context.private_key,
        run_data=run_data,
        become_pass=become_user_password,
        verbosity=100,
        connection='smart'
    )

    stats = runner.run()

    print("Debug")
    run_success = True
    hosts = sorted(stats.processed.keys())
    for h in hosts:
        t = stats.summarize(h)
        print("{} => {}".format(h, t))
        if t['unreachable'] > 0 or t['failures'] > 0:
            run_success = False

    assert run_success is True



import pytest

from ccs_celery.celery import app as celery_app

@pytest.fixture(scope='module')
def app(request):
    celery_app.conf.update(
        CELERY_ALWAYS_EAGER=True,
        CELERY_EAGER_PROPAGATES_EXCEPTIONS=True,
        CELERY_TASK_EAGER_PROPAGATES=True,
        CELERY_TASK_ALWAYS_EAGER=True
    )
    return celery_app

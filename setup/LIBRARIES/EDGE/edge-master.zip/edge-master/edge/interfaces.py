#!/usr/bin/python
# -*- coding: utf-8 -*-

#

DOCUMENTATION = '''
---
Abstract Interfaces are helpful for dependency injection
pythonic-way-for-dependency-injection: multiple inheritance and mixins
reference: https://stackoverflow.com/questions/31678827/what-is-a-pythonic-way-for-dependency-injection

'''


class Dod(object):
    def search_dns_record(self, record_type, **kwargs):
        '''

        :param record_type:
        :param kwargs:
        :return: a list of records, a record is a dict. example of output:
        [{
            u'domain': None,
            u'protocol': None,
            u'weight': None,
            u'zone': u'dns21-3.socgen',
            u'ip': '192.128.0.12',
            u'hostname': HOSTNAME,
            u'comments': u'',
            u'class': u'IN',
            u'port': None,
            u'alias': None,
            u'service': None,
            u'text': None,
            u'preference': None,
            u'ttl': None,
            u'hostname_fqdn': u'hostname.dns21-3.socgen.',
            u'type': u'A',
            u'id': xxxx,
            u'view': u'production'
        },
        ...
        '''
        raise NotImplementedError

    def create_dns_record(self, dns_service, record_type, zone, view, hostname, **kwargs):
        raise NotImplementedError

    def update_dns_record(self, dns_service, id, record_type, zone, view, hostname, ip, **kwargs):
        raise NotImplementedError

    def delete_dns_record(self, dns_service, id):
        raise NotImplementedError

    def search_and_delete_dns_records(self, dns_service, record_type, limit_rows=10, **kwargs):
        raise NotImplementedError

    def search_and_update_conflict_dns_records(self, dns_service, record_type, limit_rows=10, **kwargs):
        raise NotImplementedError


class DodV1(object):
    def get_next_free_ip(self, subnet, subnetUse="srv"):
        """
        Obtain next free IP in specified subnet for specified usage
        :param subnet: Subnet IP/Mask
        :param subnetUse: oneOf(net/srv/dyn)
        :return: Ip available or false
        """
        raise NotImplementedError

    def host_add(self, hostname, domain, subnet, ipRange="srv",
            inA=True, inPTR=True, ip="", ttl="", force=False
        ):
        """
        :param hostname: The hostname
        :param domain: The domain where to add
        :param subnet: Subnet IP/Mask
        :param ipRange: oneOf(net/srv/dyn)
        :param inA: record In A if True
        :param inPTR: record In PTR if True
        :param ip: provided ip or get_next_free_ip
        :param ttl: Don't use default TTL (Default: map default TTL)
        :param force: Force add, even if subnet not found for specified domain (advanced users only)
        :return: True on success
        """
        raise NotImplementedError

    def host_update(self, hostname, ip, domain, newHostname="",
            newIp="", newDomain="", newTTL="", force=False
        ):
        """

        :param hostname: The hostname
        :param ip: the host IP
        :param domain: The DNS Domain
        :param newHostname: the new name[OPTIONNAL]
        :param newIp: the new IP[OPTIONNAL]
        :param newDomain: the new domain[OPTIONNAL]
        :param newTTL: the new TTL [OPTIONNAL]
        :param force: Advanced users only

        :return: True on success
        """
        raise NotImplementedError

    def host_delete(self, hostname, domain, ip="", inA=True, inPTR=True):
        """
        :param hostname: The hostname to delete
        :param domain: The DNS domain
        :param ip: Ip of the hostname
        :param inA: Delete A record if True
        :param inPTR: Delete PTR record if True
        :return: True on success
        """
        raise NotImplementedError

    def host_search_infos(self, pattern):
        """
        :param pattern: Pattern to search for (hostname or IP)
        :return: Return value assocHostInfoArray: List of matching hostnames
        """
        raise NotImplementedError


class CloudVra(object):
    def get_vra_resource_data(self, filter_sentence):
        '''
        Get some information about a resource
        :param filter_sentence: string. sthg like "(name eq 'dpgalx888')"
        :return: a dictionary.
        '''
        raise NotImplementedError

    def get_vra_catalog(self, filter_sentence):
        '''
        Get a list from the catalog
        :return: a list
        '''
        raise NotImplementedError

    def run_vra_request(self, data, wait):
        raise NotImplementedError

    def vra_create_vm(self, wait, machine_item, vm_config, requested_for, provider_owner, business_group):
        raise NotImplementedError

    def vra_add_disk(self, wait, hostname_id, operation_id, organization, disk_size ):
        raise NotImplementedError

    def vra_destroy_vm(self, wait, hostname_id, operation_id, organization):
        raise NotImplementedError

    def vra_workflow_request(self, wait, workflow_item, trigram, app_env):
        raise NotImplementedError


class MarleyHPOO(object):
    def marley_hpoo_execute(self, **params):
        '''
        Invoke Step_Marley_V5 HPOO Flow
        :return: response
        '''
        raise NotImplementedError
    def marley_hpoo_status(self, **params):
        '''
        Check_Marley_V5 HPOO Flow
        :return: response
        '''
        raise NotImplementedError

class Kat(object):
    def get_single_component_data(self, trigram, irt_code):
        '''
        Get data from Kat
        :param trigram: string
        :param irt_code: string
        :return: a list of dicts. Empty list if no data found
        '''
        raise NotImplementedError

class Whats(object):

    def get_realm(self):
        raise NotImplementedError

    def get_domain(self):
        raise NotImplementedError

    def destroy_token(self):
        raise NotImplementedError

    def enroller(self, hostname, ip_address, trigram):
        '''
        Pré-enrollement whats
        :param hostname, ip_address, trigram
        :return a dict response from idm
        '''
        raise NotImplementedError

    def unroller(self, hostname):
        '''
        Unrollement whats
        :param hostname
        :return a dict of unrollment status from whats
        '''
        raise NotImplementedError

    def ip_checker(self, hostname, ip_address):
        '''
        Check if ip_address is  enrolled with another host
        :param ip_address
        :return a dict of ip check from whats
        '''
        raise NotImplementedError

    def host_checker(self, hostname):
        '''
        Check if hostname is  enrolled with another host
        :param ip_address
        :return a dict of ip check from whats
        '''
        raise NotImplementedError


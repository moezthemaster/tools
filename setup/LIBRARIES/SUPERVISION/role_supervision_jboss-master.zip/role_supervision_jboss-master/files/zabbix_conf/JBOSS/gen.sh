#/bin/bash

#Plugin to monitor JAVA_JMX , with a plugin for JBOSS
# DISCOVER JMX paramter and log file PATH
#Author : F.TCHATO
#2018 for SG


JSON="{"\"data\"":["


my_array=()
while IFS= read -r line; do
    INSTANCE_NAME=$(echo $line | cut -d'/' -f 4)
    INSTANCE_PORT=$(grep jboss.management.http.port  $line | cut -d'=' -f 2)
    HTTPS_PORT=$(grep jboss.https.port  $line | cut -d'=' -f 2)
    AJP_PORT=$(grep jboss.ajp.port  $line | cut -d'=' -f 2)
    INSTANCE_ADDR=$(grep jboss.bind.address.management $line | cut -d'=' -f 2)
    LOG=$(echo $line | cut -d'/' -f 1-3)
    LOG="$LOG/log/$INSTANCE_NAME"
    if [ -f "$LOG/server.log" ]; then
        SERVER_LOG="$LOG/server.log"
    else
        SERVER_LOG=$(find / -name server.log 2>/dev/null)
    fi
    if [ -f "$LOG/access_log.log" ]; then
        ACCESS_LOG="$LOG/access_log.log"
    else
        ACCESS_LOG=$(find / -name access_log 2>/dev/null)
    fi
    JSON="$JSON { \"{#INSTANCE_NAME}\":\"$INSTANCE_NAME\", \"{#INSTANCE_PORT}\":\"$INSTANCE_PORT\" ,  \"{#HTTPS_PORT}\":\"$HTTPS_PORT\" , \"{#AJP_PORT}\":\"$AJP_PORT\" ,\"{#INSTANCE_ADDR}\":\"$INSTANCE_ADDR\", \"{#SERVER_LOG}\":\"$SERVER_LOG\",\"{#ACCESS_LOG}\":\"$ACCESS_LOG\"},"
    my_array+=( "$line" )
done < <( find / -name standalone.properties 2>/dev/null )

JSON="${JSON::-1}"
JSON="$JSON
 ]}
"

echo $JSON

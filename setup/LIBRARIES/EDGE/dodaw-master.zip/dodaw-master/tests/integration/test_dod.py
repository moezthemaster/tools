#!/usr/bin/python
# -*- coding: utf-8 -*-

import logging

import pytest

from dodaw.dod import DodWrapper
from dodaw.conf import settings


HOSTNAME = 'dpgalxtest4100'

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


class TestDod(object):
    def test_create_search_delete_record_A(self):
        dod = DodWrapper()
        dod.search_and_delete_records(record_type='^A$',
                                    dns_service=settings.DNS_SERVICE,
                                    hostname=HOSTNAME,
                                    view='production')
        logger.debug('Create a record A')
        record_created = dod.create_record(record_type='A',
                                     dns_service=settings.DNS_SERVICE,
                                     hostname=HOSTNAME,
                                     view='production',
                                     zone='dns21-3.socgen',
                                     ip_subnet='111.80.16.0/22',
                                     ip_range='server')
        expected = {
            u'zone': u'db.dns21-3.socgen',
            u'ip': record_created['ip'],
            u'hostname': HOSTNAME,
            u'comments': u'',
            u'class': u'IN',
            u'ttl': u'Default',
            u'type': u'A',
            u'id': record_created['id'],
            u'view': u'production'
        }
        assert record_created ==  expected
        logger.debug('Search record created previously')
        records_found = dod.search_record(record_type='^A$',
                          dns_service=settings.DNS_SERVICE,
                          hostname=HOSTNAME,
                          view='production')
        expected = [{
            u'domain': None,
            u'protocol': None,
            u'weight': None,
            u'zone': u'dns21-3.socgen',
            u'ip': record_created['ip'],
            u'hostname': HOSTNAME,
            u'comments': u'',
            u'class': u'IN',
            u'port': None,
            u'alias': None,
            u'service': None,
            u'text': None,
            u'preference': None,
            u'ttl': None,
            u'hostname_fqdn': u'{}.dns21-3.socgen.'.format(HOSTNAME),
            u'type': u'A',
            u'id': records_found[0]['id'],
            u'view': u'production'
        }]
        assert records_found[0] == expected[0]
        logger.debug('Delete records created previously')
        dod.delete_record(settings.DNS_SERVICE, record_created['id'])
        
    def test_create_search_update_delete_record_A(self):
        dod = DodWrapper()
        dod.search_and_delete_records(record_type='^CNAME$',
                                    dns_service=settings.DNS_SERVICE,
                                    hostname=HOSTNAME,
                                    view='production')
        logger.debug('Create a record A')
        record_created = dod.create_record(record_type='A',
                                     dns_service=settings.DNS_SERVICE,
                                     hostname=HOSTNAME,
                                     view='production',
                                     zone='dns21-3.socgen',
                                     ip_subnet='111.80.16.0/22',
                                     ip_range='server')
        expected = {
            u'zone': u'db.dns21-3.socgen',
            u'ip': record_created['ip'],
            u'hostname': HOSTNAME,
            u'comments': u'',
            u'class': u'IN',
            u'ttl': u'Default',
            u'type': u'A',
            u'id': record_created['id'],
            u'view': u'production'
        }
        assert record_created ==  expected
        logger.debug('Search record created previously')
        records_found = dod.search_record(record_type='^A$',
                          dns_service=settings.DNS_SERVICE,
                          hostname=HOSTNAME,
                          view='production')
        expected = [{
            u'domain': None,
            u'protocol': None,
            u'weight': None,
            u'zone': u'dns21-3.socgen',
            u'ip': record_created['ip'],
            u'hostname': HOSTNAME,
            u'comments': u'',
            u'class': u'IN',
            u'port': None,
            u'alias': None,
            u'service': None,
            u'text': None,
            u'preference': None,
            u'ttl': None,
            u'hostname_fqdn': u'{}.dns21-3.socgen.'.format(HOSTNAME),
            u'type': u'A',
            u'id': records_found[0]['id'],
            u'view': u'production'
        }]
        assert records_found[0] == expected[0]
        logger.debug('Update records created previously')

        record_updated = dod.search_and_update_conflict_records(record_type='^A$',
                                    dns_service=settings.DNS_SERVICE,
                                    hostname=HOSTNAME,
                                    cause='{}_update'.format(HOSTNAME),
                                    view='production')
        
        id_updated = record_updated[0].split(" : ")[0]
        
        assert records_found[0]['id'] == id_updated

        logger.debug('Delete records created previously')
        dod.delete_record(settings.DNS_SERVICE, record_created['id'])

    def test_search_no_record_found(self):
        dod = DodWrapper()
        records = dod.search_record(record_type='DUMMY',
                          dns_service=settings.DNS_SERVICE,
                          hostname=HOSTNAME,
                          view='production')
        assert records == []

    def test_create_error(self):
        dod = DodWrapper()
        with pytest.raises(Exception):
            dod.create_record(record_type='FAKE_VALUE',
                                         dns_service=settings.DNS_SERVICE,
                                         hostname=HOSTNAME,
                                         view='production',
                                         zone='dns21-3.socgen',
                                         ip_subnet='111.80.16.0/22',
                                         ip_range='server')

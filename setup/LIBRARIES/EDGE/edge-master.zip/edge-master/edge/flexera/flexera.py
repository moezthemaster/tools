from edge.exception import EdgeException
from edge.tools.tools import VmSessionSsh

FLEX_CONF_REQUEST_CMD = "sudo /opt/managesoft/bin/mgsconfig -i /var/tmp/config.ini; " \
                        "sudo nohup /opt/managesoft/bin/mgspolicy -t machine 1>/dev/null 2>&1 &"

COMMAND_STATIC = 'static'

class FlexeraRequest(object):
    def __init__(self, ip_address):
        self.ip_address = ip_address

    def request_flexera_configuration(self):
        """

        """
        vm_session = VmSessionSsh(self.ip_address)
        try:
            code_status, stdout, stderr = vm_session.execute_cmd(FLEX_CONF_REQUEST_CMD, COMMAND_STATIC)
            return code_status
        except Exception as err:
            raise EdgeException(err.args[0])

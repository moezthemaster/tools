
import os
import re
import time

from celery import Task
from schema import Schema, And, Use, Optional, SchemaError

from ccs_celery.celery import app
from ccs_celery.settings import settings
from ccs_celery.data import SharedDataOfVm
from ccs_celery.tools.logger import set_up_logger
from ccs_celery.tools import save_to_json, get_dict, ret_or_mkt
from ccs_celery.exceptions import PyCcsCeleryError
from ccs_celery.services import \
    kat, dod, whatsprenrollment, cloud, registerpubkey, configurenetwork, registerwhatsclient, marley, flexera, \
    cloudinfos, dodinfos, marleydecom, unregisterwhats, unregisterwhatsclient, whatsinfos, unregisterdod, \
    unregisterpubkey, reconfigurenetwork, vminfos


VM_METADATA = {
    "profiles": (
        'Micro 1vCPU-1GB',
        'Small 1vCPU-2GB',
        'Small-mem4 1vCPU-4GB',
        'Medium-mem2 2vCPU-2GB',
        'Medium 2vCPU-4GB',
        'Medium-mem8 2vCPU-8GB',
        'Medium-mem16 2vCPU-16GB',
        'Medium-mem32 2vCPU-32GB',
        'Large 4vCPU-8GB',
        'Large-mem16 4vCPU-16GB',
        'Large-mem32 4vCPU-32G',
        'XLarge 8vCPU-16GB',
        'XLarge-mem32 8vCPU-32GB',
        'XLarge-mem64 8vCPU-64GB',
        'XLarge-mem128 8vCPU-128GB'
    ),
    "templates_os": (
        'RHEL_7.5_x64-RET-EDGE',
        'RHEL_7.5_x64-WEBCELL-RET-EDGE',
        'RHEL_7.5_x64-WEBCELL-BAD-EDGE',
        'RHEL_7.5_x64-TRANSVERSE-RCR',
        'RHEL_7.3_x64-WEBCELL-RET-EDGE',
        'RHEL_7.3_x64-WEBCELL-BAD-EDGE',
        'RHEL_7.3_x64-RET-EDGE',
        'RHEL_7.3_x64-TRANSVERSE-RCR',
        'CENTOS_7.5_x64-RET-EDGE',
        'CENTOS_7.5_x64-WEBCELL-RET-EDGE',
        'CENTOS_7.5_x64-WEBCELL-BAD-EDGE',
        'CENTOS_7.5_x64-TRANSVERSE-RCR',
        'CENTOS_7.0_x64-RET-EDGE',
        'CENTOS_7.0_x64-WEBCELL-BAD-EDGE',
        'CENTOS_7.0_x64-TRANSVERSE-RCR',
        'CENTOS_7.0_x64-WEBCELL-RET-EDGE'
    ),
    "size": (0, 20, 60, 160, 300, 500, 750, 1000, 2000)
}


def _delete_vm(vm_hostname, force=False):
    return "Vm successfully {} deleted...".format(vm_hostname)


class ManageClassForCreateVmTask(Task):
    # To improve
    vm_inputs_schema = Schema(
        {
            Optional("vm_hostname", default=None): And(str, Use(str.lower)),
            Optional("vm_desc", default=""): str,
            "app_id": And(str, Use(str.lower)),
            "vm_pubkey": And(str, lambda s: re.search(r'ssh-rsa AAAA[0-9A-Za-z+/]+[=]{0,3} ([^@]+@[^@]+)', s)),
            Optional("app_env", default="prd"): And(str, Use(str.lower), lambda s: s in (
                    'uat', 'tst', 'int', 'dev', 'hml', 'prd')
                ),
            "code_irt": str,
            Optional("deprecated_endClient", default=""): And(str, Use(str.lower)),
            Optional(
                "vm_profile",
                default="Micro 1vCPU-1GB"): And(
                str,
                lambda s: s in VM_METADATA["profiles"]),
            "vm_network": str,
            Optional(
                "vm_region",
                default="EU France (Greater Paris)"): And(
                    str,
                    lambda s: s in ('EU France (Greater Paris)', 'EU France (North)'
                )),
            Optional(
                "vm_az",
                default="eu-fr-paris-1"): And(str, Use(str.lower),
                    lambda s: s in ('eu-fr-paris-1', 'eu-fr-paris-2', 'eu-fr-north-1')),
            Optional(
                "vm_os",
                default="RHEL_7.3_x64-RET-EDGE"): And(str, lambda s: s in VM_METADATA["templates_os"]),
            Optional("data_disk", default=0): And(int, lambda s: s in VM_METADATA["size"]),
            Optional("vm_replication", default=False): bool,
            Optional("vm_backup", default='none'): And(
                str, lambda s: s in ('none', 'daily-31d-2AM', 'daily-31d-4AM')
                ),
            Optional("state", default="present"): lambda s: s == "present",
        }
    )

    def __init__(self, settings=settings):
        self._settings = settings

    @property
    def settings(self):
        return self._settings

    def on_success(self, retval, task_id, args, kwargs):
        self.logger.info("Task {} on_success method: saving task's data".format(self.vm_data.task_name))
        self.vm_data.finished_at = time.time()
        self.vm_data.return_value = retval
        save_to_json(
            os.path.join(
                self.settings.CCS_CELERY_LOG_FOLDER,
                self.vm_data.task_name,
                self.vm_data.task_id,
                'data.json'
            ),
            get_dict(self.vm_data)
        )
        self.logger.info("Task {} on_success method: task's data saved".format(self.vm_data.task_name))

    def on_failure(self, exc, task_id, args, kwargs, einfo):
        self.logger.info("Task {} on_failure method: saving task's data".format(self.vm_data.task_name))
        self.vm_data.finished_at = time.time()
        self.vm_data.exception_class = str(type(exc))
        self.vm_data.exception_msg = str(exc)
        self.vm_data.exception_traceback = str(einfo)
        save_to_json(
            os.path.join(
                self.settings.CCS_CELERY_LOG_FOLDER,
                self.vm_data.task_name,
                self.vm_data.task_id,
                'data.json'
            ),
            get_dict(self.vm_data)
        )
        self.logger.info("Task {} on_failure method: task's data saved".format(self.vm_data.task_name))


@app.task(bind=True, base=ManageClassForCreateVmTask)
def create_vm(self, **kwargs):
    self.logger = set_up_logger(
        self.name,
        os.path.join(
            self.settings.CCS_CELERY_LOG_FOLDER, self.name.split('.')[-1],
            self.request.id, 'task.log'
        ),
        log_level=self.settings.LOGGER_LEVEL
    )
    self.logger.debug("Creating vm with args={}".format(kwargs))
    self.vm_data = SharedDataOfVm(**{
        "log_file": os.path.join(
            self.settings.CCS_CELERY_LOG_FOLDER,
            self.name.split('.')[-1],
            self.request.id,
            'task.log'
        ),
        "log_level": self.settings.LOGGER_LEVEL,
        "created_at": time.time(),
        "task_id": self.request.id,
        "task_name": self.name.split('.')[-1],
        "task_full_name": self.name,
        "args": (),
        "original_kwargs": kwargs,
    })
    try:
        inputs_data = self.vm_inputs_schema.validate(kwargs)
        self.vm_data.kwargs = inputs_data
    except SchemaError as err:
        self.logger.error("Creation of vm failed : {}".format(err))
        raise PyCcsCeleryError("Creation of vm failed : {}".format(err))
    self.logger.info("Call workflow of creating vm")
    self.vm_data.shared_data = dict(self.vm_data.kwargs)
    self.vm_data.shared_data["network_index"] = ret_or_mkt(
        self.vm_data.kwargs["app_env"],
        self.vm_data.kwargs["vm_region"],
        self.vm_data.kwargs["vm_az"],
        self.vm_data.kwargs["vm_network"]
    )
    kat(self.vm_data).run()
    dod(self.vm_data).run()
    whatsprenrollment(self.vm_data).run()
    cloud(self.vm_data).run()
    registerpubkey(self.vm_data).run()
    configurenetwork(self.vm_data).run()
    registerwhatsclient(self.vm_data).run()
    marley(self.vm_data).run()
    vminfos(self.vm_data).run()
    flexera(self.vm_data).run()
    return "Vm successfully {} created...".format(self.vm_data.kwargs['vm_hostname'])


class ManageClassForDeleteVmTask(Task):
    # To improve
    vm_inputs_schema = Schema(
        {
            "vm_hostname": And(str, Use(str.lower)),
            Optional("vm_desc", default=""): str,
            "app_id": And(str, Use(str.lower)),
            "vm_pubkey": And(str, lambda s: re.search(r'ssh-rsa AAAA[0-9A-Za-z+/]+[=]{0,3} ([^@]+@[^@]+)', s)),
            Optional("app_env", default="prd"): And(str, Use(str.lower), lambda s: s in (
                    'uat', 'tst', 'int', 'dev', 'hml', 'prd')
                ),
            "code_irt": str,
            Optional("deprecated_endClient", default=""): And(str, Use(str.lower)),
            Optional(
                "vm_profile",
                default="Micro 1vCPU-1GB"): And(
                str,
                lambda s: s in VM_METADATA["profiles"]),
            Optional("vm_network"): str,
            Optional(
                "vm_region",
                default="EU France (Greater Paris)"): And(
                    str,
                    lambda s: s in ('EU France (Greater Paris)', 'EU France (North)'
                )),
            Optional(
                "vm_az",
                default="eu-fr-paris-1"): And(str, Use(str.lower),
                    lambda s: s in ('eu-fr-paris-1', 'eu-fr-paris-2', 'eu-fr-north-1')),
            Optional(
                "vm_os",
                default="RHEL_7.3_x64-RET-EDGE"): And(str, lambda s: s in VM_METADATA["templates_os"]),
            Optional("data_disk", default=0): And(int, lambda s: s in VM_METADATA["size"]),
            Optional("vm_replication", default=False): bool,
            Optional("vm_backup", default='none'): And(
                str, lambda s: s in ('none', 'daily-31d-2AM', 'daily-31d-4AM')
                ),
            Optional("state", default="absent"): lambda s: s == "absent",
        }
    )

    def __init__(self, settings=settings):
        self._settings = settings

    @property
    def settings(self):
        return self._settings

    def on_success(self, retval, task_id, args, kwargs):
        self.logger.info("Task {} on_success method: saving task's data".format(self.vm_data.task_name))
        self.vm_data.finished_at = time.time()
        self.vm_data.return_value = retval
        save_to_json(
            os.path.join(
                self.settings.CCS_CELERY_LOG_FOLDER,
                self.vm_data.task_name,
                self.vm_data.task_id,
                'data.json'
            ),
            get_dict(self.vm_data)
        )
        self.logger.info("Task {} on_success method: task's data saved".format(self.vm_data.task_name))

    def on_failure(self, exc, task_id, args, kwargs, einfo):
        self.logger.info("Task {} on_failure method: saving task's data".format(self.vm_data.task_name))
        self.vm_data.finished_at = time.time()
        self.vm_data.exception_class = str(type(exc))
        self.vm_data.exception_msg = str(exc)
        self.vm_data.exception_traceback = str(einfo)
        save_to_json(
            os.path.join(
                self.settings.CCS_CELERY_LOG_FOLDER,
                self.vm_data.task_name,
                self.vm_data.task_id,
                'data.json'
            ),
            get_dict(self.vm_data)
        )
        self.logger.info("Task {} on_failure method: task's data saved".format(self.vm_data.task_name))


@app.task(bind=True, base=ManageClassForDeleteVmTask)
def delete_vm(self, **kwargs):
    self.logger = set_up_logger(
        self.name,
        os.path.join(
            self.settings.CCS_CELERY_LOG_FOLDER, self.name.split('.')[-1],
            self.request.id, 'task.log'
        ),
        log_level=self.settings.LOGGER_LEVEL
    )
    self.logger.debug("Deleting vm with args={}".format(kwargs))
    self.vm_data = SharedDataOfVm(**{
        "log_file": os.path.join(
            self.settings.CCS_CELERY_LOG_FOLDER,
            self.name.split('.')[-1],
            self.request.id,
            'task.log'
        ),
        "log_level": self.settings.LOGGER_LEVEL,
        "created_at": time.time(),
        "task_id": self.request.id,
        "task_name": self.name.split('.')[-1],
        "task_full_name": self.name,
        "args": (),
        "original_kwargs": kwargs,
    })
    try:
        inputs_data = self.vm_inputs_schema.validate(kwargs)
        self.vm_data.kwargs = inputs_data
    except SchemaError as err:
        self.logger.error("Deletion of vm failed : {}".format(err))
        raise PyCcsCeleryError("Deletion of vm failed : {}".format(err))
    self.logger.info("Call workflow of deleting vm")
    self.vm_data.shared_data = dict(self.vm_data.kwargs)
    cloudinfos(self.vm_data).run()
    dodinfos(self.vm_data).run()
    whatsinfos(self.vm_data).run()
    kat(self.vm_data).run()
    marleydecom(self.vm_data).run()
    unregisterwhatsclient(self.vm_data).run()
    unregisterwhats(self.vm_data).run()
    unregisterpubkey(self.vm_data).run()
    reconfigurenetwork(self.vm_data).run()
    cloud(self.vm_data).run()
    unregisterdod(self.vm_data).run()
    return "Vm successfully {} deleted...".format(self.vm_data.kwargs['vm_hostname'])


@app.task
def hello(force_fail=False):
    if force_fail:
        raise PyCcsCeleryError("Task fails...")
    return 'hello world'

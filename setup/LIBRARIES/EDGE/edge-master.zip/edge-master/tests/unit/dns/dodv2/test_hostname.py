#!/usr/bin/python
# -*- coding: utf-8 -*-

#

import re
import pytest

import edge.dns.dodv2.hostname
import tests.mock.mock


class TestDnsHostname(object):
    def test_get_free_hostname_1_2_4(self):
        prefix = 'dpgalx'
        records = [tests.mock.mock.record_factory('A', 'dpgalx{:03d}'.format(id), id) for id in (1, 2, 4)]
        output = edge.dns.dodv2.hostname.free_slot(records, prefix)
        assert output == 3

    def test_get_free_hostname_different_prefix(self):
        prefix = 'dpgalxdifferent'
        records = [tests.mock.mock.record_factory('A', 'dpgalx{:03d}'.format(id), id) for id in range(1, 4)]
        output = edge.dns.dodv2.hostname.free_slot(records, prefix)
        assert output == 1


list_int_result = (
    ([1], 2),
    ([], 1),
    ([1,2,4], 3),
    ([1,2,3], 4),
    ([2,3,4], 1),
)


@pytest.fixture(params=(list_int_result))
def list_int(request):
    return request.param


def test_first_free_increment(list_int):
    output = edge.dns.dodv2.hostname.first_free_increment(list_int[0])
    assert output == list_int[1]


def test_validate_hostname():
    assert edge.dns.dodv2.hostname.is_valide_hostname("pga", "dpgalx10000")
    assert edge.dns.dodv2.hostname.is_valide_hostname("pga", "ppgalx10000")
    assert edge.dns.dodv2.hostname.is_valide_hostname("trv", "htrvlx10000")
    assert edge.dns.dodv2.hostname.is_valide_hostname("trv", "htrvlx-10000")
    assert edge.dns.dodv2.hostname.is_valide_hostname("trv", "htrvlx_10000")
    assert edge.dns.dodv2.hostname.is_valide_hostname("trv", "htrvlx_10000-2")
    assert edge.dns.dodv2.hostname.is_valide_hostname("trv", "edge_conflict_whats_123456")
    try:
        edge.dns.dodv2.hostname.is_valide_hostname("trv", " ")
        assert False
    except Exception as err:
        assert "  must match this regex '^(d|h|p)trv[a-zA-Z0-9_-]+$'" == err.args[0]
    try:
        edge.dns.dodv2.hostname.is_valide_hostname("trv", "")
        assert False
    except Exception as err:
        assert " must match this regex '^(d|h|p)trv[a-zA-Z0-9_-]+$'" == err.args[0]
    try:
        edge.dns.dodv2.hostname.is_valide_hostname("trv", "*")
        assert False
    except Exception as err:
        assert "* must match this regex '^(d|h|p)trv[a-zA-Z0-9_-]+$'" == err.args[0]
    try:
        edge.dns.dodv2.hostname.is_valide_hostname("trv", "dtrvlx5900*")
        assert False
    except Exception as err:
        assert "dtrvlx5900* must match this regex '^(d|h|p)trv[a-zA-Z0-9_-]+$'" == err.args[0]
    try:
        edge.dns.dodv2.hostname.is_valide_hostname("trv", "otrvlx5900")
        assert False
    except Exception as err:
        assert "otrvlx5900 must match this regex '^(d|h|p)trv[a-zA-Z0-9_-]+$'" == err.args[0]
    try:
        edge.dns.dodv2.hostname.is_valide_hostname("trv", "edge_conflict_toto_12345")
        assert False
    except Exception as err:
        assert "edge_conflict_toto_12345 must match this regex '^(d|h|p)trv[a-zA-Z0-9_-]+$'" == err.args[0]

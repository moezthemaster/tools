'''
Default settings. Override these with settings in the .py file pointed to
by the VAULT_CONFIG_FILE environment variable.
'''


APPLICATION = ''
ROLE_ID = 'edge-001-login-read'
VAULT_URL = ''
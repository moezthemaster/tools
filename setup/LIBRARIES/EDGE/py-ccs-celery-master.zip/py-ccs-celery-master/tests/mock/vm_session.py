#!/usr/bin/python
# -*- coding: utf-8 -*-

import re
import socket
import struct

import paramiko
import ipaddress

from edge.exception import EdgeException
from edge.connection.connectionhelper import ConnectionHelper


def mocked_vault(context=None):
    return   {
        'user': 'UserX',
        'private_root_key': u"private_key"
    }


def get_all_ip(subnet):
    """
    get all ip address for subnet
    eg:
    192.168.56.0/24 => yield 192.168.56.1 -> 192.168.56.254
    """
    (ip, cidr) = subnet.split("/")
    cidr = int(cidr)
    host_bits = 32 - cidr
    i = struct.unpack(">I", socket.inet_aton(ip))[0]
    start = (i >> host_bits) << host_bits
    end = i | ((1 << host_bits) - 1)
    for i in range(start, end):
        ip = socket.inet_ntoa(struct.pack(">I", i))
        if ip.endswith(".0") or ip.endswith(".255"):
            continue
        yield socket.inet_ntoa(struct.pack(">I", i))


BLACKLIST_NETWORK_DB = ("192.36.65.0/24",)


class SshDatabase(object):

    def __init__(self, shared_database=None):
        if isinstance(shared_database, list):
            self.vm_database = shared_database
        else:
            self.vm_database = []

    def search_vm(self, ip):
        try:
            index = list(map(lambda x: x["ip"], self.vm_database)).index(ip)
        except ValueError:
            return None
        vm = self.vm_database[index]
        return vm


class MockVmSession(SshDatabase):

    def __init__(self, ip_address, shared_database=None, **kwargs):
        self.ip_address = ip_address
        SshDatabase.__init__(self, shared_database)

    def execute_cmd(self, cmd, type, timeout=5, client=None):
        for network in BLACKLIST_NETWORK_DB:
            ip_in_network = self.ip_address in list(get_all_ip(network))
            if ip_in_network:
                raise socket.timeout()
        vm = self.search_vm(self.ip_address)
        if cmd == 'sudo sh -c "hostname"':
            return 0, vm["hostname"], ""
        elif cmd == 'sudo sh -c "grep \'^automation:\' /etc/passwd | cut -d: -f6 | tail -1"':
            return 0, b"/home/automation", ""
        elif re.search(r'{}'.format('sudo sh -c "grep \'ssh-rsa'), cmd):
            if vm is None:
                return "Unknown host, cannot copy the pubkey"
            else:
                if vm["pubkey"]:
                    return 0, "ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAyLXUQ9eoPr8Akx+WeJzRgAOMyUbTQ3/RDu44N2svQTa7I0ZKzqelNrSqqsgSmNN7giQGRyIvx/XgUwi9UjrxFX0XRTvwjAcXNHV2pxybbhPb8/2jiAfFTCjkwQBwtoSTEL1I5noAIgapQDZghYFkv0GUiAkebKzl0A+cNqm5Zc2UPNTqsCtIAZ5Uid+XOdECHan29Iyow0f+O/2O6mZKBGvWFJbRLCokKLUrTmhbgWIiWgQGp/PnF0XVVPiQgRfbRz1xH08JNiQz1lnvZ4ME4BhQoxSK1O8QL+dQsSXhvQyjfO8yYI+X4X73Ie9yBfZpPiGAZLo3hTVha46veVfZGw== a373785@PXPLSV02", ""
                else:
                    index = list(map(lambda x: x["ip"], self.vm_database)).index(self.ip_address)
                    self.vm_database[index]['pubkey'] = True
                    return 0, vm['hostname'], ""
        elif re.search(r'{}'.format('sudo sh -c "grep -qF'), cmd):
            if vm is None:
                raise Exception(self.ip_address)
            else:
                return "OK"
        elif re.search(r'{}'.format('a=`hostname'), cmd):
            if vm is None:
                raise Exception("SSHException: {}".format(self.ip_address))
            else:
                return 0, "1\n", ""
        elif cmd == 'sudo sh -c "cat /etc/redhat-release"':
            return 0, b"CentOS Linux release 7.5.1804 (Core) \n", ""
        elif cmd == 'sudo sh -c "cat /etc/template | grep -e REPO | awk -F \'-\' \'{print $3}\'"':
            return 0, b"REPO=7Server-x86_64-201822\n", ""

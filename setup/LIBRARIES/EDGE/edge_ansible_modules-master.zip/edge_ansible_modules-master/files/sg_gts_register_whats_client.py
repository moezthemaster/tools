
import os
import sys

if "TREE_DIR" in os.environ.keys():
    ANSIBLE_MODULES_PATH = [
        os.path.join(os.environ["TREE_DIR"], 'roles/edge'),
        os.path.join(os.environ["TREE_DIR"], 'roles/py_edge_vault'),
        os.path.join(os.environ["TREE_DIR"], "library"),
    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/edge',
        './roles/py_edge_vault'
    ]

for path in ANSIBLE_MODULES_PATH:
    sys.path.append(path)

from ansible.module_utils.basic import AnsibleModule
from edge.whats.enrollment import RegisterWhatsClient


def main():
    fields = {
        "domain": {"required": True, "type": "str"},
        "hostname": {"required": True, "type": "str"},
        "realm": {"required": True, "type": "str"},
        "ip_address": {"required": True, "type": "str"}
    }
    module = AnsibleModule(argument_spec=fields)
    try:
        register_client = RegisterWhatsClient(
            ip_address=module.params['ip_address'],
            hostname=module.params['hostname'],
            domain=module.params['domain'],
            realm=module.params['realm']
        )
        response = register_client.launch()
        module.exit_json(changed=False, meta=response)
    except Exception as err:
        module.fail_json(msg=err.args[0])

if __name__ == '__main__':
    main()

#!/usr/bin/env python
# -*- coding: utf-8 -*-

''' Check IP status. '''

__author__ = "FT Edge"
__version__ = "0.1.0"

import logging
import logzero
logzero.loglevel(level=logging.WARNING)
from logzero import logger
import argparse

import inventory


def init_logger(level):
    ''' Init logger base on level specified.'''
    if level is None:
        level = 0
    if level >= 2:
        logzero.loglevel(level=logging.DEBUG)
    elif level == 1:
        logzero.loglevel(level=logging.INFO)
    else:
        logzero.loglevel(level=logging.WARNING)


def main(args):
    ''' Main function for inventory.'''
    init_logger(level=args.verbose)
    status_inventory = inventory.StatusInventory()
    res_status = status_inventory.check_status(args.ip, False)
    whats_inventory = inventory.WhatsInventory()
    res_whats = whats_inventory.get_ip_infos(args.ip)
    output = "{};{};{};{};{}".format(args.ip, 
                                     ("Ping OK" if res_status['ping']  else "No Ping"),
                                     ("SSH OK" if res_status['ssh']  else "No SSH"),
                                     ("RDP OK" if res_status['rdp']  else "No RDP"),
                                     ("Found in WHATS:{}".format(res_whats) if res_whats else "Not in WHATS"))
    print(output)

if __name__ == '__main__':
    """ This is executed when run from the command line """

    parser = argparse.ArgumentParser()

    # Required positional argument
    parser.add_argument("ip", help="The ip to check")

    # Optional verbosity counter (eg. -v, -vv, -vvv, etc.)
    parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Verbosity (-v, -vv, etc)")

    # Specify output of "--version"
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s (version {version})".format(version=__version__))

    args = parser.parse_args()
    main(args=args)

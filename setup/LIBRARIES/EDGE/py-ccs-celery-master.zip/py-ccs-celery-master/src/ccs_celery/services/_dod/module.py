
import os

from six import with_metaclass

from ccs_celery.tools import set_env, set_missing_keys_to_none


from edge.whats.idm import Idm
from edge.interfaces import Dod
from dodaw.dod import DodWrapper
from edge.interfaces import DodV1
from whatsaw.idm import IdmWrapper
from edge.manage_ip.manage_ip import ManageIP
from edge.connection.connectionhelper import ConnectionHelper
from edge.dns.metaclass import DnsFeederMetaClass, DnsUpdaterMetaClass, DnsCleanerMetaClass, DnsInformerMetaClass

try:
    from dodaw.dodv1 import DodWrapper as DodV1Wrapper
except ImportError:
    class DodV1Wrapper(object):
        def __init__(self):
            raise Exception("Depedence Zeep must be installed for Dodv1")

PRESENT, ABSENT, INFOS = 'present', 'absent', 'infos'


class DodImpl(Dod):
    def __init__(self):
        self.dod_wrapper = DodWrapper()

    def search_dns_record(self, record_type, **kwargs):
        return self.dod_wrapper.search_record(record_type, **kwargs)

    def create_dns_record(self, dns_service, record_type, zone, view, hostname, **kwargs):
        return self.dod_wrapper.create_record(dns_service, record_type, zone, view, hostname, **kwargs)

    def update_dns_record(self, dns_service, id, record_type, zone, view, hostname, ip, **kwargs):
        return self.dod_wrapper.update_record(dns_service, record_type, zone, view, hostname, **kwargs)

    def delete_dns_record(self, dns_service, id):
        return self.dod_wrapper.delete_record(dns_service, id)

    def search_and_update_conflict_dns_records(self, dns_service, record_type, cause, limit_rows=10, **kwargs):
        return self.dod_wrapper.search_and_update_conflict_records(dns_service, record_type, cause, limit_rows,
                                                                   **kwargs)

    def search_and_delete_dns_records(self, dns_service, record_type, limit_rows=10, **kwargs):
        return self.dod_wrapper.search_and_delete_records(dns_service, record_type, limit_rows, **kwargs)


class DodV1Impl(DodV1):
    def __init__(self):
        self.dodv1_wrapper = DodV1Wrapper()

    def get_next_free_ip(self, *args, **kwargs):
        return self.dodv1_wrapper.get_next_free_ip(*args, **kwargs)

    def host_add(self, *args, **kwargs):
        return self.dodv1_wrapper.host_add(*args, **kwargs)

    def host_update(self, *args, **kwargs):
        return self.dodv1_wrapper.host_update(*args, **kwargs)

    def host_search_infos(self, *args, **kwargs):
        return self.dodv1_wrapper.host_search_infos(*args, **kwargs)

    def host_delete(self, *args, **kwargs):
        return self.dodv1_wrapper.host_delete(*args, **kwargs)


class DnsFeederAdapter(with_metaclass(DnsFeederMetaClass, DodImpl, DodV1Impl)):

    def __init__(self, *args, **kwargs):
        try:
            DodV1Impl.__init__(self)
        except Exception as err:
            if "Depedence Zeep must be installed for Dodv1" not in err.args[0]:
                raise Exception(err.args[0])
        DodImpl.__init__(self)


class DnsUpdaterAdapter(with_metaclass(DnsUpdaterMetaClass, DodImpl, DodV1Impl)):

    def __init__(self, *args, **kwargs):
        try:
            DodV1Impl.__init__(self)
        except Exception as err:
            if "Depedence Zeep must be installed for Dodv1" not in err.args[0]:
                raise Exception(err.args[0])
        DodImpl.__init__(self)


class DnsCleanerAdapter(with_metaclass(DnsCleanerMetaClass, DodImpl, DodV1Impl)):

    def __init__(self, *args, **kwargs):
        try:
            DodV1Impl.__init__(self)
        except Exception as err:
            if "Depedence Zeep must be installed for Dodv1" not in err.args[0]:
                raise Exception(err.args[0])
        DodImpl.__init__(self)


class DnsInformerAdapter(with_metaclass(DnsInformerMetaClass, DodImpl, DodV1Impl)):

    def __init__(self, *args, **kwargs):
        try:
            DodV1Impl.__init__(self)
        except Exception as err:
            if "Depedence Zeep must be installed for Dodv1" not in err.args[0]:
                raise Exception(err.args[0])
        DodImpl.__init__(self)


class IdmImpl(Idm):

    def __init__(self, hostname):
        Idm.__init__(self)
        self.idm_wrapper = IdmWrapper(hostname)

    def get_realm(self):
        return self.idm_wrapper.get_realm()

    def get_domain(self):
        return self.idm_wrapper.get_domain()

    def destroy_token(self):
        return self.idm_wrapper.destroy_token()

    def enroller(self, hostname, ip_address, trigram):
        return self.idm_wrapper.enroller(hostname, ip_address, trigram)

    def unroller(self, hostname):
        return self.idm_wrapper.unroller(hostname)

    def ip_checker(self, hostname, ip_address):
         return self.idm_wrapper.ip_checker(hostname, ip_address)

    def host_checker(self, hostname):
         return self.idm_wrapper.host_checker(hostname)


@set_missing_keys_to_none(
    (
        "vm_region", "vm_az", "app_id", "app_env", "vm_hostname",
        "vm_network", "state", "network_index"
    )
)
def dod_module(vm_region, vm_az, app_id=None, app_env="prd", vm_hostname=None,
        vm_network=None, state="present", network_index="ret"
    ):
    hostname = vm_hostname
    region_cloud = vm_region
    az_cloud = vm_az
    network_id = vm_network
    env = app_env
    trigram = app_id
    if state == PRESENT:
        manage_ip = ManageIP(IdmImpl, ConnectionHelper, DnsFeederAdapter, DnsUpdaterAdapter, DnsCleanerAdapter)
        response = manage_ip.run(env, region_cloud, az_cloud, network_id, trigram, hostname)
        return manage_ip.has_changed, response
    elif state == ABSENT:
        cleaner = DnsCleanerAdapter(env, region_cloud, az_cloud, network_id, trigram=trigram, hostname=hostname)
        response = cleaner.run()
        return cleaner.changed, response
    elif state == INFOS:
        informer = DnsInformerAdapter(
            hostname, network_index=network_index,
            region_cloud=region_cloud, az_cloud=az_cloud
        )
        response = informer.run()
        return informer.changed, response

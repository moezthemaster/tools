role_edge_patching_os
=========

Role to patch OS on RHEL7 / CENTOS 7 Edge servers.

This role use OS weekly repo (middleware installed through RHSCL or EPEL repo will not be updated).

This provides granularity to the patching level in order to match the patching needs.

We can divide updates under different 3 types :

- **RHBA** (Red Hat Bugfix Advisory) : it fix reported bugs on RPMs.
- **RHEA** (Red Hat Enhancement Advisory) : it could improve performance or offer new features to RPMs.
- **RHSA** (Red Hat Security Advisory) : it fix security flaws on RPMs.  


Requirements
------------

Facts gathering should not be disabled.

Target servers must be RHEL7 x86_64 or CENTOS7 x86_64

week_os parameter must be defined

Role Variables
--------------

Parameters week_os and week_sec are defined with the following nomenclature : YYYYWW (4 digits year + 2 digits week number)

**week_os (optional)** : defines the weekly repo used for patching RHBA/RHEA/RHSA.
Must be set between **201701** and **209952** range. If not provided, this variable will default to the current week number.

**week_sec (optional)** : defines the weekly repo used for patching RHSA.
Must be set between **201801** and **209952** range.

week_sec will not work and should not be used on CentOS because CentOS doesn't provides metadata to patch only RHSA.

Regexp verify that variables are on correct range (it's mandatory since there are some weekly repo which are not working due to sync issues)

Dependencies
------------

None

Example Playbook
----------------

Available under tests/test.yml


License
-------

BSD

Author Information
------------------

Samy Girard

#!/usr/bin/env python
# -*- coding: utf-8 -*-

import ansible_play
import re
from behave import *

@when('Create edge VM')
def step_impl(context):

    become_user_password = 'foo-whatever'
    run_data = {
        'app_id': context.params['app_id'],
        'app_env': context.params['app_env'],
        'vm_network': context.params['vm_network'],
        'vm_desc': context.params['vm_desc'],
        'vm_profile': context.params['vm_profile'],
        'vm_region': context.params['vm_region'],
        'vm_az': context.params['vm_az'],
        'vm_os': context.params['vm_os'],
        'vm_pubkey': context.params['vm_pubkey'],
        'data_disk': context.params['data_disk'],
        'state': "present",
        'vm_replication': context.params['vm_replication'],
        'vm_backup': context.params['vm_backup'],
        'code_irt': context.params['code_irt'],
        'deprecated_endClient': context.params['deprecated_endClient'],
    }
    if 'vm_hostname' in context.params:
        run_data['vm_hostname'] = context.params['vm_hostname']

    runner = ansible_play.Runner(
        hostnames = 'localhost',
        playbook = 'create.yml',
        tags = None,
        private_key_file = context.private_key,
        run_data = run_data,
        become_pass = become_user_password,
        verbosity = 100
    )

    stats = runner.run()
  
    print("Debug")
    run_success = True
    hosts = sorted(stats.processed.keys())
    for h in hosts:
        t = stats.summarize(h)
        print("{} => {}".format(h, t))
        if t['unreachable'] > 0 or t['failures'] > 0:
            run_success = False


    context.params['vm_hostname'] = runner.get_var('hostname')
    context.params['vm_ipaddr'] = runner.get_var('ip_address')
    context.params['vm_extra_disk'] = "{}G".format(run_data['data_disk'])

    assert run_success is True
    context.vm_created = True

    chaine = re.compile('\w* ([0-9]+)vCPU-([0-9]+)GB')
    res = chaine.search(context.params['vm_profile'])
    context.params['vm_cpu'] = res.group(1)
    context.params['vm_ram'] = res.group(2)

    print("Test Vm {} created with IP {}\n".format(context.params['vm_hostname'], context.params['vm_ipaddr']))

import logging

from tests.mock.mockdodv1 import MockDod
from edge.dns.dodv1.feeder import DnsFeeder
from edge.dns.dodv1.informer import DnsInformer
from tests.mock.mock import MockDod as MockDodv2

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

LIST_HOSTNAMES = ("dtrvlx10001",)


class MockedFeeder(MockDod, MockDodv2, DnsFeeder):

    def __init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname):
        MockDod.__init__(self, share_database=True)
        MockDodv2.__init__(self, tuple(), hostname=None, share_database=True)
        DnsFeeder.__init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname)


class MockedInformer(MockDod, DnsInformer):

    def __init__(self, hostname):
        MockDod.__init__(self, share_database=True)
        DnsInformer.__init__(self, hostname)


class TestDnsFeeder:

    def test_feed_dns_with_hostname_to_be_recorded(self):
        feeder = MockedFeeder(
            "DEV", "EU France (Greater Paris)", "eu-fr-paris-1", "ITEC_CLOUD_DEV_DC2_03", "trv", LIST_HOSTNAMES[0]
        )
        feeder.run()

    def test_get_infos_dns(self):
        infos = MockedInformer(LIST_HOSTNAMES[0]).run()
        assert infos[0]["vm_hostname"] == LIST_HOSTNAMES[0]

    def test_get_infos_dns_with_fake_hostname(self):
        try:
            MockedInformer("fake_hostname")
            assert False
        except Exception as err:
            assert "hostname must be alphanumeric" == err.args[0]

#!/usr/bin/python
# -*- coding: utf-8 -*-

import re
import logging

from dodaw.dodv1 import DodWrapper

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


HOSTNAME = "test_vm_edge_dodv1_by_integration_test"
HOSTNAME2 = "test_vm_edge_dodv1_by_integration_test_2"
NEW_HOSTNAME = "test_vm_edge_dodv1_by_integration_test_2_new"
DOMAIN = "fr.world.socgen"
SUBNET = "184.44.4.0/24"
SUBNETUSE = "srv"
REGEX_IP = r"^\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b$"


class TestDodV1(object):

    def test_get_next_free_ip(self):
        dod = DodWrapper()
        logger.debug(
            "Try to get ip within subnet={} with SUBNETUSE={}".format(SUBNET, SUBNETUSE)
        )
        ip = dod.get_next_free_ip(SUBNET, SUBNETUSE)
        obj_match = re.match(REGEX_IP, ip)
        assert obj_match.group()

    def test_host_add(self):
        dod = DodWrapper()
        logger.debug(
            "Try to add record for hostname={}, domain={}, subnet={}".format(
                HOSTNAME,
                DOMAIN,
                SUBNET
            )
        )
        result = dod.host_add(HOSTNAME, DOMAIN, SUBNET)
        assert result

    def test_host_update(self):
        dod = DodWrapper()
        result = dod.host_delete(HOSTNAME2, DOMAIN)
        assert result
        result = dod.host_delete(NEW_HOSTNAME, DOMAIN)
        assert result
        logger.debug(
            "Try to add record for hostname={}, domain={}, subnet={}".format(
                HOSTNAME2,
                DOMAIN,
                SUBNET
            )
        )
        result = dod.host_add(HOSTNAME2, DOMAIN, SUBNET)
        assert result
        search = dod.host_search_infos(HOSTNAME2)
        result = dod.host_update(HOSTNAME2, search[0].ip, DOMAIN, NEW_HOSTNAME)
        assert result
        search = dod.host_search_infos(NEW_HOSTNAME)
        assert search[0].infos.hostname == NEW_HOSTNAME
        search = dod.host_search_infos(HOSTNAME2)
        assert search == []
        result = dod.host_delete(NEW_HOSTNAME, DOMAIN)
        assert result

    def test_host_search_infos_for_hostname_which_exist(self):
        dod = DodWrapper()
        logger.debug("Try to get infos for pattern={}".format(HOSTNAME))
        result = dod.host_search_infos(HOSTNAME)
        first_value = result[0]
        assert first_value.ip
        assert first_value.infos.ip
        assert first_value.infos.hostname
        assert first_value.infos.reverse
        assert first_value.infos.map_filename
        assert first_value.infos.domain

    def test_host_delete(self):
        dod = DodWrapper()
        logger.debug(
            "Try to delete record for hostname={}, domain={}".format(
                HOSTNAME,
                DOMAIN
            )
        )
        result = dod.host_delete(HOSTNAME, DOMAIN)
        assert result

    def test_host_search_infos_for_hostname_which_does_not_exist(self):
        dod = DodWrapper()
        logger.debug(
            "Try to get infos for pattern=cumhaectaliaquesollicitaseiusaure".format(
                HOSTNAME,
                DOMAIN
            )
        )
        result = dod.host_search_infos("cumhaectaliaquesollicitaseiusaure")
        assert not result

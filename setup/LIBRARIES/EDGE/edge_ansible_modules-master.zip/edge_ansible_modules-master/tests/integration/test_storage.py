
# import os
# import sys
# # import pytest
# import logging

# sys.path.append(
#     os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
# )

# # from cloudaw.exception import CloudError

# from files.sg_gts_storage import VmImpl
# from files.sg_gts_storage import ConnectionHelperImp

# logging.basicConfig(level=logging.DEBUG)
# logger = logging.getLogger(__name__)


# class TestCloudVm(object):
#     def test_add_disk(self):
#         vm = VmImpl(hostname='dpgalx004')
#         ip_found = vm.extract_ip_address(vm.hostname_data)
#         print(ip_found)
#         try: 
#             response = vm.add_disk(20)
#             print(response)
#             assert True
#         except Exception as e: 
#             print(e.args[0])
#             assert False
#         finally:  
#             vm.token.delete()
#     def test_add_disk_error(self):
#         vm = VmImpl(hostname='dpgalx5901')
#         try: 
#             response = vm.add_disk(2100)
#             print(response)
#             assert False
#         except Exception as e: 
#             print(e.args[0])
#             assert True
#         finally:  
#             vm.token.delete()    
#     def test_add_disk_shell_cmd(self):
#         cnx = ConnectionHelperImp()
#         vm = VmImpl(hostname='dpgalx004')
#         ip_found = vm.extract_ip_address(vm.hostname_data)
#         print(ip_found)
#         try: 
#             response=cnx.cnxhelp_discover_disk(ip_found)
#             print(response)
#             assert True
#         except Exception as e: 
#             print(e.args[0])
#             assert False
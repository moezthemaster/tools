from logzero import logger
import re
import os
from .vra_inventory_uat import VRAInventory as VRAInventoryUat
from .vra_inventory_prod import VRAInventory as VRAInventoryProd
dirname = os.path.dirname(os.path.realpath(__file__))
if not dirname:
    FILE_EXPORT = os.path.join('conf', 'settings_prod.cfg')
else:
    FILE_EXPORT = os.path.join(dirname, 'conf', 'settings_prod.cfg')
os.environ["CLOUDAW_CONFIG_FILE"] = FILE_EXPORT
os.environ["EDGE_CONFIG_FILE"] = FILE_EXPORT

class VRAInventory(object):
    def __init__(self, trigram, check_uat, check_prod):
        logger.debug("__init__ %s", trigram)
        if check_uat:
            self._vra_inv_uat = VRAInventoryUat(trigram)
        else:
            self._vra_inv_uat = None
        if check_prod:
            self._vra_inv_prod = VRAInventoryProd(trigram)
        else:
            self._vra_inv_prod = None
        self._inventory = {}

    def add_infos_from_vra(self, vra_instance):
        logger.debug("add infos from vra")
        if vra_instance:
            inv = vra_instance.get_infos()
            for (key, value) in inv.iteritems():
                if key in self._inventory:
                    self._inventory[key].append(value)
                else:
                    self._inventory[key] = [value]

    def get_infos(self):
        logger.debug("get infos")
        if self._vra_inv_uat:
            self.add_infos_from_vra(self._vra_inv_uat)
        if self._vra_inv_prod:
            self.add_infos_from_vra(self._vra_inv_prod)

    def check_status(self, status_inventory):
        for (hostname, entries) in self._inventory.iteritems():
            for entry in entries:
                if 'EDGE' in entry['blueprint']:
                    status_host = status_inventory.check_edge(hostname)
                    status_ip = status_inventory.check_edge(entry["ip"])
                else:
                    status_host = status_inventory.check_status(hostname)
                    status_ip = status_inventory.check_status(entry["ip"])
                entry['status_host'] = status_host
                entry['status_ip'] = status_ip

    def output(self):
        for (hostname, entries) in sorted(self._inventory.iteritems()):
            print(hostname)
            for entry in entries:
                if entry['comment'] is None:
                    entry['comment'] = ""
                if hostname:
                    print(
                        "{}:{};{};{};{};{};{};{};{};{};{}".format(
                            hostname.encode('utf8'),
                            entry["status_host"]['edge'].encode('utf8'),
                            entry["status_host"]['os'].encode('utf8'),
                            entry['comment'].encode('utf8'),
                            entry["ip"].encode('utf8'),
                            entry["env"].encode('utf8'),
                            entry["creation"].encode('utf8'),
                            entry["expiration"].encode('utf8'),
                            entry["blueprint"].encode('utf8'),
                            entry["bg"].encode('utf8'),
                            entry["status_host"]['alive'].encode('utf8')
                        )
                    )

    def check_bg_mismatch(self):
        logger.debug("check BG mismatch")
        for (hostname, entries) in sorted(self._inventory.iteritems()):
            for entry in entries:
                if re.match("^p", hostname) and \
                        not re.match(".*[-_]PRD$", entry["bg"]):
                    print("{}:VRA:Non PRD BG".format(hostname))
                if re.match("^[dh]", hostname) and \
                        re.match(".*[-_]PRD$", entry["bg"]):
                    print("{}:VRA:PRD BG".format(hostname))

    def check_duplicates(self):
        logger.debug("check duplicates")
        for (hostname, entries) in sorted(self._inventory.iteritems()):
            if len(entries) >= 2:
                print("{}:VRA:Duplicate hostname PROD-UAT".format(hostname))

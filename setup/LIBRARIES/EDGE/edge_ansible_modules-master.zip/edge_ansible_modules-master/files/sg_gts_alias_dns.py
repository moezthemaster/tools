
import os
import sys
import logging

if "TREE_DIR" in os.environ.keys():
    ANSIBLE_MODULES_PATH = [
        os.path.join(os.environ["TREE_DIR"], 'roles/edge'),
        os.path.join(os.environ["TREE_DIR"], 'roles/dodaw'),
        os.path.join(os.environ["TREE_DIR"], "library"),
        os.path.join(os.environ["TREE_DIR"], 'roles/py_edge_vault'),
    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/edge',
        './roles/dodaw',
        './roles/py_edge_vault'
    ]
for path in ANSIBLE_MODULES_PATH:
    sys.path.append(path)

from ansible.module_utils.basic import AnsibleModule

from dodaw.dod import DodWrapper

from edge.interfaces import Dod
from edge.dns.dodv2.tools import ManageCname


logger = logging.getLogger(__name__)


class DodImpl(Dod):
    def __init__(self):
        self.dod_wrapper = DodWrapper()

    def search_dns_record(self, record_type, **kwargs):
        return self.dod_wrapper.search_record(record_type, **kwargs)

    def create_dns_record(self, dns_service, record_type, zone, view, hostname, **kwargs):
        return self.dod_wrapper.create_record(dns_service, record_type, zone, view, hostname, **kwargs)

    def delete_dns_record(self, dns_service, id):
        return self.dod_wrapper.delete_record(dns_service, id)

    def search_and_delete_dns_records(self, dns_service, record_type, limit_rows=10, **kwargs):
        return self.dod_wrapper.search_and_delete_records(dns_service, record_type, limit_rows, **kwargs)


class ManageCnameImpl(DodImpl, ManageCname):

    def __init__(
        self, hostname, alias, alias_zone, env=None, region_cloud=None,
        az_cloud=None, network_id=None, **kwargs
    ):
        DodImpl.__init__(self)
        ManageCname.__init__(
            self, env=env, region_cloud=region_cloud, az_cloud=az_cloud, network_id=network_id,
            hostname=hostname, alias=alias, alias_zone=alias_zone,
        )


PRESENT, ABSENT = 'present', 'absent'

FIELDS = {
    "app_env": {
        "type": "str",
        "choices": [
            'uat',
            'tst',
            'int',
            'dev',
            'hml',
            'prd'
        ],
        "required": False,
    },
    "vm_region": {
        "choices": [
            'EU France (Greater Paris)',
            'EU France (North)'
        ],
        "type": "str",
        "required": False,
    },
    "vm_az": {
        "choices": [
            'eu-fr-paris-1',
            'eu-fr-paris-2',
            'eu-fr-north-1'
        ],
        "type": "str",
        "required": False,
    },
    "vm_network": {
        "type": "str"
    },
    "vm_hostname": {
        "required": True,
        "type": "str",
        "default": None
    },
    "dns_alias_name": {
        "required": True,
        "type": "str"
    },
    "dns_alias_zone": {
        "required": True,
        "type": "str"
    },
    "state": {
        "default": PRESENT,
        "choices": [
            PRESENT,
            ABSENT,
        ],
        "type": "str",
    }
}


def main():
    module = AnsibleModule(argument_spec=FIELDS)
    env = module.params['app_env']
    region_cloud = module.params['vm_region']
    az_cloud = module.params['vm_az']
    network_id = module.params['vm_network']
    hostname = module.params['vm_hostname']
    alias = module.params['dns_alias_name']
    alias_zone = module.params['dns_alias_zone']
    state = module.params['state']

    try:
        manage_cname = ManageCnameImpl(
            hostname, alias, alias_zone, env=env,
            region_cloud=region_cloud, az_cloud=az_cloud, network_id=network_id,
        )
        if state == PRESENT:
            response = manage_cname.record_cname()
            module.exit_json(changed=manage_cname.changed, meta=response)
        elif state == ABSENT:
            response = manage_cname.delete_cname()
            module.exit_json(changed=manage_cname.changed, meta=response)
    except Exception as e:
        module.fail_json(msg=e.args[0])


if __name__ == '__main__':
  main()

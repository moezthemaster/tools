
[![CC0](https://upload.wikimedia.org/wikipedia/en/thumb/6/6b/Redis_Logo.svg/200px-Redis_Logo.svg.png)](https://redis.io/)


Role Redis
=========

Create a Redis Database and let you execute some admin tasks such as :
 * Creating a Redis Database. Version 3.2.4 is available.
 * Stop / Start Redis Service


If no action is specified when calling this role, it will execute the following actions :
 1. __create.yml__ :
   * installing requested packages
   * creating & enabling the Redis.service
 2. __configure.yml__ :
   * creating a Redis configuration file (Redis.conf)
   * starting Redis Service
 3. __start.yml__ :
   * starting Redis service


Here's a description of the other tasks that can be executed in this role, filling the *redis_action* with the name of the task requested :

 __stop.yml__ : stopping Redis service

 __delete.yml__ : decomissioning all the Redis configuration :
  * stopping Redis service
  * disabling Redis service
  * removing packages that were installed


This role is developped for FastIT & PAAP projects. Some updates may have to be done for other needs : contact us :email: FR-FR-RET-ODB-L3@socgen.com, or Fork it.



Requirements
------------
Facts gathering shouldn't be disabled.

Target servers must be RHEL7.


Role Variables
--------------
Here are the requested values for each action :

__create.yml__
- redis_version (should be "3.2.4-1.el7")

__configure.yml__
- redis_version
- redis_maxmemory (default = "300mb")
- You can override these values to modify the configuration file :
  - redis_protected_mode (default = "yes")
  - redis_port (default = "6379")
  - redis_timeout (default = "0")
  - redis_tcp_keepalive (default = "300")
  - redis_supervised (default = "no")
  - redis_loglevel (default = "notice")
  - redis_databases (default = "16")
  - redis_save (default = "")
  - #redis_save:  # seconds & keys values
  -    #- { seconds: "900", changes: "1" }
  -    #- { seconds: "300", changes: "10" }
  -    #- { seconds: "60",  changes: "10000" }
  - redis_dbfilename (default = "dump.rdb")
  - redis_password (default = "")
  - redis_maxclients (default = "")
  - redis_maxmemory_policy (default = "")   # v3.2 default : "noeviction" / v2.8 default value : "volatile-lru" /  secure value  "allkeys_lru"
  - redis_appendonly (default = "no")
  - redis_appendfilename (default = "appendonly.aof")
  - redis_appendfsync (default = "everysec")
  - redis_no_appendfsync_on_rewrite (default = "no")
  - redis_auto_aof_rewrite_percentage (default = "100")
  - redis_auto_aof_rewrite_min_size (default = "64mb")
  - redis_lua_time_limit (default = "10000"  # default value is 5000(ms))
  - redis_latency_monitor_threshold (default = "0")
  - redis_notify_keyspace_events (default = "")

__delete.yml__
- "validate_decomissioning == 'yes'"

Default Values :
redis_version_supported: [ "3.2.4-1.el7" ]



Dependencies
------------
None


Example Playbook
----------------

    - hosts: servers
      gather_facts: yes
      roles:
      - { role: role_redis,
           redis_action: "create",
           redis_version: "{{ redis_package_version }}"
        }
      - { role: role_redis,
           redis_action: "configure",
           redis_version: "{{ redis_package_version }}",
           redis_maxmemory: "{{ redis_maxmemory_size }}"
        }
      - { role: role_redis,
           redis_action: "start",
           redis_version: "{{ redis_version }}"
        }


Some example values that can be specified in a group_vars file : `~/group_vars/example.yml`
```yml
redis_package_version: "3.2.4-1.el7"
redis_maxmemory_size: "1024mb"
```



License
-------
[![CC0](https://www.usenix.org/legacy/events/usenix04/art/build_icons/bsd.gif)] (https://fr.wikipedia.org/wiki/Licence_BSD)

Author Information
------------------

GUFFROY Philippe


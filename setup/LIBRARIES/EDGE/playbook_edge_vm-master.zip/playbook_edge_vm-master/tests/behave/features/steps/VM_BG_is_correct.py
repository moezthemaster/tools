#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *


@then('VM BG is correct')
def step_impl(context):
    print("Test vm business group")
    print("###########################################################################################")

    bg_dev_hml_ret = "BG_GTS-RET"
    bg_prd_ret = "BG_GTS-RET_PRD"

    if context.params['vm_environment'] == 'UAT' or context.params['vm_environment'] == 'DEV':
        if bg_dev_hml_ret == context.params['business_group']:
            assert context.failed is False
        else:
            assert context.failed is True

    elif context.params['vm_environment'] == 'PRD':
        if bg_prd_ret == context.params['business_group']:
            assert context.failed is False
        else:
            assert context.failed is True


@then('VM mkt BG is correct')
def step_impl(context):
    print("Test vm mkt business group")
    print("###########################################################################################")

    bg_dev_hml_mkt = "BG_GTS-TRANSVERSE-RCR"
    bg_prd_mkt = "BG_GTS-TRANSVERSE-RCR_PRD"

    if context.params['vm_environment'] == 'UAT' or context.params['vm_environment'] == 'DEV':
        if bg_dev_hml_mkt == context.params['business_group']:
            assert context.failed is False
        else:
            assert context.failed is True

    elif context.params['vm_environment'] == 'PRD':
        if bg_prd_mkt == context.params['business_group']:
            assert context.failed is False
        else:
            assert context.failed is True

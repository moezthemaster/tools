
#!/applis/ccsp/virtualenv/py-ccs-celery/bin/python
# -*- coding: utf-8 -*-
import os
import sys

sys.path.insert(0, "/applis/ccsp/py-ccs-celery/src")

from ccs_celery.run_tasks import create_vm, delete_vm

SETTINGS_FILE_PATH = "/applis/ccsp/tmp/settings_prd.cfg"
EDGE_LIBRARIES = ['CCS_CELERY', 'INCUBAW', 'EDGE', 'VAULT', 'DODAW', 'WHATSAW', 'CLOUDAW']

class ManageVm():
    """

    """
    def __init__(self, vm_os, app_env, vm_hostname, app_id, vm_network, vm_pubkey, code_irt, vm_desc, data_disk):
        self.vm_os = vm_os
        self.app_env = app_env
        self.vm_hostname = vm_hostname
        self.vm_network = vm_network
        self.app_id = app_id
        self.vm_pubkey = vm_pubkey
        self.code_irt = code_irt
        self.vm_desc = vm_desc
        self.data_disk = data_disk
        
        try:
            for library in EDGE_LIBRARIES:
                os.environ["{}_CONFIG_FILE".format(library)] = SETTINGS_FILE_PATH
        except Exception:
            raise


    def create_full_vm(self):
        """

        :return:
        """

        t = create_vm.apply_async(
        kwargs={"vm_os": self.vm_os, "app_env": self.app_env, "vm_hostname": self.vm_hostname,
                "app_id": self.app_id, "vm_network": self.vm_network,
                "vm_pubkey": self.vm_pubkey,
                "code_irt": self.code_irt,
                "vm_desc": self.vm_desc,
                "data_disk": self.data_disk})
        try:
            t.wait(timeout=None)
        except:
            pass
        status = t.status
        return t, status

    def delete_vm(self):
        """

        :return:
        """
        
        t = delete_vm.apply_async(
        kwargs={"vm_os": self.vm_os, "app_env": self.app_env, "vm_hostname": self.vm_hostname,
                "app_id": self.app_id, "vm_network": self.vm_network,
                "vm_pubkey": self.vm_pubkey,
                "code_irt": self.code_irt,
                "vm_desc": self.vm_desc,
                "data_disk": self.data_disk})
        try:
            t.wait(timeout=None)
        except:
            pass
        status = t.status
        return t, status

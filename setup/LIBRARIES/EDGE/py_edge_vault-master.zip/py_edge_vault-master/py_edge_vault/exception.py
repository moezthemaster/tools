class VaultException(Exception):
    pass

class ImproperlyConfigured(VaultException):
    '''VAULT is somehow improperly configured'''
    pass
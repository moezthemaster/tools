# ansible libraries [DEPRECATED]

WARNING: #THIS REPO IS DEPRECATED #

See https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge_ansible_modules for new modules

GTS Cloud VM - Management : sg_gts_cloud_vm.py
----------------------------------------------
<pre>
  name:
    description:
    - vm hostname
    required: true

  trigram:
    description:
    - vm trigram
    required: true

  env:
    description:
    - vm environment
    choices: ['dev','prd']
    default: prd
    required: false

  size:
    description:
    - vm size
    choices: ['Micro 1vCPU-1GB', 'Small 1vCPU-2GB', 'Small-mem4 1vCPU-4GB', 'Medium-mem2 2vCPU-2GB', 'Medium 2vCPU-4GB', 'Medium-mem8 2vCPU-8GB', 'Medium-mem16 2vCPU-16GB', 'Medium-mem32 2vCPU-32GB', 'Large 4vCPU-8GB', 'Large-mem16 4vCPU-16GB', 'Large-mem32 4vCPU-32GB', 'XLarge 8vCPU-16GB', 'XLarge-mem32 8vCPU-32GB', 'XLarge-mem64 8vCPU-64GB', 'XLarge-mem128 8vCPU-128GB']
    default: Micro 1vCPU-1GB
    required: false

  ip:
    description:
    - vm ipv4 address
    required: true

  network:
    description:
    - vm network
    required: true

  region:
    description:
    - vm region
    choices: ['EU France (Greater Paris)']
    default: EU France (Greater Paris)
    required: false

  zone:
    description:
    - vm availability zone
    choices: ['eu-fr-paris-1']
    default: eu-fr-paris-1
    required: false

  desc:
    description:
    - vm description
    default: ''
    required: false

  profile:
    description:
    - vm operating system flavor
    choices: ['RHEL_7.3_x64-RET-EDGE','RHEL_7.2_x64-RET-EDGE', 'RHEL_7.2_x64-CLOUDCELL-RET-EDGE', 'CENTOS_7.0_x64-RET-EDGE']
    default: RHEL_7.3_x64-RET-EDGE
    required: true

  pubkey:
    description:
    - add authorized keys
    default: ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEA43kkbWmmtCfZwjsXlmQbeTGOVMlDMA0njeo65Gs42VCElN1R8gHyQisgUZa6lWkWp3z0Asqzc0ApMQUODDUC2v+u7yU2y0zF8vVKxySm1ev0GlhbAG0Zowf5Q4I0XLEXsmOpMrXUG5GFMBuWSiMiWgPDyGCVgZjj7+MVjTrXIisjYTe40ZyUIGdtiboxkbBs1sbCG8vhha4VFUjTmkzkxiFgVzro08BCzlgZnACGSJWPFC88LE1NeOAGM/lfOmVuIC940zhJIxF09K4Prmd2HO7w2g3q/fSv9hHeX4loxPtOgbvQArLUyo/0aMf24BYgnYJoUqBw311hjKG+xLOpdw== postinstall@retinf
    type: str
    required: False

  disk:
    description:
    - vm data disk size
    choices: ['20', '60', '160, '300', '500', '750', '1000', '2000']
    default: 20
    required: false



  state:
    choices: [ "present", "absent" ]
    default: present
    description:
    - Control if the vm exists or not.
    required: false
</pre>
Requirements `/etc/ansible/gts_cloud_vm.cfg`
<pre>
[URL_DEV]
;UAT - HOMOL
urlRoot: https://cldcaccafeh01.fr.world.socgen

[URL_PRD]
;PROD - PRD
urlRoot: https://cldcaccafep01.fr.world.socgen

[CATALOG]
catalogSuffix: /catalog-service/api/consumer/entitledCatalogItems
consumerSuffix: /catalog-service/api/consumer/requests
querySuffix: /catalog-service/api/consumer/resources/types/Infrastructure.Machine/?page=n&limit=n
trigram: CIN
filter: Get_BG_List_From_Trigram

[TOKEN]
tokenSuffix: /identity/api/tokens/

[AUTH_DEV]
;CREDENTIAL UAT
username: EAN_DEV_SVC@EUR
password: ******
tenant: sgcloudhom

[AUTH_PRD]
;CREDENTIAL PRD
username: EAN_PRD_SVC@EUR
password: *****
tenant: sgcloud
</pre>

DoDv2 - Management : sg_gts_dod.py
----------------------------------
<pre>
  name:
    description:
    - dns A record: If name is not provided, it is generated using environment and trigram (ex dpgalx001). The first available name in DNS is used.
    required: False
    

  subnet:
    description:
    - dns record network
    required: true

  zone:
    description:
    - record availability zone
    required: true

  publish:
    description:
    - record alias
    required: true

  state:
    choices: [ "present", "absent" ]
    default: present
    description:
    - Control if the vm exists or not.
    required: false
</pre>
Requirements `/etc/ansible/gts_dod.cfg`
<pre>
[DOD]
urlRoot: https://dnsondemand.dns20.socgen
urlSuffix: /dns-record-rest
dnsService: PRD2 France RET
username: username
password: ******
</pre>

GTS Cloud VM PubKey - Management : sg_gts_cloud_pubkey.py
---------------------------------------------------------
<pre>
  name:
    description:
    - vm hostname
    required: true

  env:
    description:
    - vm environment
    choices: ['dev','prd']
    default: prd
    required: false

  ip:
    description:
    - vm ipv4 address
    required: true

  state:
    choices: [ "present", "absent" ]
    default: present
    description:
    - Control if the vm exists or not.
    required: false
</pre>
Requirements `/etc/ansible/gts_cloud_pubkey.cfg`
<pre>
[ROOT_KEY]
path=/path/to/root/priv/key/.ssh/id_rsa
</pre>

WHATS Management - sg_gts_idm module
---------------------------------------------------------
Example playbook:


```yml

- hosts: localhost

  vars:
    - vm_hostname: "your server"
    - ip_address: "your server ip address"
    - app_id: "your trigram"
    - environment: "your environnement"

  tasks:

    - name: whats_enrollement
      sg_gts_idm:
        whats_hostname: "{{vm_hostname}}"
        whats_ip: "{{ip_address}}"
        whats_trigram: "{{app_id}}"
        whats_environment: "{{environment}}"

    - name: whats_ununrolement
      sg_gts_idm:
        whats_hostname: "{{vm_hostname}}"
        whats_environment: "{{environment}}"
        state: absent
    
    - name: check ip address
      sg_gts_idm:
        whats_hostname: "{{vm_hostname}}"
        whats_ip: "{{ip_address}}"
        whats_environment: "{{environment}}"
        state: check_ip
        
    - name: check hostname
      sg_gts_idm:
        whats_hostname: "{{vm_hostname}}"
        whats_ip: "{{ip_address}}"
        whats_environment: "{{environment}}"
        state: check_hostname
```

TODO
----
- mettre le publish à vide quand il n'y pas besoin de cname et modifier la fonction dans le module dod en conséquence.
- eviter le redondance des infos dans les readme

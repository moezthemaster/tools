#!/usr/bin/python
# -*- coding: utf-8 -*-

#



from  edge.conf import settings


KWARGS_SEARCH = {
    'dns_service':settings.DOD_DNS_SERVICE,
    'view': 'production',
}
A='A'

DEFAULT_IP_ADDRESS = '127.0.0.1'
DEFAULT_FQDN = 'localhost.localdomain'


class ResponseMixin(object):
    def _get_response(self):
        '''
        This class is a Mixin for other classes that inherit from edge.interfaces.Dod and
        handle the attribute self.records which is a dictionary
        :param vm_subnet:
        :return: a dictionary
        '''
        records_A_found = self.search_dns_record(record_type=A,
                                                 hostname='^%s$' % self.hostname,
                                                 dns_service=settings.DOD_DNS_SERVICE,
                                                 view='production')
        ip_addr = DEFAULT_IP_ADDRESS
        fqdn = DEFAULT_FQDN
        record_A_id = self.record_A['id'] if self.record_A else ''
        for record_A in records_A_found:
            ip_addr = record_A.get('ip', DEFAULT_IP_ADDRESS)
            fqdn = record_A.get('hostname_fqdn', DEFAULT_FQDN)
            if not record_A_id:
                record_A_id = record_A.get('id', '')
        response = {
            'output': records_A_found,
            'id': record_A_id,
            'ip_address': ip_addr,
            'subnet': self.network_cidr,
            'fqdn': fqdn,
        }
        return response


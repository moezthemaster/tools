#!/usr/bin/env python
# -*- coding: utf-8 -*-

''' Main census module. '''

__author__ = "FT Edge"
__version__ = "0.1.0"

import logging
import logzero
logzero.loglevel(level=logging.WARNING)
from logzero import logger
import argparse

import inventory


def init_logger(level):
    ''' Init logger base on level specified.'''
    if level is None:
        level = 0
    if level >= 2:
        logzero.loglevel(level=logging.DEBUG)
    elif level == 1:
        logzero.loglevel(level=logging.INFO)
    else:
        logzero.loglevel(level=logging.WARNING)


def main(args):
    ''' Main function for inventory.'''
    init_logger(level=args.verbose)
    vra_inventory = inventory.VRAInventory(trigram=args.trigram,
                                           check_uat=not args.skip_uat_vra,
                                           check_prod=not args.skip_prod_vra)
    status_inventory = inventory.StatusInventory()
    
    # Inventaire VRA pour le trigramme
    vra_inventory.get_infos()

    # Update du status des VM
    vra_inventory.check_status(status_inventory)

    if args.cloud_inventory:
        print("## Cloud inventory for trigram : {}".format(args.trigram))
        vra_inventory.output()

    # Inventaire DNS pour le trigramme
    dod_inventory = inventory.DodInventory()
    dod_inventory.search(trigram=args.trigram)
    dod_inventory.search_from_vra(vra_inventory)

    dod_inventory.check_status(status_inventory)
    if args.dns_inventory:
        print("## DNS inventory for trigram : {}".format(args.trigram))
        dod_inventory.output()

    # Inventaire Marley pour le trigramme
    marley_inventory = inventory.MarleyInventory()
    marley_inventory.get_infos(trigram=args.trigram)
    marley_inventory.check_status(status_inventory)
    
    if args.marley_inventory:
        print("## Marley inventory for trigram : {}".format(args.trigram))
        marley_inventory.output()

    # Inventaire Whats pour les VM et les ips
    whats_inventory = inventory.WhatsInventory()
    whats_inventory.get_infos(vra_inventory, dod_inventory)
    whats_inventory.check_status(status_inventory)

    if args.whats_inventory:
        print("## Whats inventory for trigram : {}".format(args.trigram))
        whats_inventory.output()

    logger.debug("Checking for inconsistencies")
    print "### Checking for inconsistencies"

    vra_inventory.check_duplicates()
    vra_inventory.check_bg_mismatch()

    dod_inventory.check_ghost_records(vra_inventory)
    dod_inventory.check_incorrect_records(vra_inventory)

    marley_inventory.check_ghost_records(vra_inventory)
    marley_inventory.check_missing_records(vra_inventory)

    whats_inventory.check_records(vra_inventory)
    whats_inventory.check_ghost_records(vra_inventory)
    whats_inventory.check_incorrect_records(vra_inventory)


if __name__ == '__main__':
    """ This is executed when run from the command line """

    parser = argparse.ArgumentParser()

    # Required positional argument
    parser.add_argument("trigram", help="The trigram to inventory")

    # Optional verbosity counter (eg. -v, -vv, -vvv, etc.)
    parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Verbosity (-v, -vv, etc)")

    # Specify output of "--version"
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s (version {version})".format(version=__version__))

    parser.add_argument("-c", "--cloud-inventory",
                        action="store_true", dest="cloud_inventory",
                        default=False,
                        help="Output cloud inventory")
    parser.add_argument("-d", "--dns_inventory",
                        action="store_true", dest="dns_inventory",
                        default=False,
                        help="Output DNS inventory")
    parser.add_argument("-m", "--marley_inventory",
                        action="store_true", dest="marley_inventory",
                        default=False,
                        help="Output Marley inventory")
    parser.add_argument("-w", "--whats_inventory",
                        action="store_true", dest="whats_inventory",
                        default=False,
                        help="Output Whats inventory")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--no_uat",
                       action="store_true", dest="skip_uat_vra",
                       default=False,
                       help="Skip calls to UAT VRA")
    group.add_argument("--no_prod",
                       action="store_true", dest="skip_prod_vra",
                       default=False,
                       help="Skip calls to PROD VRA")

    args = parser.parse_args()
    main(args=args)

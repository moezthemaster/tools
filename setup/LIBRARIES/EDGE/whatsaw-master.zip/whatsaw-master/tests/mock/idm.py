#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
from requests.models import Response
from whatsaw.idm import IdmWrapper
from whatsaw.token import Token
from whatsaw.conf import settings

HOSTNAME = "dpgalxunit001"
IP_ADDRESS = "1.5.95.2"

class MockedIdmWrapper(IdmWrapper):
    def __init__(self, hostname):
        IdmWrapper.__init__(self, hostname)
    
class MockedToken(Token):
    def __init__(self, env):
        Token.__init__(self, env)

def mock_vault():
    return {
        "username": "userX",
        "password": "Pass"
    }

def mock_get_exitcode_stdout_stderr():
    return 0, 0, ""

def mock_request(method):
    realm = getattr(settings, 'REALM_DEV').lower()
    realm.split('.')[0]
    if method == "iru_host_add":
        result = {
            u'id': 0,
            u'principal': u'iru_pga_edge_service@{}'.format(realm.upper()),
            u'version': u'4.5.0',
            u'result': {
                u'failed': {},
                u'result': {
                    u'dn': u'fqdn={}.{},cn=computers,cn=accounts,dc={},dc={},dc={}'.format(HOSTNAME, realm, realm.split('.')[0], realm.split('.')[1], realm.split('.')[2]),
                    u'has_keytab': False,
                    u'cn': [u'{}.{}'.format(HOSTNAME, realm)],
                    u'objectclass': [u'ipaobject', u'nshost', u'ipahost', 
                                     u'pkiuser', u'ipaservice', u'ieee802device', 
                                     u'ipasshhost', u'top', u'ipaSshGroupOfPubKeys'],
                    u'ipakrbokasdelegate': False,
                    u'description': [u'EDGE SERVER'],
                    u'fqdn': [u'{}.{}'.format(HOSTNAME, realm)],
                    u'nsosversion': [u'Linux'],
                    u'managing_host': [u'{}.{}'.format(HOSTNAME, realm)],
                    u'memberof_hostgroup': [u'hg_a_pga', u'hg_p_std'],
                    u'ipauniqueid': [u'520ceec0-7925-11e8-9e7d-005056857189'],
                    u'has_password': True,
                    u'ipakrbrequirespreauth': True,
                    u'ipakrboktoauthasdelegate': False,
                    u'managedby_host': [u'{}.{}'.format(HOSTNAME, realm)],
                    u'serverhostname': [HOSTNAME],
                    u'memberofindirect_hbacrule': [
                        u'HB_T_INXN3',u'HB_T_SDIV', u'HB_T_AIXN2', u'HB_T_DB2N2',
                        u'HB_T_BTBSI', u'HB_T_TEAMHABIL', u'HB_T_BACKN3', u'HB_T_OMTR',
                        u'HB_T_INXN2', u'HB_T_BACKN2', u'HB_T_BTAPIIBF', u'HB_T_MDBMFA',
                        u'HB_T_STORN1', u'HB_T_BDDF', u'HB_T_SUPPMUT', u'HB_T_BHF',
                        u'HB_T_AIXN1', u'HB_T_MDBMFI', u'HB_T_DB2N3', u'HB_T_BTAPISFS',
                        u'HB_T_DMQINF', u'HB_T_LNXN2', u'HB_T_BTAPIMOP', u'HB_T_BTAPIBKS',
                        u'HB_T_BACKN1', u'HB_T_MDBMFAN2', u'HB_T_ORAN3', u'HB_T_BTAPIPSM',
                        u'HB_T_BTAUTOL1', u'HB_T_STORN2', u'HB_T_BTFRO', u'HB_T_MDBBFT',
                        u'HB_T_SUPRVISION', u'HB_T_BTAUTOL2', u'HB_T_MDBMFIN2', u'HB_T_WEBM',
                        u'HB_T_STORN3', u'HB_T_BTAPICSC', u'HB_T_CTE', u'HB_T_UNDI',
                        u'HB_T_BDDP', u'HB_T_BDDU', u'HB_T_MDBDMQ', u'HB_T_BTAPIDIS',
                        u'HB_T_IPMAPI', u'HB_T_MDBBFTN2', u'HB_T_GCL', u'HB_T_ORAN2',
                        u'HB_T_BTMET', u'HB_T_LNXN1', u'HB_T_SUPER', u'HB_T_EAO'
                    ]
                },
                u'value': u'{}.{}'.format(HOSTNAME, realm),
                u'summary': u'Added host "{}.{}"'.format(HOSTNAME, realm)
            },
            u'error': None
        }
    elif method == "iru_host_del":
        result = {
            u'id': 0,
            u'principal': u'iru_pga_edge_service@{}'.format(realm.upper()),
            u'version': u'4.5.0',
            u'result': {
                u'failed': {},
                u'value': u'{}.{}'.format(HOSTNAME, realm),
                u'summary': u'Deleted host "{}.{}"'.format(HOSTNAME, realm)
            },
            u'error': None
        }
    elif method == "iru_ip4_exists":
        result = {
            u'id': 0,
            u'principal': u'iru_pga_edge_service@{}'.format(realm.upper()),
            u'version': u'4.5.0',
            u'result': {
                u'additional': {
                    u'idnsname': [HOSTNAME]
                },
                u'value': IP_ADDRESS,
                u'summary': u'IP "{}" exists'.format(IP_ADDRESS)
            },
            u'error': None
        }
    elif method == "iru_host_exists":
        result = {
            u'id': 0,
            u'principal': u'iru_pga_edge_service@{}'.format(realm.upper()),
            u'version': u'4.5.0',
            u'result': {
                u'additional': {
                    u'arecord': [IP_ADDRESS]
                },
                u'value': u'{}.{}'.format(HOSTNAME, realm),
                u'summary': u'Host "{}.{}" exists'.format(HOSTNAME, realm)
            },
            u'error': None
        }
    else:
        result = {}

    resp = Response()
    resp.status_code = 200
    resp._content = json.dumps(result).encode()   
    return resp

def mock_request_error(method):
    realm = getattr(settings, 'REALM_DEV').lower()
    realm.split('.')[0]
    if method == "iru_host_add":
        result = {
            u'id': 0,
            u'principal': u'iru_pga_edge_service@{}'.format(realm.upper()),
            u'version': u'4.5.0',
            u'result': None,
            u'error': {
                u'message': u'IP address {} is already assigned in domain {}..'.format(IP_ADDRESS, realm),
                u'code': 4002,
                u'data': {},
                u'name': u'DuplicateEntry'
            }
        }
    elif method == "iru_host_del":
        result = {
            u'id': 0,
            u'principal': u'iru_pga_edge_service@{}'.format(realm.upper()),
            u'version': u'4.5.0',
            u'result': None,
            u'error': {
                u'message': u'Insufficient access: ',
                u'code': 2100,
                u'data': {
                    u'info': u''
                },
                u'name': u'ACIError'
            }
        }
    elif method == "iru_ip4_exists":
        result = {
            u'id': 0,
            u'principal': u'iru_pga_edge_service@{}'.format(realm.upper()),
            u'version': u'4.5.0',
            u'result': None,
            u'error': {
                u'message': u'The IPv4 address "{}" is not assigned in this domain.'.format(IP_ADDRESS),
                u'code': 4001,
                u'data': {
                    u'reason': u'The IPv4 address "{}" is not assigned in this domain.'.format(IP_ADDRESS)
                },
                u'name': u'NotFound'
            }
        }
    elif method == "iru_host_exists":
        result = {
            u'id': 0,
            u'principal': u'iru_pga_edge_service@{}'.format(realm.upper()),
            u'version': u'4.5.0',
            u'result': None,
            u'error': {
                u'message': u'The host "{}.{}" does not exist.'.format(HOSTNAME, realm),
                u'code': 4001,
                u'data': {
                    u'reason': u'The host "{}.{}" does not exist.'.format(HOSTNAME, realm)
                },
                u'name': u'NotFound'
            }
        }
    else:
        result = {}

    resp = Response()
    resp.status_code = 200
    resp._content = json.dumps(result).encode()   
    return resp
import steps.ansible_play
import subprocess


def after_scenario(context, scenario):

    try:
        output = subprocess.check_output('hostname').strip()
    except Exception:
        raise
    if output == "pedglx112":
        playbook_delete = "delete_mkt.yml"
    else:
        playbook_delete = "delete.yml"

    if hasattr(context, 'vm_created') and not hasattr(context, 'vm_purged') and not context.params['vm_hostname'] == "":

        become_user_password = 'foo-whatever'
        run_data = {
            'app_id': context.params['app_id'],
            'app_env': context.params['app_env'],
            'vm_hostname': context.params['vm_hostname'],
            'state': "absent",
            'code_irt': context.params['code_irt'],
            'vm_supervision': context.params['vm_supervision'],
            'vm_pubkey': context.params['vm_pubkey'],

        }

        runner = steps.ansible_play.Runner(
            hostnames='localhost',
            playbook="{}".format(playbook_delete),
            tags='',
            private_key_file=context.private_key,
            run_data=run_data,
            become_pass=become_user_password,
            verbosity=100,
            connection='local'
        )

        stats = runner.run()

        print("Debug")
        run_success = True
        hosts = sorted(stats.processed.keys())
        for h in hosts:
            t = stats.summarize(h)
            print("{} => {}".format(h, t))
            if t['unreachable'] > 0 or t['failures'] > 0:
                run_success = False

        assert run_success is True
        context.vm_purged = True

        print("Vm {} with IP {} deleted\n".format(context.params['vm_hostname'], context.params['vm_ipaddr']))

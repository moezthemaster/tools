#!/usr/bin/env bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PID_FILE=server.pid

# Python install
if [ ! -d ${HOME}/tools/python/bin ]; then
    curl -k https://sgithub.fr.world.socgen/raw/CDPlatformPython/python-configuration/master/install.sh | sh
fi
export PATH=${HOME}/tools/python/bin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin

cd ${DIR}/..

export CONFFILE_PATH={{conffile_path}}

pip install -r requirements.txt
python manage.py db migrate
python manage.py db upgrade
gunicorn manage:app -c config/config.py --pid ${PID_FILE}

#! /bin/sh

if [ $# -ne 1 ]; then
  echo "Please provide the filename containing the list of servers"
  exit 1
fi
filename=$1
if [ ! -f $filename ]; then
  echo "$filename not found"
  exit 1
fi
cat $filename | while read line 
do
     #trigram="${line:1:3}" 
     echo "run check sudo on $line"
     if [ -f logs/${line}.log ]; then 
       mv logs/${line}.log logs/${line}.`date +%s`.log
     fi
     ansible-playbook -i $line, update_sudoers.yml > logs/${line}.log #-e "trigram=$trigram" 
done

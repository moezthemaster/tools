import static sgcib.coc.bootcamp.Git.*
import static sgcib.coc.bootcamp.Maven.*
import static sgcib.coc.bootcamp.Utils.*

properties = readProperties(this, 'jenkins/job.properties')
String slave = properties.slave

String gitCreds = properties.gitCreds
String gitRepo = properties.gitRepo

String root = properties.xldRoot
String xldServer = properties.xldServer
String xldPort = properties.xldPort

String itaasCreds = properties.itaasCreds
String centrify_zone= properties.centrify_zone
String vmCreds = properties.itaasVmCreds
String itaasTrigram = properties.itaasTrigram

String mavenVersion = properties.mavenVersion
String jdkVersion = properties.jdkVersion

node(slave) {

    stage('Checkout') {
        git branch: "${BRANCH}", credentialsId: "${gitCreds}", url: "${gitRepo}", refspec: 'origin'
    }

    stage('Clean current dev') {
        try {
            mvn(this, jdkVersion, mavenVersion, 'clean xldeploy:clean')
        }
        catch (e) {
            echo "Error while undeploying : ${e}"
            echo "Moving on"
        }
    }

    stage('Query for a new VM') {
        withCredentials([usernamePassword(credentialsId: itaasCreds, passwordVariable: 'IAC_PASSWORD', usernameVariable: 'IAC_USER'),
                         usernamePassword(credentialsId: vmCreds, passwordVariable: 'VM_PASSWORD', usernameVariable: 'VM_USER')]) {
            sh "sed 's/VM_USER/${VM_USER}/g' -i puppet/basic_env.json"
            sh "sed 's/CENTRIFY_ZONE/${centrify_zone}/g' -i puppet/basic_env.json"
            sh "sed 's/TRIGRAM/${itaasTrigram}/g' -i puppet/basic_env.json"
            gts_itaas iacFile: 'puppet/basic_env.json', login: IAC_USER, password: IAC_PASSWORD
        }
    }

    stage('Update XLD configuration') {
        withCredentials([usernamePassword(credentialsId: vmCreds, passwordVariable: 'VM_PASSWORD', usernameVariable: 'VM_USER')]) {
            sh "chmod u+x ${WORKSPACE}/puppet/generate_yaml.sh;${WORKSPACE}/puppet/generate_yaml.sh \"${env.IAC_PYTHON_HOSTNAME}\" \"${VM_USER}\" \"${VM_PASSWORD}\" \"${DEPLOYMENT_FOLDER}\" \"${root}\" \"https://${xldServer}:${xldPort}\""
        }
    }

    stage('Push new configuration') {
        push(this, gitCreds, 'origin', "${BRANCH}") {
            sh "git add ${WORKSPACE}/puppet/hiera/dev.yaml"
            sh "git commit -m 'Updating dev env with ${env.IAC_PYTHON_HOSTNAME}'"
        }
    }
}

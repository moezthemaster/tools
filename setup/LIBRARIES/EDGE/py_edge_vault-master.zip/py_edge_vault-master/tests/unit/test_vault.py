import pytest
import unittest
try:
    from unittest import mock
except ImportError:
    import mock
import requests
from py_edge_vault import secrets
from tests.mock.vault import mocked_secret, mocked_client_token
from py_edge_vault.exception import  VaultException


class TestVault(unittest.TestCase):
    
    @mock.patch('requests.get')
    @mock.patch('requests.post')
    def test_get_good_secrets(self, mock_get, mock_post):
        CONTEXT = 'test_context'
        ENV = 'uat'
        mock_get.return_value = mocked_client_token()
        mock_post.return_value = mocked_secret(context=CONTEXT, env=ENV)
        result = {"password": "dummy", "username": "test"}
        data = secrets.get_secrets(context=CONTEXT, env=ENV)
        self.assertEqual(data, result)

    @mock.patch('requests.get')
    @mock.patch('requests.post')
    def test_get_bad_secrets(self, mock_get, mock_post):
        CONTEXT = 'test_context'
        mock_get.return_value = mocked_client_token()
        mock_post.return_value = mocked_secret(context=CONTEXT)
        self.assertRaises(VaultException, secrets.get_secrets, CONTEXT)

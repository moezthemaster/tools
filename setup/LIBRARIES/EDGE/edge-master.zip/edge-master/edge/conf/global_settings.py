'''
Default settings. Override these with settings in the .py file pointed to
by the EDGE_CONFIG_FILE environment variable.
'''

DEBUG = False

###########
#   DOD   #
###########

DOD_DNS_SERVICE = ''  # e.g.: 'UAT France RET'

#############
# CLOUD_VRA #
#############

CLOUD_VRA_TENANT = ''  # e.g.: 'SGCLOUDHOM'
CLOUD_VRA_TRIGRAM = 'api'
CLOUD_MAX_WAIT_ON_DESTROY = 600 # Max seconds to wait after VM destroy call
BG_ALLOWED_TO_DEPLOY_IN_MKT = (
    'BG_GTS-TRANSVERSE-RCR', 'BG_GTS-TRANSVERSE-RCR_PRD',
    'BG_GTS-PAS-DBAAS', 'BG_GTS-PAS-DBAAS_PRD',
    'BG_GTS-PAS-BAASBEB', 'BG_GTS-PAS-BAASBEB_PRD',
    'BG_GTS-PAS-CAAS', 'BG_GTS-PAS-CAAS_PRD',
    'BG_GTS-IAS-SDN', 'BG_GTS-IAS-SDN_PRD'  
)

###############
# ELASTIC KPI #
###############

KPI_CREDENTIALS_GROUP = ''  # e.g.: ELASTIC_PROD_CREDENTIALS
KPI_ENV = ''
ELK_URL = ''

###########
# LOGGING #
###########

LOGGER_LEVEL = 'WARN'


#############
#  PUBKEY  #
#############

PUBKEY_CREDENTIALS_GROUP = 'key'  # by default ROOT_KEY



##############
#  MANAGE IP #
##############

NB_ATTEMPT = 3

##############
#   ZABBIX   #
##############

ZBXAPIURLRET = "https://pspvlx009.dns20.socgen/zabbix/api_jsonrpc.php"
ZBXAPIURLMKT = "https://selprdweb010.fr.world.socgen/zabbix/api_jsonrpc.php"

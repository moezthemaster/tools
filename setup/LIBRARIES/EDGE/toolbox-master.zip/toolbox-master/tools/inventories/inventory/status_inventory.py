import os
import sys
from logzero import logger

dirname = os.path.dirname(os.path.realpath(__file__))
if not dirname:
    FILE_EXPORT = os.path.join('conf', 'settings_prod.cfg')
else:
    FILE_EXPORT = os.path.join(dirname, 'conf', 'settings_prod.cfg')
os.environ["EDGE_CONFIG_FILE"] = FILE_EXPORT

from edge.exception import EdgeException
from edge.connection.connectionhelper import ConnectionHelper


class StatusInventory:
    def __init__(self):
        logger.debug("__init__")
        self._status = ConnectionHelper()
        self._inventory = {}

    def add_infos(self, hostname, alive, edge, os, uname=""):
        if hostname not in self._inventory:
            self._inventory[hostname] = {'alive': alive, 'edge': edge, 'os': os, "uname": uname}

    def check_edge(self, hostname):
        logger.debug("check edge")
        if hostname in self._inventory:
            return self._inventory[hostname]

        uname = ""

        alive_ssh = self._status.is_alive(address=hostname, port=22, timeout=3)
        if alive_ssh:
            alive = "Alive"
            try:
                uname = self._status.check_ssh_connection(ip_address=hostname, timeout=3, cmd='sudo sh -c "uname -a"')
                logger.debug("uname=%s", uname)
            except EdgeException as e:
                logger.debug("exception %s", repr(e))
        else:
            alive = "Dead"
        os = "Linux"
        edge = "Edge"

        self.add_infos(hostname, alive, edge, os, uname)
        logger.debug("%s %r", hostname, self._inventory[hostname])
        return self._inventory[hostname]

    def check_edge(self, hostname):
        logger.debug("check edge")
        if hostname in self._inventory:
            return self._inventory[hostname]

        alive_ssh = self._status.is_alive(address=hostname, port=22, timeout=3)
        if alive_ssh:
            alive = "Alive"
        else:
            alive = "Dead"
        os = "Linux"
        edge = "Edge"

        self.add_infos(hostname, alive, edge, os)
        logger.debug("%s %r", hostname, self._inventory[hostname])
        return self._inventory[hostname]

    def check_status(self, hostname):
        logger.debug("get_infos")
        if hostname in self._inventory:
            return self._inventory[hostname]

        alive_ssh = self._status.is_alive(address=hostname, port=22, timeout=3)
        alive_rdp = self._status.is_alive(address=hostname, port=3389, timeout=3)
        alive_rdp_sg = self._status.is_alive(address=hostname, port=33089, timeout=3)
        if alive_ssh or alive_rdp or alive_rdp_sg:
            alive = "Alive"
        else:
            alive = "Dead"
        os = "Unknown"
        edge = "Core"
        uname = ""
        if alive_ssh:
            os = "Linux"
            try:
                uname = self._status.check_ssh_connection(ip_address=hostname, timeout=3, cmd='sudo sh -c "uname -a"')
                logger.debug("uname=%s", uname)
                edge = "Edge"
            except EdgeException as e:
                logger.debug("exception %s", e)

        if alive_rdp or alive_rdp_sg:
            os = "Windows"
            try:
                rdp_sattus = self._status.check_rdp_connection(ip_address=hostname, timeout=3)
            except EdgeException as e:
                logger.debug("exception %s", e)

        self.add_infos(hostname, alive, edge, os, uname)
        logger.debug("%s %r", hostname, self._inventory[hostname])
        return self._inventory[hostname]

    def output(self):
        for (key, entries) in sorted(self._inventory.iteritems()):
            for entry in entries:
                print("{} : {}".format(key, entry))

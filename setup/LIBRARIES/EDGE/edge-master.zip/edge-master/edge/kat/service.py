import logging

from edge.conf import settings
from edge.conf import kat_marley
from edge.interfaces import Kat
from edge.exception import EdgeException

logging.basicConfig(level=logging.getLevelName(settings.LOGGER_LEVEL))
logger = logging.getLogger(__name__)


class KatService(Kat):
    def get_client(self, trigram, irt_code, default_client=''):
        '''
        return translated client from kat if exists.
        Otherwise return default client if not empty, raises an exception if default client is empty
        :param trigram: string
        :param irt_code: string
        :param default_client: string. optional
        :return: a string: client_ME
        '''
        kat_response = self.get_single_component_data(trigram, irt_code)
        if not kat_response:
            raise EdgeException('couple trigram {} and irt_code {} not found in Kat'.format(trigram, irt_code))
        client = ''
        try:
            client = kat_response[0]['client_ME']
            mapping = kat_marley.KAT_MRL
            for item in mapping:
                if item in client:
                    return mapping[item]
        except Exception as e:
            pass
        if default_client:
            logger.warning('default_endClient used instead of client_ME {} from Kat... '
                           'it was not translated successfully'.format(client))
            return default_client
        raise EdgeException('client_ME {} failed to be translated from Kat, '
                            'you can force the deprecated_endClient instead'.format(client))

# py-vault-edge
This module is used to get edge credentials from vault.

For our Team, the vault is mainly used to store credentials and store a whitelist of authorized commands to be executed.

In order to get credentials, you need to provide the context and optionnally the environment.

|   context           | env  choices                           |
|:-----------------:|:---------------------------------------------:|
|  kat     |            prod               |
|  marley         |          prod         |
|  elastic           |          prod            |
|  hpoo           |            prod          |
|  whats           |       dev, hml, prod               |
|  root_key           |         None             |
|  key           |         None             |
|  artifactory           |        None              |
|  ret-dodv2           |          prod, uat            |
|  mkt-dodv1           |     prod, uat, dev                 |
|  tower          |         None             |
|  whitelist         |          None            |
|  vra         |           prod, uat           |
|  ad         |           windows           |
|automation   | id_rsa_base64, ansible_vault|

## Usage

```
from py_edge_vault import secrets

vault_secret = secrets.get_secrets('mkt-dodv1', 'prod')
username = vault_secret['username']
password = vault_secret['password']

```

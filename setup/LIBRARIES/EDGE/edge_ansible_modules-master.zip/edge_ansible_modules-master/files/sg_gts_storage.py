import logging
import io
import sys
import os

if "TREE_DIR" in os.environ.keys():
    ANSIBLE_MODULES_PATH = [
        os.path.join(os.environ["TREE_DIR"], 'roles/edge'),
        os.path.join(os.environ["TREE_DIR"], 'roles/cloudaw'),
        os.path.join(os.environ["TREE_DIR"], 'roles/py_edge_vault'),
        os.path.join(os.environ["TREE_DIR"], "library"),
    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/edge',
        './roles/cloudaw',
        './roles/py_edge_vault'
    ]
for path in ANSIBLE_MODULES_PATH:
    sys.path.append(path)

from ansible.module_utils.basic import AnsibleModule

import edge.interfaces
from edge.cloud_vm.vm import Vm
from cloudaw.token import Token
from edge.kpi.elk import Loader
from edge.tools.tools import VmSessionSsh
from cloudaw.catalog import Catalog
from cloudaw.resource import Resource
from cloudaw.request import VmRequest, WorkflowRequest
from edge.conf.cloud_network import find_network_infos
from edge.connection.connectionhelper import ConnectionHelper


formatter = logging.Formatter(fmt='%(asctime)s %(levelname)-8s %(message)s',
                              datefmt='%Y-%m-%d %H:%M:%S')
logstream = io.StringIO()
handler = logging.StreamHandler(logstream)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.addHandler(handler)
logger.setLevel(logging.WARNING)

class ConnectionHelperImp(ConnectionHelper):
    def __init__(self):
        ConnectionHelper.__init__(self)

    def cnxhelp_discover_disk(self, address):
        return self.discover_disk(address)

class CloudVraImpl(edge.interfaces.CloudVra):
    def __init__(self):
        self.token = Token()
        self.resource = Resource(self.token)
        self.catalog = Catalog(self.token)
        self.vm_request = VmRequest(self.token)
        self.workflow_request = WorkflowRequest(self.token)

    def get_vra_resource_data(self, filter_sentence):
        return self.resource.get_resource_data(filter_sentence)

    def get_vra_catalog(self, filter_sentence):
        return self.catalog.get_vra_catalog(filter_sentence)

    def vra_add_disk(self, wait, hostname_id, operation_id, organization, disk_size ):
        return self.vm_request.add_disk(wait,hostname_id, operation_id, organization,disk_size)


    def vra_workflow_request(self, wait, workflow_item, trigram, app_env):
        return self.workflow_request(wait, workflow_item, trigram, app_env)


class VmImpl(Vm, CloudVraImpl):
    def __init__(self, hostname):
        CloudVraImpl.__init__(self)
        Vm.__init__(self, hostname)


PRESENT, ABSENT, INFOS = 'present', 'absent', 'info'

FIELDS = {
    "vm_hostname": {
        "type": "str"
    },
    "disk_size": {
        "default": 20,
        "type": "int",
    },

    "state": {
        "default": PRESENT,
        "choices": [PRESENT],
        "type": "str",
    }
}

REQUIRED_FIELDS = [
    ["state", "disk_size", "vm_hostname" ]
    ]

def discover_disk_on_hostname(hostname):
    cnx = ConnectionHelperImp()
    response = cnx.discover_disk(hostname)
    return response

def main():
    module = AnsibleModule(argument_spec=FIELDS, required_if=REQUIRED_FIELDS)
    if module._verbosity == 1:
        logger.setLevel(logging.INFO)
    if module._verbosity == 3:
        logger.setLevel(logging.DEBUG)
    logger.info('module sg_gts_storage called')

    try:
        state = module.params['state']
        vm = VmImpl(module.params['vm_hostname'])
        ip_found = vm.extract_ip_address(vm.hostname_data)
        if state == PRESENT:
            
            response = vm.add_disk(module.params['disk_size'])

            response = discover_disk_on_hostname(ip_found)

            module.exit_json(changed=vm.has_changed, meta=response, debug_out=logstream.getvalue())
        
    except Exception as e:
        module.fail_json(msg=e.args[0], debug_out=logstream.getvalue())
    finally:
        try:
            vm.token.delete()
        except NameError:
            pass


if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-

"""Top-level package for zabaw."""

__author__ = """GTS-RET-AUTOMATION-EDGE"""
__email__ = 'list.fr-ret-edge-automation@socgen.com'
__version__ = '0.0.1'

import logging

import pytest

from edge.conf import settings
from edge.cloud_vm.vm import Vm, VmConfig
from tests.mock.cloud import MockedCloudVra
from edge.exception import ImproperlyConfigured, DataMismatch
from edge.conf.cloud_network import get_blueprint_name

SHARED_DATABASE = []


logging.basicConfig(level=logging.getLevelName(settings.LOGGER_LEVEL))
logger = logging.getLogger(__name__)


class MockedVm(MockedCloudVra, Vm):
    def __init__(self, hostname):
        MockedCloudVra.__init__(self, shared_database=SHARED_DATABASE)
        Vm.__init__(self, hostname)


class TestVm(object):
    def test_create_vm_new_hostname(self):
        vm = MockedVm(hostname='dpgalx5500')
        response = vm.create(vm_os='RHEL_7.2_x64-RET-EDGE', trigram='pga', app_env='dev', vm_profile='Micro 1vCPU-1GB',
                          data_disk='20', vm_desc='test', ip_address='192.128.0.1',
                          vm_region='EU France (Greater Paris)', vm_az='eu-fr-paris-2', vm_subnet='192.128.0.1/72',
                          vm_backup='daily-31d-2AM', vm_replication=False)
        assert response

    def test_create_vm_hostname_already_exists_same_ip(self):
        vm = MockedVm(hostname='dpgalx5500')
        response = vm.create(vm_os='RHEL_7.2_x64-RET-EDGE', trigram='pga', app_env='dev', vm_profile='Micro 1vCPU-1GB',
                          data_disk='20', vm_desc='test', ip_address='192.128.0.1',
                          vm_region='EU France (Greater Paris)', vm_az='eu-fr-paris-2', vm_subnet='192.128.0.1/72',
                          vm_backup='daily-31d-2AM', vm_replication=False)
        assert response is SHARED_DATABASE[0]

    def test_create_vm_hostname_already_exists_different_ip(self):
        vm = MockedVm(hostname='dpgalx5500')
        with pytest.raises(DataMismatch):
            response = vm.create(vm_os='RHEL_7.2_x64-RET-EDGE', trigram='pga', app_env='dev', vm_profile='Micro 1vCPU-1GB',
                                 data_disk='20', vm_desc='test', ip_address='192.128.0.2',
                                 vm_region='EU France (Greater Paris)', vm_az='eu-fr-paris-2', vm_subnet='192.128.0.1/72',
                                 vm_backup='daily-31d-2AM', vm_replication=False)

    def test_destroy_vm(self):
        vm = MockedVm(hostname='dpgalx5500')
        vm.destroy()

    def test_create_vm_no_bg_found(self):
        vm = MockedVm(hostname='dotolx5500')
        with pytest.raises(ImproperlyConfigured):
            vm.create(vm_os='RHEL_7.2_x64-RET-EDGE', trigram='oto', app_env='dev', vm_profile='Micro 1vCPU-1GB',
                      data_disk='20', vm_desc='test', ip_address='192.128.0.1',
                      vm_region='EU France (Greater Paris)', vm_az='eu-fr-paris-2', vm_subnet='192.128.0.1/72',
                      vm_backup='daily-31d-2AM', vm_replication=False)

    def test_vm_config_RHEL_Standard(self):
        vm = VmConfig(
            os=get_blueprint_name(requested_bp='RHEL_7.2_x64-RET-EDGE', env='dev',
                region_cloud='EU France (Greater Paris)', az_cloud='eu-fr-paris-2',
                network_cidr='192.128.0.1/72', provider_bg='GTS_RET'),
            trigram='pga', app_env='dev', profile='Micro 1vCPU-1GB',
            data_disk='20', desc='test', ip_address='192.128.0.1', hostname='dpgalx5500',
            region='EU France (Greater Paris)', az='eu-fr-paris-2', subnet='192.128.0.1/72',
            backup='daily-31d-2AM', replication=False
        )
        assert vm.os_translated == 'RHEL 7.2 x64 RET EDGE'

    def test_vm_config_RHEL_Transverse(self):
        vm = VmConfig(
            os=get_blueprint_name(requested_bp='RHEL_7.2_x64-RET-EDGE', env='dev',
                region_cloud='EU France (Greater Paris)', az_cloud='eu-fr-paris-2',
                network_cidr='192.128.0.1/72', provider_bg='BG_GTS-TRANSVERSE-RCR'),
            trigram='trv', app_env='dev', profile='Micro 1vCPU-1GB',
            data_disk='20', desc='test', ip_address='192.128.0.1', hostname='dpgalx5500',
            region='EU France (Greater Paris)', az='eu-fr-paris-2', subnet='192.128.0.1/72',
            backup='daily-31d-2AM', replication=False
        )
        assert vm.os_translated == 'RHEL 7.2 x64 TRANSVERSE RCR'


import time

from edge.tools.tools import VmSessionSsh
from ccs_celery.abstract import TaskServiceManager
from ccs_celery.services.rollback import RollBackMixins


class VmInfos(TaskServiceManager, RollBackMixins):

    def __init__(self, data):
        super().__init__("VmInfos", data)

    def on_failure(self, exc, kwargs, excinfo):
        self.data.services[self._task_name]["finished_at"] = time.time()
        self.data.services[self._task_name]["status"] = "FAILED"
        self.data.services[self._task_name]["exception_class"] = str(type(exc))
        self.data.services[self._task_name]["exception_msg"] = str(exc)
        self.data.services[self._task_name]["exception_traceback"] = str(excinfo)

    def on_success(self, result, kwargs):
        self.data.services[self._task_name]["finished_at"] = time.time()
        self.data.services[self._task_name]["status"] = "SUCCESS"
        self.data.services[self._task_name]["return_value"] = result

    def _set_up(self):
        self.data.services[self._task_name] = {
            "changed": False,
            "launch_at": time.time(),
            "service_kwargs": {}
        }

    def task(self):
        self._set_up()
        self.logger.info("Invoke {} module with kwargs={}".format(
            self._task_name,
            self.data.services[self._task_name]["service_kwargs"])
        )
        # this below code allows to get some informations of vm.
        # the patch level of the vm and his os
        cnx = VmSessionSsh(self.data.shared_data["vm_ip"])
        vm_os_installed = cnx.execute_cmd('sudo sh -c "cat /etc/redhat-release"', "static")[1].decode("utf-8")
        vm_level_patch = cnx.execute_cmd(
            'sudo sh -c "cat /etc/template | grep -e REPO | awk -F \'-\' \'{print $3}\'"', "static"
        )[1].decode("utf-8")
        self.data.shared_data["vm_os_installed"] = vm_os_installed
        self.data.shared_data["vm_level_patch"] = vm_level_patch
        _result = dict(
            vm_os_installed=vm_os_installed,
            vm_level_patch=vm_level_patch
        )
        self.data.services[self._task_name]["changed"] = False
        return (False, _result)

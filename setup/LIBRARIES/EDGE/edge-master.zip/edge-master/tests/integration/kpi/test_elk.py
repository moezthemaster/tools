from edge.kpi.elk import Loader


class TestELK(object):
    def test_index_data(self):
        loader = Loader()
        response = loader.index_data(id_execution=456, service="test Service", hostname="testVM", status="OK",category="Provisionning VM", client="RET", trigram="pga", environment="dev")
        expected =  {u'successful': 1, u'failed': 0, u'total': 2}
        assert response == expected
import logging
from time import sleep
from collections import namedtuple


import edge.interfaces
from edge.conf import settings
from edge.conf.cloud_network import get_blueprint_name
from edge.exception import EdgeException, ImproperlyConfigured, DataMismatch

logging.basicConfig(level=logging.getLevelName(settings.LOGGER_LEVEL))
logger = logging.getLogger(__name__)

GET_BG_LIST_FROM_TRIGRAM = 'Get BG List From Trigram'


Item = namedtuple('Item', ['item_id', 'tenant_ref', 'subtenant_ref'])


class VmConfig(
        namedtuple(
            'VmConfig',
            [
                # p_os, p_os_translated as identified for private vars
                # for operating with public vars os and os_translated
                'p_os', 'p_os_translated', 'trigram', 'app_env', 'profile', 'data_disk', 'desc',
                'hostname', 'ip_address', 'region', 'az', 'subnet', 'backup', 'replication'
            ]
        )
):

    def __new__(cls, **kwargs):
        kwargs["p_os"] = kwargs.pop("os")
        kwargs["trigram"] = kwargs["trigram"].upper()
        kwargs["desc"] = "[EDGE] {}".format(kwargs["desc"])
        kwargs["app_env"] = kwargs["app_env"].upper().replace('HML', 'UAT')
        kwargs["p_os_translated"] = kwargs["p_os"].replace('-', ' ').replace('_', ' ')
        return super(VmConfig, cls).__new__(cls, **kwargs)

    @property
    def os(self):
        if hasattr(self, '_os'):
            return self._os
        else:
            return self.p_os

    @os.setter
    def os(self, v):
        self._os = v

    @property
    def os_translated(self):
        if hasattr(self, '_os_translated'):
            return self._os_translated
        else:
            return self.p_os_translated

    @os_translated.setter
    def os_translated(self, v):
        self._os_translated = v


class Vm(edge.interfaces.CloudVra):
    def __init__(self, hostname):
        try:
            assert hostname, "hostname is None"
        except AssertionError as e:
            raise EdgeException(repr(e))
        self.hostname = hostname
        self.has_changed = False
        self._hostname_data = None #lazy loaded
        self._bg_list_from_trigram_item = None #Lazy loaded
        self.machine_item = None #loaded afterwards

    @property
    def hostname_data(self):
        if not self._hostname_data:
            filter_sentence = "(name eq '{}')".format(self.hostname)
            data = self.get_vra_resource_data(filter_sentence)
            if data:
                try:
                    assert len(data) == 1, "Hostname was not found in vRA"
                    self._hostname_data = data[0]
                except AssertionError as e:
                    raise EdgeException(repr(e))
        return self._hostname_data

    @staticmethod
    def extract_ip_address(hostname_data):
        '''
        Extract ip address from vRA
        :param hostname_data: data extracted from vra
        :return: ip address - string
        '''
        try:
            for entry in hostname_data['resourceData']['entries']:
                if entry['key'] == 'ip_address':
                    return entry['value']['value']
        except:
            raise EdgeException('Hostname was found in vRA but it was not possible to read ip address')

    @property
    def bg_list_from_trigram_item(self):
        if not self._bg_list_from_trigram_item:
            try:
                filter_sentence = "(name eq '{}')".format(GET_BG_LIST_FROM_TRIGRAM)
                item = self.get_vra_catalog(filter_sentence)[0]
                item_id = item['catalogItem']['id']
                subtenant_ref = item['entitledOrganizations'][0]['subtenantRef']
                self._bg_list_from_trigram_item = Item(item_id=item_id, tenant_ref='', subtenant_ref=subtenant_ref)
            except:
                raise EdgeException('Cannot find workflow item "{}" in the vra Catalog'.format(GET_BG_LIST_FROM_TRIGRAM))
        return self._bg_list_from_trigram_item

    def create(self, vm_os, trigram, app_env, vm_profile, data_disk, vm_desc,
               ip_address, vm_region, vm_az, vm_subnet, vm_backup, vm_replication):
        if self.hostname_data:
            found_ip = self.extract_ip_address(self.hostname_data)
            if ip_address == found_ip:
                logger.debug("VM already exists with same ip_address, that's it")
                return self.hostname_data
            else:
                raise DataMismatch('Hostname {} already exists in vRA with another IP address {}'
                                   .format(self.hostname,found_ip))
        logger.debug("VM does not exist, let's make it")
        provider_bg, requested_for, provider_owner = self._get_provider_bg(trigram=trigram, app_env=app_env)
        vm_config = VmConfig(
            os=get_blueprint_name(vm_os, app_env, vm_region, vm_az, vm_subnet, provider_bg),
            trigram=trigram,
            app_env=app_env,
            profile=vm_profile,
            data_disk=data_disk,
            desc=vm_desc,
            hostname=self.hostname,
            ip_address=ip_address,
            region=vm_region,
            az=vm_az,
            subnet=vm_subnet,
            backup=vm_backup,
            replication=vm_replication
        )
        self._load_machine_item(vm_config, provider_bg)
        #raise  DataMismatch('Requested BP = {}, Generated BP = {}'.format(vm_os, vm_config.os))
        self.vra_create_vm(
            wait=True,
            machine_item=self.machine_item,
            vm_config=vm_config,
            requested_for=requested_for,
            provider_owner=provider_owner,
            business_group=provider_bg
        )
        self.has_changed = True
        return self.hostname_data

    def add_disk(self, disk_size): 
        hostname_organization = self.hostname_data['organization']
        for operation in self.hostname_data['operations']:
            if operation['bindingId'] == "sgcloud!::!b4ffdfd5-940a-4790-87d0-dff9fdabd6e1" or operation['name'] == "Add Storage":
                destroy_operation_id = operation['id']
        response = self.vra_add_disk(
            wait=True,
            hostname_id=self.hostname_data['id'],
            operation_id=destroy_operation_id,
            organization=hostname_organization, 
            disk_size=disk_size,
        )
        
        self.has_changed = True
        return response

    def destroy(self):
        hostname_organization = self.hostname_data['organization']
        for operation in self.hostname_data['operations']:
            if operation['bindingId'] == "Infrastructure.Virtual.Action.Destroy":
                destroy_operation_id = operation['id']
                response = self.vra_destroy_vm(
                    wait=True,
                    hostname_id=self.hostname_data['id'],
                    operation_id=destroy_operation_id,
                    organization=hostname_organization
                )
                infos = self.get_infos(refresh=True)
                assert settings.CLOUD_MAX_WAIT_ON_DESTROY > 0
                loop = settings.CLOUD_MAX_WAIT_ON_DESTROY
                loop_wait = loop / 10
                while not infos is None and loop > 0:
                    infos = self.get_infos(refresh=True)
                    loop -= 1
                    sleep(loop_wait)

                if loop == 0 and not infos is None:
                    self.has_changed = False
                    raise EdgeException('machine "{}" still present in the vra after {} seconds'.format(self.hostname, settings.CLOUD_MAX_WAIT_ON_DESTROY))
                self.has_changed = True
                return response
        raise EdgeException('machine "{}" still present in the vra. Cannot find Infrastructure.Virtual.Action.Destroy'.format(
                self.hostname
            )
        )

    def get_infos(self, refresh=False, extended=False):
        if not self._hostname_data or refresh:
            self._hostname_data = None

            if self.hostname_data and extended:
                hostname_organization = self.hostname_data['organization']
                for operation in self.hostname_data['operations']:
                    if operation['name'] == "Get VM Information":
                        vm_info_operation_id = operation['id']
                        res_infos = self.vra_destroy_vm(
                                   wait = True,
                                   hostname_id = self._hostname_data['id'],
                                   operation_id = vm_info_operation_id,
                                   organization = hostname_organization
                               )
                        if res_infos and res_infos['values']:
                            self._hostname_data['extended'] = res_infos['values']

        return self._hostname_data

    def _load_machine_item(self, vm_config, provider_business_group):
        item_id, tenant_ref, subtenant_ref = '', '', ''
        try:
            filter_sentence = "(name eq '{}')".format(vm_config.os_translated)
            item = self.get_vra_catalog(filter_sentence)[0]
            item_id = item['catalogItem']['id']
            for organization in item['entitledOrganizations']:
                if organization['subtenantLabel'] == provider_business_group:
                    tenant_ref = organization['tenantRef']
                    subtenant_ref = organization['subtenantRef']
        except:
            raise EdgeException('Cannot find machine item "{}" in the vra Catalog'.format(vm_config.os))
        self.machine_item = Item(item_id, tenant_ref, subtenant_ref)

    def _get_provider_bg(self, trigram, app_env):
        '''

        :param environment:
        :param catalog:
        :return: tuple of 3 strings: provider_bg, requested_for, provider_owner
        '''
        data = self.vra_workflow_request(
            wait=True,
            workflow_item=self.bg_list_from_trigram_item,
            trigram=trigram,
            app_env=app_env
        )
        try:
            for entry in data['values']['entries']:
                entry_key = entry['key']
                if entry_key == 'provider-BGResult':
                    provider_bg = entry['value']['items'][0]['value']
            assert provider_bg
        except Exception:
            raise ImproperlyConfigured('BusinessGroup not found in vRA, please check that trigram {} '
                                       'and app_env {} are referenced in http://sgcloudview'
                                       .format(trigram, app_env))
        provider_owner = 'EAN_PRD_SVC@eur.msd.world.socgen'
        requested_for = 'EAN_PRD_SVC@eur.msd.world.socgen'
        return provider_bg, requested_for, provider_owner


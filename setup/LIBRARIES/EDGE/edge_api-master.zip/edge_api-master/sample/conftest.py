""" Configuration for testing Flask API """
import json
import pytest
from flask import Flask, Response
from faker import Faker

from sample.apis import api

faker = Faker()


class JSONResponse(Response):
    # pylint: disable=too-many-ancestors
    """
    A Response class with extra useful helpers, i.e. ``.json`` property.
    """

    def json(self):
        """ Load json """
        return json.loads(self.get_data(as_text=True))

# pylint: disable=redefined-outer-name


@pytest.fixture(scope='function')
def set_logger(mocker):
    """ Mock DatalakeLog """
    mocker.patch('sample.core.utils.DatalakeLog', autospec=True)


@pytest.fixture(scope='function')
def mock_db_session(mocker):
    """ Mock DB Session """
    mocker.patch("sample.apis.contacts.db.session")


@pytest.fixture(scope='function')
def sg_connect_token(mocker):
    """ Setup SG Connect Token """
    sg_connect = mocker.patch(
        "sample.core.decorators.sg_connect_client.get_token_info")
    sg_connect.return_value.email.return_value = faker.email()
    sg_connect.return_value.login_ad.return_value = faker.user_name()


@pytest.yield_fixture(scope='session')
def flask_app():
    """ Setup Flask app fro Testing """
    class _Client:
        def __init__(self, conn):
            self.hostname, self.port = conn[0]
            self.data = dict()

        def get(self, var):
            try:
                return self.data[var]
            except KeyError:
                pass

        def set(self, var, val):
            self.data[var] = val
            return True

        def delete(self, var):
            try:
                del self.data[var]
            except KeyError:
                pass
            return True

    class Memcache:
        Client = _Client

    app = Flask(__name__)
    load_config(app, Memcache)
    api.init_app(app)
    api._config = app.config
    with app.app_context():
        yield app


@pytest.fixture(scope='session')
def flask_app_client(flask_app):
    """ Load up Flask app api client for testing """
    flask_app.response_class = JSONResponse
    return flask_app.test_client()


def load_config(app, memcache):
    """ Load Config for Test Suite """
    app.config['SERVER_NAME'] = "127.0.0.1"
    app.config['ERROR_404_HELP'] = False
    app.config['TESTING'] = True
    app.config['DL_LOGGER_CONFFILE'] = 'confpath'
    app.config['demo_db'] = memcache.Client([('127.0.0.1', 11211)])


def pytest_itemcollected(item):
    # pylint: disable=W0212
    """
    Configuration of Pytest output format
    Display only the comments by readable test result
    """
    par = item.parent.obj
    node = item.obj
    pref = par.__doc__.strip() if par.__doc__ else par.__class__.__name__
    suf = node.__doc__.strip() if node.__doc__ else node.__name__
    pref = "[" + pref + "]"
    if pref or suf:
        item._nodeid = ' '.join((pref, suf))

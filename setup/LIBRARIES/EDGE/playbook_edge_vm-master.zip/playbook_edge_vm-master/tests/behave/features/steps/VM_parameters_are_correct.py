#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
import testinfra


LIST_BLUEPRINT_CENTOS_7_5 = (
    'CENTOS_7.5_x64-RET-EDGE', 'CENTOS_7.5_x64-WEBCELL-RET-EDGE',
    'CENTOS_7.5_x64-WEBCELL-BAD-EDGE', 'CENTOS_7.5_x64-TRANSVERSE-RCR'
)

LIST_BLUEPRINT_CENTOS_7_0 = (
    'CENTOS_7.0_x64-RET-EDGE', 'CENTOS_7.0_x64-WEBCELL-RET-EDGE',
    'CENTOS_7.0_x64-WEBCELL-BAD-EDGE', 'CENTOS_7.0_x64-TRANSVERSE-RCR'
)

LIST_BLUEPRINT_RHEL_7_5 = (
    'RHEL_7.5_x64-RET-EDGE', 'RHEL_7.5_x64-WEBCELL-RET-EDGE',
    'RHEL_7.5_x64-WEBCELL-BAD-EDGE', 'RHEL_7.5_x64-TRANSVERSE-RCR'
)

LIST_BLUEPRINT_RHEL_7_3 = (
    'RHEL_7.3_x64-RET-EDGE', 'RHEL_7.3_x64-WEBCELL-RET-EDGE',
    'RHEL_7.3_x64-WEBCELL-BAD-EDGE', 'RHEL_7.3_x64-TRANSVERSE-RCR'
)


def check_os(blueprint, os):
    if blueprint in LIST_BLUEPRINT_CENTOS_7_5:
        if "7.5" in os and "CentOS" in os:
            return True
    elif blueprint in LIST_BLUEPRINT_RHEL_7_5:
        if "7.5" in os and "Red Hat" in os:
            return True
    elif blueprint in LIST_BLUEPRINT_RHEL_7_3:
        if "7.3" in os and "Red Hat" in os:
            return True
    elif blueprint in LIST_BLUEPRINT_CENTOS_7_0:
        # Normal don't worry
        if "7.3" in os and "CentOS" in os:
            return True
    return False


@then('VM parameters are OK')
def step_impl(context):

    print("extra disk has correct size and RAM & CPU & OS are OK\n")

    server=testinfra.get_host('ssh://automation@'+context.params['vm_ipaddr'])


    # Test if mountpoint requested is mounted
    cmd_disk=server.run("lsblk -l --noheadings --nodeps /dev/sdb -o size")

    if cmd_disk.stdout.strip() == context.params['vm_extra_disk']:
        assert context.failed is False
    else:
        assert context.failed is True


    # Test the number of CPU
    cmd_cpu=server.run("cat /proc/cpuinfo | grep 'cpu cores' | cut -d':' -f2 | tr -d ' ' " ) 
    
    if cmd_cpu.stdout [:-1] == context.params['vm_cpu']:
      assert context.failed is False
    else:
      assert context.failed is True


    # Test the amount of RAM
    cmd_ram=server.run("cat /proc/meminfo | grep 'MemTotal' | cut -d':' -f2 | tr -d ' ' " )

    if int( cmd_ram.stdout [:-3] ) / ( float(context.params['vm_ram']) * 1024 * 1024) > 0.95 :
      assert context.failed is False
    else:
      assert context.failed is True

    # Test OS
    cmd_os = server.run("cat /etc/redhat-release")
    print("OS requested is {} ".format(context.params['vm_os']))
    print("OS on vm {} is {} ".format(context.params['vm_hostname'], cmd_os.stdout))
    if check_os(context.params['vm_os'], cmd_os.stdout):
        assert context.failed is False
    else:
        assert context.failed is True

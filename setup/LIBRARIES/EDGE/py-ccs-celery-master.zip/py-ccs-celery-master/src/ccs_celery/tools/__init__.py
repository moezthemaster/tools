
import os
import attr
import json
import contextlib

from edge.conf.cloud_network import get_details


def save_to_json(filename, data):
    with open(filename, 'w') as fp:
        json.dump(data, fp, indent=4)


get_dict = lambda x: attr.asdict(x)


@contextlib.contextmanager
def set_env(**environ):
    """
    Temporarily set the process environment variables.

    :type environ: dict[str, unicode]
    :param environ: Environment variables to set
    """
    old_environ = dict(os.environ)
    os.environ.update(environ)
    try:
        yield
    finally:
        os.environ.clear()
        os.environ.update(old_environ)


def set_missing_keys_to_none(keys):
    def real_decorator(func):
        def func_wrapper(**kwargs):
            """
            set missings keys to none
            :param kwargs:
            :return:
            """
            for k in keys:
                kwargs.setdefault(k, None)
            return func(**kwargs)
        return func_wrapper
    return real_decorator


def ret_or_mkt(env, region_cloud, az_cloud, network_id):
    return get_details(env, region_cloud, az_cloud, network_id).get("network_tag", "ret")

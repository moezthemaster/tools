#!/bin/bash
##################################################
# Main authors: Arnauld FRACHE and Olivier ANSQUIN
# Description: zabbix mongodb monitor
# Date: 2018, December 1 
# Version: 1.0
# Requirements: mongo, jq ,MongoDB account
# Example :./zbx_MongoDB_LagInReplication.sh localhost 12500 zabbix zabbix dauddaud
# Results : numbers ...
#
##################################################
# set -xv # Debug
#
DB_HOST=$1
DB_PORT=$2
DB_USERNAME=$3
DB_PASSWORD=$4
DB_INSTANCE=$5
#
##################################################
# ENV - path for Mongo DB
##################################################
#
MONGO=`which mongo`
#
########
#
#echo "verif path Mongo:" $MONGO # DEBUG use
JQ="/etc/zabbix/zabbix_agentd.d/MGDB_EDGE/jq"
#echo "verif path jq tool :" $JQ # DEBUG use
EXIT_ERROR=1
EXIT_OK=0
#
if [ ! -x "$MONGO" ] ; then
  echo "mongo not found"
  exit $EXIT_ERROR
elif [ ! -x "$JQ" ] ; then
  echo "jq not found"
  exit $EXIT_ERROR
elif [ $# -eq 0 ] ; then
  echo "No values pass"
  exit $EXIT_ERROR
fi
##########################################
# DATA COLLECTION
# Build request
LAGIN1=`$MONGO --host $DB_HOST --port $DB_PORT --authenticationDatabase admin --username $DB_USERNAME --password $DB_PASSWORD --quiet<<<"rs.printSlaveReplicationInfo()"`
# echo $LAGIN1 # for debug use
# Case / No replica
LAGIN2=`echo $LAGIN1 | grep "is empty" | wc -l`
if [  "$LAGIN2" == "1" ] ; then
 echo "-1"
 exit 0  
else
LAGIN2=`echo $LAGIN1 | grep $DB_HOST:$DB_PORT | wc -l` 
# Case / Primary instance
 if [  "$LAGIN2" == "0" ] ; then
  echo "0"
  exit 0
fi
# Case with replicaset 
LAGIN=`$MONGO --host $DB_HOST --port $DB_PORT --authenticationDatabase admin --username $DB_USERNAME --password $DB_PASSWORD --quiet<<<"rs.printSlaveReplicationInfo()"| grep -A2 $DB_HOST:$DB_PORT | sed '1,2d' |awk '{print $1}'`
#  sed '1,2d' remove the first and second line - keep only time information 
# awk - keep only number of second 
#
echo $LAGIN
exit 0 
fi
### END

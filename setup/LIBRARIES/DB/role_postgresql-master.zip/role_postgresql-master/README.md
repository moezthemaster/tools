[![CC0](https://www.fullstackpython.com/img/logos/postgresql.jpg)](https://www.postgresql.org/)

Role Postgresql
=========

Create a Postgresql Database Cluster and let you execute some admin tasks such as :
 * Creating a Postgresql Database Cluster : versions 9.4 & 9.5 are available ;
 * Stop / Start / Reload Postgresql Service ;
 * Exporting a Database in a compressed dumpfile ;
 * Listing dumpfiles ;
 * Importing a Database from a dump file ;

Requirements
------------
  * Facts gathering shouldn't be disabled ;
  * Target servers must be RHEL or CentOS 7 ;
  * If you want to create a Postgresql Cluster on a VM created using the Edge template, you should consider executing [role_edge_fs](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/role_edge_fs) : specify a mountpoint named "/bases/pgsql", Owner & Group to "postgres" ;
  * If you are not working on a VM Edge, you should first execute [role_postgresql_fs](specify a mountpoint named "/bases/pgsql" and Owner & Group to "postgres") in order to mount a FS "/bases/pgsql".  
  * For Monitoring & Supervision : [role_patrol_postgresql](https://sgithub.fr.world.socgen/GTS-MFI-COMPOSANTS-EDGE/role_patrol_postgresql) - release [2.0.2](https://sgithub.fr.world.socgen/GTS-MFI-COMPOSANTS-EDGE/role_patrol_postgresql/tree/2.0.2) : if Patrol Agent is installed on the VM, Postgresql Supervision will be installed, using Perl script [check_postgres](https://bucardo.org/wiki/Check_postgres) 


If no action is specified when calling this role, it will execute the following actions :
 1. __create.yml__ :
   * installing requested packages
   * create Group and User Postgres
   * creating & enabling the Postgresql.service
 2. __configure.yml__ :
   * creating a Postgresql Cluster if it doesn't exists
   * creating a Host Based Authentication configuration file (pg_hba.conf)
   * creating a Postgresql configuration file (postgresql.conf)
   * starting the Postgresql Service
   * creating a Database
   * remove the fact that any role is allowed to create object in Public Schema in the Database created
   * granting all privileges to the applicative user under its database
   * creating a remote user that will only have Select privilege on the Database created
   * adding extensions if they are specified
 3. __start.yml__ :
   * starting Postgresql service


Here's a description of the other tasks that can be executed in this role, filling the *postgresql_action* with the name of the task :


 __stop.yml__ : stopping Postgresql Service

__export.yml__ : dumping Metadatas and Datas of the Postgres Cluster using [pg_dumpall](http://docs.postgresql.fr/9.5/app-pg-dumpall.html) tool.<br>
This tool is just a way given to the projects to export their Metadatas before delivering a new version of an application ; It's not a "Hot backup" based on a [continuous archiving](http://docs.postgresql.fr/9.5/continuous-archiving.html), that can let you proceed a Point In Time Recovery (PITR) in case of urgency.<br>
As advice, in order to have a consistent export of all objects and datas, no other session than the SuperUser should be connected ; It's better to set the application in a maintenance way, or disconnect all sessions before using this tool.

__export_list.yml__ : list the dump files generated with the task "export"

__import.yml__ : import everything from a dump file created with the export.yml, into a Postgresql Cluster

 __delete.yml__ : decomissioning all the Postgres Cluster configuration :
  * stopping Postgresql Service
  * removing directories under /bases/pgsql
  * removing packages that were installed


This role is developped for SOFA & PAAP projects. Some updates may have to be done for other needs : contact us :email: list.fr-ret-edge-automation@socgen.com, or Fork it.


Role Variables
--------------
Here are the requested values for each action :

__create.yml__
- postgresql_action: "create"
- postgresql_version ("9.4" or "9.5")
- postgresql_cluster_name
- You can change these default thresholds values related to [Patrol Postgresql Supervision](https://sgithub.fr.world.socgen/GTS-MFI-COMPOSANTS-EDGE/role_patrol_postgresql) :
  - postgresql_patrol_disk_space_warning (default = 85)
  - postgresql_patrol_disk_space_critical (default = 92)
  - postgresql_patrol_backends_warning (default = 90)
  - postgresql_patrol_backends_critical (default = 95)
  - postgresql_patrol_db_size_warning (default = 53687091200 = 50Go, size is in bytes = 50 * 1024 * 1024 * 1024) ; 
  - postgresql_patrol_commitratio_warning (default = 90)
  - postgresql_patrol_commitratio_critical (default = 80)
  - postgresql_patrol_hitratio_warning (default = 90)
  - postgresql_patrol_hitratio_critical (default = 80)
  - postgresql_patrol_sequence_warning (default = 85)
  - postgresql_patrol_sequence_critical (default = 95)
 
__configure.yml__
- postgresql_action: "configure"
- postgresql_version
- postgresql_cluster_name
- postgresql_superuser_password
- postgresql_db_name
- postgresql_db_user
- postgresql_db_password
- postgresql_remote_db_password
- postgresql_encoding [(cf. Character Set Support)](https://www.postgresql.org/docs/9.5/static/multibyte.html)
- postgresql_locale
- You can change these values :
  - postgresql_port (default = 12400) (if you change port value, you should execute the role 2 times, one with "create" action and one with "configure" action)
  - postgresql_extensions (default = "")
  - postgresql_max_connections (default = 100)
  - postgresql_shared_buffers (default = "256MB")
  - postgresql_log_statement ("none", "ddl", "mod", "all" - default = "none") [cf. Logging](https://www.postgresql.org/docs/9.5/static/runtime-config-logging.html)
  - postgresql_log_connections ("off", "on" - default = "off")
  - postgresql_log_disconnections ("off", "on" - default = "off")
  - postgresql_log_lock_waits ("off", "on" - default = "off")
  - postgresql_log_checkpoints ("off", "on" - default = "off")
  - postgresql_ssl (default = "off")
    - postgresql_ssl_cert (required when postgresql_ssl = "on")
    - postgresql_ssl_key (required when postgresql_ssl = "on")

__delete.yml__
- postgresql_action: "delete"
- postgresql_version
- postgresql_cluster_name
- You must overwrite this value to validate the decomissioning :
  - validate_decomissioning: "yes" (default = "no")

__start.yml__
- postgresql_action: "start"
- postgresql_version

__stop.yml__
- postgresql_action: "stop"
- postgresql_version

__export.yml__
- postgresql_action: "export"
- postgresql_version
- postgresql_cluster_name
- You can override these values :
  - pg_dumpall_directory (default = directory where are stored backups, /bases/pgsql/*postgresql_cluster_name*/backups)
  - postgresql_dumps_rotate: The number of backups to keep. If not specified (default value), all backups are kept.

__export_list.yml__
- postgresql_action: "export_list"
- postgresql_cluster_name
- You can override these values :
    - pg_dumpall_directory (default = directory where are stored backups, /bases/pgsql/*postgresql_cluster_name*/backups)

__import.yml__
- postgresql_action: "import"
- postgresql_version: "9.4" or "9.5"
- postgresql_cluster_name
- pg_dumpall_gzip_file: name of the GZip file that contains the Dump file you wish to restore 
- You must overwrite this value to validate the Import : you agree that all datas that are in the Postgresql Cluster will be erased.
  - validate_import: "yes" (default = "no")
- You can override these values :
  - postgresql_vacuumdb: "no" (default = "yes"), if you want or don't want to execute [vacuumdb](https://www.postgresql.org/docs/9.5/static/app-vacuumdb.html) utility after Import
  - postgresql_reindexdb: "no" (default = "yes"), if you want or don't want to execute [reindexdb](https://www.postgresql.org/docs/9.5/static/app-reindexdb.html) utility
  - pg_dumpall_directory (default = directory where are stored backups, /bases/pgsql/*postgresql_cluster_name*/backups)



Dependencies
------------
None


Examples Playbook
-----------------

    - hosts: servers
      gather_facts: yes
      roles:
      - { role: role_postgresql,
           postgresql_action: "create",
           postgresql_version: "{{ postgres_version }}",
           postgresql_cluster_name: "{{ cluster_name }}"
       }
     - { role: role_postgresql,
           postgresql_action: "configure",
           postgresql_version: "{{ postgres_version }}",
           postgresql_cluster_name: "{{ cluster_name }}",
           postgresql_superuser_password: "{{ superuser_password }}",
           postgresql_encoding: "{{ cluster_encoding }}",
           postgresql_locale: "{{ cluster_locale }}",
           postgresql_db_name: "{{ db_name }}",
           postgresql_db_user: "{{ db_user }}",
           postgresql_db_password: "{{ db_password }}",
           postgresql_remote_db_password: "{{ remote_db_password }}",
           postgresql_extensions: "{{ db_extensions }}"
       }
     - { role: role_postgresql,
           postgresql_action: "start",
           postgresql_version: "{{ postgres_version }}"
       }


     - { role: role_postgresql,
           postgresql_action:  "export",
           postgresql_version: "{{ postgres_version }}",
           postgresql_cluster_name: "{{ cluster_name }}"
       }


     - { role: role_postgresql,
           postgresql_action: "delete",
           postgresql_version: "{{ postgres_version }}",
           postgresql_cluster_name: "{{ cluster_name }}",
           validate_decomissioning: "yes"
       }

     #  If you want to use a SSL connexion :
     - { role: role_postgresql,
           postgresql_action: "configure",
           postgresql_version: "{{ postgres_version }}",
           postgresql_cluster_name: "{{ cluster_name }}",
           postgresql_superuser_password: "{{ superuser_password }}",
           postgresql_encoding: "{{ cluster_encoding }}",
           postgresql_locale: "{{ cluster_locale }}",
           postgresql_db_name: "{{ db_name }}",
           postgresql_db_user: "{{ db_user }}",
           postgresql_db_password: "{{ db_password }}",
           postgresql_remote_db_password: "{{ remote_db_password }}",
           postgresql_extensions: "{{ db_extensions }}"
           postgresql_ssl: "on",
           postgresql_ssl_cert: "-----BEGIN CERTIFICATE-----\n
    <value_of_the_certificate>
    -----END CERTIFICATE-----",
           postgresql_ssl_key: "-----BEGIN RSA PRIVATE KEY-----\n
    <value_of_the_private_key>
    -----END RSA PRIVATE KEY-----"
       }

Some example values that can be specified in a group_vars file : `~/group_vars/example.yml`
```yml
postgres_version: "9.5"

cluster_name: dfsfsofa
superuser_password: "PostgresMotd3pass3achang3r"
cluster_encoding: "UTF8"
cluster_locale: "fr_FR.UTF8"

db_name: epic
db_user: epic
db_password: "Motd3pass3achang3r"
remote_db_password: "3ncore1MDPachang3r"

# Specify extensions that will be loaded at DB startup (modules or extensions separated with a coma) ; example :
# db_extensions: "plpgsql,pg_stat_statements"
db_extensions: ""
```



License
-------
[![CC0](https://www.usenix.org/legacy/events/usenix04/art/build_icons/bsd.gif)](https://fr.wikipedia.org/wiki/Licence_BSD)

Author Information
------------------

AZEMA Mickael & GUFFROY Philippe


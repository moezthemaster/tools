#!/usr/bin/env python

"""
AUTHOR:
RET AUTOMATION EDGE

MODULE: ansible_sg_gts_filesystem

DESCRIPTION:
This module is used to create/customize file systems

EXAMPLES:
    - name: Call the edge_fs module to create fs
      ansible_sg_gts_filesystem:
        module_hostname: "{{ vm_hostname }}"
        module_fs_list: "{{ fs_list }}"
        module_action: "present"
      register: gts_fs_result

"""

import warnings
from ansible.module_utils.basic import *

if "TREE_DIR" in os.environ.keys():
    ANSIBLE_MODULES_PATH = [
        './roles/ansible_libraries/files',
        os.path.join(os.environ["TREE_DIR"], "library"),
    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/ansible_libraries/files'
    ]

for path in ANSIBLE_MODULES_PATH:
    sys.path.append(path)

import sg_gts_tools.read_settings
import paramiko
import StringIO
import logging

GTS_CLOUD_PUBKEY = "gts_cloud_pubkey.cfg"
GTS_FS_SCRIPT = "sg_gts_filesystem.py"

formatter = logging.Formatter(fmt='%(asctime)s %(levelname)-8s %(message)s',
                              datefmt='%Y-%m-%d %H:%M:%S')
logstream = StringIO.StringIO()
handler = logging.StreamHandler(logstream)
handler.setFormatter(formatter)
logger = logging.getLogger("ansible_sg_gts_filesystem")
logger.addHandler(handler)
logger.setLevel(logging.WARNING)


def open_ssh_connection(username, hostname, keyfile):
    """
    Open an SSH connection on the target machine
    :param username:
    :param hostname:
    :param keyfile:
    :return: connection open
    """
    key = paramiko.RSAKey.from_private_key_file(keyfile)
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname=hostname, username=username, pkey=key)
    return client


def send_file_over_ssh(client, filename, remote_path="/tmp"):
    """
    Sending Python script on target machine
    """
    for path in ANSIBLE_MODULES_PATH:
        if os.path.exists(os.path.join(path, filename)):
            sftp = client.open_sftp()
            sftp.put(os.path.join(path, filename), os.path.join(remote_path, filename))
            sftp.close()


def run_python_over_ssh(client, command):
    """
    Run Script on target machine
    """
    stdin, stdout, stderr = client.exec_command('sudo python {}'.format(command))

    return stdout.read()


def convert_to_bytes(size):
    """
    Convert disks size
    :rtype:
    """
    logger.debug("Size  = {}".format(size))
    if re.match('^[0-9]+[GM]{0,1}$', size):
        if size[-1] == 'G':
            coef = 1024 * 1024 * 1024
            num_size = size[0:-1]
        elif size[-1] == 'M':
            coef = 1024 * 1024
            num_size = size[0:-1]
        else:
            coef = 1
            num_size = size

        return int(num_size) * coef
    else:
        raise ValueError("{} is not a correct size".format(size))


def compute_vg_needs(fs_list, infos):
    """
    Calculate vg size needs on the target machine
    :rtype: object
    """
    logger.info("Computing vg needs")
    vg_needs = {}
    for request in fs_list:
        if not 'vg' in request:
            request['vg'] = 'SocleVg'

        request_size = convert_to_bytes(request['size'])

        # TODO : ne garder que la plus grande des entrees de modules_fs_list

        # on verifie si le fs existe deja
        existing_fs = False
        for fs in infos['fs']:
            if fs['mountpoint'] == request['mountpoint']:
                existing_fs = True
                logger.debug("found matching fs {} {},{}".format(fs['mountpoint'], request_size, fs['size']))
                if request_size > int(fs['size']):
                    # le fs existe et sa taille est inferieur a la demande
                    logger.debug("known vg {}, adding {}".format(request['vg'], (request_size - int(fs['size']))))
                    vg_needs[request['vg']] = vg_needs.get(request['vg'], 0) + (request_size - int(fs['size']))

        if not existing_fs:
            logger.debug("fs not present, adding {}".format(request_size))
            vg_needs[request['vg']] = vg_needs.get(request['vg'], 0) + request_size

    logger.debug("  VG needs {}".format(vg_needs))
    return vg_needs


def get_free_pv(infos, size):
    """
    Get free Physical volume on the target machine
    find the smallest free pv with of at list size bytes
    :rtype: object
    """
    logger.info("Get free pv")
    smallest_disk_name = ""
    smallest_disk_size = 4 * 1024 * 1024 * 1024 * 1024
    # Ugly Hack to prevent disk to be just too small
    size = size + 100 * 1024 * 1024
    for disk in infos['disks']:
        logger.debug("Checking disk {}".format(disk['name']))
        disk_in_use = False
        for vg in infos['vg']:
            logger.debug("in vg {}".format(vg['name']))
            for pv in vg['pvs']:
                logger.debug("pv {}".format(pv['name']))
                if disk['name'] in pv['name']:
                    logger.debug("disk {} is used".format(disk['name']))
                    disk_in_use = True

        logger.debug(
            "in_use: {}, size: {}, disk_size: {}, smallest_disk_size: {}".format(disk_in_use, size, disk['size'],
                                                                                 smallest_disk_size))
        if not disk_in_use and int(disk['size']) >= size and int(disk['size']) < smallest_disk_size:
            smallest_disk_name = disk['name']
            smallest_disk_size = int(disk['size'])
            logger.debug("found smaller disk {} matching".format(smallest_disk_name))

    if smallest_disk_name != "":
        return smallest_disk_name
    else:
        return None


def get_vg_operation(vg_needs, infos):
    """
    return vg and disk in case of extension needed
    :rtype: object
    """
    logger.info("Checking vg free size")
    logger.debug("vg_needs: {}".format(vg_needs))
    if not vg_needs:
        return None, None, False
    for name, need in vg_needs.iteritems():
        logger.debug("Checking if {} vg has enough space".format(name))
        vg_infos = infos['vg']
        existing_vg = False
        for vg in vg_infos:
            if name == vg['name']:
                existing_vg = True
                logger.debug("Existing {} vg has {} free space, {} needed".format(name, vg['freeSize'], need))
                if int(need) > int(vg['freeSize']):
                    unused_disk = get_free_pv(infos, int(need) - int(vg['freeSize']))
                    if unused_disk == None:
                        # TODO appel VRA pour ajouter disque
                        raise ValueError("Not enough free space on {} vg".format(name))
                    else:
                        # TODO appel script pour agrandir vg avec nouveau disque
                        return name, unused_disk, True

        if not existing_vg:
            # TODO appel VRA pour ajouter disque
            # TODO appel script pour creer vg avec nouveau disque
            unused_disk = get_free_pv(infos, need)
            if unused_disk:
                return name, unused_disk, False
            else:
                raise ValueError("No disk available to create vg {}".format(name))

    return None, None, False


def check_fs_list(fs_list):
    """
    :param fs_list: fs_list variable from ansible module call
    """
    if not isinstance(fs_list, list):
        raise ValueError("fs_list must be a list")

    for fs in fs_list:
        if not isinstance(fs, dict):
            raise ValueError("fs item must be a dictionary, not {}".format(type(fs)))
        if not "mountpoint" in fs:
            raise ValueError("mountpoint is mandatory in fs item {}".format(fs))
        elif not re.match('^(\/[\w^]+)*\/?$', fs["mountpoint"]):
            raise ValueError("mountpoint is not valid for fs item {}".format(fs))
        if not "size" in fs:
            raise ValueError("size is mandatory in fs item {}".format(fs))
        if not "vg" in fs:
            fs["vg"] = "SocleVg"
        if not "user" in fs:
            fs["user"] = "-1"
        if not "group" in fs:
            fs["group"] = "-1"
        if not "file_mode" in fs:
            fs["file_mode"] = "-1"

def fs_present(params, config):
    """
    :param params: ansible role variables
    :param config: dict of variables from config file
    """
    logger.info("Present in edge fs ansible module")

    result = "OK"
    has_changed = False

    try:
        check_fs_list(params['module_fs_list'])
    except Exception, e:
        result = "Exception : {}".format(e)
        raise

    # envoyer le script python sur la cible
    try:
        logger.info("Sending {} to {}".format(GTS_FS_SCRIPT, params['module_hostname']))
        logger.info("Using key file {}".format(config['ROOT_KEY_path']))
        client = open_ssh_connection(config['ROOT_KEY_username'], params['module_hostname'], config['ROOT_KEY_path'])
        send_file_over_ssh(client, GTS_FS_SCRIPT)

    except Exception, e:
        result = "Exception : {}".format(e)
        raise

    try:
        # recuperer la config disk/vg/fs de la cible
        logger.info("Calling script on {} to get lvm informations".format(params['module_hostname']))
        json_output = run_python_over_ssh(client, "{} get_infos".format(os.path.join("/tmp", GTS_FS_SCRIPT)))
        logger.debug("Result  = {}".format(json_output))
        infos = json.loads(json_output)

        # calculer la taille necessaire pour chaque vg identifie
        logger.info("Computing vg needs")
        vg_needs = compute_vg_needs(params['module_fs_list'], infos)

        # Verifier que les besoins sont disponibles dans les vg existants ou disques libres
        vg, disk, existing_vg = get_vg_operation(vg_needs, infos)
        while (vg != None):
            if existing_vg:
                logger.info("Calling script on {} to add disk {} to vg {} ".format(params['module_hostname'], disk, vg))
                json_output = run_python_over_ssh(client,
                                                  "{} vg_extend {} {}".format(os.path.join("/tmp", GTS_FS_SCRIPT), vg,
                                                                              disk))
            else:
                logger.info("Calling script on {} to create vg {} with disk {} ".format(params['module_hostname'], vg, disk))
                json_output = run_python_over_ssh(client,
                                                  "{} vg_create {} {}".format(os.path.join("/tmp", GTS_FS_SCRIPT), vg,
                                                                              disk))
            logger.debug("Result  = {}".format(json_output))
            has_changed = True
            infos = json.loads(json_output)
            vg_needs = compute_vg_needs(params['module_fs_list'], infos)
            vg, disk, existing_vg = get_vg_operation(vg_needs, infos)

        # Parcourir la liste des fs pour creation/extension
        for fs_entry in params['module_fs_list']:
            existing_fs = [x for x in infos['fs'] if fs_entry['mountpoint'] == x["mountpoint"]]
            if len(existing_fs) > 0:
                fs_size_in_bytes = convert_to_bytes(fs_entry['size'])
                if int(existing_fs[0]["size"])  >= fs_size_in_bytes:
                    logger.warning("FS {} : Requested size {} lower than actual size {}G. No action taken.".format(fs_entry['mountpoint'], fs_entry['size'], int(existing_fs[0]["size"]) / 1024 / 1024 / 1024 ))
                else:
                    logger.info("Calling script on {} to resize fs {} to size {} ".format(params['module_hostname'],
                                                                                      fs_entry['mountpoint'],
                                                                                      fs_entry.get('size')))
                    json_output = run_python_over_ssh(client,
                                                  "{} fs_resize {} {} {} {} {}".format(os.path.join("/tmp", GTS_FS_SCRIPT),
                                                                              fs_entry['mountpoint'],
                                                                              fs_entry['size'], fs_entry['user'], 
                                                                              fs_entry['group'], fs_entry['file_mode']))
                logger.debug("Result  = {}".format(json_output))
            else:
                logger.info("Calling script on {} to create fs {} on vg {} to size {}".format(params['module_hostname'],
                                                                                              fs_entry['mountpoint'],
                                                                                              fs_entry.get('vg',
                                                                                                           'SocleVg'),
                                                                                              fs_entry.get('size')))
                json_output = run_python_over_ssh(client,
                                                  "{} fs_create {} {} {} {} {} {}".format(os.path.join("/tmp", GTS_FS_SCRIPT),
                                                                                 fs_entry['mountpoint'],
                                                                                 fs_entry['size'],
                                                                                 fs_entry.get('vg', 'SocleVg'),
                                                                                 fs_entry['user'], fs_entry['group'], 
                                                                                 fs_entry['file_mode']))
                logger.debug("Result  = {}".format(json_output))

            has_changed = True

    except Exception, e:
        result = "Exception : {}".format(e)
        raise

    return has_changed, result


def fs_absent():
    """
    :param params: ansible role variables
    :return:
    """
    # TODO: delete fs
    return False, None


def main():
    """
    Main function
    :return: role entry point
    """

    fields = {
        "module_hostname": {"required": True, "type": "str"},
        "module_fs_list": {"required": True, "type": "list"},
        "module_action": {"default": "present", "choices": ['present', 'absent'], "type": 'str'},
    }

    choice_map = {
        "present": fs_present,
        "absent": fs_absent,
    }

    module = AnsibleModule(argument_spec=fields)

    if module._verbosity == 1:
        logger.setLevel(logging.INFO)
    if module._verbosity == 3:
        logger.setLevel(logging.DEBUG)

    logger.info("Starting edge fs ansible module")
    logger.debug("action = {}, hostname= {}, fs_list = {}".format(module.params['module_action'],
                                                                  module.params['module_hostname'],
                                                                  module.params['module_fs_list']))
    try:
        config = sg_gts_tools.read_settings.read_settings(GTS_CLOUD_PUBKEY)
        has_changed, result = choice_map.get(module.params['module_action'])(module.params, config)

    except Exception, e:
        logger.exception(e)
        module.fail_json(msg="{}".format(str(e)), debug_out=logstream.getvalue())

    module.exit_json(changed=has_changed, meta=str(result), debug_out=logstream.getvalue())


if __name__ == '__main__':
    main()

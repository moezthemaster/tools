import logging

from edge.conf.cloud_network import find_network_infos

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class TestConf:

    def test_find_network_infos_ret(self):
        env, region_cloud, az_cloud, network_id, network_cidr, dns_zone, dns_cname = find_network_infos("192.36.69.1")
        assert dns_cname == "wce.bsc.socgen"

    def test_find_network_infos_mkt(self):
        env, region_cloud, az_cloud, network_id, network_cidr, dns_zone, dns_cname = find_network_infos("192.160.64.1")
        assert dns_cname is None

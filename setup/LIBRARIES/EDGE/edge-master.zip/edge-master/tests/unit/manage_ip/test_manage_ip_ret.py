import logging

import pytest
from six import with_metaclass
from tests.mock.mock import MockDod
from tests.mock.idm import MockedIdm
from edge.manage_ip.manage_ip import ManageIP
from tests.mock.connectionhelper import MockedConnectionHelper
from edge.dns.metaclass import DnsFeederMetaClass, DnsUpdaterMetaClass, DnsCleanerMetaClass, DnsInformerMetaClass

# logging.basicConfig(level=logging.DEBUG)

logger = logging.getLogger(__name__)

# debug during test
# for e in SHARED_DATABASE:
#     if e['type'] == "A":
#         print "{} - {}".format(
#             e["hostname"], e["ip"]
#         )

# reset mock database due to residue in previous tests
# MockDod._LIST_NETWORK_SUBNET = set()
# MockDod._LIST_IP_RECORDED = set()
# MockDod._id = 0

SHARED_DATABASE = []
SHARED_DATABASE_IDM = [
    {"hostname": "for_raise_an_ip_confict", "ip": "111.80.16.2"},
    {"hostname": "for_raise_an_ip_confict", "ip": "111.80.16.4"},
    {  # raise an hostname conflict
        "hostname": "dpgalx004", "ip": "111.80.16.250"
    },

]
SHARED_DATABASE_CONNEXION_SSH = [
    {"ip": "111.80.16.5", "hostname": "dpgalx1000", "sshd": True, "rdp": False, "ping": False},
    {"ip": "111.80.16.8", "hostname": "dpgalx1001", "sshd": True, "rdp": False, "auth_failed": True, "ping": False},
    {"ip": "111.80.16.9", "hostname": "dpgalx1001", "sshd": False, "rdp": True, "ping": False},
    {"ip": "111.80.16.10", "hostname": "dpgalx1010", "sshd": False, "rdp": False, "ping": True}
]


class MockedFeederDodv2(with_metaclass(DnsFeederMetaClass, MockDod)):
    def __init__(self, *args, **kwargs):
        MockDod.__init__(self, (), hostname=None, shared_database=SHARED_DATABASE)


class MockedUpdaterDodv2(with_metaclass(DnsUpdaterMetaClass, MockDod)):
    def __init__(self, *args, **kwargs):
        MockDod.__init__(self, (), hostname=None, shared_database=SHARED_DATABASE)


class MockedCleanerDodv2(with_metaclass(DnsCleanerMetaClass, MockDod)):
    def __init__(self, *args, **kwargs):
        MockDod.__init__(self, (), hostname=None, shared_database=SHARED_DATABASE)


class MockedInformerDodv2(with_metaclass(DnsInformerMetaClass, MockDod)):
    def __init__(self, *args, **kwargs):
        MockDod.__init__(self, (), hostname=None, shared_database=SHARED_DATABASE)


class MockedIdmWrapper(MockedIdm):
    def __init__(self, env):
        MockedIdm.__init__(self, env, shared_database=SHARED_DATABASE_IDM)


class MockedIdmWrapperUnknownError(MockedIdm):
    def __init__(self, env):
        MockedIdm.__init__(self, env, shared_database=SHARED_DATABASE_IDM)

    def check_whats(self, *args, **kwargs):
        raise Exception('Unknown Error')


class MockedConnectionHelperImpl(MockedConnectionHelper):
    def __init__(self):
        MockedConnectionHelper.__init__(self, shared_database=SHARED_DATABASE_CONNEXION_SSH)


def insert_record(hostname=None):
    run_kwargs = {
        "env": "dev",
        "region_cloud": "EU France (Greater Paris)",
        "az_cloud": "eu-fr-paris-1",
        "network_id": "CDN",
        "trigram": "pga",
        "hostname": hostname,
        "max_retries": 1
    }
    feeder = ManageIP(
        MockedIdmWrapper, MockedConnectionHelperImpl, MockedFeederDodv2,
        MockedUpdaterDodv2, MockedCleanerDodv2
    )
    feeder.run(**run_kwargs)


def test_dod_by_metaclass_client_call():
    feeder = MockedFeederDodv2(
        "dev", 'EU France (Greater Paris)',
        'eu-fr-paris-1', 'CDN', trigram='pga', hostname=None
    )
    response = feeder.run()
    assert response["output"][0]["hostname"] == "dpgalx001"
    informer = MockedInformerDodv2(
        "dpgalx001", 'EU France (Greater Paris)',
        'eu-fr-paris-1', network_index="ret"
    )
    response = informer.run()
    assert response[0]["vm_hostname"] == "dpgalx001"
    updater = MockedUpdaterDodv2(
        "dev", 'EU France (Greater Paris)',
        'eu-fr-paris-1', 'CDN', trigram='pga', hostname="dpgalx001"
    )
    response = updater.run("ssh")
    assert "ssh" in response[0].split(" : ")[1].split(" -")[0]
    assert len(updater.dns_database) == 1
    cleaner = MockedCleanerDodv2(
        "dev", 'EU France (Greater Paris)',
        'eu-fr-paris-1', 'CDN', trigram='pga', hostname=response[0].split(" : ")[1].split(" -")[0]
    )
    cleaner.run()
    assert len(cleaner.dns_database) == 0


def init_params_for_get_ip():
    run_kwargs1 = {
        "env": "dev",
        "region_cloud": "EU France (Greater Paris)",
        "az_cloud": "eu-fr-paris-1",
        "network_id": "CDN",
        "trigram": "pga",
        "hostname": None,
        "max_retries": 1
    }
    run_kwargs2 = {
        "env": "dev",
        "region_cloud": "EU France (Greater Paris)",
        "az_cloud": "eu-fr-paris-1",
        "network_id": "CDN",
        "trigram": "pga",
        "hostname": None,
        "max_retries": 2
    }
    run_kwargs3 = {
        "env": "dev",
        "region_cloud": "EU France (Greater Paris)",
        "az_cloud": "eu-fr-paris-1",
        "network_id": "CDN",
        "trigram": "pga",
        "hostname": None,
        "max_retries": 3
    }
    return [
        (
            'get_ip_in_first_attempt', MockedIdmWrapper, MockedConnectionHelperImpl, MockedFeederDodv2,
            MockedUpdaterDodv2, MockedCleanerDodv2, run_kwargs1, "dpgalx001"
        ),
        (
            'get_ip_in_second_attempt', MockedIdmWrapper, MockedConnectionHelperImpl, MockedFeederDodv2,
            MockedUpdaterDodv2, MockedCleanerDodv2, run_kwargs2, "dpgalx002"
        ),
        (
            'get_ip_in_third_attempt', MockedIdmWrapper, MockedConnectionHelperImpl, MockedFeederDodv2,
            MockedUpdaterDodv2, MockedCleanerDodv2, run_kwargs3, "dpgalx003"
        ),
    ]


@pytest.mark.parametrize('test_type, idm, connexion_helper, feeder, updater, cleaner, run_kwargs, expect',
                         init_params_for_get_ip()
                         )
def test_manage_ip_get_ip(test_type, idm, connexion_helper, feeder, updater, cleaner, run_kwargs, expect):
    print("Name test : " + test_type)
    feeder = ManageIP(idm, connexion_helper, feeder, updater, cleaner)
    response = feeder.run(
        **run_kwargs
    )
    assert response["output"][0]["hostname"] == expect


def test_manage_ip_whats_hostname_conflict():
    run_kwargs = {
        "env": "dev",
        "region_cloud": "EU France (Greater Paris)",
        "az_cloud": "eu-fr-paris-1",
        "network_id": "CDN",
        "trigram": "pga",
        "hostname": None,
        "max_retries": 1
    }
    feeder = ManageIP(
        MockedIdmWrapper, MockedConnectionHelperImpl, MockedFeederDodv2,
        MockedUpdaterDodv2, MockedCleanerDodv2
    )
    try:
        feeder.run(
            **run_kwargs
        )
        assert False
    except Exception as err:
        assert "IP conflict with whats_hostname" in err.args[0]


def test_manage_ip_ssh_conflict():
    insert_record(hostname="dpgalx100")
    run_kwargs = {
        "env": "dev",
        "region_cloud": "EU France (Greater Paris)",
        "az_cloud": "eu-fr-paris-1",
        "network_id": "CDN",
        "trigram": "pga",
        "hostname": "dpgalx005",
        "max_retries": 1
    }
    feeder = ManageIP(
        MockedIdmWrapper, MockedConnectionHelperImpl, MockedFeederDodv2,
        MockedUpdaterDodv2, MockedCleanerDodv2
    )
    try:
        feeder.run(
            **run_kwargs
        )
        assert False
    except Exception as err:
        assert "IP conflict with unix server:" in err.args[0]

def test_manage_ip_rdp_conflict():
    run_kwargs = {
        "env": "dev",
        "region_cloud": "EU France (Greater Paris)",
        "az_cloud": "eu-fr-paris-1",
        "network_id": "CDN",
        "trigram": "pga",
        "hostname": "dpgalx006",
        "max_retries": 1
    }
    feeder = ManageIP(
        MockedIdmWrapper, MockedConnectionHelperImpl, MockedFeederDodv2,
        MockedUpdaterDodv2, MockedCleanerDodv2
    )
    try:
        feeder.run(
            **run_kwargs
        )
        assert False
    except Exception as err:
        assert "IP conflict with windows server:" in err.args[0]
        
def test_manage_ip_ping_conflict():
    run_kwargs = {
        "env": "dev",
        "region_cloud": "EU France (Greater Paris)",
        "az_cloud": "eu-fr-paris-1",
        "network_id": "CDN",
        "trigram": "pga",
        "hostname": "dpgalx1010",
        "max_retries": 1
    }
    feeder = ManageIP(
        MockedIdmWrapper, MockedConnectionHelperImpl, MockedFeederDodv2,
        MockedUpdaterDodv2, MockedCleanerDodv2
    )
    try:
        feeder.run(
            **run_kwargs
        )
        assert False
    except Exception as err:
        assert "IP conflict with a component:" in err.args[0]

def test_manage_ip_suppress_ghost_entries_in_case_of_unknwon_error():
    run_kwargs = {
        "env": "dev",
        "region_cloud": "EU France (Greater Paris)",
        "az_cloud": "eu-fr-paris-1",
        "network_id": "CDN",
        "trigram": "pga",
        "hostname": "dpgalx007",
        "max_retries": 1
    }
    feeder = ManageIP(
        MockedIdmWrapperUnknownError, MockedConnectionHelperImpl, MockedFeederDodv2,
        MockedUpdaterDodv2, MockedCleanerDodv2
    )
    try:
        feeder.run(
            **run_kwargs
        )
        assert False
    except Exception as err:
        cleaner = MockedCleanerDodv2(
            "dev", 'EU France (Greater Paris)',
            'eu-fr-paris-1', 'CDN', trigram='pga',
            hostname="dpgalx007"
        )
        cleaner.run()
        assert cleaner.changed is False
        assert "Unknown Error" in err.args[0]

#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
import subprocess

@given('check if pga test server')
def step_impl(context):
    output = subprocess.check_output('hostname').strip()

    if output == "peaalx21.dns20-3.socgen":
        context.params["vm_pubkey"] = "ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAyLXUQ9eoPr8Akx+WeJzRgAOMyUbTQ3/RDu44N2svQTa7I0ZKzqelNrSqqsgSmNN7giQGRyIvx/XgUwi9UjrxFX0XRTvwjAcXNHV2pxybbhPb8/2jiAfFTCjkwQBwtoSTEL1I5noAIgapQDZghYFkv0GUiAkebKzl0A+cNqm5Zc2UPNTqsCtIAZ5Uid+XOdECHan29Iyow0f+O/2O6mZKBGvWFJbRLCokKLUrTmhbgWIiWgQGp/PnF0XVVPiQgRfbRz1xH08JNiQz1lnvZ4ME4BhQoxSK1O8QL+dQsSXhvQyjfO8yYI+X4X73Ie9yBfZpPiGAZLo3hTVha46veVfZGw== automation@PGA"
      #  context.params["vm_desc"] = "[JENKINS SOFY] {}".format(context.params["vm_desc"])
        context.private_key = "/applis/pgapadm/.ssh/id_rsa"
    elif output == "pedglx112":
        context.private_key = "/applis/edgp/.ssh/id_rsa"
    else:
        context.private_key = "/home/automation/.ssh/id_rsa"

    assert context.failed is False


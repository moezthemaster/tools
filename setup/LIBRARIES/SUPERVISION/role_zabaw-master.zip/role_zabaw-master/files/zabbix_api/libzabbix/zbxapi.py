##############################################################################
#
# File		: zbxapi.py
#
# Date		: 12-12-2017
#
# Author	: Emmanuel TELECHEA - RESG/GTS/MKT/OPM
#
# Purpose	: Maintain Zabbix API def
#
##############################################################################
#
# History	:
#
# ET : 12-12-2017 : Creation
#
##############################################################################

import json
import logging

import requests
import urllib3

# Do not check certificate validity => Getting errors even when using SG UniPass cert
urllib3.disable_warnings()


##############################################################################
# Class : zbxApi
# Use handle Zabbix API calls
##############################################################################


class zbxApi(object):
    def __init__(self, zbxUrl, zbxUser, zbxPwd):
        self.logger = logging.getLogger(__name__)
        self.zbxApiHeaders = {'Content-Type': 'application/json-rpc'}
        self.zbxUrl = zbxUrl
        self.zbxUser = zbxUser
        self.zbxPwd = zbxPwd
        self.zbxApiData = ''
        self.zbxLoginToken = ''

    ##############################################################################
    # Zabbix REST WS logon method
    def zbxLogin(self):
        self.zbxApiData = \
            {
                'jsonrpc': '2.0',
                'method': 'user.login',
                'params':
                    {
                        'user': self.zbxUser,
                        'password': self.zbxPwd
                    },
                'id': 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to open Zabbix API session with error code : ' + zbxReturnCode)
            raise SystemExit('[ERROR] Unable to open Zabbix API session with error code : ' + zbxReturnCode)

        self.logger.debug('[LOG] Opening session to Zabbix WS with result : ' + zbxResponse.json()['result'])
        self.zbxLoginToken = zbxResponse.json()['result']
        return self.zbxLoginToken

    ##############################################################################
    # Method to retrieve GroupId from group name
    def zbxGetGroupId(self, zbxGroup):
        self.zbxApiData = \
            {
                'jsonrpc': '2.0',
                'method': 'hostgroup.get',
                'params':
                    {
                        'output': ['groupid'],
                        'filter':
                            {
                                'name': [zbxGroup]
                            }
                    },
                'auth': self.zbxLoginToken,
                'id': 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)
        zbxReturnCode = zbxResponse.status_code
        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to retreive groupId for group : ' + zbxGroup +
                              ' , with error code : ' + zbxReturnCode)
            raise SystemExit('[ERROR] Unable to retreive groupId for group : ' + zbxGroup +
                             ' , with error code : ' + zbxReturnCode)

        zbxGroupId = zbxResponse.json()['result'][0]['groupid']
        self.logger.debug('[LOG] Group : ' + zbxGroup + ' id is : ' + zbxGroupId)

        return zbxGroupId

    ##############################################################################
    # Method to retrieve host list from group id
    def zbxGetHostFromGroup(self, zbxGroupId):
        self.zbxApiData = \
            {
                'jsonrpc': '2.0',
                'method': 'host.get',
                'params':
                    {
                        'output': ['host', 'status', 'groups'],
                        'selectGrloups': ['groupid'],
                        'selectInventory': ['os', 'deployment_status'],
                        'withInventory': 1,
                        'groupids': [zbxGroupId]
                    },
                'auth': self.zbxLoginToken,
                'id': 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)
        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to retreive hosts from group id : ' + zbxGroupId +
                              ' , with error code : ' + zbxReturnCode)
            raise SystemExit('[ERROR] Unable to retreive hosts for group id : ' + zbxGroupId +
                             ' , with error code : ' + zbxReturnCode)

        return zbxResponse.json()['result']

    ##############################################################################
    # Method to link host to template
    def zbxLinkHostToTemplate(self, zbxHosId, zbxTemplateId):
        self.zbxApiData = \
            {
                'jsonrpc': '2.0',
                'method': 'host.massadd',
                'params': {
                    "hosts": [
                        {
                            "hostid": zbxHosId
                        },
                    ],

                    'templates': [
                        {"templateid": zbxTemplateId}
                    ]
                },
                'auth': self.zbxLoginToken,
                'id': 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)
        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to link host to template, with error code : ' + zbxReturnCode)
            raise SystemExit('[ERROR] Unable to link host to template, with error code : ' + zbxReturnCode)
        # print zbxResponse.json()
        return zbxResponse.json()['result']

    ##############################################################################
    # Method to link host to template
    def zbxUnlinkHostToTemplate(self, zbxHosId, zbxTemplateId):
        self.zbxApiData = \
            {
                'jsonrpc': '2.0',
                'method': "host.massremove",
                'params': {
                    "hostids": [zbxHosId],
                    "templateids_clear": zbxTemplateId
                },
                'auth': self.zbxLoginToken,
                'id': 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)
        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to unlink host to template, with error code : ' + zbxReturnCode)
            raise SystemExit('[ERROR] Unable to unlink host to template, with error code : ' + zbxReturnCode)

        return zbxResponse.json()['result']

    ##############################################################################
    # Method to retrieve GroupId from group name
    def zbxGetTemplateId(self, zbxTemplate):
        self.zbxApiData = \
            {
                'jsonrpc': '2.0',
                'method': 'template.get',
                'params':
                    {
                        'output': ['templateid'],
                        'filter':
                            {
                                'name': [zbxTemplate]
                            }
                    },
                'auth': self.zbxLoginToken,
                'id': 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)
        zbxReturnCode = zbxResponse.status_code
        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to retreive templateId for template : ' + zbxTemplate +
                              ' , with error code : ' + zbxReturnCode)
            raise SystemExit('[ERROR] Unable to retreive templateId for template : ' + zbxTemplate +
                             ' , with error code : ' + zbxReturnCode)

        zbxTemplateId = zbxResponse.json()['result'][0]['templateid']
        self.logger.debug('[LOG] Template : ' + zbxTemplate + ' id is : ' + zbxTemplateId)

        return zbxTemplateId

    ##############################################################################
    # Method to remove host from discovery group
    def zbxManageHostInitialGroups(self, zbxHost, zbxDiscoveryGroupId, zbxTargetGroupIds):

        # Check if host already belongs to other group than the discovery one
        zbxHostNbGroup = len(zbxHost['groups'])
        self.logger.debug('Host ' + zbxHost['host'] + ' (OS: ' + zbxHost['inventory']['os'] +
                          '  belongs to : ' + str(zbxHostNbGroup) + ' group(s)')

        # Remove host from Discovery group if already member of other one
        if zbxHostNbGroup != 1:

            groupList = []
            for group in zbxHost['groups']:
                if group['groupid'] == zbxDiscoveryGroupId:
                    continue
                else:
                    groupList.append(group['groupid'])

            self.zbxApiData = \
                {
                    'jsonrpc': '2.0',
                    'method': 'host.update',
                    'params':
                        {
                            'hostid': zbxHost['hostid'],
                            'groups': groupList
                        },
                    'auth': self.zbxLoginToken,
                    'id': 1
                }

            zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                        verify=False)
            zbxReturnCode = zbxResponse.status_code
            if zbxReturnCode != 200:
                self.logger.error('[ERROR] Unable to remove host: ' + zbxHost['host'] +
                                  ' from discovery group, with error code : ' + zbxReturnCode)
                raise SystemExit('[ERROR] Unable to remove host: ' + zbxHost['host'] +
                                 ' from discovery group, with error code : ' + zbxReturnCode)

        # Moving host to according groups
        else:
            self.zbxApiData = \
                {
                    'jsonrpc': '2.0',
                    'method': 'host.update',
                    'params':
                        {
                            'hostid': zbxHost['hostid'],
                            'groups': [zbxTargetGroupIds]
                        },
                    'auth': self.zbxLoginToken,
                    'id': 1
                }

            zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                        verify=False)

            zbxReturnCode = zbxResponse.status_code
            if zbxReturnCode != 200:
                self.logger.error('[ERROR] Unable to remove host: ' + zbxHost['host'] +
                                  ' from discovery group, with error code : ' + zbxReturnCode)
                raise SystemExit('[ERROR] Unable to remove host: ' + zbxHost['host'] +
                                 ' from discovery group, with error code : ' + zbxReturnCode)

    ##############################################################################
    # zbxGetHosts method


    def zbxGetHosts(self, zbxHostName):
        self.zbxApiData = \
            {
                'jsonrpc': '2.0',
                'method': 'host.get',
                'params':
                    {
                        'output': ['host', 'status'],
                        'selectInterfaces': ['ip', 'dns', 'port'],
                        'search': {'host': [zbxHostName]}
                    },
                'auth': self.zbxLoginToken,
                'id': 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to open Zabbix API session with error code : ' + zbxReturnCode)
            raise SystemExit('[ERROR] Unable to open Zabbix API session with error code : ' + zbxReturnCode)

        zbxHostList = zbxResponse.json()['result']
        return zbxHostList

    ##############################################################################
    # zbxGetTemplatesLinkedToHostid

    def zbxGetTemplatesLinkedToHostid(self, zbxHostId):
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "host.get",
                "params": {
                    "output": ["hostid"],
                    "selectParentTemplates": [
                        "templateid"
                    ],
                    "hostids": zbxHostId
                },
                "id": 1,
                "auth": self.zbxLoginToken,
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to open Zabbix API session with error code : ' + zbxReturnCode)
            raise SystemExit('[ERROR] Unable to open Zabbix API session with error code : ' + zbxReturnCode)
        return zbxResponse.json()['result']

    ##############################################################################
    # zbxDeleteHost method

    def zbxDeleteHost(self, zbxHost):
        self.zbxApiData = \
            {
                'jsonrpc': '2.0',
                'method': 'host.delete',
                'params': [zbxHost['hostid']],
                'auth': self.zbxLoginToken,
                'id': 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to open Zabbix API session with error code : ' + zbxReturnCode)
            raise SystemExit('[ERROR] Unable to open Zabbix API session with error code : ' + zbxReturnCode)

    def zbx_user_macro_create(self, **kwargs):
        """

        :param args: [{
                    "hostid": zbxhostid,
                    "macro": zbxmacro,
                    "value": zbxvalue
                }],
        :return:
        """
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "usermacro.create",
                "params": kwargs,
                "auth": self.zbxLoginToken,
                "id": 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code
        # print zbxResponse.json()

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to create user macros with error code : ' + zbxReturnCode)
            raise SystemExit('[ERROR] Unable to create user macros with error code : ' + zbxReturnCode)
        return zbxResponse.json()

    def zbx_user_macro_update(self, hostmacroid, value):
        """

        :param kwargs:
        :return:
        """
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "usermacro.update",
                "params": {
                    "hostmacroid": hostmacroid,
                    "value": value
                },
                "auth": self.zbxLoginToken,
                "id": 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)
        zbxReturnCode = zbxResponse.status_code
        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to update user macros with error code : ' + zbxReturnCode)
            raise SystemExit('[ERROR] Unable to update user macros with error code : ' + zbxReturnCode)
        return zbxResponse.json()

    def zbx_get_user_macros(self, host_id):
        """

        :param kwargs:
        :return:
        """
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "usermacro.get",
                "params": {
                    "output": "extend",
                    "hostids": host_id
                },
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to get user macros id with error code : ' + zbxReturnCode)
            raise SystemExit('[ERROR] Unable to get user macros id with error code : ' + zbxReturnCode)
        return zbxResponse.json()

    def zbx_delete_user_macros(self, hostmacroid):
        """

        :return:
        """
        """

        :param kwargs:
        :return:
        """
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "usermacro.delete",
                "params": [
                    hostmacroid
                ],
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to get user macros id with error code : ' + zbxReturnCode)
            raise SystemExit('[ERROR] Unable to get user macros id with error code : ' + zbxReturnCode)
        return zbxResponse.json()

    def zbx_get_hostgroup(self, group_name):
        """

        :param host_group:
        :return:
        """
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "hostgroup.get",
                "params": {
                    "output": "extend",
                    "filter": {
                        "name": [
                            group_name,
                        ]
                    }
                },
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to get host group with error code : ' + zbxReturnCode)
            raise SystemExit('[ERROR] Unable to get host group with error code : ' + zbxReturnCode)
        return zbxResponse.json()

    def zbx_hostgroup_msadd(self, group_id, host_id):
        """

        :param group_id:
        :param host_id:
        :return:
        """
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "hostgroup.massadd",
                "params": {
                    "groups": [
                        {
                            "groupid": group_id
                        }
                    ],
                    "hosts": [
                        {
                            "hostid": host_id
                        }
                    ]
                },
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to associate host in host group with error code : ' + zbxReturnCode)
            raise SystemExit('[ERROR] Unable to associate host in host group with error code : ' + zbxReturnCode)
        return zbxResponse.json()

    def zbx_hostgroup_msremove(self, group_id, host_id):
        """

        :param group_id:
        :param host_id:
        :return:
        """
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "hostgroup.massremove",
                "params": {
                    "groupids": [
                        group_id,
                    ],
                    "hostids": [
                        host_id
                    ]
                },
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to remove host from host group with error code : ' + zbxReturnCode)
            raise SystemExit('[ERROR] Unable to remove host from host group with error code : ' + zbxReturnCode)
        return zbxResponse.json()


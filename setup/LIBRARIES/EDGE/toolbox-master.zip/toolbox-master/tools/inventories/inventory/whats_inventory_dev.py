import os
import string
from logzero import logger

dirname = os.path.dirname(os.path.realpath(__file__))
if not dirname:
    FILE_EXPORT = os.path.join('conf', 'settings_prod.cfg')
else:
    FILE_EXPORT = os.path.join(dirname, 'conf', 'settings_prod.cfg')
os.environ["WHATSAW_CONFIG_FILE"] = FILE_EXPORT
os.environ["EDGE_CONFIG_FILE"] = FILE_EXPORT

import whatsaw
from whatsaw.token import Token
from whatsaw.conf import settings
from whatsaw.idm import IdmWrapper


class WhatsInventory(IdmWrapper):
    def __init__(self):
        logger.debug("__init__")
        os.environ["WHATSAW_CONFIG_FILE"] = FILE_EXPORT
        os.environ["EDGE_CONFIG_FILE"] = FILE_EXPORT
        reload(whatsaw.conf)
        reload(whatsaw.credential)
        reload(whatsaw.token)
        reload(whatsaw.idm)
        super(WhatsInventory, self).__init__("DEV")

    def check_in_whats(self, list_hosts, list_ips):
        os.environ["WHATSAW_CONFIG_FILE"] = FILE_EXPORT
        os.environ["EDGE_CONFIG_FILE"] = FILE_EXPORT
        reload(whatsaw.conf)
        reload(whatsaw.credential)
        reload(whatsaw.token)
        reload(whatsaw.idm)
        whats_entries = {}
        whats_ips = set([])
        whats_ip = ""
        for host in list_hosts:
            if '.' not in host and host not in whats_entries and host[0] == 'd':
                response = self.host_checker(hostname=host)
                logger.debug("Dev check %s : %r", host, response)
                if response['result'] is not None and \
                        response['result']["value"].startswith(host):
                    try:
                        whats_ip = response['result']['additional']['arecord'][0]
                        whats_ips.add(whats_ip)
                        if host in whats_entries:
                            whats_entries[host].append(whats_ip)
                        else:
                            whats_entries[host] = [whats_ip]
                    except IndexError:
                        logger.debug("Key error %s : %r", host, response)

        for ip in list_ips:
            if ip not in whats_ips:
                response = self.ip_checker(ip_address=ip, environment="dev")
                logger.debug("Dev check ip %s : %r", ip, response)
                if response['result'] is not None and\
                        response['result']["value"] == ip:
                    try:
                        whats_host = \
                            response['result']['additional']['idnsname'][0]
                        whats_ips.add(whats_ip)
                        if whats_host in whats_entries:
                            whats_entries[whats_host].append(ip)
                        else:
                            whats_entries[whats_host] = [ip]
                    except IndexError:
                        logger.debug("Key error %s : %r", ip, response)


        return whats_entries

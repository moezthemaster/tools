from sg_datalake import DatalakeRecord
from sample.core.utils import dl_logger

"""Exception"""


class InvalidUsage(Exception):
    status_code = 400

    def __init__(self, message, status_code=None, payload=None):
        Exception.__init__(self)
        self.message = message
        if status_code is not None:
            self.status_code = status_code
        self.payload = payload
        dl_logger.error(DatalakeRecord(event="exception",
                                       response_http_code=status_code,
                                       error_message=message,
                                       error_component='User'))

    def to_dict(self):
        rv = dict(self.payload or ())
        rv['message'] = self.message
        return rv

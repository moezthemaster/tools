INFOS_FIELDS = {
    'resourceData': {'MachineName': 'vm_hostname',
                     'MachineCPU': 'vm_cpu',
                     'MachineMemory': 'vm_memory',
                     'ip_address': 'ip_address',
                     'MachineGroupName': 'vm_bg',
                     'MachineBlueprintName': 'vm_os',
                     'MachineStatus': 'vm_status',
                     },
    'extended': {'provider-AvailabilityZone': 'vm_az',
                 'provider-Region': 'vm_region',
                 'provider-Description': 'vm_desc',
                 'provider-Subnet': 'vm_subnet',
                 'provider-Replication': 'vm_replication',
                 'provider-Backup': 'vm_backup',
                 'provider-Environment': 'vm_env'
                 }
}
PROFILES_MAP = {
    "1": {"1024": "Micro 1vCPU-1GB", "2048": "Small 1vCPU-2GB", "4096": "Small-mem4 1vCPU-4GB"},
    "2": {"2048": "Medium-mem2 2vCPU-2GB", "4096": "Medium 2vCPU-4GB", "8192": "Medium-mem8 2vCPU-8GB",
          "16384": "Medium-mem16 2vCPU-16GB", "32768": "Medium-mem32 2vCPU-32GB"},
    "4": {"8192": "Large 4vCPU-8GB", "16384": "Large-mem16 4vCPU-16GB", "32768": "Large-mem32 4vCPU-32GB"},
    "8": {"16384": "XLarge 8vCPU-16GB", "32768": "XLarge-mem32 8vCPU-32GB",
          "65536": "XLarge-mem64 8vCPU-64GB", "131072": "XLarge-mem128 8vCPU-128GB"}
}
BACKUP_MAP = {
    "Daily | 31d retention | 02h00 AM": "daily-31d-2AM",
    "Daily | 31d retention | 04h00 AM": "daily-31d-4AM"
}
REGIONS_MAP = {"eu-fr-paris": "EU France (Greater Paris)",
               "eu-fr-north": "EU France (North)"
}
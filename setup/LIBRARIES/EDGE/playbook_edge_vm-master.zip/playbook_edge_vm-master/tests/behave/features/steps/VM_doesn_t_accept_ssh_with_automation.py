#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
import paramiko

@then('VM doesn t accept ssh with automation')
def step_impl(context):
    print("Test connection to VM {}, IP {}\n".format(context.vm_hostname, context.vm_ipaddr))

    # Create a paramiko Key from specified file
    key = paramiko.RSAKey.from_private_key_file('/var/lib/awx/.ssh/id_rsa')

    # Open a SSH connection to VM
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
      client.connect(hostname=context.vm_ipaddr, username='automation', pkey=key)
      client.close()
    except (BadHostKeyException, AuthenticationException, SSHException, socket.error) as e:
        print(e)
        # si on ne peut se connecter à la VM le test est valide
        assert context.failed is False
    
    assert context.failed is True

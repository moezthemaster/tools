
import os
import logging
from pathlib import Path


def set_up_logger(app_name, log_file, log_level="INFO"):
    """

    :param task_id: celery task id or uuid
    :param task_name: celery task name
    :param log_folder: parent log folder
    :param log_level: log level
    :return: logger
    """
    logger = logging.getLogger(app_name)
    task_log_folder = os.path.dirname(log_file)
    path = Path(task_log_folder)
    path.mkdir(parents=True, exist_ok=True)
    handler = logging.FileHandler(log_file)
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)
    logger.setLevel(logging.getLevelName(log_level))
    return logger

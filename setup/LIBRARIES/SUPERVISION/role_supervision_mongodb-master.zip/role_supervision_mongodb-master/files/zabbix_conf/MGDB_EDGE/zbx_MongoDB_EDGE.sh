#!/bin/bash
##################################################
# Main authors: Arnauld FRACHE and Olivier ANSQUIN
# Description: zabbix mongodb monitor
# Date: 2018, december 1
# Version: 1.0
# MongoDB account
# Requirements: mongo, jq 
# Example :
# ./zbx_MongoDB.sh localhost 12500 zabbix zabbix dauddaud connections available
# ./zbx_MongoDB.sh localhost 12500 zabbix zabbix dauddaud connections current
# Results : numbers ...
# 
##################################################
# set -xv # Debug
#
DB_HOST=$1
DB_PORT=$2
DB_USERNAME=$3
DB_PASSWORD=$4
DB_INSTANCE=$5
# $6,$7,$8,$9,$10 : others parameters from zabbix item - filter 
# 
##################################################
# ENV - path for Mongo DB
##################################################
# echo $DB_HOST # for debug host
#
MONGO=`which mongo`
#
########
# echo "verif path Mongo:" $MONGO # DEBUG use
JQ="/etc/zabbix/zabbix_agentd.d/MGDB_EDGE/jq"
#echo "verif path jq tool :" $JQ # DEBUG use
EXIT_ERROR=1
EXIT_OK=0
# Exit if problem 
if [ ! -x "$MONGO" ] ; then
  echo "mongo not found"
  exit $EXIT_ERROR
elif [ ! -x "$JQ" ] ; then
  echo "jq not found"
  exit $EXIT_ERROR
elif [ $# -eq 0 ] ; then
  echo "No values pass"
  exit $EXIT_ERROR
fi
#
##########################################
# DATA COLLECTION
# Build request 
index=.$(echo $6 $7 $8 $9 | sed 's/[ ,]/./g')
# echo "Index :" $index # for debug
#
MONGO_CMD="$MONGO --host ${DB_HOST} --port ${DB_PORT} --authenticationDatabase admin --quiet"
[[ "$DB_USERNAME" ]] && MONGO_CMD="${MONGO_CMD} --username ${DB_USERNAME}"
[[ "$DB_PASSWORD" ]] && MONGO_CMD="${MONGO_CMD} --password ${DB_PASSWORD}"
#$MONGO_CMD <<< "db.runCommand( { serverStatus: 1} )" 
output=$(
	$MONGO_CMD <<< "db.runCommand( { serverStatus: 1} )" |\
	sed -e 's/NumberLong(\(.*\))/\1/ 
	  s/ISODate(\(.*\))/\1/
	  s/ObjectId(\(.*\))/\1/
	  s/Timestamp(.*)/"&"/
	  s/"\([0-9]*\)"/\1/
	  s/"hash" : BinData.*/"hash":"",/'
)
# sed command : convert data output from the mongo command to JSON format
# Last line of sed command : necessary with MongoDB cluster  
mongo_status=${PIPESTATUS[0]}
if [ $mongo_status -ne $EXIT_OK ] ; then
  echo "mongo exec error"
  exit $EXIT_ERROR
fi
value=$(echo $output | $JQ $index)
jq_status=$?
# Send result to Zabbix
echo $value
### END

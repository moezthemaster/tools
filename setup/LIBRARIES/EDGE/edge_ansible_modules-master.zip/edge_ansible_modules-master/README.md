# edge_ansible_modules
This repo contains ansible modules used by A4C and Ansible Tower developped by Edge feature team.


___
## sg_gts_storage
This module manages storage on a VM.

### dependencies
- edge: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge.git
- cloudaw: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/cloudaw.git


### Module arguments

|   Variable           | Description                                | Choices   | Default  |  Required  |
|:--------------------:|:------------------------------------------:|:---------:|:--------:|:-----------|
|  state               | Add a disk on a virtual machine            | present   | present  |    True    |
|  vm_hostname         | Your Server name                           |           |    " "   |    True    |
|  disk_size           | Size of the disk (gigabytes, integer)      |           |    20    |    True    |


### Example

```yaml
- name: Adding a disk to a VM
  sg_gts_storage:
    state: "present"
    vm_hostname: "dpgalx5000"
    disk_size: 20
  register: add_storage_result
  environment:
    EDGE_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/{{EDGE_settings_file}}"
    CLOUDAW_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/{{CLOUDAW_settings_file}}"
```

#### Note
This module uses Edge Python Libraries, that's why we have to set CLOUDAW_CONFIG_FILE and EDGE_CONFIG_FILE.


___
## sg_gts_cloud_vm2
This module create/delete a VM.

### dependencies
- edge: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge.git
- cloudaw: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/cloudaw.git


### Module arguments

|   Variable           | Description                                | Choices                    | Default               |  Required         |
|:-----------------:|:---------------------------------------------:|:--------------------------:|:---------------------:|:------------------|
|  state            | create/remove/get infos virtual machine       |  present, absent, status   |   present             |    True          |
|  app_id           | Your trigram                                  |                            |    " "                |    True           |
|  vm_hostname      | Your Server name                              |                            |    " "                |    True           |
|  vm_desc          | Your server description                       |                            |    " "                |    False           |
|  app_env          | Your application environement                 |  'dev', 'hml', 'prd'       |    'prd'              |    False          |
|  vm_profile       | Your server profile                           | See playbook_edge_vm       | Micro 1vCPU-1GB       |    False          |
|  ip_address       | Your server's ip address                      |                            |      " "                 |    True          |
|  vm_subnet        | Your server subnet                            |                            |       " "               |    True          |
|  vm_region        | Your server region                            | 'EU France (Greater Paris)', 'EU France (North)'                            | EU France (Greater Paris)                      |    False          |
|  vm_az            | Your server AZ                                | 'eu-fr-paris-1', 'eu-fr-paris-2', 'eu-fr-north-1'                           | "eu-fr-paris-1"                      |    False          |
|  vm_os            | Your server operationg system                 | See playbook_edge_vm                           | "RHEL_7.3_x64-RET-EDGE"                       |    False          |
|  data_disk        | Your server data disk size                    | 0, 20, 60, 160, 300, 500, 750, 1000, 2000                           |       0                |    False          |
|  vm_replication   | Activate or not replication for your server   |    True , False                        |    False                   |    False          |
|  vm_backup        | Activate or not backup for your server   | 'none', 'daily-31d-2AM', 'daily-31d-4AM'                           |    none                   |    False          |
|  extended_infos   | Get extended informations about your server   |         True , False                   |    False                   |    False          |
|  kpi_data         | Your server profile                           |                            |                       |    True          |


### Example

```yaml
- name: Create vm
  sg_gts_cloud_vm2:
    app_id: "{{app_id}}" 
    vm_hostname: "{{edge_vm_hostname}}" 
    vm_desc: "{{vm_desc}}" 
    app_env: "{{app_env}}" 
    vm_profile: "{{vm_profile}}" 
    ip_address: "{{ip_address}}" 
    vm_subnet: "{{subnet}}" 
    vm_region: "{{vm_region}}" 
    vm_az: "{{vm_az}}" 
    vm_os: "{{vm_os}}" 
    data_disk: "{{data_disk}}" 
    vm_backup: "{{vm_backup}}" 
    vm_replication: "{{vm_replication}}" 
    state: "{{state}}" 
    kpi_data: "{{kpi_index_data}}"
  register: create_vm_result
  environment:
    EDGE_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/{{EDGE_settings_file}}"
    CLOUDAW_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/{{CLOUDAW_settings_file}}"
```
#### Note
The module needs informations about environement. That's why we have to set CLOUDAW_CONFIG_FILE and EDGE_CONFIG_FILE.


___
## sg_gts_whats
This module register/delete a VM in whats.

### dependencies
- whatsaw: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/whatsaw.git


### Module arguments

|   Variable           | Description                                | Choices                    | Default               |  Required         |
|:-----------------:|:---------------------------------------------:|:--------------------------:|:---------------------:|:------------------|
|  state            | Enrole/remove/check server in IDM             |  present, absent, status   |   present             |    True           |
|  whats_hostname   | Server to unrole or un_unrole                 |                            |    " "                |    True           |
|  whats_ip         | Server @IP to unrole or un_unrole             |                            |    " "                |    True           |
|  whats_trigram    | Your application trigram                      |                            |    " "                |    True           |

### Example

```yaml
- name : Whats Pre-enrolment
   sg_gts_whats:
     whats_ip: "ip adress of server to register in IDM"
     whats_hostname: "hostname to register in IDM"
     whats_trigram: "trigram"
     state: "present"
    register: result_whats
    environment:
      WHATSAW_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/settings_{{app_env}}.cfg"
      EDGE_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/{{EDGE_settings_file}}"
```
#### Note
The module needs informations about environement. That's why we have to set WHATSAW_CONFIG_FILE and EDGE_CONFIG_FILE.


___
## sg_gts_marley
This module register/delete a VM in Marley.

### dependencies
- incubaw: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/incubaw.git

### Module arguments


|   Variable           | Description                                | Choices                | Default               |  Required         |
|:-----------------:|:---------------------------------------------:|:----------------------:|:---------------------:|:------------------|
|  state            | Register or delete server in Marley           |  present, absent       |   present             |     True          |
|  marley_operation | Register or delete server in Marley           |  create, decom         |     create                  |    False          |
|  vm_hostname      | Your server hostname                          |       " "              |        " "               |    False          |
|  vm_os            | Your server operating system                  | see playbook_edge_vm   | RHEL_7.3_x64-RET-EDGE |    False          |
|  vm_profile       | Your server profile                           | see playbook_edge_vm   |  Micro 1vCPU-1GB      |    False          |
|  code_irt         | Your irt code                                 |                        |        " "              |    False          |
|  endClient        | Register or delete server in Marley           |  GTS, ITIM, BSC        |        " "              |    False          |
|  app_env          | Your server environement                      |  dev, hml, prd         |         prd           |    False          |
|  disk_size        | your server disk size                         |  [0, 20, 60, 160, 300, 500, 750, 1000, 2000    |       0                |    False          |
|  vm_backup        | Activate or not backup for your server        |  'none', 'daily-31d-2AM', 'daily-31d-4AM'      |    none                   |    False          |
|  kpi_data         | Register or delete server in Marley           |                        |                       |              |


### Example

```yaml
- name: _ Invoke Step_Marley_V5 HPOO Flow _
  sg_gts_marley:
      marley_operation: "create"
      vm_hostname: "{{edge_vm_hostname}}"
      vm_os: "{{vm_os}}"
      vm_profile: "{{vm_profile}}"
      code_irt: "{{code_irt}}"
      endClient: "{{endClient}}"
      app_env: "{{app_env}}"
      disk_size: "{{data_disk}}"
      vm_backup: "{{vm_backup| default('none')}}"
      kpi_data: "{{ kpi_index_data }}"
  environment:
    EDGE_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/{{EDGE_settings_file}}"
    INCUBAW_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/{{INCUBAW_settings_file}}"
  register: response_step1
```
#### Note
The module needs informations about environement. That's why we have to set INCUBAW_CONFIG_FILE and EDGE_CONFIG_FILE.


___
## sg_gts_dod1
This module register a dns entry in dodv1

### dependencies
- dodaw: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/dodaw.git
- edge: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge.git


### Module arguments

|   Variable           | Description                                | Choices                    | Default               |  Required         |
|:-----------------:|:---------------------------------------------:|:--------------------------:|:---------------------:|:------------------|
|  state            | register/remove server in dodv1               |  present, absent,          |   present             |    True          |
|  vm_hostname   | Your server hostname                 |                            |    " "                |    True           |
|  vm_network         | Your server network             |                            |     " "                  |    True           |
|  vm_subnet    | Your server subnet                     |                            |    " "                  |    False           |
|  dns_zone       | Your server zone                           |                            |     " "                 |    False          |
|  vm_region       | Your server region      | 'EU France (Greater Paris)' , 'EU France (North)'                           | EU France (Greater Paris)                      |    False          |
|  vm_az       | Your server az                           | 'eu-fr-paris-1', 'eu-fr-paris-2', 'eu-fr-north-1'                         |      "eu-fr-paris-1"                 |    False          |
|  app_env       | Your server environement                           | 'dev', 'hml', 'prd',                          |       'prd'                |    False          |


### Example

```yaml
- name : Record dns
   sg_gts_dod1:
     vm_hostname: "{{edge_vm_hostname}}"
     vm_network: "{{vm_network}}"
     vm_subnet: "{{vm_subnet}}"
     dns_zone: "{{dns_zone}}"
     vm_region: "{{vm_region}}"
     vm_az: "{{vm_az}}"
     app_env: "{{app_env}}"
     state: "present"
    register: result
    environment:
      DODAW_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/settings_{{app_env}}.cfg"
      EDGE_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/{{EDGE_settings_file}}"
```
#### Note
The module needs informations about environement. That's why we have to set DODAW_CONFIG_FILE and EDGE_CONFIG_FILE.


___
## sg_gts_dod2
This module register a dns entry in dodv2

### dependencies
- dodaw: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/dodaw.git
- edge: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge.git


### Module arguments

|   Variable           | Description                                | Choices                    | Default               |  Required         |
|:-----------------:|:---------------------------------------------:|:--------------------------:|:---------------------:|:------------------|
|  state            | register/remove server in dodv2               |  present, absent,          |   present             |    True          |
|  vm_hostname   | Your server hostname                 |                            |    " "                |    True           |
|  vm_network         | Your server network             |                            |      " "                 |    True           |
|  vm_subnet    | Your server subnet                     |                            |     " "                 |    False           |
|  dns_zone       | Your server zone                           |                            |   " "                   |    False          |
|  vm_region       | Your server region      | 'EU France (Greater Paris)' , 'EU France (North)'                           | EU France (Greater Paris)                      |    False          |
|  vm_az       | Your server az                           | 'eu-fr-paris-1', 'eu-fr-paris-2', 'eu-fr-north-1'                         |      "eu-fr-paris-1"                 |    False          |
|  app_env       | Your application environement                           | 'dev', 'hml', 'prd',                          |       'prd'                |    False          |
|  app_id       | Your application trigram                           |                           |     " "                |    True          |
|  kpi_data       |                            |                          |                      |              |

### Example

```yaml
- name : Record dns
   sg_gts_dod2:
     vm_hostname: "{{edge_vm_hostname}}"
     vm_network: "{{vm_network}}"
     vm_subnet: "{{vm_subnet}}"
     dns_zone: "{{dns_zone}}"
     dns_publish: "{{dns_publish}}"
     vm_region: "{{vm_region}}"
     vm_az: "{{vm_az}}"
     app_env: "{{app_env}}"
     app_id: "{{app_id}}"
     kpi_data: "{{kpi_data}}"
     state: "present"
    register: result
    environment:
      DODAW_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/settings_{{app_env}}.cfg"
      EDGE_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/{{EDGE_settings_file}}"
```
#### Note
The module needs informations about environement. That's why we have to set DODAW_CONFIG_FILE and EDGE_CONFIG_FILE.


___
## sg_gts_kat2
This module gets endclient from kat.

### dependencies
- edge: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge.git
- incubaw: incubaw: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/incubaw.git

### Module arguments

|   Variable           | Description                                | Choices                    | Default               |  Required         |
|:-----------------:|:---------------------------------------------:|:--------------------------:|:---------------------:|:------------------|
|  state            | Get client from kat            |  present   |   present             |    True          |
|  app_id   | Your application trigram                 |                            |    " "                |    True           |
|  code_irt         | Your code IRT             |                            |        " "               |    True           |
|  kpi_data    |                       |                            |                       |               |
|  endClient       | End client                           |     'GTS', 'ITIM', 'BSC'                       |     "  "                 |    False          |

### Example

```yaml
- name : Get client from kat
   sg_gts_kat2:
     app_id: "{{app_id}}"
     code_irt: "{{code_irt}}"
     endClient: "{{endClient}}"
     kpi_data :
    register: result
    environment:
      INCUBAW_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/settings_{{app_env}}.cfg"
      EDGE_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/{{EDGE_settings_file}}"
```
#### Note
The module needs informations about environement. That's why we have to set WHATSAW_CONFIG_FILE and EDGE_CONFIG_FILE.


___
## sg_gts_networkhelper
This module configure server resolv.conf and ntp.

### dependencies
- edge: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge.git

### Module arguments

|   Variable           | Description                                | Choices                    | Default               |  Required         |
|:-----------------:|:---------------------------------------------:|:--------------------------:|:---------------------:|:------------------|
|  state            | configure resolv.con file             |  present   |   present             |    True          |
|  network_domain   | Your network domain                 |           " "                 |    " "                |    True           |
|  network_id         | Your network id             |             " "               |         " "              |    False           |
|  app_env    |  Your application environement                     |       'prd', 'hml', 'dev'                     |         'prd'              |        False       |
|  endClient       | Client                           | 'GTS', 'ITIM', 'BSC'      |          " "             |    False          |
|  kpi_data       |                            |                            |                       |              |

### Example

```yaml
- name : Configure vm network
   sg_gts_networkhelper:
     network_domain: "{{network_domain}}"
     network_id: "{{network_id}}"
     app_env: "{{app_env}}"
     endClient: "{{endClient}}"
     kpi_data :
    register: result
    environment:
      EDGE_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/{{EDGE_settings_file}}"
```
#### Note
The module needs informations about environement. That's why we have to set EDGE_CONFIG_FILE.


___
## sg_gts_connectionhelper
This module deploys the public key on vm.

### dependencies
- edge: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge.git

### Module arguments

|   Variable           | Description                                | Choices                    | Default               |  Required         |
|:-----------------:|:---------------------------------------------:|:--------------------------:|:---------------------:|:------------------|
|  state            | Deploy/checks ssh key              |  present, status   |   present             |    True          |
|  ip   | Your server ip address                 |                            |    " "                |    True           |
|  vm_hostname   | Your server name                 |                            |    " "                |    True           |
|  remote_user   | Your remote user                |                            |    "automation"                |    False           |
|  remote_group   | Your remote group                |                            |    "automation"                |    False           |
|  pubkey   | Your generated public key                 |                            |    " "                |    False           |
|  app_env    |  Your application environement                     | 'prd', 'hml', 'dev'           |       'prd'                |        False       |
|  endClient       | Client                           |  'GTS', 'ITIM', 'BSC'                          |      " "                 |    False          |
|  kpi_data       |                            |                            |                       |              |

### Example

```yaml
- name : Deploy ssh private key
   sg_gts_connectionhelper:
     ip: "{{network_domain}}"
     vm_hostname: "{{edge_vm_hostname}}"
     remote_user: "{{remote_user}}"
     remote_group: "{{remote_group}}"
     pubkey: "{{pubkey}}"
     app_env: "{{app_env}}"
     endClient: "{{endClient}}"
     kpi_data :
    register: result
    environment:
      EDGE_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/{{EDGE_settings_file}}"
```
#### Note
The module needs informations about environement. That's why we have to set WHATSAW_CONFIG_FILE and EDGE_CONFIG_FILE.


___
## sg_gts_fs
This module allows you to create or extend a fs..

### dependencies
- edge: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge.git

### Module arguments

|   Variable           | Description                                | Choices                    | Default               |  Required         |
|:-----------------:|:---------------------------------------------:|:--------------------------:|:---------------------:|:------------------|
|  module_action            | create/delete/get informations/ status of fs              |  'present', 'absent', 'infos', 'check'   |   infos             |    True          |
|  module_vm_hostname   | server_where_disk_should_be_mounted                 |                            |    " "                |    True           |
|  module_fs_list   | Your fs list to create or delete                |                            |    []                |    True           |


### Example

```yaml
- name : Manage file system
   sg_gts_fs:
     module_action: "{{action}}"
     module_vm_hostname: "{{edge_vm_hostname}}"
     module_fs_list:
         - { mountpoint: "/", size: "40G" }
         - { mountpoint: "/produits/patrol", size: "2G" }
         - { mountpoint: "/bases", size: "20G", vg: "BasesVg", uid: "oracle", gid: "dba", file_mode: "770" }
    register: result
```
#### Note
A filesystem is a dictionary containing entries :
- mountpoint: string, mandatory
- size: string, mandatory, ex: "20G"
- vg: string, optional, default is "SocleVg"
- user: string, optional, default is root
- group: string, optional, default is root
- file_mode: string, optional, default is "750"

**absent**
- vm_hostname : 'server_where_disk_should_be_unmounted'`
- do nothing for the moment

The following filesystem is currently supported:
- [ext4](http://en.wikipedia.org/wiki/Ext4)

More informations: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/role_edge_fs


___
## sg_gts_alias_dns

https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/role_edge_alias_dns
___
## sg_gts_manage_ip
This module register a dns entry and provide you an IP without any conflict from ssh, rdp, whats 

### dependencies
- dodaw: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/dodaw.git
- edge: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge.git
- whatsaw: https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/whatsaw.git


### Module arguments

|   Variable           | Description                                | Choices                    | Default               |  Required         |
|:-----------------:|:---------------------------------------------:|:--------------------------:|:---------------------:|:------------------|
|  state            | register/remove server in dodv2               |  present, absent,          |   present             |    True          |
|  vm_hostname   | Your server hostname                 |                            |    " "                |    True           |
|  vm_network         | Your server network             |                            |      " "                 |    True           |
|  vm_subnet    | Your server subnet                     |                            |     " "                 |    False           |
|  dns_zone       | Your server zone                           |                            |   " "                   |    False          |
|  vm_region       | Your server region      | 'EU France (Greater Paris)' , 'EU France (North)'                           | EU France (Greater Paris)                      |    False          |
|  vm_az       | Your server az                           | 'eu-fr-paris-1', 'eu-fr-paris-2', 'eu-fr-north-1'                         |      "eu-fr-paris-1"                 |    False          |
|  app_env       | Your application environement                           | 'dev', 'hml', 'prd',                          |       'prd'                |    False          |
|  app_id       | Your application trigram                           |                           |     " "                |    True          |
|  kpi_data       |                            |                          |                      |              |

### Example

```yaml
- name : Record dns
   sg_gts_manage_ip:
     vm_hostname: "{{edge_vm_hostname}}"
     vm_network: "{{vm_network}}"
     vm_subnet: "{{vm_subnet}}"
     dns_zone: "{{dns_zone}}"
     dns_publish: "{{dns_publish}}"
     vm_region: "{{vm_region}}"
     vm_az: "{{vm_az}}"
     app_env: "{{app_env}}"
     app_id: "{{app_id}}"
     kpi_data: "{{kpi_data}}"
     state: "present"
    register: result
    environment:
      DODAW_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/settings_{{app_env}}.cfg"
      EDGE_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/{{EDGE_settings_file}}"
      WHATSAW_CONFIG_FILE: "{{ansible_user_dir}}/tmp/{{playbook_version}}/settings_{{app_env}}.cfg"
```
#### Note
The module needs informations about environement. That's why we have to set DODAW_CONFIG_FILE and EDGE_CONFIG_FILE.
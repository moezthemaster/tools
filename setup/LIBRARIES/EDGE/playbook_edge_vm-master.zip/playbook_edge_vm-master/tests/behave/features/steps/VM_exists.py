#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *

@given('VM exists')
def vm_exists(context):
    assert context.failed is (context.vm_hostname == '' or context.ipaddr == '' )




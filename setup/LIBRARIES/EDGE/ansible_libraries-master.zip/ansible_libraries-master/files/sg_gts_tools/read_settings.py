#!/usr/bin/python
# -*- coding: utf-8 -*-

import ConfigParser
import string
import os
import logging
import re

def read_settings(config_file):
    logger = logging.getLogger()
    output = {}
    config = ConfigParser.SafeConfigParser()
    output['os_dir'] = os.path.dirname(os.path.realpath(__file__))

    # if not absolute path, we add the current working directory
    if config_file[0] != '/':
        config_file = os.path.join(output['os_dir'], "..", "config", config_file)

    try:
        logger.info("Reading config file {}".format(config_file))
        config.read(config_file)

        for each_section in config.sections():
            #print(each_section)
            for (each_key, each_val) in config.items(each_section):
                #print("  {}".format(each_key))
                label = "{}_{}" . format(each_section, each_key)
                try:
                    output[label] = config.get(each_section, each_key)
                    # be careful when decommenting this line, it will show passwords in debug output
                    #logger.debug("{} = {}".format(label, output[label]))
                except Exception, e:
                    logger.exception(e)
                    raise

    except Exception, e:
        logger.exception(e)
        raise

    #logger.debug("config = {}".format(output))
    return output

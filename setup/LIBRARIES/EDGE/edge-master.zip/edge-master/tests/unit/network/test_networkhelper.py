
import edge
import paramiko
import unittest
try:
    from unittest import mock
except ImportError:
    import mock

from edge.exception import EdgeException
from edge.network.networkhelper import NetworkHelper
from tests.mock.networkhelper import MockedNetworkHelper
from tests.mock.vm_session import MockVmSession, mocked_vault

SHARED_DATABASE = [
    {"ip": "111.80.12.192", "hostname": "dpgalx5900"},
    {"ip": "1.1.1.1", "hostname": "dpgalx00"},
]


class MockedHelper(MockedNetworkHelper):
    def __init__(self, shared_database=None):
        MockedNetworkHelper.__init__(self, shared_database)


class MockedVmSession(MockVmSession):

    def __init__(self, ip_address, shared_database=SHARED_DATABASE):
        MockVmSession.__init__(self, ip_address, shared_database)


class TestNetworkHelper(unittest.TestCase):

    @mock.patch.object(edge.network.networkhelper, 'VmSessionSsh', MockedVmSession)
    @mock.patch.object(edge.network.networkhelper.secrets, 'get_secrets', mocked_vault)
    def test_update_etc_host_ok(self):
        network_helper = NetworkHelper()
        reponse = ""
        reponse = network_helper.update_etc_host(ip_address='111.80.12.192', network_id='CDN')
        assert reponse == "OK"

    @mock.patch.object(edge.network.networkhelper, 'VmSessionSsh', MockedVmSession)
    @mock.patch.object(edge.network.networkhelper.secrets, 'get_secrets', mocked_vault)
    def test_update_etc_host_nok_timeout(self):
        network_helper = NetworkHelper()
        reponse = ""
        try:
            reponse = network_helper.update_etc_host(ip_address='111.80.12.198', network_id='CDN')
        except EdgeException as e:
            assert e.args[0] == "Error when adding repo IAS for cdn server : {}".format('111.80.12.198')
            return
        assert False

    @mock.patch.object(edge.network.networkhelper, 'VmSessionSsh', MockedVmSession)
    @mock.patch.object(edge.network.networkhelper.secrets, 'get_secrets', mocked_vault)
    def test_update_etc_host_nok(self):
        network_helper = NetworkHelper()
        try:
            reponse = network_helper.update_etc_host(ip_address='111.80.12.19', network_id='CDN')
        except EdgeException as e:
            assert e.args[0] == "Error when adding repo IAS for cdn server : {}".format('111.80.12.19')
            return
        assert False

    @mock.patch('edge.network.networkhelper.paramiko')
    @mock.patch.object(edge.network.networkhelper, 'VmSessionSsh', MockedVmSession)
    @mock.patch.object(edge.network.networkhelper.secrets, 'get_secrets', mocked_vault)
    def test_update_config_dns_ok(self, paramiko):
        network_helper = NetworkHelper()
        reponse = ""

        try:
            reponse = network_helper.update_dns_config(ip_address='111.80.12.192', network_id='CDN',
                                                       geo_domain='ppr.cdn.socgen', network_envi='dev')
        except EdgeException as e:
            print(e.args[0])
        assert reponse == "OK"

    @mock.patch('edge.network.networkhelper.paramiko')
    @mock.patch.object(edge.network.networkhelper, 'VmSessionSsh', MockedVmSession)
    @mock.patch.object(edge.network.networkhelper.secrets, 'get_secrets', mocked_vault)
    def test_update_config_dns_nok(self, paramiko):
        network_helper = NetworkHelper()
        reponse = ""

        try:
            reponse = network_helper.update_dns_config(ip_address='111.80.12.193', network_id='CDN',
                                                       geo_domain='ppr.cdn.socgen', network_envi='dev')
        except Exception as e:
            assert e.args[0] == "Error while execution command a=`hostname -s|tail -c2`;test=$(($a % 2));echo $test: SSHException: {}".format("111.80.12.193")

    @mock.patch('edge.network.networkhelper.paramiko')
    @mock.patch.object(edge.network.networkhelper, 'VmSessionSsh', MockedVmSession)
    @mock.patch.object(edge.network.networkhelper.secrets, 'get_secrets', mocked_vault)
    def test_config_ntp_ok(self, paramiko):
        network_helper = NetworkHelper()
        reponse = ""
        try:
            reponse = network_helper.configure_ntp(ip_address='111.80.12.192', network_id='CDN')
        except EdgeException as e:
            print(e.args[0])
        except Exception as e:
            print(e.args[0])
        assert reponse == "OK"

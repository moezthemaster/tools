#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
import paramiko
import subprocess

@then('VM accepts ssh with automation')
def step_impl(context):
    print("Test connection to VM {}, IP {}\n".format(context.vm_hostname, context.vm_ipaddr))

    output = subprocess.check_output('hostname').strip()
    if output == "peaalx21.dns20-3.socgen":
        PRIVATE_KEY = "/var/lib/awx/.ssh/id_rsa"
    else:
        PRIVATE_KEY = "/home/automation/.ssh/id_rsa"


    # Create a paramiko Key from specified file
    key = paramiko.RSAKey.from_private_key_file(PRIVATE_KEY)

    # Open a SSH connection to VM
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
      client.connect(hostname=context.vm_ipaddr, username='automation', pkey=key)
      client.close()
    except (BadHostKeyException, AuthenticationException, SSHException, socket.error) as e:
        print(e)
        assert context.failed is True
    
    assert context.failed is False

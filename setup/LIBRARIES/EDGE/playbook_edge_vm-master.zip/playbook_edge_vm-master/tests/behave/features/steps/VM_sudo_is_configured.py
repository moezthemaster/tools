#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
import testinfra


def cool_print():
    print("\n")
    print("###########################################################################################")
    print("#                        TEST SUDO IS WELL CONFIGURED ON MACHINE                          #")
    print("###########################################################################################")
    print("\n")


@then('VM sudo is configured')
def step_impl(context):
    #vm_trigram = "pga"  # todo: replace by context.params['app_id']
    #vm_hostname = "dpgalx015"  # todo: replace by context.vm_hostname
    bt_list = [
        "%btpma      ALL=NOPASSWD: /bin/su - {trigram}*adm".format(trigram=context.params['app_id']),
        "%btbks      ALL=NOPASSWD: /bin/su - {trigram}*adm".format(trigram=context.params['app_id']),
        "%btmcl      ALL=NOPASSWD: /bin/su - {trigram}*adm".format(trigram=context.params['app_id']),
        "%btnss      ALL=NOPASSWD: /bin/su - {trigram}*adm".format(trigram=context.params['app_id']),
        "%btplax     ALL=NOPASSWD: /bin/su - {trigram}*adm".format(trigram=context.params['app_id']),
        "%btapiibf   ALL=NOPASSWD: /bin/su - {trigram}*adm".format(trigram=context.params['app_id']),
        "%btapipla   ALL=NOPASSWD: /bin/su - {trigram}*adm".format(trigram=context.params['app_id']),
        "%btapiprg   ALL=NOPASSWD: /bin/su - {trigram}*adm".format(trigram=context.params['app_id']),
        "%btcyy      ALL=NOPASSWD: /bin/su - {trigram}*adm".format(trigram=context.params['app_id']),
        "%btdlv      ALL=NOPASSWD: /bin/su - {trigram}*adm".format(trigram=context.params['app_id']),
        "%btopmpla   ALL=NOPASSWD: /bin/su - {trigram}*adm".format(trigram=context.params['app_id']),
    ]

    server = testinfra.get_host('ssh://automation@' + context.params['vm_ipaddr'], sudo=True)

    cool_print()

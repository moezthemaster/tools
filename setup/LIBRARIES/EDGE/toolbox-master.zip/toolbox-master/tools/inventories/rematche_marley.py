#!/usr/bin/env python
# -*- coding: utf-8 -*-

''' Main census module. '''

__author__ = "FT Edge"
__version__ = "0.1.0"

import logging
import logzero
import os

logzero.loglevel(level=logging.WARNING)
from logzero import logger
import argparse

dirname = os.path.dirname(os.path.realpath(__file__))
if not dirname:
    FILE_EXPORT = os.path.join('conf', 'settings_prod.cfg')
else:
    FILE_EXPORT = os.path.join(dirname, 'conf', 'settings_prod.cfg')
os.environ["CLOUDAW_CONFIG_FILE"] = FILE_EXPORT
os.environ["DODAW_CONFIG_FILE"] = FILE_EXPORT
os.environ["EDGE_CONFIG_FILE"] = FILE_EXPORT
os.environ["VAULT_CONFIG_FILE"] = FILE_EXPORT
os.environ["INCUBAW_CONFIG_FILE"] = FILE_EXPORT
import inventory


def init_logger(level):
    ''' Init logger base on level specified.'''
    if level is None:
        level = 0
    if level >= 2:
        logzero.loglevel(level=logging.DEBUG)
    elif level == 1:
        logzero.loglevel(level=logging.INFO)
    else:
        logzero.loglevel(level=logging.WARNING)


def main(args):
    ''' Main function for inventory.'''
    init_logger(level=args.verbose)
    vra_inventory = inventory.VRAInventory(trigram=args.trigram,
                                           check_uat=not args.skip_uat_vra,
                                           check_prod=not args.skip_prod_vra)
    status_inventory = inventory.StatusInventory()

    # Inventaire VRA pour le trigramme
    vra_inventory.get_infos()

    # Update du status des VM
    vra_inventory.check_status(status_inventory)

    if args.cloud_inventory:
        print("## Cloud inventory for trigram : {}".format(args.trigram))
        vra_inventory.output()

    # Inventaire Marley pour le trigramme
    marley_inventory = inventory.MarleyInventory()
    marley_inventory.get_infos(trigram=args.trigram)
    marley_inventory.check_status(status_inventory)

    if args.marley_inventory:
        print("## Marley inventory for trigram : {}".format(args.trigram))
        marley_inventory.output()

    logger.debug("Checking for inconsistencies")
    marley_inventory.check_ghost_records(vra_inventory, trigram=args.trigram)
    marley_inventory.check_missing_records(vra_inventory, trigram=args.trigram)


if __name__ == '__main__':
    """ This is executed when run from the command line """

    parser = argparse.ArgumentParser()

    # Required positional argument
    parser.add_argument("trigram", help="The trigram to inventory")

    # Optional verbosity counter (eg. -v, -vv, -vvv, etc.)
    parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Verbosity (-v, -vv, etc)")

    # Specify output of "--version"
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s (version {version})".format(version=__version__))

    parser.add_argument("-c", "--cloud-inventory",
                        action="store_true", dest="cloud_inventory",
                        default=False,
                        help="Output cloud inventory")
    parser.add_argument("-m", "--marley_inventory",
                        action="store_true", dest="marley_inventory",
                        default=False,
                        help="Output Marley inventory")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--no_uat",
                       action="store_true", dest="skip_uat_vra",
                       default=False,
                       help="Skip calls to UAT VRA")
    group.add_argument("--no_prod",
                       action="store_true", dest="skip_prod_vra",
                       default=False,
                       help="Skip calls to PROD VRA")

    args = parser.parse_args()
    main(args=args)

# role_zabbix_supervision
=========

Requirements
------------

The target server shoud exist in the cloud

Dependencies
------------
None

Variables
------------
zabbix_action: create or delete

Example Playbook
----------------
```yaml
- hosts: target
  roles:
    - { role: role_zabaw }
```

Author Information
------------------

Feature Team EDGE

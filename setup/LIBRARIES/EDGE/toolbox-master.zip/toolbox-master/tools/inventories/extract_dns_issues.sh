grep ':DNS:' logs/*.log | egrep -v 'vip|cce|wce' | while read line; do
  trig=`echo $line | cut -c6-8`
  server=`echo $line | cut -d':' -f2`
  cause=`echo $line | cut -d':' -f4-`
  cloud=`egrep "$server:" logs/$trig.log | cut -d':' -f2`
  vmtype=`echo $cloud | cut -d';' -f1`
  ip=`echo $cloud | cut -d';' -f4`
  if [ "$vmtype" == "Edge" ]; then
    echo $trig $server $cause VM in cloud $ip
  elif [ "$vmtype" == "Core" ]; then
    echo "## CORE : $trig $server $cause"
  else
    echo "$trig $server $cause "
  fi
done

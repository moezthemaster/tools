#!/usr/bin/env python
# -*- coding: utf-8 -*-

import testinfra
import re
from behave import *
from time import sleep


def cool_print1():
    print("\n")
    print("###########################################################################################")
    print("#                           TEST SQUID RESTART AFTER VM REBOOT                            #")
    print("#                             Rebooting machine. Waiting.....                             #")
    print("###########################################################################################")
    print("\n")


def cool_print2():
    print("\n")
    print("###########################################################################################")
    print("#                      TEST SQUID RESTART AFTER KILLING HIS PROCESS                       #")
    print("#                           Killing squid process. Waiting.....                           #")
    print("###########################################################################################")
    print("\n")

def cool_print3():
    print("\n")
    print("###########################################################################################")
    print("#                      TEST SQUID HHTP_PORT IS LISTENING                                  #")
    print("#                           shoud listen on port: 3128                                    #")
    print("###########################################################################################")
    print("\n")

@then('Squid is installed and configured')
def step_impl(context):
    #vm_hostname = 'dpgalx001'
    reboot_command = 'sudo reboot'
    get_squid_pid_command = 'systemctl status squid'
    server = testinfra.get_host('ssh://automation@' + context.params['vm_ipaddr'])

    def get_squid_pid():
        ch = "Main PID"
        squid_status = server.run(get_squid_pid_command).stdout.splitlines()
        for i in squid_status:
            if re.search(ch, i) is not None:
                squid_pid = i.split()[2]
                return squid_pid
            else:
                pass

    cool_print1()
    server.run(reboot_command)
    sleep(10)
    pid_before_kill = get_squid_pid()

    count = 0

    while pid_before_kill is None and count < 6:
        try:
            sleep(10)
            pid_before_kill = get_squid_pid()
            count += 1
        except Exception:
            raise Exception("Somethong goes wrong!")

    if pid_before_kill is None:
        print("Squid automatic restart failed. PID is {}".format(pid_before_kill))
    else:
        print("Squid restarted automatically after VM reboot and his PID is: {}".format(pid_before_kill))
    cool_print2()

    server.run("sudo kill -9 {}".format(pid_before_kill))
    sleep(30)

    pid_after_kill = get_squid_pid()
    print("Squid PID after kill: {}".format(pid_after_kill))

    if pid_before_kill != pid_after_kill and None not in [pid_before_kill, pid_after_kill]:
        assert context.failed is False
    else:
        assert context.failed is True

    cool_print3()

    get_squid_port_command = "sudo netstat  -tlunp | grep  squid"
    squid_port = server.run(get_squid_port_command).stdout.splitlines()
    ch = "LISTEN"

    def get_http_port():
        for i in squid_port:
            if re.search(ch, i) is not None:
                port = i.split()[3]
                http_port = port[3:]
                return http_port

    squid_http_port = get_http_port()

    print("Squid is Listening on {} http_port".format(squid_http_port))
    print('port')
    if squid_http_port != 3128:
        assert context.failed is False
    else:
        assert context.failed is True
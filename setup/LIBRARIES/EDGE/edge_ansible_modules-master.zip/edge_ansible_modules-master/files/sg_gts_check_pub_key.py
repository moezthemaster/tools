import os
import sys
import logging
import datetime
import io



if "TREE_DIR" in os.environ.keys():
    ANSIBLE_MODULES_PATH = [
        os.path.join(os.environ["TREE_DIR"], 'roles/edge'),
        os.path.join(os.environ["TREE_DIR"], "library"),
        os.path.join(os.environ["TREE_DIR"], 'roles/py_edge_vault'),
    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/edge',
        './roles/py_edge_vault'
    ]

for path in ANSIBLE_MODULES_PATH:
    sys.path.append(path)

from ansible.module_utils.basic import AnsibleModule
from edge.kpi.elk import Loader
from edge.tools.tools import VmSessionSsh


formatter = logging.Formatter(fmt='%(asctime)s %(levelname)-8s %(message)s',
                              datefmt='%Y-%m-%d %H:%M:%S')
logstream = io.StringIO()
handler = logging.StreamHandler(logstream)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.addHandler(handler)
logger.setLevel(logging.WARNING)


CHECK_PUBKEY, CHECK_USER = 'check_vm_pubkey', 'check_user_existance'

FIELDS = {
    "pub_key": {"required": False, "type": "str"},
    "ip_address": {"required": True, "type": "str"},
    "user": {"required": False, "type": "str"},
    "action": {
        "default": "check_vm_pubkey",
        "choices": ['check_vm_pubkey', 'check_user_existance'],
        "required": False
    },
    "network": {
        "default": "ret",
        "choices": ['ret', 'mkt'],
        "required": False
    },
    "kpi_data": {
        "type": "dict"
    },
}

def index_error_kpi(kpi_data,kpi_start_time):
    try:
        kpi_end_time = datetime.datetime.now()
        kpi_data['duration'] = (kpi_end_time - kpi_start_time).seconds
        loader = Loader()
        loader.index_data(
            id_execution=kpi_data['id_execution'], timestamp=kpi_data['timestamp'],
            duration=kpi_data['duration'], service=kpi_data['service'],
            hostname=kpi_data['vm_hostname'], status="failure",
            category=kpi_data['category'], client=kpi_data['endClient'],
            trigram=kpi_data['app_id'], environment=kpi_data['app_env'],
            error=kpi_data['error'], playbook_version=kpi_data['playbook_version']
        )
    except Exception:
        pass

def main():

    module = AnsibleModule(argument_spec=FIELDS)
    if module._verbosity == 1:
        logger.setLevel(logging.INFO)
    if module._verbosity == 3:
        logger.setLevel(logging.DEBUG)
    logger.info('module sg_gts_check_pub_key')
    kpi_data = module.params['kpi_data']

    kpi_start_time = datetime.datetime.now()

    try:
        state = module.params['action']

        if isinstance(kpi_data, dict):
            kpi_data['service'] = 'sg_gts_check_pub_key_{}'.format(state)

        vm_session = VmSessionSsh(module.params['ip_address'])

        if state == CHECK_PUBKEY:
            response = vm_session.check_if_host_contains_pub_key(
                module.params['network'],
                pub_key=module.params['pub_key']
            )
            module.exit_json(changed=False, meta=response, debug_out=logstream.getvalue())

        elif state == CHECK_USER:
            response = vm_session.check_user_existance(
                module.params['user']
            )
            module.exit_json(changed=False, meta=response, debug_out=logstream.getvalue())

    except Exception as e:
        if isinstance(kpi_data, dict):
            kpi_data['error'] = e.args[0]
            index_error_kpi(kpi_data, kpi_start_time)
        module.fail_json(msg=e.args[0], debug_out=logstream.getvalue())


if __name__ == '__main__':
    main()

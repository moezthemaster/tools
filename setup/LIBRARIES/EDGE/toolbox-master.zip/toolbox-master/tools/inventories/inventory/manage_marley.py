import vm_informations
import os
import sys
import logging
import io
import datetime
import edge.interfaces
from time import sleep
from incubaw.hpoo import HpooAW
from edge.marley.manage_asset import MarleyLoader
from conf.inputs import INPUTS_DATA, FAKE_DATA

class MarleyHPOOImpl(edge.interfaces.MarleyHPOO):
    def __init__(self):
        self.hpoo = HpooAW()

    def marley_hpoo_execute(self, **params):
        return self.hpoo.execute(**params)

    def marley_hpoo_status(self, **params):
        return self.hpoo.check_completion_step(**params)


class MarleyLoaderImpl(MarleyLoader, MarleyHPOOImpl):
    pass


def get_irt_client_from_trigram(trigram):
    """

    :param trigram:
    :return: code_irt, client
    """
    try:
        code_irt = INPUTS_DATA[trigram.upper()]['code_irt']
        client = INPUTS_DATA[trigram.upper()]['client']
    except Exception:
        raise
    return code_irt, client


def run_marley_hpoo_flow(hostname, trigram, state):
    """

    :param hostname:
    :param trigram:
    :param state:
    :return:
    """
    try:
        marley = MarleyLoaderImpl()
        if state == 'create':
            vm_infos = vm_informations.get_vm_informations(hostname)
            inputs_data = get_irt_client_from_trigram(trigram)
            response = marley.invoc_step_marley_v5(
                marley_operation=state,
                vm_hostname=vm_infos['vm_hostname'],
                vm_os=vm_infos['vm_os'],
                vm_profile=vm_infos['vm_profile'],
                code_irt=inputs_data[0],
                endClient=inputs_data[1],
                app_env=vm_infos['vm_env'],
                disk_size='20',
                vm_backup=vm_infos['vm_backup']
            )
        elif state == 'decom':
            environment = get_host_environment(hostname=hostname)
            response = marley.invoc_step_marley_v5(
                marley_operation=state,
                vm_hostname=hostname.strip(),
                vm_os=FAKE_DATA['vm_os'],
                vm_profile=FAKE_DATA['vm_profile'],
                code_irt=FAKE_DATA['code_irt'],
                endClient=FAKE_DATA['endClient'],
                app_env=environment,
                disk_size=FAKE_DATA['disk_size'],
                vm_backup=FAKE_DATA['vm_backup']
            )
        return response
    except KeyError:
        log_infos(trigram=trigram, state='incomplet', hostname=hostname, id_execution='N/A', flow_status='N/A')
        pass
    except Exception:
        raise


def get_host_environment(hostname):
    """

    :param hostname:
    :return: environment
    """
    try:
        first_letter = str(hostname.strip()[:1])
        if first_letter.upper() == 'D':
            environment = 'DEV'
        elif first_letter.upper() == 'H':
            environment = 'UAT'
        elif first_letter.upper() == 'P':
            environment = 'PRD'
    except Exception:
        raise
    return environment


def get_marley_hpoo_flow_status(id_execution):
    try:
        marley = MarleyLoaderImpl()
        response = marley.marley_hpoo_status(executionId=id_execution)
    except Exception:
        raise
    return response


def log_infos(trigram, state, hostname, id_execution, flow_status):
    """

    :param trigram:
    :param state:
    :param hostname:
    :return:
    """
    log = "/tmp/logs/{}".format(trigram)
    try:
        os.makedirs(log, 0755)
    except OSError as e:
        if e.errno != os.errno.EEXIST:
            raise
        pass
    try:
        with open("{}/{}ed_asset_data_{}.log".format(log, state, trigram), "a") as log_file:
            log_file.write('{}:{}:{}\n'.format(hostname, id_execution, flow_status))
    except KeyError:
        pass
    except Exception:
        raise


def manage_asset(hostname, trigram, state):
    """

    :param hostname:
    :param trigram:
    :param state:
    :return:
    """
    try:
        execute = run_marley_hpoo_flow(hostname, trigram, state=state)
        status = get_marley_hpoo_flow_status(id_execution=execute['executionId'])
        log_infos(hostname=hostname, trigram=trigram, state=state, flow_status=status['resultStatusName'],
                  id_execution=execute['executionId'])
    except TypeError:
        pass
    except Exception:
        raise

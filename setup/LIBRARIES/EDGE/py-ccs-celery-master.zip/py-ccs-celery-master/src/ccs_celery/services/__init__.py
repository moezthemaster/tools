
from ccs_celery.services._kat.func import KatTask as kat
from ccs_celery.services._dod.func import DodTask as dod
from ccs_celery.services._cloud.func import CloudTask as cloud
from ccs_celery.services._marley.func import MarleyTask as marley
from ccs_celery.services._vm_infos.func import VmInfos as vminfos
from ccs_celery.services._dod.func import DodInfosTask as dodinfos
from ccs_celery.services._flexera.func import FlexeraTask as flexera
from ccs_celery.services._cloud.func import CloudInfosTask as cloudinfos
from ccs_celery.services._whats.func import WhatsTask as unregisterwhats
from ccs_celery.services._whats.func import WhatsInfosTask as whatsinfos
from ccs_celery.services._whats.func import WhatsTask as whatsprenrollment
from ccs_celery.services._marley.func import MarleyDecomTask as marleydecom
from ccs_celery.services._dod.func import UnRegisterDodTask as unregisterdod
from ccs_celery.services._connection.func import RegisterPubKeyTask as registerpubkey
from ccs_celery.services._network.func import ConfigureNetworkTask as configurenetwork
from ccs_celery.services._connection.func import UnRegisterPubKeyTask as unregisterpubkey
from ccs_celery.services._whats.func import RegisterWhatsClientTask as registerwhatsclient
from ccs_celery.services._network.func import ReConfigureNetworkTask as reconfigurenetwork
from ccs_celery.services._whats.func import UnRegisterWhatsClientTask as unregisterwhatsclient

__all__ = (
    kat, dod, whatsprenrollment, cloud, registerpubkey, configurenetwork, registerwhatsclient, marley, flexera,
    cloudinfos, dodinfos, marleydecom, unregisterwhats, unregisterwhatsclient, whatsinfos, unregisterdod,
    unregisterpubkey, reconfigurenetwork
)

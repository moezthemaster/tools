#!/bin/bash

readonly PROGNAME=$(basename $0)

usage="${PROGNAME} 3.2.0 patch
where:
    -h, --help
        Show this help text
    -d, --dev
        concatenate '.dev' to updated version
examples:
    ${PROGNAME} 3.2.0 minor"

if [ $# -eq 0 ]; then
  echo "$usage"
  exit 1
fi

function join_by { local IFS="$1"; shift; echo "$*"; }

current_version="${1}"
release_type="${2}"
concatenate_with_dev=false
if [[ ! ($current_version =~ ^[0-9]+\.[0-9]+\.[0-9]+(\.dev)?$) ]]; then
    echo "Invalid format for version. Use --help to see the valid value"
    exit 1
fi
if [[ ! ("$release_type" =~ ^(major|minor|patch)$) ]]; then
    echo "Invalid value for version's type. Use --help to see the valid value" >&2
    exit 1
fi

if [ "$#" -ne 0 ]; then
    while [ "$#" -gt 0 ]
    do
        case "$1" in
        -h|--help)
            echo "$usage"
            exit 0
            ;;
        -d|--dev)
            concatenate_with_dev=true
            ;;
        -*)
            echo "Invalid option '$1'. Use --help to see the valid options" >&2
            exit 1
            ;;
        # an option argument, continue
        *)  ;;
        esac
        shift
    done
fi
set -f
array=(${current_version//./ })
if [  $release_type = "major" ]; then
      array[0]=`expr ${array[0]} + 1`
      array[1]=0
      array[2]=0
elif [ $release_type = "minor" ]; then
      array[1]=`expr ${array[1]} + 1`
      array[2]=0
elif [ $release_type = "patch" ]; then
      array[2]=`expr ${array[2]} + 1`
fi
if [  "$concatenate_with_dev" = true ]; then
    array[3]="dev"
fi
join_by . ${array[@]}

import time
import paramiko
from edge.conf import settings
from edge.exception import EdgeException
from edge.tools.tools import VmSessionSsh


WHATS_CLIENT_CMD = "sudo ipa-client-install --domain={domain} --mkhomedir -w password --realm={realm} --hostname={hostname}.{domain}" \
                    " --unattended --no-ntp"

COMMAND_STATIC = 'static'
COMMAND_DYNAMIC = 'dynamic'



class RegisterWhatsClient(object):

    def __init__(self, ip_address, hostname, domain, realm):
        self.ip_address = ip_address
        self.hostname = hostname
        self.domain = domain
        self.realm = realm

    def launch(self, retries=12):
        vm_session = VmSessionSsh(self.ip_address)

        for num in range(0, retries):
            code_status, stdout, stderr = vm_session.execute_cmd(WHATS_CLIENT_CMD.format(domain=self.domain, hostname=self.hostname, realm=self.realm), COMMAND_DYNAMIC)

            if code_status not in (0, 3) and (num == retries - 1):
                raise EdgeException(
                    "Error RegisterWhatsClient : {}".format(stderr)
                )
            elif code_status in (0, 3):
                hostname_cmd = "sudo hostname {}".format(self.hostname)
                vm_session.execute_cmd(hostname_cmd, COMMAND_DYNAMIC)
                return {
                    "output": {
                        "code_status": code_status
                    }
                }
            time.sleep(5)
        raise EdgeException("Maximum attempts Register Whats Client...")

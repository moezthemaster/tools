#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
import socket
import time
import sys
import os

ANSIBLE_MODULES_PATH = [
    './roles/dodaw',
    './roles/py_edge_vault'
]
for path in ANSIBLE_MODULES_PATH:
    sys.path.append(path)


os.environ["DODAW_CONFIG_FILE"] = "./files/settings_prod.cfg"
os.environ["VAULT_CONFIG_FILE"] = "./files/settings_prod.cfg"

from dodaw.dod import DodWrapper
from dodaw.conf import settings



@Then('Alias is created')
def step_impl(context):
    print("Check if alias {} is created for VM {}\n".format(context.params['dns_alias_name'], context.params['vm_hostname']))

    dod = DodWrapper()
    records = dod.search_record(record_type='^CNAME$',
        dns_service='PRD2 France RET',
        hostname=context.params['vm_hostname'],
        view='production'
    )
    #print(records)
    #print(records[1]['alias'])
    assert records[1]['alias'] == context.params['dns_alias_name']


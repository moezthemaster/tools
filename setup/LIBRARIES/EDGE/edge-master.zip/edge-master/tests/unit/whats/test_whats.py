import logging

import pytest

from edge.conf import settings
from edge.whats.idm import Idm
from tests.mock.whats import MockedIdm
from edge.exception import ImproperlyConfigured

SHARED_DATABASE = []


class MockedWhats(MockedIdm, Idm):
    def __init__(self, env):
        MockedIdm.__init__(self, env=env, shared_database=SHARED_DATABASE)
        Idm.__init__(self)


class TestWhats(object):
    def test_create_whats(self):
        whats_hostname = "dpgalx5900"
        whats_ip= "10.12.55.8"
        whats_trigram = "pga"
        idm = MockedWhats('dev')
        response = idm.create_whats(whats_hostname=whats_hostname, whats_ip=whats_ip, whats_trigram=whats_trigram)
        assert response['error'] is None

    def test_create_whats_already_exists(self):
        whats_hostname = "dpgalx5900"
        whats_ip= "10.12.55.8"
        whats_trigram = "pga"
        idm = MockedWhats('dev')
        response = idm.create_whats(whats_hostname=whats_hostname, whats_ip=whats_ip, whats_trigram=whats_trigram)
        assert response['error']['code'] == 4002

    def test_check_whats(self):
        whats_hostname = "dpgalx5900"
        whats_ip= "10.12.55.8"
        idm = MockedWhats('dev')
        response = idm.check_whats(whats_ip,whats_hostname)
        assert response['msg'] == 'The hostname {} ({}) is well assigned'.format(whats_hostname, whats_ip)

    def test_check_ip(self):
        whats_hostname = "dpgalx5900"
        whats_ip= "10.12.55.8"
        idm = MockedWhats('dev')
        response = idm.check_ip(whats_hostname, whats_ip)
        assert 'The hostname {} is'.format(whats_ip) in response['msg']

    def test_delete_whats(self):
        whats_hostname = "dpgalx5900"
        idm = MockedWhats('dev')
        response = idm.delete_whats(whats_hostname)
        assert response['error'] is None

    def test_check_delete_whats(self):
        whats_hostname = "dpgalx5900"
        whats_ip= "10.12.55.8"
        idm = MockedWhats('dev')
        response = idm.check_whats(whats_ip,whats_hostname)
        assert response['msg'] == 'The hostname {} ({}) is not assigned in this domain'.format(whats_hostname, whats_ip)

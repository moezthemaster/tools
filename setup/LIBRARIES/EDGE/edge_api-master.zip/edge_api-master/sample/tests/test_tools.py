import pytest
from faker import Faker

from sample.apis import api
from sample.apis.contacts import ContactList
from sample.core.exception import InvalidUsage
from sample.tests.mock_classes import mock_get_token_info, fake_header


faker = Faker()


@pytest.mark.usefixtures("set_logger")
class TestTools(object):
    """Test get_sg_token method """

    def test_get_sg_token_empty(self, flask_app_client):
        """ Verify get_sg_token raising custom error on no header token"""
        with pytest.raises(InvalidUsage) as excinfo:
            flask_app_client.get(api.url_for(ContactList))
        assert excinfo.value.status_code == 401

    def test_get_sg_token_information(self, mocker, flask_app_client):
        """ Verify get_sg_token raising token information error"""
        mock_sg_connect = mocker.patch(
            "sample.core.decorators.sg_connect_client.get_token_info")
        mock_sg_connect.return_value = None
        with pytest.raises(InvalidUsage) as excinfo:
            flask_app_client.get(api.url_for(ContactList),
                                 headers=fake_header())
        assert excinfo.value.status_code == 400
        assert excinfo.value.message.startswith("Cannot retrieve information")

    def test_get_sg_token_loginad(self, mocker, flask_app_client):
        """ Verify get_sg_token raising login_ad error"""
        mock_sg_connect = mocker.patch(
            "sample.core.decorators.sg_connect_client.get_token_info")
        mock_sg_connect.return_value = mock_get_token_info(faker.
                                                           pystr(min_chars=32,
                                                                 max_chars=32),
                                                           ad=None)
        with pytest.raises(InvalidUsage) as excinfo:
            flask_app_client.get(api.url_for(ContactList),
                                 headers=fake_header())
        assert excinfo.value.status_code == 400
        assert excinfo.value.message.startswith("Cannot retrieve AD login")

    @pytest.mark.usefixtures("mock_db_session")
    @pytest.mark.usefixtures("sg_connect_token")
    def test_get_sg_token_instantiated(self, mocker, flask_app,
                                       flask_app_client):
        """ Verify get_sg_token g object instantiation"""
        with flask_app.app_context() as context:
            assert not hasattr(context.g, "token")
            res = flask_app_client.get(api.url_for(ContactList),
                                       headers=fake_header())
            assert res.status_code == 200
            assert hasattr(context.g, "token")


@pytest.mark.usefixtures("mock_db_session")
@pytest.mark.usefixtures("sg_connect_token")
class TestLogRequest(object):
    """ Test Log Request """

    def test_decorator_log_request(self, mocker, flask_app):
        """ Test that log_request is being called as a decorator """
        mocked_init = mocker.patch(
            'sample.core.decorators.log_request', autospec=True)
        from sample.core.decorators import log_request

        @log_request
        def decorated_func():
            print("decorated func")

        with flask_app.test_request_context():
            decorated_func()
            assert mocked_init.call_count == 1

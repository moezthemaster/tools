Role Redis_fs
=========

Creating a FS for a Redis Database.

This role is a prerequisite of [![CC0](role_redis)] (https://sgithub.fr.world.socgen/GTS-RET-DBA-COMPOSANTS-EDGE/role_redis)

If no action is specified when calling this role, it will execute the following action :
 1. __create.yml__ :
   * creating Group & User "redis"
   * creating FS /bases/redis


Here's a description of the other task that can be executed in this role, filling the *redis_action* with the name of the task requested :

 __delete.yml__ : removing Redis FS :
  * deleting Group & User "redis"
  * removing directories in /bases/redis (backups & logs)
  * removing FS /bases/redis


This role is developped for FastIT & PAAP projects. Some updates may have to be done for other needs : contact us :email: FR-FR-RET-ODB-L3@socgen.com, or Fork it.



Requirements
------------
Facts gathering shouldn't be disabled.

Target servers must be RHEL7.

When executing action "delete", a "delete" action should be executed from role role_redis.

Role Variables
--------------
Here are the requested values for each action :

__create.yml__
- redis_device_vg
- redis_db_install_size (increasing the size will be taken into account, decreasing it will failed)

__delete.yml__
- redis_device_vg
- "validate_decomissioning == 'yes'"



Dependencies
------------
None


Example Playbook
----------------

    - hosts: servers
      gather_facts: yes
      roles:
      - { role: role_redis_fs,
           redis_action: "create",
           redis_device_vg: "{{ vg_name }}",
           redis_db_install_size: "{{ db_install_size }}"
        }


Some example values that can be specified in a group_vars file : `~/group_vars/example.yml`
```yml
vg_name: "BdddVg"
db_install_size: "5g"
```



License
-------
[![CC0](https://www.usenix.org/legacy/events/usenix04/art/build_icons/bsd.gif)] (https://fr.wikipedia.org/wiki/Licence_BSD)

Author Information
------------------

GUFFROY Philippe


# Vault
This repo contrains the secret Id used to get credentials from vault, and a command whitelist used to check commands before executing them.
In order to edit or add new entries to the vault, refer to vault as a service [documentation](https://portalpaas.paas-dev.fr.world.socgen/vault/api/v1):

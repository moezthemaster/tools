#!/usr/bin/python
# -*- coding: utf-8 -*-

import json
import time
import logging

import requests
from random import randrange
from whatsaw.token import Token
from whatsaw.conf import settings
from whatsaw.exception import WhatsError
from requests_kerberos import HTTPKerberosAuth, REQUIRED
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from whatsaw.switch import whats_env

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
requests.packages.urllib3.disable_warnings()

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

renew_token = Token
MSG_ERRORS_TO_TREAT = ["No JSON object could be decoded", "line 1 column 1 (char 0)"]



def request(url, environment, data, max_retries=settings.MAX_RETRIES):
    """
    :param url:
    :param data:
    :return:
    """

    ssl = getattr(settings, 'SSL_{}'.format(environment))
    # warnings.simplefilter('ignore', urllib3.exceptions.SecurityWarning)
    headers = {"Referer": url, "Content-type": "application/json",
               "Accept": "application/json"}
    kerberos_auth = HTTPKerberosAuth(mutual_authentication=REQUIRED)
    r = requests.post(url=url, auth=kerberos_auth, data=json.dumps(data),
                      verify=ssl, headers=headers)
    try:
        r.json()
    except Exception as err:
        logging.info("err.args[0] : {}".format(err.args[0]))
        logging.debug("request whats :: Retrying number : {}".format(5 - max_retries))
        if (MSG_ERRORS_TO_TREAT[0] in err.args[0] or MSG_ERRORS_TO_TREAT[1] in err.args[0]) and max_retries > 0:
            time.sleep(randrange(settings.REQUEST_MIN_WAIT_TIME, settings.REQUEST_MAX_WAIT_TIME))
            renew_token(environment)
            return request(url, environment, data, max_retries=max_retries - 1)
        if (MSG_ERRORS_TO_TREAT[0] in err.args[0] or MSG_ERRORS_TO_TREAT[1] in err.args[0]) and max_retries == 0:
            raise WhatsError(
                "Maximum attemps for request url={} and data={}".format(
                    url, data
                )
            )
    return r

# idm_realm = getattr(settings, 'REALM_{}'.format(environment))

class IdmWrapper(object):
    def __init__(self, hostname):
        self.environment = whats_env.get_whats_environment(hostname)
        self.token = Token(self.environment)

    def get_realm(self):

        return getattr(settings, 'REALM_{}'.format(self.environment))

    def get_domain(self):
        return getattr(settings, 'DOMAIN_{}'.format(self.environment))

    def destroy_token(self):
        self.token.delete()

    def enroller(self, hostname, ip_address, trigram):
        """
        :param hostname:
        :param ip_address:
        :param trigram:
        :return:
        """
        data = {
            "id": 0,
            "method": 'iru_host_add',
            "params": [
                [
                    hostname
                ],
                {
                    "all": False,
                    "description": 'EDGE SERVER',
                    "force": False,
                    "ip_address": ip_address,
                    "non_standard": False,
                    "nsosversion": "Linux",
                    "random": False,
                    "raw": False,
                    "tla": [
                        trigram
                    ],
                    "userpassword": "password",
                    "version": "2.112"
                }
            ]
        }
        try:
            r = request(getattr(settings, 'URL_{}'.format(self.environment)), self.environment, data)
        except requests.exceptions.ConnectionError:
            r = request(getattr(settings, 'URLFAILOVER_{}'.format(self.environment)), self.environment, data)
        return r.json()

    def unroller(self, hostname):
        """
        :param hostname:
        :return:
        """
        data = {
            "id": 0,
            "method": 'iru_host_del',
            "params": [
                [
                    hostname
                ],
                {
                    "force": False,
                    "no_updatedns": False,
                    "version": "2.112"
                }
            ]
        }

        try:
            r = request(getattr(settings, 'URL_{}'.format(self.environment)), self.environment, data)
        except requests.exceptions.ConnectionError:
            r = request(getattr(settings, 'URLFAILOVER_{}'.format(self.environment)), self.environment, data)
        return r.json()

    def ip_checker(self, environment, ip_address):
        """
        :param ip_address:
        :return:
        """
        data = {
            "id": 0,
            "method": 'iru_ip4_exists',
            "params": [
                [
                    ip_address
                ],
                {
                    "all": False,
                    "raw": True,
                    "version": '2.112'
                }
            ]
        }
        try:
            r = request(getattr(settings, 'URL_{}'.format(self.environment)), self.environment, data)
        except requests.exceptions.ConnectionError:
            r = request(getattr(settings, 'URLFAILOVER_{}'.format(self.environment)), self.environment, data)
        return r.json()

    def host_checker(self, hostname):
        """
        :param hostname:
        :return:
        """
        data = {
            "id": 0,
            "method": 'iru_host_exists',
            "params": [
                [
                    hostname
                ],
                {
                    "all": False,
                    "raw": False,
                    "version": '2.112'
                }
            ]
        }
        try:
            r = request(getattr(settings, 'URL_{}'.format(self.environment)), self.environment, data)
        except requests.exceptions.ConnectionError:
            r = request(getattr(settings, 'URLFAILOVER_{}'.format(self.environment)), self.environment, data)
        return r.json()

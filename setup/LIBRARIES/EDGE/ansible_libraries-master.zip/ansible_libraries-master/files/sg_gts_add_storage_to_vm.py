#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import *
import re
import json
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from requests.auth import HTTPBasicAuth
import ConfigParser
import time
import datetime
import random
import string
import yaml

if "TREE_DIR" in os.environ.keys() : 
     ANSIBLE_MODULES_PATH = [
       './roles/ansible_libraries/files',  
       os.path.join(os.environ["TREE_DIR"], "library"),
        ]
else:
  ANSIBLE_MODULES_PATH = [
     './roles/ansible_libraries/files'
     ]

for path in ANSIBLE_MODULES_PATH:
  sys.path.append(path)

import sg_gts_tools.sg_gts_init



CONFIG_ROOT = '/etc/ansible'

GTS_CONFIG = 'gts_cloud_vm.cfg'


def default_config(params):


  isError, log, out = sg_gts_tools.sg_gts_init.read_settings(CONFIG_ROOT, GTS_CONFIG)

  global SETTINGS

  vOutput = {


    'catalog_url': "{}{}" . format(out['TOKEN_urlroot'], out['CATALOG_catalogsuffix']),
    'catalog_consumer': "{}{}" . format(out['TOKEN_urlroot'], out['CATALOG_consumersuffix']),
    'catalog_query': "{}{}" . format(out['TOKEN_urlroot'], out['CATALOG_querysuffix']),
    'catalog_filter': out['CATALOG_filter'],

  }


  SETTINGS.update( vOutput )

  # RETURN
  return isError, log, out


def get_vm_info(params):
    result = {}
    isError = False
    hasChanged = False

    # TOKEN
    token = {'Authorization': "Bearer {}".format(params['token'])}

    # GET VM CATALOG
    url = SETTINGS['catalog_query']
    status, output = sg_gts_tools.sg_gts_init.get_vm_catalog_json(url, params['vm_hostname'], **token)

    result['json'] = output
    # result['code_status'] = status
    # result['settings'] = SETTINGS
    requestId = 'Not-a-requestId'
    try:
        requestId = output['content'][0]['requestId']
    except Exception, e:
        # raise e
        pass

    # GET VM REQUEST
    url = "{}/{}".format(SETTINGS['catalog_consumer'], requestId)
    data = {}
    output = {}
    if requestId != 'Not-a-requestId':
        status, output = sg_gts_tools.sg_gts_init.submit_url_json('GET', url, data, **token)

    result['request'] = output
    result['code_status'] = status

    return isError, hasChanged, result


def add_vm_storage(data, params, **headerAuth):
    url = SETTINGS['catalog_consumer']

    try:

        vmId = data['id']
        operationId = data["resourceActionRef"]["id"]
        tenantRef = data['organization']['tenantRef']
        tenantLabel = data['organization']['tenantLabel']
        subtenantRef = data['organization']['subtenantRef']
        subtenantLabel = data['organization']['subtenantLabel']
        providerDiskSize = params['requestData']['entries']['provider-DiskSize']

        data = {
            "@type": "ResourceActionRequest",
            "resourceRef": {
                "id": vmId
            },
            "resourceActionRef": {
                "id": operationId
            },
            "organization": {
                "tenantRef": tenantRef,
                "tenantLabel": tenantLabel,
                "subtenantRef": subtenantRef,
                "subtenantLabel": subtenantLabel
            },
            "state": "SUBMITTED",
            "requestNumber": 0,
            "requestData": {
                "entries": [{
                    "key": "provider-DiskId",
                    "value": {
                        "type": "string",
                        "value": "New Disk"
                    }
                }, {
                    "key": "provider-DiskSize",
                    "value": {
                        "type": "decimal",
                        "value": providerDiskSize
                    }
                }]
            }
        }
        statusCode, jsonOutput = sg_gts_tools.sg_gts_init.submit_url_json('post', url, data, **headerAuth)

    except Exception, e:
        statusCode = 404
        jsonOutput = {}

    return statusCode, jsonOutput


def main():
    fields = {

        "token": {"required": True, "type": "str"},

        "vm_hostname": {"required": True, "type": "str"},
        "vm_ipaddress": {"required": False, "type": "str"},
        "providerDiskSize": {"required": True, "type": "int"},

        "state": {
            "default": "present",
            "choices": ['present'],
            "type": "str"
        },
    }

    choice_map = {
        "present": add_vm_storage,
    }

    module = AnsibleModule(argument_spec=fields)

    # Config settings
    isError, logOutput, output = default_config(module.params)

    if isError:
        module.fail_json(msg=logOutput)

    # state
    isError, hasChanged, result = choice_map.get(module.params['state'])(module.params)

    if not isError:
        module.exit_json(changed=hasChanged, meta=result)

    else:
        module.fail_json(msg="Error request cannot be completed", meta=result)


"""
"""
SETTINGS = {}

if __name__ == '__main__':
    main()

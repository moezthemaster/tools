import re
import os
import sys
import time
import logging
import datetime
import traceback
from six import with_metaclass

if "TREE_DIR" in os.environ.keys():
    ANSIBLE_MODULES_PATH = [
        os.path.join(os.environ["TREE_DIR"], 'roles/edge'),
        os.path.join(os.environ["TREE_DIR"], 'roles/dodaw'),
        os.path.join(os.environ["TREE_DIR"], 'roles/whatsaw'),
        os.path.join(os.environ["TREE_DIR"], "library"),
        os.path.join(os.environ["TREE_DIR"], 'roles/py_edge_vault'),
    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/edge',
        './roles/dodaw',
        './roles/whatsaw',
        './roles/py_edge_vault'

    ]
for path in ANSIBLE_MODULES_PATH:
    sys.path.insert(0, path)

from ansible.module_utils.basic import AnsibleModule

from edge.whats.idm import Idm
from edge.kpi.elk import Loader
from edge.interfaces import Dod
from dodaw.dod import DodWrapper
from edge.interfaces import DodV1
from whatsaw.idm import IdmWrapper
from edge.manage_ip.manage_ip import ManageIP
from edge.connection.connectionhelper import ConnectionHelper
from edge.dns.metaclass import DnsFeederMetaClass, DnsUpdaterMetaClass, DnsCleanerMetaClass, DnsInformerMetaClass

try:
    from dodaw.dodv1 import DodWrapper as DodV1Wrapper
except ImportError:
    class DodV1Wrapper(object):
        def __init__(self):
            raise Exception("Depedence Zeep must be installed for Dodv1")

logger = logging.getLogger(__name__)


class IdmImpl(Idm):
    def __init__(self, hostname):
        Idm.__init__(self)
        self.idm_wrapper = IdmWrapper(hostname)

    def get_realm(self):
        return self.idm_wrapper.get_realm()

    def get_domain(self):
        return self.idm_wrapper.get_domain()

    def destroy_token(self):
        return self.idm_wrapper.destroy_token()

    def enroller(self, hostname, ip_address, trigram):
        return self.idm_wrapper.enroller(hostname, ip_address, trigram)

    def unroller(self, hostname):
        return self.idm_wrapper.unroller(hostname)

    def ip_checker(self, hostname, ip_address):
        return self.idm_wrapper.ip_checker(hostname, ip_address)

    def host_checker(self, hostname):
        return self.idm_wrapper.host_checker(hostname)


class DodImpl(Dod):
    def __init__(self):
        self.dod_wrapper = DodWrapper()

    def search_dns_record(self, record_type, **kwargs):
        return self.dod_wrapper.search_record(record_type, **kwargs)

    def create_dns_record(self, dns_service, record_type, zone, view, hostname, **kwargs):
        return self.dod_wrapper.create_record(dns_service, record_type, zone, view, hostname, **kwargs)

    def update_dns_record(self, dns_service, id, record_type, zone, view, hostname, ip, **kwargs):
        logger.debug('update id {}'.format(id))
        return self.dod_wrapper.update_record(dns_service, record_type, zone, view, hostname, **kwargs)

    def delete_dns_record(self, dns_service, id):
        logger.debug('Delete id {}'.format(id))
        return self.dod_wrapper.delete_record(dns_service, id)

    def search_and_update_conflict_dns_records(self, dns_service, record_type, cause, limit_rows=10, **kwargs):
        return self.dod_wrapper.search_and_update_conflict_records(dns_service, record_type, cause, limit_rows,
                                                                   **kwargs)

    def search_and_delete_dns_records(self, dns_service, record_type, limit_rows=10, **kwargs):
        return self.dod_wrapper.search_and_delete_records(dns_service, record_type, limit_rows, **kwargs)


class DodV1Impl(DodV1):
    def __init__(self):
        self.dodv1_wrapper = DodV1Wrapper()

    def get_next_free_ip(self, *args, **kwargs):
        return self.dodv1_wrapper.get_next_free_ip(*args, **kwargs)

    def host_add(self, *args, **kwargs):
        return self.dodv1_wrapper.host_add(*args, **kwargs)

    def host_update(self, *args, **kwargs):
        return self.dodv1_wrapper.host_update(*args, **kwargs)

    def host_search_infos(self, *args, **kwargs):
        return self.dodv1_wrapper.host_search_infos(*args, **kwargs)

    def host_delete(self, *args, **kwargs):
        return self.dodv1_wrapper.host_delete(*args, **kwargs)


class DnsFeederAdapter(with_metaclass(DnsFeederMetaClass, DodImpl, DodV1Impl)):
    #__metaclass__ = DnsFeederMetaClass

    def __init__(self, *args, **kwargs):
        try:
            DodV1Impl.__init__(self)
        except Exception as err:
            if "Depedence Zeep must be installed for Dodv1" not in err.args[0]:
                raise Exception(err.args[0])
        DodImpl.__init__(self)


class DnsUpdaterAdapter(with_metaclass(DnsUpdaterMetaClass, DodImpl, DodV1Impl)):
    #__metaclass__ = DnsUpdaterMetaClass

    def __init__(self, *args, **kwargs):
        try:
            DodV1Impl.__init__(self)
        except Exception as err:
            if "Depedence Zeep must be installed for Dodv1" not in err.args[0]:
                raise Exception(err.args[0])
        DodImpl.__init__(self)


class DnsCleanerAdapter(with_metaclass(DnsCleanerMetaClass, DodImpl, DodV1Impl)):
    #__metaclass__ = DnsCleanerMetaClass

    def __init__(self, *args, **kwargs):
        try:
            DodV1Impl.__init__(self)
        except Exception as err:
            if "Depedence Zeep must be installed for Dodv1" not in err.args[0]:
                raise Exception(err.args[0])
        DodImpl.__init__(self)


class DnsInformerAdapter(with_metaclass(DnsInformerMetaClass, DodImpl, DodV1Impl)):
    #__metaclass__ = DnsInformerMetaClass

    def __init__(self, *args, **kwargs):
        try:
            DodV1Impl.__init__(self)
        except Exception as err:
            if "Depedence Zeep must be installed for Dodv1" not in err.args[0]:
                raise Exception(err.args[0])
        DodImpl.__init__(self)


PRESENT, ABSENT, INFOS = 'present', 'absent', 'infos'
NB_ATTEMPT = 3
FIELDS = {
    "vm_hostname": {
        "type": "str",
        "default": None
    },
    "vm_network": {
        "type": "str"
    },
    "vm_subnet": {
        "type": "str"
    },
    "dns_zone": {
        "type": "str"
    },
    "dns_publish": {
        "type": "str"
    },
    "vm_region": {
        "default": "EU France (Greater Paris)",
        "choices": [
            'EU France (Greater Paris)',
            'EU France (North)'
        ],
        "type": "str",
    },
    "vm_az": {
        "default": "eu-fr-paris-1",
        "choices": [
            'eu-fr-paris-1',
            'eu-fr-paris-2',
            'eu-fr-north-1'
        ],
        "type": "str",
    },
    "app_id": {
        "type": "str"
    },
    "app_env": {
        "type": "str",
        "choices": [
            'uat',
            'tst',
            'int',
            'dev',
            'hml',
            'prd'
        ],
        "default": "prd",
    },
    "kpi_data": {
        "type": "dict"
    },
    "network_index": {
        "type": "str",
        "default": "ret"
    },
    "state": {
        "default": PRESENT,
        "choices": [
            PRESENT,
            ABSENT,
            INFOS,
        ],
        "type": "str",
    },
}

REQUIRED_FIELDS = [
    ["state", PRESENT, ["app_id", "vm_network"]],
    ["state", ABSENT, ["vm_hostname"]],
    ["state", INFOS, ["vm_hostname"]]
]


def index_error_kpi(kpi_data):
    try:
        loader = Loader()
        loader.index_data(
            id_execution=kpi_data['id_execution'], timestamp=kpi_data['timestamp'], duration=kpi_data['duration'],
            service=kpi_data['service'],
            hostname=kpi_data['vm_hostname'], status="failure",
            category=kpi_data['category'], client=kpi_data['endClient'],
            trigram=kpi_data['app_id'], environment=kpi_data['app_env'],
            error=kpi_data["error"], playbook_version=kpi_data['playbook_version']
        )
    except Exception:
        pass


def main():
    module = AnsibleModule(argument_spec=FIELDS, required_if=REQUIRED_FIELDS)
    hostname = module.params['vm_hostname']
    state = module.params['state']
    region_cloud = module.params['vm_region']
    az_cloud = module.params['vm_az']
    env = module.params['app_env']
    kpi_data = module.params['kpi_data']
    kpi_start_time = datetime.datetime.now()

    if isinstance(kpi_data, dict):
        kpi_data['service'] = 'sg_gts_manage_ip_{}'.format(state)

    try:
        if state == PRESENT:
            trigram = module.params['app_id'].lower()
            network_id = module.params['vm_network']
            manage_ip = ManageIP(IdmImpl, ConnectionHelper, DnsFeederAdapter, DnsUpdaterAdapter, DnsCleanerAdapter)
            response = manage_ip.run(env, region_cloud, az_cloud, network_id, trigram, hostname)
            module.exit_json(changed=manage_ip.has_changed, meta=response)
        elif state == ABSENT:
            network_id = module.params['vm_network']
            trigram = module.params['app_id'].lower()
            cleaner = DnsCleanerAdapter(env, region_cloud, az_cloud, network_id, trigram=trigram, hostname=hostname)
            response = cleaner.run()
            module.exit_json(changed=cleaner.changed, meta=response)
        elif state == INFOS:
            informer = DnsInformerAdapter(hostname, network_index=module.params['network_index'],
                                          region_cloud=region_cloud, az_cloud=az_cloud)
            response = informer.run()
            module.exit_json(changed=informer.changed, meta=response)
    except Exception as e:
        if isinstance(kpi_data, dict):
            kpi_data['error'] = e.args[0]
            kpi_end_time = datetime.datetime.now()
            kpi_data['duration'] = (kpi_end_time - kpi_start_time).seconds
            index_error_kpi(kpi_data)
        if module._verbosity == 3:
            module.fail_json(msg=e.args[0], exception=traceback.format_exc())
        module.fail_json(msg=e.args[0])


if __name__ == '__main__':
    main()

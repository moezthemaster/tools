"""Model for Contact."""
from sample.resources.base import db


class Contact(db.Model):
    """Model for Contact."""
    __tablename__ = 'contact'

    id = db.Column(db.Integer, primary_key=True)
    team = db.Column(db.String(80), nullable=False)
    mail = db.Column(db.String(80))
    phone = db.Column(db.String(80))
    impulse_group = db.Column(db.String(80))
    jive = db.Column(db.String(80))
    doc_url = db.Column(db.String(80))
    preferred_method = db.Column(db.String(80), default="mail")

    def __init__(self, dict_args):
        self.id = dict_args.get("id")
        self.team = dict_args.get("team")
        self.mail = dict_args.get("mail")
        self.phone = dict_args.get("phone")
        self.impulse_group = dict_args.get("impulse_group")
        self.doc_url = dict_args.get("doc_url")
        self.jive = dict_args.get("jive")
        self.preferred_method = dict_args.get("preferred_method")

    def assign_attributes(self, dict_args):
        """ loop through dictionary arguement and assign each """
        for key, value in dict_args.items():
            if value is not None:
                setattr(self, key, value)

    def __str__(self):
        return '<Slb #%r> %r' % (self.id, self.team)


import time

from ccs_celery.abstract import TaskServiceManager
from ccs_celery.services.rollback import RollBackMixins
from ccs_celery.services._flexera.module import flexera_module


class FlexeraTask(TaskServiceManager, RollBackMixins):

    def __init__(self, data):
        super().__init__("Flexera", data)

    def on_failure(self, exc, kwargs, excinfo):
        try:
            self.rollback()
        except Exception as err:
            self.logger.error("Rollback for {} module has failded".format(str(err)))
        finally:
            self.data.services[self._task_name]["finished_at"] = time.time()
            self.data.services[self._task_name]["status"] = "FAILED"
            self.data.services[self._task_name]["exception_class"] = str(type(exc))
            self.data.services[self._task_name]["exception_msg"] = str(exc)
            self.data.services[self._task_name]["exception_traceback"] = str(excinfo)

    def on_success(self, result, kwargs):
        self.data.services[self._task_name]["finished_at"] = time.time()
        self.data.services[self._task_name]["status"] = "SUCCESS"
        self.data.services[self._task_name]["return_value"] = result

    def _set_up(self):
        self.data.services[self._task_name] = {
            "changed": False,
            "launch_at": time.time(),
            "service_kwargs": {}
        }
        self.data.services[self._task_name]["service_kwargs"]["state"] = self.data.shared_data["state"]
        self.data.services[self._task_name]["service_kwargs"]["vm_ip"] = self.data.shared_data["vm_ip"]


    def task(self):
        self._set_up()
        self.logger.info("Invoke {} module with kwargs={}".format(
            self._task_name,
            self.data.services[self._task_name]["service_kwargs"])
        )
        result = flexera_module(**self.data.services[self._task_name]["service_kwargs"])
        self.data.services[self._task_name]["changed"] = result[0]
        return result

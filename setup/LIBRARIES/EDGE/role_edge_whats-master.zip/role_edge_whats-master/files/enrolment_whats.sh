#!/bin/sh
#####################################################
#                                                   #
#      SCRIPT FOR ENRONLING HOST TO IDM : STEP 2     #
#                                                   #
#####################################################

# Description: this script will do step 2 of enroling host to IDM.
#		The operation follows the steps below.
#		1- Install ipa-client package if the it does not exist.
#		2- Enrole the host to IDM
#		3- Changing hostname back to original
#		4- Backup and update configurations

# Parameters :  -d domain -h hostname -p password

# ERROR CODES:
# 0 if the installation was successful
# 1 if an error occurred
# 2 if uninstalling and the client is not configured
# 3 if installing and the client is already configured
# 4 if an uninstall error occurred
# 5 If an argument is not found
# 6 If ipa-client install failed




while [[ $# -gt 1 ]]
do
	key="$1"
	case $key in
		-d|--domain)
		DOMAIN="$2"
		shift # past argument
		;;
		-h|--hostname)
		HOSTNAME="$2"
		shift # past argument
		;;
		*)
				# unknown option
		echo echo "Usage: basename $0 -d domain -h hostname -p password"
		exit 5
		;;
	esac
	shift # past argument or value
done

echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - scritp args :  "
if [[ -n $DOMAIN ]]
	then
		echo DOMAIN = "${DOMAIN}"
	else
		echo "[$(date +%Y-%m-%d\ %H:%M:%S)] - ERROR - domain is not set "
		exit 5
fi

if [[ -n $HOSTNAME ]]
	then
		echo HOSTNAME = "${HOSTNAME}"
	else
		echo "[$(date +%Y-%m-%d\ %H:%M:%S)] - ERROR - hostname is not set "
		exit 5
fi




# Vars
EXIT_CODE=1
GROUP_LIST="super lnxn1 lnxn2 storn1 storn2 storn3 backn1 backn2 backn dmqinf dmqmdb suppmut outils systeme applis ics dba ccase pilotage webm mqm"

# START
echo "-------------  START ------------- "

# 1- Install ipa-client package if the it does not exist.
echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - Checking ipa-client package  "
rpm -qa | grep 'ipa-client'
EXIT_CODE=$?
if [  $EXIT_CODE -eq 0  ]
     then
           echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - ipa-client is installed. Nothing to do "
     else
           echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - ipa-client not installed "
           echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO -  Installing ipa-client "
           yum install -y ipa-client >/dev/null 2>&1
		   EXIT_CODE=$?

           if [  $EXIT_CODE -eq 0  ]
           then
                  echo "[$(date +%Y-%m-%d\ %H:%M:%S)] SUCCESS - ipa-client successfully installed "
           else
                echo "[$(date +%Y-%m-%d\ %H:%M:%S)] ERROR - ipa-client installation failed with exit code : $EXIT_CODE "
                exit 6
           fi
fi

# 2- Enrole the host to IDM
echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - Enroling $HOSTNAME "
# ipa-client-install --domain=${domain} --mkhomedir -w '${otp}' --hostname=${hostname}.${domain} --no-ntp --unattended
ipa-client-install --domain=$DOMAIN --mkhomedir -w password --hostname=$HOSTNAME.$DOMAIN --no-ntp --unattended 2>&1
EXIT_CODE=$?

if [  $EXIT_CODE -eq 0  ]
     then
		echo "[$(date +%Y-%m-%d\ %H:%M:%S)]  SUCCESS - $HOSTNAME enrolment is successfull "
     else
		echo "[$(date +%Y-%m-%d\ %H:%M:%S)]  ERROR - $HOSTNAME enrolment has failed. Exiting process "
		exit $EXIT_CODE
fi

# 3- Changing hostname back to original
echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - Changing hostname back to original"
if [ $(hostname) = $HOSTNAME ]
	then
		echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - Hostname matches. No need to change "
	else
		hostname  $HOSTNAME
		echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - Hostname changed to $HOSTNAME"
fi


# 4- Backup and update configurations
echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - Checking /etc/nsswitch.conf "

# Search malformed sudoers line:
# sudoers: files sssnetgroup:   files sss
#
# Regex : ^(sudoers:)(\ +)(files)(\ +)(sss)$
#
grep -E "^(sudoers:)(\ +)(files)(\ +)(sss)$" /etc/nsswitch.conf
EXIT_CODE=$?

if [ $EXIT_CODE -eq 1 ]
	then
		# Replace line 'sudoers: files sssnetgroup:   files sss' by 'sudoers: files sss'
		echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - Updating sudoers line in /etc/nsswitch.conf "
		cp /etc/nsswitch.conf /etc/nsswitch.conf.$(date +%d%m%y%H%M)
		sed -i -r "s/^(sudoers:)(\ +)(files)(\ +)(sssnetgroup:)(\ +)(files)(\ +)(sss)$/\1\2\3\4\9/g"  /etc/nsswitch.conf
	else
		echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - sudoers line in /etc/nsswitch.conf look good."
fi


# Search user ID in /etc/passwd :
# sudoers: files sssnetgroup:   files sss
#
# Regex : ^(sudoers:)(\ +)(files)(\ +)(sss)$
#
echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - Searching user ID in /etc/passwd "
grep -E "^([ax]{1})([0-9]{6})" /etc/passwd
EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]
	then
		# Remove USER ID aXXXXXX xXXXXXX from /etc/passwd
		echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - Backing up and Removing account aXXXXXX xXXXXXX from /etc/passwd "
		cp /etc/passwd /etc/passwd.$(date +%d%m%y%H%M)
		sed -i -r '/^([ax]{1})([0-9]{6})/d'  /etc/passwd
	else
		echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - /etc/passwd looks good. "
fi

# Search user ID in /etc/shadow :
# sudoers: files sssnetgroup:   files sss
#
# Regex : ^(sudoers:)(\ +)(files)(\ +)(sss)$
#
echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - Search user ID in /etc/shadow "
grep -E "^([ax]{1})([0-9]{6})" /etc/shadow
EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]
	then
		# Remove USER ID aXXXXXX xXXXXXX from /etc/shadow
		echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - Backup and Remove account aXXXXXX xXXXXXX from /etc/shadow "
		cp /etc/shadow /etc/shadow.$(date +%d%m%y%H%M)
		sed -i -r '/^([ax]{1})([0-9]{6})/d'  /etc/shadow
		# Regex: /^([ax]{1})([0-9]{6})/d
	else
		echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - /etc/shadow looks good "
fi

# Delete group :
# "super lnxn1 lnxn2 storn1 storn2 storn3 backn1 backn2 backn dmqinf dmqmdb suppmut outils systeme applis ics dba ccase pilotage webm mqm"
#
#
#

echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - Backing up /etc/group "
cp /etc/group /etc/group.$(date +%d%m%y%H%M)

echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - Deleting groups: $GROUP_LIST "
for grp in $GROUP_LIST
do
	userdel $grp
done

EXIT_CODE=$?
if [ $EXIT_CODE -eq 0 ]
	then
		echo "[$(date +%Y-%m-%d\ %H:%M:%S)] INFO - Groups successfully deleted "
	else
		echo "[$(date +%Y-%m-%d\ %H:%M:%S)] WARNING - Delete group fail "
fi

echo "[$(date +%Y-%m-%d\ %H:%M:%S)] SUCCESS - $HOSTNAME successfully enroled "
echo "-------------  END ------------- "
exit 0
# END
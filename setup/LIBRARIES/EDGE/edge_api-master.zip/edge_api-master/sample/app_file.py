"""Initialize Flask."""
import os

from flask import Flask, render_template, jsonify, request
from flask_migrate import Migrate

from sample.resources.base import db
from sample.apis import api
from sample.core.exception import InvalidUsage


def create_app():
    """ To setup Flask app """
    app = Flask(__name__, static_folder='../swagger', static_url_path='',
                template_folder='../swagger/dist')
    load_config(app)
    database_init(app)
    api.init_app(app)
    init_demo(app)
    return app


def init_demo(app):
    """ Init demo """
    try:
        import memcache
        demo_db = memcache.Client([('127.0.0.1', 11211)])
    except ModuleNotFoundError:
        class _Client:
            def __init__(self, conn):
                self.hostname, self.port = conn[0]
                self.data = dict()

            def get(self, var):
                try:
                    return self.data[var]
                except KeyError:
                    pass

            def set(self, var, val):
                self.data[var] = val
                return True

            def delete(self, var):
                try:
                    del self.data[var]
                except KeyError:
                    pass
                return True

        class Memcache:
            Client = _Client

        demo_db = Memcache.Client([('127.0.0.1', 11211)])
    app.config["demo_db"] = demo_db
    api._config = app.config


def load_config(app):
    """Set app configuration variable."""
    app.config.from_object('config.default')
    # Load from env var
    if 'CONFFILE_PATH' in os.environ:
        app.config.from_envvar('CONFFILE_PATH')


def database_init(app):
    """Initialize the db."""
    db.init_app(app)
    Migrate(app, db)


app = create_app()


@app.route('/documentation/')
def swagger_template():
    """Serve swagger templated documentation"""
    return render_template('index.html', title='Swagger Template')


@app.route('/documentation/<path:filename>')
def swagger_static(filename):
    """Serve swagger related static files"""
    return app.send_static_file('dist/' + filename)


@app.errorhandler(InvalidUsage)
def all_exception_handler(error):
    """ Final catch to InvalidUsage exceptions
        return inner details of exception"""
    response = jsonify(error.to_dict())
    response.status_code = error.status_code
    return response


if __name__ == "__main__":
    app.run()

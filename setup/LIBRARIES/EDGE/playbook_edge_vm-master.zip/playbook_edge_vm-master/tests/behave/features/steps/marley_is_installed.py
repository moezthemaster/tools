#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
import re
import testinfra


@then('Marley is installed')
def step_impl(context):
    print("check marley agent installation")
    server = testinfra.get_host('ssh://automation@' + context.params['vm_ipaddr'])
    cron_scrpits = [
        'toplaunch.sh',
        'auditvol.sh',
        'runconfig.sh'
    ]

    command = "sudo crontab -l"
    result = server.run(command)
    for cron in cron_scrpits:
        if re.search(cron, result.stdout):
            assert context.failed is False
        else:
            assert context.failed is True

    scripts_dir = '/opt/auditvol/'
    audit_script = cron_scrpits[2]
    output = server.run('sudo {}{}'.format(scripts_dir, audit_script))
    if output.exit_status == 0:
        assert context.failed is False
    else:
        assert context.failed is True

#!/bin/ksh

# first, we configure python path for edge libs
cd `dirname $0`
current_path=`pwd`
# export PYTHONPATH="$current_path/libs/edge:$current_path/libs/cloudaw:$current_path/libs/dodaw:$current_path/libs/incubaw:$current_path/libs/whatsaw"

# run duration in sec
if [ $# -lt 1 ]; then
  RUN_DURATION=14400
else
  RUN_DURATION=$1
fi

# record start time
start_time=`date +'%s'`

current_time=`date +'%s'`
delta_time=`echo "$current_time - $start_time" | bc`
echo "`date` : Starting inventory for `date --date=@$start_time +'%Y/%m/%d'` : ${RUN_DURATION}s" >> logs/output.txt

# Main loop until we reach specified duration
while [ $delta_time -lt $RUN_DURATION ]; do
   start_time_trigram=`date +'%s'`
   # find oldest .log file in logs directory, and extract trigram
   oldest_trig=`ls -t1 logs/*.log | tail -1 | sed 's!^logs/\(.*\)\.log$!\1!'`
   modification_time=`date -r logs/$oldest_trig.log +%s`
   delta_modif_time=`echo "$current_time - $modification_time" | bc`
   if [ "$delta_modif_time" -lt 86400 ]; then
     echo "`date` : Oldest trigram processed less than one day ago. Stooping process." >> logs/output.txt
     break
   fi
   echo "`date` : Starting trigram $oldest_trig" >> logs/output.txt
   # backup log file for the trigram
   mv logs/$oldest_trig.log logs/$oldest_trig.log.backup 
   # run python script to inventory this trigram
   /applis/pgapadm/venv_inventory/bin/python ./inventaire.py -c -d -m -w $oldest_trig >logs/$oldest_trig.log 2>logs/$oldest_trig.err
   # check if some errors poped during inventory
   nb_errors=`wc -l logs/$oldest_trig.err | cut -d' ' -f1`
   if [ "$nb_errors" -ne 0 ]; then
     # if yes, we rename the generated log file for later analysis
     mv logs/$oldest_trig.log logs/$oldest_trig.log.$current_time
     echo "`date` : Errors detected, please check files $oldest_trig.log.$current_time, and $oldest_trig.err" >> logs/output.txt
     # and create a new one with current time so that next iteration skip this trigram
     touch logs/$oldest_trig.log
   else
     # if no, we remove error file
     rm logs/$oldest_trig.err
   fi
   current_time=`date +'%s'`
   delta_time=`echo "$current_time - $start_time" | bc`
   delta_time_trigram=`echo "$current_time - $start_time_trigram" | bc`
   echo "`date` : End of trigram $oldest_trig (duration `date --date=@$delta_time_trigram -u +'%H:%M:%S'`)" >> logs/output.txt
done
echo "`date` : End of inventory for `date --date=@$start_time +'%Y/%m/%d'`" >> logs/output.txt



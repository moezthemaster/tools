#!/usr/bin/python
# -*- coding: utf-8 -*-


class IdmDatabase(object):
    def __init__(self, shared_database=None):
        if isinstance(shared_database, list):
            self.database = shared_database
        else:
            self.database = []

    def enroll(self, ip, hostname):
        found = filter(lambda record: record["ip"] == ip, self.database)
        if found:
            if found[0]["hostname"] != hostname:
                raise Exception('ip {} is already assign for hostname={}'.format(
                    ip, found[0]["hostname"]
                ))
        found = filter(lambda record: record["hostname"] == hostname, self.database)
        if found:
            if found[0]["ip"] != ip:
                raise Exception('hostname {} is already assign for ip={}'.format(
                    hostname, found[0]["ip"]
                ))
        self.database.append({"ip": ip, "hostname": hostname})
        return True

    def unenroll(self, hostname):
        try:
            index = list(map(lambda x: x["hostname"], self.database)).index(hostname)
        except ValueError:
            return True
        self.database.remove(index)
        return True

    def ip_checker(self, ip):
        try:
            index = list(map(lambda x: x["ip"], self.database)).index(ip)
            return {
                u'id': 0,
                u'principal': u'iru_pga_edge_service@IRU-P-2.DNS20.SOCGEN',
                u'version': u'4.5.0',
                u'result': {
                    u'additional': {u'idnsname': [u'{}'.format(self.database[index]["hostname"])]},
                    u'value': u'{}'.format(ip), u'summary':
                        u'IP "{}" exists'.format(ip)
                },
                u'error': None
            }
        except ValueError:
            return {
                u'id': 0,
                u'principal': u'iru_pga_edge_service@IRU-P-2.DNS20.SOCGEN',
                u'version': u'4.5.0', u'result': None,
                u'error': {
                    u'message': u'The IPv4 address {} is not assigned in this domain.'.format(ip),
                    u'code': 4001,
                    u'data': {u'reason': u'The IPv4 address {} is not assigned in this domain.'.format(ip)},
                    u'name': u'NotFound'
                }
            }

    def host_checker(self, hostname):
        try:
            index = list(map(lambda x: x["hostname"], self.database)).index(hostname)
            return {
                u'id': 0,
                u'principal': u'iru_pga_edge_service@IRU-P-2.DNS20.SOCGEN',
                u'version': u'4.5.0',
                u'result': {
                    u'additional': {
                        u'arecord': [u'{}'.format(self.database[index]["ip"])]
                    },
                    u'value': u'{}.iru-p-2.dns20.socgen'.format(hostname),
                    u'summary': u'Host "{}.iru-p-2.dns20.socgen" exists'.format(hostname)
                },
                u'error': None
            }
        except ValueError:
            return {
                u'id': 0,
                u'principal': u'iru_pga_edge_service@IRU-P-2.DNS20.SOCGEN',
                u'version': u'4.5.0',
                u'result': None,
                u'error': {
                    u'message': u'The host "{}.iru-p-2.dns20.socgen" does not exist.'.format(hostname),
                    u'code': 4001,
                    u'data': {
                        u'reason': u'The host "{}.iru-p-2.dns20.socgen" does not exist.'.format(hostname)},
                    u'name': u'NotFound'
                }
            }


class MockedIdm(IdmDatabase):
    def __init__(self, env, **kwargs):
        IdmDatabase.__init__(self, **kwargs)

    def check_whats(self, whats_ip, whats_hostname):
        response_hostname = self.host_checker(whats_hostname)
        result = {}
        if response_hostname['error'] is None:
            if response_hostname['result'] is not None and response_hostname['result']['additional']['arecord'][
                0] == whats_ip:
                result = {
                    'status': 200,
                    'msg': 'The hostname {} ({}) is well assigned'.format(whats_hostname, whats_ip)
                }
            else:
                result = {'status': 202, 'msg': response_hostname}
        elif response_hostname['error']["code"] == 4001:
            response_ip = self.ip_checker(whats_ip)
            if response_ip["error"] is not None and response_ip["error"]["code"] == 4001:
                result = {
                    'status': 200,
                    'msg': 'The hostname {} ({}) is not assigned in this domain'.format(whats_hostname, whats_ip)
                }
            else:
                result = {'status': 201, 'msg': response_ip}
        return result

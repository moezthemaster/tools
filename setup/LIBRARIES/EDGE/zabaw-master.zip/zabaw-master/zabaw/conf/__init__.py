"""
Settings and configuration for Incubaw.
Read values from the .py file specified by the INCUBAW_CONFIG_FILE environment variable,
 and then from incubaw.conf.global_settings.
See the global_settings.py for a list of all possible variables.
"""

try:
    import ConfigParser
except ImportError:
    import configparser as ConfigParser
import os

from zabaw.exeption import ImproperlyConfigured

from zabaw.conf import global_settings


ENVIRONMENT_VARIABLE = 'ZABBIX_CONFIG_FILE'
SECTION_NAME = 'ZABAW'


class Settings(object):
    def __init__(self):
        """
        Load settings from global_settings then override the settings module pointed to by the environment variable.
        """

        settings_cfg_file = os.environ.get(ENVIRONMENT_VARIABLE)
        if not settings_cfg_file:
            raise ImproperlyConfigured(
                'Requested settings, but settings are not configured. '
                'You must define the environment variable %s to point to a settings file '
                'and override global_settings.py'
                % ENVIRONMENT_VARIABLE)
        # update this object from global settings (but only for ALL_CAPS settings)
        for setting in dir(global_settings):
            if setting.isupper():
                setattr(self, setting, getattr(global_settings, setting))
        # update this object from settings cfg file

        parser = ConfigParser.SafeConfigParser()
        parsed_files = parser.read(settings_cfg_file)
        if not parsed_files:
            raise ImproperlyConfigured('Cannot find or access file {}'.format(settings_cfg_file))
        try:
            for (key, val) in parser.items(SECTION_NAME):
                setattr(self, key.upper(), val)
        except ConfigParser.NoSectionError as e:
            raise ImproperlyConfigured('Section [{}] not found in file {}'.format(SECTION_NAME, settings_cfg_file))

settings = Settings()

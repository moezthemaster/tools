#!/usr/bin/python
# -*- coding: utf-8 -*-

import json
import time
import requests
import urlparse
import logging
import re
from datetime import datetime, timedelta
from sg_gts_tools.read_settings import read_settings


# Exception related to GtsCloudApi
class GtsDoDApiError(Exception):
    def __init__(self, msg, original):
        super(GtsDoDApiError, self).__init__(msg + (": %s" % original))
        self.original = original

class GtsDoDApi(object):

    def __init__(self, config_file = "gts_dod_api.cfg"):
        logger = logging.getLogger()
        logger.debug("GtsDoDApi constructor")
        self.config = read_settings(config_file)
        self.credentials = read_settings(self.config["DOD_CONFIG_credential_file"])
        
    def __del__(self):
        pass

    
    def delete_record_id(self, id):
        logger = logging.getLogger()
        logger.debug("Delete record {}".format(id))
        if not re.match('^[0-9]{6,}$', id):
            raise GtsDoDApiError("id must be an integer with at least 6 digits")
        url = urlparse.urljoin(self.config["DOD_PRD_url"],
                               self.config["DOD_SUFFIX_urlsuffix"])
        url = url + "/{}?dns_service={}".format(id,self.config["DOD_PRD_dnsservice"])
        print(url)
        auth = requests.auth.HTTPBasicAuth(self.credentials["DOD_PROD_CREDENTIALS_username"],self.credentials["DOD_PROD_CREDENTIALS_password"])
        headers = {'Accept': 'application/json'}

        try:
            r = requests.delete(url, headers=headers, auth=auth, verify = False)

            if r.status_code < 200 or r.status_code >= 300:
                raise GtsDoDApiError("Impossible to delete id {}".format(id), None)
        except Exception, e:
            raise GtsDoDApiError("Impossible to delete id {}".format(id), e)

 
    def search_in_DoD(self,pattern_hostname = "",pattern_ip = "", record_type = ""):
    	logger = logging.getLogger()
        logger.debug("Search in DoD")
        if pattern_hostname == "" and pattern_ip == "":
        	raise GtsDoDApiError("Pattern for hostname or ip must be provided")
        url = urlparse.urljoin(self.config["DOD_PRD_url"], 
                               self.config["DOD_SUFFIX_urlsuffix"])
        headers = {'Accept': 'application/json'}
        url_ext = "?dns_service={}&method=record_search&view=production".format(self.config["DOD_PRD_dnsservice"])
        if pattern_hostname != "":
        	url_ext = url_ext + "&hostname={}".format(pattern_hostname)
        if pattern_ip != "":
        	url_ext = url_ext + "&ip={}".format(pattern_ip)
        if record_type != "":
        	url_ext = url_ext + "&type={}".format(record_type)

        url = url + url_ext

        auth = requests.auth.HTTPBasicAuth(self.credentials["DOD_PROD_CREDENTIALS_username"],self.credentials["DOD_PROD_CREDENTIALS_password"])        

        try:        
            r = requests.get(url, headers=headers, auth=auth, verify = False)

            if r.status_code < 200 or r.status_code >= 300:
                raise GtsDoDApiError("Impossible to get trigram on DoD", None)
        except Exception, e:
            raise GtsDoDApiError("Impossible to get trigram on DoD {}", e)
        
        return r.json()["Response"]

    def search_trigram_in_DoD(self, trigram, record_type = "", env = ""):
        logger = logging.getLogger()
        logger.debug("Search trigram {} in DoD".format(trigram))
        if env == "":
        	env = "[dhp]"
        return self.search_in_DoD("^{}{}lx.*$".format(env,trigram), "", record_type)
    
    def search_hostname_in_DoD(self, hostname, record_type = ""):
    	logger = logging.getLogger()
        logger.debug("Search hostname {} in DoD".format(hostname))
        return self.search_in_DoD("^{}$".format(hostname), "", record_type)

    def search_ip_in_Dod(self, ip, record_type = ""):
     	logger = logging.getLogger()
        logger.debug("Search IP {} in DoD".format(ip))
        response = self.search_in_DoD("","^{}$".format(ip),record_type)
        if isinstance(response, list):
            return response
        else:
            return None

    def get_server_list_from_trigram(self, trigram, env = ""):
    
        trigram_DoD = self.search_trigram_in_DoD(trigram = trigram, env = env)

        return trigram_DoD



if __name__ == '__main__':
    pass

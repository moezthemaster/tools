##############################################################################
#
# File		: config.py
#
# Date		: 12-12-2017
#
# Author	: Emmanuel TELECHEA - RESG/GTS/MKT/OPM
#
# Purpose	: Python script used to handle config functions
#
##############################################################################
#
# History	:
#
# ET : 12-12-2017 : Creation
#
##############################################################################
import sys

try:
    import ConfigParser
except ImportError:
    import configparser as ConfigParser
import base64


##############################################################################
# Function : encodePwd
# Retrieve config file infos
##############################################################################
def encodePwd(key, clear):
    enc = []
    for i in range(len(clear)):
        key_c = key[i % len(key)]
        enc_c = (ord(clear[i]) + ord(key_c)) % 256
        enc.append(enc_c)
    if sys.version_info > (3,):
        return base64.urlsafe_b64encode(bytes(enc))
    else:
        for i, v in enumerate(enc):
            enc[i] = struct.pack("B", v)
        return base64.urlsafe_b64encode("".join(enc))


# END encodePwd #############################################################

##############################################################################
# Function : decodePwd
# Retrieve config file infos
##############################################################################
def decodePwd(key, enc):
    dec = []
    enc = base64.urlsafe_b64decode(enc)
    for i in range(len(enc)):
        key_c = key[i % len(key)]
        if sys.version_info > (3,):
            dec_c = chr((256 + enc[i] - ord(key_c)) % 256)
        else:
            import struct
            dec_c = chr((256 + struct.unpack("<B", enc[i])[0] - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)


# END decodePwd ##############################################################


##############################################################################
# Class : zbxConfig
# Use to manage script configuration file
##############################################################################
class zbxConfig(object):
    def __init__(self, iniFile):

        self.iniFile = iniFile
        parser = ConfigParser.ConfigParser()
        parser.optionxform = str
        parser.read(self.iniFile)

        # private attributes
        self.__key = "Tsx?G58H6hus{ks:sS0"

        # public attributes
        self.zbxApiInfo = {}

        zbxApiUrlRET = parser.get('ZABBIX_API', 'zbxApiUrlRET')
        zbxApiUrlMKT = parser.get('ZABBIX_API', 'zbxApiUrlMKT')
        zbxApiUser = parser.get('ZABBIX_API', 'zbxApiUser')
        zbxCfgEncryption = parser.get('ZABBIX_API', 'encrypted')

        # Manage password encryption
        if zbxCfgEncryption == 'false':
            zbxApiUserPwd = parser.get('ZABBIX_API', 'zbxApiUserPwd')
            # Encrypt password
            zbxApiEncUserPwd = encodePwd(self.__key, zbxApiUserPwd)
            parser.set('ZABBIX_API', 'encrypted', 'true')
            parser.set('ZABBIX_API', 'zbxApiUserPwd', zbxApiEncUserPwd.decode())

            with open(iniFile, 'w') as newCfg:
                parser.write(newCfg)
                newCfg.close()
        else:
            # Assume from config info that password already encrypted in config file
            zbxApiEncUserPwd = parser.get('ZABBIX_API', 'zbxApiUserPwd')
            zbxApiUserPwd = decodePwd(self.__key, zbxApiEncUserPwd)

        self.zbxApiInfo['zbxApiUrlRET'] = zbxApiUrlRET
        self.zbxApiInfo['zbxApiUrlMKT'] = zbxApiUrlMKT
        self.zbxApiInfo['zbxApiUser'] = zbxApiUser
        self.zbxApiInfo['zbxApiUserPwd'] = zbxApiUserPwd

    def zbxGetApiConfig(self):
        return self.zbxApiInfo

# END zbxConfig Class #######################################################



# END config.py ###############################################################

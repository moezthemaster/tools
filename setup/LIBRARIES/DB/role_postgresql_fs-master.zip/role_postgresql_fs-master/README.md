Role postgresql_fs
=========

Creating File Systems for a Postgresql Database.

This role is a prerequisite of [role_postgresql] (https://sgithub.fr.world.socgen/GTS-RET-DBA-COMPOSANTS-EDGE/role_postgresql)

If no action is specified when calling this role, the main task file, main.yml, will execute the following actions :
 1. __create.yml__ :
   * creating File Systems :
     * /bases/pgsql
	 * /bases/pgsql/*cluster_name*          : used to store datas of Postgresql Database Cluster
	 * /bases/pgsql/*cluster_name*/wal      : used to store Write Ahead Log files
	 * /bases/pgsql/*cluster_name*/var      : used to store logfiles from Dabase and backups
	 * /bases/pgsql/*cluster_name*/backups  : used to store last full backup and dumpfiles


Here's a description of the other task that can be executed in this role, filling the *postgresql_action* with the name of the task requested :

 __delete.yml__ : removing Postgresql File Systems :
  * removing directories under /bases/pgsql 
  * removing all File Systems that were used by the Postgresql Database Cluster


This role is developped for FastIT & PAAP projects. Some updates may have to be done for other needs : contact us :email: FR-FR-RET-ODB-L3@socgen.com, or Fork it.



Requirements
------------
Facts gathering shouldn't be disabled.

Target servers must be RHEL7.

When executing action "delete", a "delete" action should be executed first from role role_postgresql.

Role Variables
--------------
Here are the requested values for each action :

__create.yml__
- postgresql_action: "create"
- postgresql_device_vg
- postgresql_cluster_name
- postgresql_cluster_install_size (increasing the size will be taken into account, decreasing it will failed)
- You can override these values :
  - postgresql_cluster_wal_size (default = "3G")
  - postgresql_cluster_log_size (default = "2G")
  - postgresql_cluster_backup_size (default = "5G")

__delete.yml__
- postgresql_action: "delete"
- postgresql_device_vg
- postgresql_cluster_name
- validate_decomissioning: yes



Dependencies
------------
None


Example Playbook
----------------

    - hosts: servers
      gather_facts: yes
      roles:
      - { role: role_postgresql_fs,
           postgresql_action: "create",
           postgresql_device_vg: "{{ vg_name }}",
           postgresql_cluster_name: "{{ cluster_name }}",
           postgresql_cluster_install_size: "{{ cluster_install_size }}",
           postgresql_cluster_log_size: "{{ cluster_log_size }}",
           postgresql_cluster_wal_size: "{{ cluster_wal_size }}",
           postgresql_cluster_backup_size: "{{ cluster_backup_size }}"
        }


Some example values that can be specified in a group_vars file : `~/group_vars/example.yml`
```yml
vg_name: "BdddVg"
cluster_name: dfsfsofa
cluster_install_size: "10g"
cluster_log_size: "3g"
cluster_wal_size: "5g"
cluster_backup_size: "10g"
```
 


TODO List
------------
- Correcting known errors :
  - FS resize operation : when you increase size of FS, the new size is not taken into account
  - when using a decimal value in a FS size (ex: "3.5g"), the first time the role is executed, FS is well created with the desired size ; when executing a second time, an error is raised instead of having a return code "OK".




License
-------
[![CC0](https://www.usenix.org/legacy/events/usenix04/art/build_icons/bsd.gif)] (https://fr.wikipedia.org/wiki/Licence_BSD)

Author Information
------------------

GUFFROY Philippe




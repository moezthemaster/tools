
import logging

import edge.interfaces
from edge.conf import settings
from edge.exception import EdgeException
from edge.conf.cloud_network import get_details

PRODUCTION = 'production'
KWARGS_SEARCH = {
    'dns_service': settings.DOD_DNS_SERVICE,
    'view': PRODUCTION,
}
logger = logging.getLogger(__name__)


class ManageCname(edge.interfaces.Dod):

    def __init__(self, **kwargs):
        self.hostname = kwargs['hostname']
        try:
            assert self.hostname, "hostname is None"
        except AssertionError as e:
                    raise EdgeException(repr(e))
        self.alias = kwargs['alias']
        self.alias_zone = kwargs['alias_zone']
        self.changed = False
        if kwargs.get("env", None):
            self.env = kwargs['env']
            self.region_cloud = kwargs['region_cloud']
            self.az_cloud = kwargs['az_cloud']
            self.network_id = kwargs['network_id']

    @property
    def hostname_zone(self):
        try:
            if not hasattr(self, 'env'):
                if not hasattr(self, '_hostname_zone'):
                    searches = self.search_dns_record(
                        record_type="^A$",
                        hostname="^{}$".format(self.hostname),
                        **KWARGS_SEARCH
                    )
                    if len(searches) > 1:
                        raise Exception("Found more than one hostname")
                    elif len(searches) == 0:
                        raise Exception("Hostname not found")
                    found_hostname = searches[0]
                    self._hostname_zone = found_hostname["zone"]
                return self._hostname_zone
            else:
                return get_details(self.env, self.region_cloud, self.az_cloud, self.network_id)["dns_zone"]
        except Exception as err:
            raise EdgeException("Hostname {} not found in {}, Error: {}".format(
                self.hostname, settings.DOD_DNS_SERVICE, err.args[0])
            )

    @property
    def alias_fqdn(self):
        return "{}.{}.".format(self.alias, self.alias_zone)

    @property
    def hostname_fqdn(self):
        if not hasattr(self, "_hostname_fqdn"):
            self._hostname_fqdn = "{}.{}.".format(self.hostname, self.hostname_zone)
        return self._hostname_fqdn

    @hostname_fqdn.setter
    def hostname_fqdn(self, value):
        self._hostname_fqdn = value

    def check_if_hostname_exists(self):
        """
        raise Exception unless hostname exits
        :return:
        """
        searches = self.search_dns_record(
            record_type="^A$",
            hostname="^{}$".format(self.hostname),
            zone=self.hostname_zone,
            **KWARGS_SEARCH
        )
        if len(searches) > 1:
            raise Exception("Found more than one hostname")
        elif len(searches) == 0:
            raise EdgeException("Hostname {} not found in {}".format(self.hostname, settings.DOD_DNS_SERVICE))

    def get_alias_infos(self):
        """
        get infos of alias
        :return: dict
        """
        searches = self.search_dns_record(
            record_type="^CNAME$",
            alias="^{}$".format(self.alias),
            hostname="^{}$".format(self.hostname_fqdn),
            zone=self.alias_zone,
            **KWARGS_SEARCH
        )
        if not searches:
            searches = self.search_dns_record(
                record_type="^CNAME$",
                alias="^{}$".format(self.alias),
                hostname="^{}$".format(self.hostname),
                zone=self.alias_zone,
                **KWARGS_SEARCH
            )
        if len(searches) > 1:
            raise Exception("Found more than one alias")
        found_alias = searches[0] if searches else None
        return found_alias

    def delete_cname(self):
        """
        delete specified alias
        :return: dict
        """
        logger.debug("Deleting record CNAME")
        self.check_if_hostname_exists()
        found_alias = self.get_alias_infos()
        if found_alias:
            try:
                self.delete_dns_record(
                    id=found_alias["id"],
                    dns_service=settings.DOD_DNS_SERVICE
                )
                self.changed = True
            except Exception as err:
                raise EdgeException(err.args[0])
            logger.debug("record CNAME {} deleted for hostname {}".format(
                self.alias_fqdn, self.hostname)
            )
            return {
                "msg": "record CNAME {} deleted for hostname {}".format(
                    self.alias_fqdn, self.hostname
                )
            }
        logger.debug("record CNAME does not exist, no record deleted")
        return {
            "msg": "record CNAME {} does not exist, no record deleted for hostname {}".format(
                self.alias_fqdn,
                self.hostname
            )
        }

    def record_cname(self, **kwargs):
        """
        record field cname
        :param kwargs: additionnals parameters for record operation
        :return: dict
        """
        params = kwargs
        logger.debug("Creating record CNAME for {}".format(self.hostname_fqdn))
        self.check_if_hostname_exists()
        found_alias = self.get_alias_infos()
        if not found_alias:
            try:
                params.update(KWARGS_SEARCH)
                created = self.create_dns_record(
                    hostname=self.hostname_fqdn,
                    alias=self.alias,
                    record_type="CNAME",
                    zone=self.alias_zone,
                    inA=True,
                    inPTR=True,
                    **params
                )
                self.changed = True
            except Exception as err:
                raise EdgeException(err.args[0])
            logger.debug("record CNAME {} created for {}".format(self.alias_fqdn, created["hostname"]))
            return created
        logger.debug(
            "record CNAME {} exists already for {}, no record created".format(
                self.alias_fqdn, found_alias["hostname"]
            )
        )
        return found_alias

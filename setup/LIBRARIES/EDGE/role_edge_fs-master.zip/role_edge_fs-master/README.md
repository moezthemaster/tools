Role VM_edge_fs
====

This role allows you to create or extend a fs.

**present.yml**
* create a list of fs

The role inventory what is present on the server. Then it evaluates the needs in each referenced VG.
If the need is greater than what is available in the VG, or if it is a new VG, the role tries to extend or create the VG with the smaller available disk.

Then for each fs in the list :
- If the fs is not present, it is created in the specified vg. 
- If the fs exists and its size is lower than requested, it is resized.
- If the fs exists and its size is greater than requested, no action is taken and a warning message is displayed

The filesystem ownership and rights are only used in case of a creation. No change is made when dealing with an existing fs.

**absent.yml**
* Do nothing

Configuration
-------------
### Requirements
Target servers must be existing Linux.
This role can only be executed through A4C or Ansible Tower platform.

### Role Variables

Here are the requested values for each action :


**present.yml**

- `vm_hostname : 'server_where_disk_should_be_mounted'`
- `fs_list : list of the filesystems to create

A filesystem is a dictionary containing entries :
- mountpoint: string, mandatory
- size: string, mandatory, ex: "20G"
- vg: string, optional, default is "SocleVg"
- user: string, optional, default is root
- group: string, optional, default is root
- file_mode: string, optional, default is "750"

**absent.yml**
- vm_hostname : 'server_where_disk_should_be_unmounted'`
- do nothing for the moment

The following filesystem is currently supported:
- [ext4](http://en.wikipedia.org/wiki/Ext4)

### Dependencies
None


How it works
------------



### Example Playbook

      ---
      - hosts: servers

      - vars: 
          fs_list:
             - { mountpoint: "/", size: "40G" }
             - { mountpoint: "/produits/patrol", size: "2G" }
             - { mountpoint: "/bases", size: "20G", vg: "BasesVg", uid: "oracle", gid: "dba", file_mode: "770" }

        roles:
             - { role: role_edge_fs, action: "present" } 

Licence
------------
BSD

Author
------------
GTS FEATURE TEAM

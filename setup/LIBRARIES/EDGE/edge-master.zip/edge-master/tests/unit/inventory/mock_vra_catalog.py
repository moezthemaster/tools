import logging

import edge.interfaces

logger = logging.getLogger(__name__)

BG_LIST_FROM_TRIGRAM_ID = u'5e535eb1-0bd8-450d-b7de-214020eeee25'

BG_LIST_FROM_TRIGRAM_SUBTENANT_REF = u'89b69827-655e-414c-96cd-e56ca0e09460'

MACHINE_ID = u'6675fc19-d01d-4de6-a13b-420a315ae1a0'

PROVIDER_BG = u'BG_BSC-ISA-ARM_PRD'

MACHINE_TENANT_REF = u'sgcloud'

MACHINE_SUBTENANT_REF = u'50957a48-141e-425a-afcc-b74d040bf61e'

VRA_CATALOG_TWO_ITEMS = [
    {
        u'catalogItem': {
            u'status': u'PUBLISHED',
            u'description': u'This workflow returns all the BGs associated to a trigram.',
            u'callbacks': None,
            u'isNoteworthy': False,
            u'iconId': u'5e535eb1-0bd8-450d-b7de-214020eeee25',
            u'catalogItemTypeRef': {
                u'id': u'com.vmware.csp.core.designer.service.serviceblueprint',
                u'label': u'Advanced Service Blueprint'
            },
            u'serviceRef': {
                u'id': u'36f963b4-db1d-4931-bae6-81e093ecca83',
                u'label': u'Advanced Services'
            },
            u'dateCreated': u'2015-11-26T10:50:06.532Z',
            u'forms': {
                u'catalogRequestInfoHidden': True,
                u'requestFormScale': u'BIG',
                u'requestSubmission': {
                    u'type': u'external',
                    u'formId': u'com.vmware.csp.core.designer.service.serviceblueprint_Request.Submit'
                },
                u'itemDetails': {
                    u'type': u'external',
                    u'formId': u'com.vmware.csp.core.designer.service.serviceblueprint_ServiceBlueprint.Details'
                },
                u'requestDetails': {
                    u'type': u'external',
                    u'formId': u'com.vmware.csp.core.designer.service.serviceblueprint_Request.Details'
                }
            },
            u'providerBinding': {
                u'bindingId': u'0d02280f-06e4-4ab9-9199-0dc18938ef88',
                u'providerRef': {
                    u'id': u'8b8ff6ef-86bb-423a-be30-8e7a65395d25',
                    u'label': u'Advanced Designer Service'
                }
            },
            u'version': 2,
            u'lastUpdatedDate': u'2017-06-06T14:23:20.632Z',
            u'organization': {
                u'subtenantLabel': None,
                u'tenantLabel': u'sgcloud',
                u'subtenantRef': None,
                u'tenantRef': u'sgcloud'
            },
            u'statusName': u'Published',
            u'id': BG_LIST_FROM_TRIGRAM_ID,
            u'name': u'Get BG List From Trigram'
        },
        u'entitledOrganizations': [
            {
                u'subtenantLabel': u'BG_ITIM-PPM-UVP',
                u'tenantLabel': u'sgcloud',
                u'subtenantRef': BG_LIST_FROM_TRIGRAM_SUBTENANT_REF,
                u'tenantRef': u'sgcloud'
            },
            {
                u'subtenantLabel': u'BG_BSC-DCO-OPE_PRD',
                u'tenantLabel': u'sgcloud',
                u'subtenantRef': u'3f4bbd37-f6c8-4a45-ba0d-441925bcb037',
                u'tenantRef': u'sgcloud'
            }
        ],
        u'@type': u'ConsumerEntitledCatalogItem'
    },
    {
        u'catalogItem': {
            u'status': u'PUBLISHED',
            u'description': u'',
            u'callbacks': None,
            u'isNoteworthy': False,
            u'iconId': u'6675fc19-d01d-4de6-a13b-420a315ae1a0',
            u'catalogItemTypeRef': {
                u'id': u'com.vmware.csp.core.designer.service.serviceblueprint',
                u'label': u'Advanced Service Blueprint'
            },
            u'serviceRef': {
                u'id': u'68bb0048-2bbe-4f83-afe6-afe4768dec76',
                u'label': u'Linux'
            },
            u'dateCreated': u'2017-02-06T14:43:39.363Z',
            u'forms': {
                u'catalogRequestInfoHidden': True,
                u'requestFormScale': u'BIG',
                u'requestSubmission': {
                    u'type': u'external',
                    u'formId': u'com.vmware.csp.core.designer.service.serviceblueprint_Request.Submit'
                },
                u'itemDetails': {
                    u'type': u'external',
                    u'formId': u'com.vmware.csp.core.designer.service.serviceblueprint_ServiceBlueprint.Details'
                },
                u'requestDetails': {
                    u'type': u'external',
                    u'formId': u'com.vmware.csp.core.designer.service.serviceblueprint_Request.Details'
                }
            },
            u'providerBinding': {
                u'bindingId': u'0c23f31e-d152-49e4-bb24-0560c694e811',
                u'providerRef': {
                    u'id': u'8b8ff6ef-86bb-423a-be30-8e7a65395d25',
                    u'label': u'Advanced Designer Service'
                }
            },
            u'version': 10,
            u'lastUpdatedDate': u'2017-09-29T07:30:04.647Z',
            u'organization': {
                u'subtenantLabel': None,
                u'tenantLabel': u'sgcloud',
                u'subtenantRef': None,
                u'tenantRef': u'sgcloud'
            },
            u'statusName': u'Published',
            u'id': MACHINE_ID,
            u'name': u'RHEL 7.2 x64 RET EDGE'
        },
        u'entitledOrganizations': [
            {
                u'subtenantLabel': u'BG_ITIM-PPM-UVP',
                u'tenantLabel': u'sgcloud',
                u'subtenantRef': u'89b69827-655e-414c-96cd-e56ca0e09460',
                u'tenantRef': u'sgcloud'
            },
            {
                u'subtenantLabel': u'BG_BSC-DCO-OPE_PRD',
                u'tenantLabel': u'sgcloud',
                u'subtenantRef': u'3f4bbd37-f6c8-4a45-ba0d-441925bcb037',
                u'tenantRef': u'sgcloud'
            },
            {
                u'subtenantLabel': PROVIDER_BG,
                u'tenantLabel': u'sgcloud',
                u'subtenantRef': MACHINE_SUBTENANT_REF,
                u'tenantRef': MACHINE_TENANT_REF
            }
        ],
        u'@type': u'ConsumerEntitledCatalogItem'
    }
]

REQUESTED_FOR = u'EAN_PRD_SVC@eur.msd.world.socgen'

PROVIDER_OWNER = u'EAN_PRD_SVC@eur.msd.world.socgen'

RESPONSE_GET_BG_REQUEST = {
    u'values': {
        u'entries': [
            {
                u'value': {
                    u'type': u'string',
                    u'value': u'PRD'
                },
                u'key': u'provider-environment'
            },
            {
                u'value': {
                    u'type': u'string',
                    u'value': u'sgcloud'
                },
                u'key': u'provider-__asd_tenantRef'
            },
            {
                u'value': {
                    u'items': [
                        {
                            u'type': u'string',
                            u'value': PROVIDER_BG
                        }
                    ],
                    u'elementTypeId': u'STRING',
                    u'type': u'multiple'
                },
                u'key': u'provider-BGResult'
            },
            {
                u'value': {
                    u'type': u'string',
                    u'value': u'c8667608-4c30-4a32-b122-7d6d1ee79c29'
                },
                u'key': u'provider-__asd_catalogRequestId'
            },
            {
                u'value': {
                    u'type': u'string',
                    u'value': u'RET'
                },
                u'key': u'provider-restrictedTo'
            },
            {
                u'value': {
                    u'type': u'string',
                    u'value': u'api'
                },
                u'key': u'provider-trigram'
            },
            {
                u'value': {
                    u'type': u'string',
                    u'value': REQUESTED_FOR
                },
                u'key': u'provider-__asd_requestedFor'
            },
            {
                u'value': {
                    u'type': u'string',
                    u'value': u'b12b07ac-56d8-4508-8eeb-33581c3ab013'
                },
                u'key': u'provider-__asd_subtenantRef'
            },
            {
                u'value': {
                    u'type': u'string',
                    u'value': PROVIDER_OWNER
                },
                u'key': u'provider-__asd_requestedBy'
            }
        ]
    },
    u'layout': {
        u'pages': [
            {
                u'state': {
                    u'facets': [

                    ],
                    u'dependencies': [

                    ]
                },
                u'sections': [
                    {
                        u'state': {
                            u'facets': [
                                {
                                    u'type': u'visible',
                                    u'value': {
                                        u'type': u'constantClause',
                                        u'value': {
                                            u'type': u'boolean',
                                            u'value': False
                                        }
                                    }
                                }
                            ],
                            u'dependencies': [

                            ]
                        },
                        u'rows': [
                            {
                                u'items': [
                                    {
                                        u'dataType': {
                                            u'typeId': u'STRING',
                                            u'type': u'primitive'
                                        },
                                        u'labelSize': 0,
                                        u'state': {
                                            u'facets': [
                                                {
                                                    u'type': u'visible',
                                                    u'value': {
                                                        u'type': u'constantClause',
                                                        u'value': {
                                                            u'type': u'boolean',
                                                            u'value': False
                                                        }
                                                    }
                                                }
                                            ],
                                            u'dependencies': [

                                            ]
                                        },
                                        u'displayAdvice': None,
                                        u'isMultiValued': False,
                                        u'type': u'field',
                                        u'id': u'provider-__ASD_PRESENTATION_INSTANCE',
                                        u'columns': [

                                        ],
                                        u'size': 2
                                    }
                                ]
                            }
                        ],
                        u'id': None
                    },
                    {
                        u'state': {
                            u'facets': [

                            ],
                            u'dependencies': [

                            ]
                        },
                        u'rows': [
                            {
                                u'items': [
                                    {
                                        u'description': u'trigram',
                                        u'dataType': {
                                            u'typeId': u'STRING',
                                            u'type': u'primitive'
                                        },
                                        u'labelSize': 2,
                                        u'label': u'trigram',
                                        u'state': {
                                            u'facets': [

                                            ],
                                            u'dependencies': [

                                            ]
                                        },
                                        u'displayAdvice': None,
                                        u'isMultiValued': False,
                                        u'type': u'field',
                                        u'id': u'provider-trigram',
                                        u'columns': [

                                        ],
                                        u'size': 2
                                    }
                                ]
                            },
                            {
                                u'items': [
                                    {
                                        u'description': u'restrictedTo',
                                        u'dataType': {
                                            u'typeId': u'STRING',
                                            u'type': u'primitive'
                                        },
                                        u'labelSize': 2,
                                        u'label': u'restrictedTo',
                                        u'state': {
                                            u'facets': [

                                            ],
                                            u'dependencies': [

                                            ]
                                        },
                                        u'displayAdvice': None,
                                        u'isMultiValued': False,
                                        u'type': u'field',
                                        u'id': u'provider-restrictedTo',
                                        u'columns': [

                                        ],
                                        u'size': 2
                                    }
                                ]
                            },
                            {
                                u'items': [
                                    {
                                        u'dataType': {
                                            u'typeId': u'STRING',
                                            u'type': u'primitive'
                                        },
                                        u'labelSize': 2,
                                        u'label': u'BGResult',
                                        u'state': {
                                            u'facets': [
                                                {
                                                    u'type': u'readOnly',
                                                    u'value': {
                                                        u'type': u'constantClause',
                                                        u'value': {
                                                            u'type': u'boolean',
                                                            u'value': True
                                                        }
                                                    }
                                                }
                                            ],
                                            u'dependencies': [

                                            ]
                                        },
                                        u'displayAdvice': u'SEARCHER',
                                        u'isMultiValued': True,
                                        u'type': u'field',
                                        u'id': u'provider-BGResult',
                                        u'columns': [

                                        ],
                                        u'size': 2
                                    }
                                ]
                            }
                        ],
                        u'id': None
                    }
                ],
                u'id': None,
                u'label': u'Step'
            }
        ]
    }
}

VRA_RESOURCE_DATA = [{u'operations': [
    {u'extensionId': None, u'name': u'Add Storage', u'iconId': u'6d0a5fc3-e443-497c-9611-a0d965aebccf_icon',
     u'hasForm': True, u'bindingId': u'b4ffdfd5-940a-4790-87d0-dff9fdabd6e1', u'formScale': u'BIG', u'type': u'ACTION',
     u'id': u'ecbceb62-0e6c-45a1-b894-bb75d61aa912', u'providerTypeId': u'com.vmware.csp.core.designer.service',
     u'description': u'Add or extend a disk linked to a VM'},
    {u'extensionId': None, u'name': u'Add Tags To VM', u'iconId': u'd5d4fa0a-247e-49af-83e8-531f33429071_icon',
     u'hasForm': True, u'bindingId': u'078c39b3-cdd1-49d0-bd9e-90f51ab1dd30', u'formScale': u'BIG', u'type': u'ACTION',
     u'id': u'3d1c69ff-bf7b-4fbb-bf40-f66c3038dd25', u'providerTypeId': u'com.vmware.csp.core.designer.service',
     u'description': u'REST API function to add a tag to an instance (Get the type and name from the id)'},
    {u'extensionId': None, u'name': u'Change Lease', u'iconId': u'machineChangeLease.png', u'hasForm': True,
     u'bindingId': u'Infrastructure.Machine.Action.ChangeLease', u'formScale': u'SMALL', u'type': u'ACTION',
     u'id': u'3a7c6419-e6e8-463b-86b7-8f9c9e09ee12', u'providerTypeId': u'com.vmware.csp.iaas.blueprint.service',
     u'description': u'Change the lease for a machine. Leave empty for indefinite.'},
    {u'extensionId': None, u'name': u'Change VM Backup Policy', u'iconId': u'1b8e8265-238c-4f26-a5fa-7f4d340e8b04_icon',
     u'hasForm': True, u'bindingId': u'ddf08847-a146-495b-a83f-61938ee1bdd1', u'formScale': u'BIG', u'type': u'ACTION',
     u'id': u'f79df9f5-ffc3-4133-9b6b-243ba48ef539', u'providerTypeId': u'com.vmware.csp.core.designer.service',
     u'description': u''},
    {u'extensionId': None, u'name': u'Change VM Description', u'iconId': u'b6204ee0-7515-421f-b358-3c5e01cef573_icon',
     u'hasForm': True, u'bindingId': u'035e941e-bea0-4178-b3f7-19792b5f3883', u'formScale': u'BIG', u'type': u'ACTION',
     u'id': u'52def6a2-80cd-409c-97dc-490fdad540eb', u'providerTypeId': u'com.vmware.csp.core.designer.service',
     u'description': u''},
    {u'extensionId': None, u'name': u'Change VM Model', u'iconId': u'b415e0ad-644c-4875-9308-6892e7f35740',
     u'hasForm': True, u'bindingId': u'2e1eedff-5da5-495e-9396-0321d5ee2b8f', u'formScale': u'BIG', u'type': u'ACTION',
     u'id': u'b415e0ad-644c-4875-9308-6892e7f35740', u'providerTypeId': u'com.vmware.csp.core.designer.service',
     u'description': u''},
    {u'extensionId': None, u'name': u'Change VM Owner', u'iconId': u'f2b31ac5-2924-4ed6-9657-d641a3d97f11',
     u'hasForm': True, u'bindingId': u'9b569182-731c-401b-bd0a-908fef4480e9', u'formScale': u'BIG', u'type': u'ACTION',
     u'id': u'f2b31ac5-2924-4ed6-9657-d641a3d97f11', u'providerTypeId': u'com.vmware.csp.core.designer.service',
     u'description': u''},
    {u'extensionId': None, u'name': u'Destroy', u'iconId': u'virtualDestroy.png', u'hasForm': False,
     u'bindingId': u'Infrastructure.Virtual.Action.Destroy', u'formScale': None, u'type': u'ACTION',
     u'id': u'cea15550-4a48-4896-8c7c-3b21eef2772e', u'providerTypeId': u'com.vmware.csp.iaas.blueprint.service',
     u'description': u'Destroy a virtual machine.'},
    {u'extensionId': None, u'name': u'Edit VM', u'iconId': u'0c22b69a-a641-47f0-aa85-8ebf44f47683_icon',
     u'hasForm': True, u'bindingId': u'a97764a0-3dc5-49de-a1e6-ba326c39182f', u'formScale': u'BIG', u'type': u'ACTION',
     u'id': u'fe801c87-ce92-4a33-809d-75622da6d2a3', u'providerTypeId': u'com.vmware.csp.core.designer.service',
     u'description': u'This workflow updates different parameters of a VM\nCurrently, we update the Additional Email parameter'},
    {u'extensionId': None, u'name': u'Get Tags From VM', u'iconId': u'b582dca7-ab08-4d1b-bfcc-b9ac6e481dd0_icon',
     u'hasForm': True, u'bindingId': u'442ec744-7a42-4377-b34e-a4f62774ad84', u'formScale': u'BIG', u'type': u'ACTION',
     u'id': u'b2df7865-7e94-4f45-8304-90e59a2e447d', u'providerTypeId': u'com.vmware.csp.core.designer.service',
     u'description': u'REST API function to add a tag to an instance (Get the type and name from the id)'},
    {u'extensionId': None, u'name': u'Get VM Information', u'iconId': u'eeb0d977-1e6d-49f8-8b9f-d81f118d471d_icon',
     u'hasForm': True, u'bindingId': u'cb328c51-92a7-4809-b887-5cd8d5cdcd10', u'formScale': u'BIG', u'type': u'ACTION',
     u'id': u'a1a2245a-b6dd-4487-9a53-e720a5eeaf80', u'providerTypeId': u'com.vmware.csp.core.designer.service',
     u'description': u''},
    {u'extensionId': None, u'name': u'Get VM SG Attributes', u'iconId': u'cafe_default_icon_genericResourceOperation',
     u'hasForm': True, u'bindingId': u'c55610bb-6c39-47f9-953a-e1f568868e65', u'formScale': u'BIG', u'type': u'ACTION',
     u'id': u'd452ff16-0172-4288-9da6-2c3d5343226b', u'providerTypeId': u'com.vmware.csp.core.designer.service',
     u'description': u'This workflow returns the list of All available custom properties of a VM listed in ASD_CONFIG.'},
    {u'extensionId': None, u'name': u'RA - Force restart VM', u'iconId': u'45cb9d09-6806-4159-bab8-92bab36f46ac_icon',
     u'hasForm': True, u'bindingId': u'611b13f3-d4d3-43fb-bd79-292803b93dd5', u'formScale': u'BIG', u'type': u'ACTION',
     u'id': u'2917a439-137e-4f7b-8a37-876b3fe0e5e6', u'providerTypeId': u'com.vmware.csp.core.designer.service',
     u'description': u''},
    {u'extensionId': None, u'name': u'Remove All Tags From VM', u'iconId': u'fbcd02fd-0e62-4d73-b9a0-92f653596253_icon',
     u'hasForm': True, u'bindingId': u'043cf543-3131-4275-8fd4-6669d352936e', u'formScale': u'BIG', u'type': u'ACTION',
     u'id': u'24e7468c-2a69-426a-aed7-838939dd4592', u'providerTypeId': u'com.vmware.csp.core.designer.service',
     u'description': u'Function to update the tags on a VLB from the portal.'},
    {u'extensionId': None, u'name': u'Remove Tags From VM', u'iconId': u'afc82a1c-d34b-4e1f-a33a-01e332014006_icon',
     u'hasForm': True, u'bindingId': u'5607985b-e71b-40bf-b9f6-8216b5f1b198', u'formScale': u'BIG', u'type': u'ACTION',
     u'id': u'9f2110f9-fa2b-40c3-a39b-a763a2acc2ec', u'providerTypeId': u'com.vmware.csp.core.designer.service',
     u'description': u'Function to update the tags on a VLB from the portal.'},
    {u'extensionId': None, u'name': u'Restart VM', u'iconId': u'72bbc884-fb76-4cd2-8228-87c406f5c858_icon',
     u'hasForm': True, u'bindingId': u'46cf5de7-07c1-4981-9ccc-08bc872dd5bc', u'formScale': u'BIG', u'type': u'ACTION',
     u'id': u'134d6742-a802-43ea-a828-d6d2d175dc98', u'providerTypeId': u'com.vmware.csp.core.designer.service',
     u'description': u'Restart a Virtual Machine'},
    {u'extensionId': None, u'name': u'Update Tags From VM', u'iconId': u'fa8ab11e-bcfa-4e9f-8f4f-c03cf0bbdb29_icon',
     u'hasForm': True, u'bindingId': u'0a8ac7a0-a260-4ceb-a2c7-0d4245a31a6e', u'formScale': u'BIG', u'type': u'ACTION',
     u'id': u'15dbd19b-29e0-41d5-abff-880f206576c6', u'providerTypeId': u'com.vmware.csp.core.designer.service',
     u'description': u'Function to update the tags on an object from the portal.'}], u'childResources': [],
                      u'id': u'e03a00d8-3a9d-4547-ab93-e8848cfa2d9f',
                      u'totalCost': {u'currencyCode': u'USD', u'type': u'money', u'amount': 0.0},
                      u'iconId': u'0e98935b-28b9-4091-b4aa-4f075f82d34e', u'forms': {u'catalogResourceInfoHidden': True,
                                                                                     u'details': {
                                                                                         u'extensionPointId': None,
                                                                                         u'extensionId': u'csp.places.iaas.item.details',
                                                                                         u'type': u'extension'}},
                      u'providerBinding': {u'bindingId': u'4afb4b17-6c8b-44ea-8f5b-fe481efc3170',
                                           u'providerRef': {u'id': u'ea3f4a9f-ed7c-4e05-a516-5784f2b87ab3',
                                                            u'label': u'iaas-service'}},
                      u'requestId': u'27c6c249-ad5e-4491-9844-c820278ae968',
                      u'costToDate': {u'currencyCode': u'USD', u'type': u'money', u'amount': 0.0},
                      u'lease': {u'start': u'2017-03-07T14:07:30.000Z', u'end': u'2027-03-05T14:11:07.000Z'},
                      u'status': u'ACTIVE', u'description': u'Test new template EDGE',
                      u'lastUpdated': u'2017-03-07T14:12:45.868Z', u'dateCreated': u'2017-03-07T14:10:45.725Z',
                      u'catalogItem': {u'id': u'0e98935b-28b9-4091-b4aa-4f075f82d34e',
                                       u'label': u'RHEL_7.2_x64-RET-EDGE'},
                      u'leaseForDisplay': {u'amount': 3650, u'type': u'timeSpan', u'unit': u'DAYS'}, u'owners': [
        {u'type': u'USER', u'tenantName': u'sgcloud', u'ref': u'EAN_PRD_SVC@eur.msd.world.socgen',
         u'value': u'Generic Account'}], u'name': u'dpgalx001', u'hasCosts': True, u'resourceData': {u'entries': [{
                                                                                                                      u'value': {
                                                                                                                          u'items': [
                                                                                                                              {
                                                                                                                                  u'classId': u'dynamicops.api.model.NetworkViewModel',
                                                                                                                                  u'typeFilter': None,
                                                                                                                                  u'componentTypeId': u'com.vmware.csp.component.iaas.proxy.provider',
                                                                                                                                  u'values': {
                                                                                                                                      u'entries': [
                                                                                                                                          {
                                                                                                                                              u'value': {
                                                                                                                                                  u'type': u'string',
                                                                                                                                                  u'value': u'192.88.70.137'},
                                                                                                                                              u'key': u'NETWORK_ADDRESS'},
                                                                                                                                          {
                                                                                                                                              u'value': {
                                                                                                                                                  u'type': u'string',
                                                                                                                                                  u'value': u'00:50:56:ab:5f:5e'},
                                                                                                                                              u'key': u'NETWORK_MAC_ADDRESS'},
                                                                                                                                          {
                                                                                                                                              u'value': {
                                                                                                                                                  u'type': u'string',
                                                                                                                                                  u'value': u'RET_192-88-64-0_21'},
                                                                                                                                              u'key': u'NETWORK_NAME'}]},
                                                                                                                                  u'type': u'complex',
                                                                                                                                  u'componentId': None}],
                                                                                                                          u'elementTypeId': u'COMPLEX',
                                                                                                                          u'type': u'multiple'},
                                                                                                                      u'key': u'NETWORK_LIST'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'string',
                                                                                                                          u'value': u'BG_GTS-RET'},
                                                                                                                      u'key': u'MachineGroupName'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'boolean',
                                                                                                                          u'value': True},
                                                                                                                      u'key': u'ConnectViaSsh'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'boolean',
                                                                                                                          u'value': True},
                                                                                                                      u'key': u'Expire'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'items': [],
                                                                                                                          u'elementTypeId': u'COMPLEX',
                                                                                                                          u'type': u'multiple'},
                                                                                                                      u'key': u'SNAPSHOT_LIST'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'string',
                                                                                                                          u'value': u'On'},
                                                                                                                      u'key': u'MachineStatus'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'string',
                                                                                                                          u'value': u'vSphere (vCenter)'},
                                                                                                                      u'key': u'MachineInterfaceDisplayName'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'boolean',
                                                                                                                          u'value': True},
                                                                                                                      u'key': u'PowerOff'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'items': [
                                                                                                                              {
                                                                                                                                  u'classId': u'dynamicops.api.model.DiskInputModel',
                                                                                                                                  u'typeFilter': None,
                                                                                                                                  u'componentTypeId': u'com.vmware.csp.component.iaas.proxy.provider',
                                                                                                                                  u'values': {
                                                                                                                                      u'entries': [
                                                                                                                                          {
                                                                                                                                              u'value': {
                                                                                                                                                  u'type': u'integer',
                                                                                                                                                  u'value': 40},
                                                                                                                                              u'key': u'DISK_CAPACITY'},
                                                                                                                                          {
                                                                                                                                              u'value': {
                                                                                                                                                  u'type': u'string',
                                                                                                                                                  u'value': u'DISK_INPUT_ID1'},
                                                                                                                                              u'key': u'DISK_INPUT_ID'}]},
                                                                                                                                  u'type': u'complex',
                                                                                                                                  u'componentId': None},
                                                                                                                              {
                                                                                                                                  u'classId': u'dynamicops.api.model.DiskInputModel',
                                                                                                                                  u'typeFilter': None,
                                                                                                                                  u'componentTypeId': u'com.vmware.csp.component.iaas.proxy.provider',
                                                                                                                                  u'values': {
                                                                                                                                      u'entries': [
                                                                                                                                          {
                                                                                                                                              u'value': {
                                                                                                                                                  u'type': u'integer',
                                                                                                                                                  u'value': 60},
                                                                                                                                              u'key': u'DISK_CAPACITY'},
                                                                                                                                          {
                                                                                                                                              u'value': {
                                                                                                                                                  u'type': u'string',
                                                                                                                                                  u'value': u'DISK_INPUT_ID2'},
                                                                                                                                              u'key': u'DISK_INPUT_ID'}]},
                                                                                                                                  u'type': u'complex',
                                                                                                                                  u'componentId': None}],
                                                                                                                          u'elementTypeId': u'COMPLEX',
                                                                                                                          u'type': u'multiple'},
                                                                                                                      u'key': u'DISK_VOLUMES'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'string',
                                                                                                                          u'value': u'RHEL_7.2_x64-RET-EDGE'},
                                                                                                                      u'key': u'MachineBlueprintName'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'boolean',
                                                                                                                          u'value': True},
                                                                                                                      u'key': u'Reboot'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'boolean',
                                                                                                                          u'value': True},
                                                                                                                      u'key': u'Suspend'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'boolean',
                                                                                                                          u'value': True},
                                                                                                                      u'key': u'Reprovision'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'decimal',
                                                                                                                          u'value': 0.0},
                                                                                                                      u'key': u'MachineDailyCost'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'integer',
                                                                                                                          u'value': 100},
                                                                                                                      u'key': u'MachineStorage'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'boolean',
                                                                                                                          u'value': True},
                                                                                                                      u'key': u'Destroy'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'string',
                                                                                                                          u'value': u'Virtual'},
                                                                                                                      u'key': u'MachineType'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'boolean',
                                                                                                                          u'value': True},
                                                                                                                      u'key': u'Shutdown'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'boolean',
                                                                                                                          u'value': True},
                                                                                                                      u'key': u'ConnectViaVmrc'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'boolean',
                                                                                                                          u'value': True},
                                                                                                                      u'key': u'ChangeLease'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'string',
                                                                                                                          u'value': u'4afb4b17-6c8b-44ea-8f5b-fe481efc3170'},
                                                                                                                      u'key': u'machineId'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'boolean',
                                                                                                                          u'value': False},
                                                                                                                      u'key': u'IS_COMPONENT_MACHINE'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'integer',
                                                                                                                          u'value': 8192},
                                                                                                                      u'key': u'MachineMemory'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'string',
                                                                                                                          u'value': u'dpgalx001'},
                                                                                                                      u'key': u'MachineName'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'string',
                                                                                                                          u'value': u'Red Hat Enterprise Linux 7 (64-bit)'},
                                                                                                                      u'key': u'MachineGuestOperatingSystem'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'dateTime',
                                                                                                                          u'value': u'2027-03-06T14:11:07.900Z'},
                                                                                                                      u'key': u'MachineDestructionDate'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'integer',
                                                                                                                          u'value': 4},
                                                                                                                      u'key': u'MachineCPU'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'string',
                                                                                                                          u'value': u'vSphere'},
                                                                                                                      u'key': u'MachineInterfaceType'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'string',
                                                                                                                          u'value': u'BG_GTS-RET-Res-36'},
                                                                                                                      u'key': u'MachineReservationName'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'boolean',
                                                                                                                          u'value': True},
                                                                                                                      u'key': u'Reconfigure'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'boolean',
                                                                                                                          u'value': True},
                                                                                                                      u'key': u'GetExpirationReminder'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'string',
                                                                                                                          u'value': u'vm-48921'},
                                                                                                                      u'key': u'EXTERNAL_REFERENCE_ID'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'dateTime',
                                                                                                                          u'value': u'2027-03-05T14:11:07.900Z'},
                                                                                                                      u'key': u'MachineExpirationDate'},
                                                                                                                  {
                                                                                                                      u'value': {
                                                                                                                          u'type': u'boolean',
                                                                                                                          u'value': True},
                                                                                                                      u'key': u'Reset'}]},
                      u'costs': {u'leaseRate': {u'cost': {u'currencyCode': u'USD', u'type': u'money', u'amount': 0.0},
                                                u'type': u'moneyTimeRate',
                                                u'basis': {u'amount': 1, u'type': u'timeSpan', u'unit': u'DAYS'}}},
                      u'resourceTypeRef': {u'id': u'Infrastructure.Virtual', u'label': u'Virtual Machine'},
                      u'organization': {u'subtenantLabel': u'BG_GTS-RET', u'tenantLabel': u'sgcloud',
                                        u'subtenantRef': u'7fc7be70-7251-4c52-8296-4414de8cf88c',
                                        u'tenantRef': u'sgcloud'}, u'hasLease': True, u'@type': u'CatalogResource'}]


class MockCloudVra(edge.interfaces.CloudVra):
    def get_vra_catalog(self):
        logger.debug('get_vra_catalog method called from MockCloudVra')
        return VRA_CATALOG_TWO_ITEMS

    def get_vra_resource_data(self): # filter_sentence
        logger.debug('get_vra_resource_data method called from MockCloudVra')
        return VRA_RESOURCE_DATA

role_edge_sudo
================

Rôle de post-configuration de la couche système d'une VM.
  - Ajout des commandes SUDO autorisées aux groupes ME & BT*[trigram]

Requirements
------------

Pas de pré-requis particulier, à part l'existence de la VM spécifiée.

Role Variables
--------------

**system_trigram** : Trigramme applicatif a utiliser pour donner les droits sudo (Obligatoire)


Dependencies
------------

Aucune dépendance.

Example Playbook
----------------

````yaml
- hosts: DPGALXRET1028

  roles:
  - { role: role_edge_sudo,
        system_trigram: "pga"
    }
````

License
-------

BSD

Author Information
------------------

Role créé par la feature Team Edge

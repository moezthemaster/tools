# role_edge_alias_dns
Role_edge_alias_dns is to add and delete dns cname record

# Installation

```
ansible-galaxy install git+https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/role_edge_alias_dns.git,latest_release -p roles -f
```

This above command will install role_edge_alias_dns with its dependencies in the specified folder roles of current folder

# Pre-requirements

  You must create an ansible.cfg file on same folder with the playbook which will be launched.
  libray is the location ansible looks to find modules for role_edge_alias_dns.

  ```
    [defaults]
    library        = ./roles/edge_ansible_modules/files
  ```
  edge_ansible_modules is one of dependencies for role_edge_alias_dns. he contains modules that edge_ansible_modules looks for its operation

# How to use it ?

And here's an example to record cname for hostname :

```
---
- hosts: localhost
  vars:
    vm_hostname: 'dpgalxtest'
    dns_alias_name: 'dpgalxtestalias'
    dns_alias_zone: 'dns21.socgen'
    state: 'present'

  roles:
    - role_edge_alias_dns
```

You have to specify an inventory file containing localhost as hostname.

This role can only be executed through A4C or Ansible Tower platform.

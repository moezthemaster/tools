import pytest
from faker import Faker

from sample.tests.mock_classes import fake_header
from sample.apis import api
from sample.apis.contacts import ContactList

faker = Faker()


@pytest.mark.usefixtures("mock_db_session")
@pytest.mark.usefixtures("sg_connect_token")
class TestUtils(object):
    """Test get_logger method"""

    def test_logger_is_instantiated(self, mocker, flask_app_client, flask_app):
        """ Test that logger is instantiated in g object """
        mocked_logger_cls = mocker.patch(
            'sample.core.utils.DatalakeLog', autospec=True)
        mocked_logger = mocked_logger_cls.return_value
        with flask_app.app_context() as context:
            assert not hasattr(context.g, "_logger")
            flask_app_client.get(api.url_for(ContactList),
                                 headers=fake_header())
            assert hasattr(context.g, "_logger")
            assert getattr(context.g, "_logger") is mocked_logger

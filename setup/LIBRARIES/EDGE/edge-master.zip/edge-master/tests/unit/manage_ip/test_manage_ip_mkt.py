import logging

import pytest
from six import with_metaclass
from tests.mock.mock import MockDod
from tests.mock.idm import MockedIdm
from edge.manage_ip.manage_ip import ManageIP
from tests.mock.mockdodv1 import MockDod as MockDodv1
from tests.mock.connectionhelper import MockedConnectionHelper
from edge.dns.metaclass import DnsFeederMetaClass, DnsUpdaterMetaClass, DnsCleanerMetaClass, DnsInformerMetaClass

#logging.basicConfig(level=logging.DEBUG)

logger = logging.getLogger(__name__)

#debug during test
# for e in SHARED_DATABASE:
#     if e['type'] == "A":
#         print "{} - {}".format(
#             e["hostname"], e["ip"]
#         )

SHARED_DATABASE = {
    "A": dict(),
    "PTR": dict()
}
SHARED_DATABASE_DOD_V2 = []
SHARED_DATABASE_IDM = [
    {"hostname": "for_raise_an_ip_confict", "ip": "192.163.216.2"},
    {"hostname": "for_raise_an_ip_confict", "ip": "192.163.216.4"},
    {# raise an hostname conflict
        "hostname": "dtrvlx004", "ip": "192.163.216.250"
    }
]
SHARED_DATABASE_CONNEXION_SSH = [
    {"ip": "192.163.216.5", "hostname": "dtrvlx1000", "sshd": True, "rdp": False, "ping": False},
    {"ip": "192.163.216.8", "hostname": "dtrvlx1001", "sshd": True, "rdp": False, "auth_failed": True, "ping": False},
    {"ip": "192.163.216.9", "hostname": "dtrvlx1001", "sshd": False, "rdp": True, "ping": False},
]


class MockedFeederdodv1(with_metaclass(DnsFeederMetaClass, MockDod, MockDodv1)):
    #__metaclass__ = DnsFeederMetaClass

    def __init__(self, *args, **kwargs):
        MockDodv1.__init__(self, shared_database=SHARED_DATABASE)
        MockDod.__init__(self, (), hostname=None, shared_database=SHARED_DATABASE_DOD_V2)


class MockedUpdaterdodv1(with_metaclass(DnsUpdaterMetaClass, MockDod, MockDodv1)):
    #__metaclass__ = DnsUpdaterMetaClass

    def __init__(self, *args, **kwargs):
        MockDodv1.__init__(self, shared_database=SHARED_DATABASE)
        MockDod.__init__(self, (), hostname=None, shared_database=SHARED_DATABASE_DOD_V2)



class MockedCleanerdodv1(with_metaclass(DnsCleanerMetaClass, MockDod, MockDodv1)):
    #__metaclass__ = DnsCleanerMetaClass

    def __init__(self, *args, **kwargs):
        MockDodv1.__init__(self, shared_database=SHARED_DATABASE)
        MockDod.__init__(self, (), hostname=None, shared_database=SHARED_DATABASE_DOD_V2)


class MockedInformerdodv1(with_metaclass(DnsInformerMetaClass, MockDod, MockDodv1)):
    #__metaclass__ = DnsInformerMetaClass

    def __init__(self, *args, **kwargs):
        MockDodv1.__init__(self, shared_database=SHARED_DATABASE)
        MockDod.__init__(self, (), hostname=None, shared_database=SHARED_DATABASE_DOD_V2)


class MockedIdmWrapper(MockedIdm):
    def __init__(self, env):
        MockedIdm.__init__(self, env=env, shared_database=SHARED_DATABASE_IDM)


class MockedIdmWrapperUnknownError(MockedIdm):
    def __init__(self, env):
        MockedIdm.__init__(self, env=env, shared_database=SHARED_DATABASE_IDM)

    def check_whats(self, *args, **kwargs):
        raise Exception('Unknown Error')


class MockedConnectionHelperImpl(MockedConnectionHelper):
    def __init__(self):
        MockedConnectionHelper.__init__(self, shared_database=SHARED_DATABASE_CONNEXION_SSH)


def insert_record(hostname):
    run_kwargs = {
        "env": "dev",
        "region_cloud": "EU France (Greater Paris)",
        "az_cloud": "eu-fr-paris-1",
        "network_id": "ITEC_CLOUD_DEV_DC2_04",
        "trigram": "trv",
        "hostname": hostname,
        "max_retries": 1
    }
    feeder = ManageIP(
        MockedIdmWrapper, MockedConnectionHelperImpl, MockedFeederdodv1,
        MockedUpdaterdodv1, MockedCleanerdodv1
    )
    feeder.run(**run_kwargs)


def test_dod_by_metaclass_client_call():
    feeder = MockedFeederdodv1(
        "dev", 'EU France (Greater Paris)', 'eu-fr-paris-1', 'ITEC_CLOUD_DEV_DC2_04', trigram='trv',
        hostname="dtrvlx001"
    )
    response = feeder.run()
    assert response["output"][0]["hostname"] == "dtrvlx001"
    informer = MockedInformerdodv1(
        "dtrvlx001", network_index="mkt", region_cloud='EU France (Greater Paris)',
        az_cloud='eu-fr-paris-1'
    )
    response = informer.run()
    assert response[0]["vm_hostname"] == "dtrvlx001"
    updater = MockedUpdaterdodv1(
        "dev", 'EU France (Greater Paris)', 'eu-fr-paris-1', 'ITEC_CLOUD_DEV_DC2_04', trigram='trv', hostname="dtrvlx001"
    )
    response = updater.run("ssh")
    assert response["output"][0]["ip"] == "192.163.216.1"
    # check alias is removed in dodv2
    assert len(updater.dns_database) == 0
    cleaner = MockedCleanerdodv1(
        "dev", 'EU France (Greater Paris)', 'eu-fr-paris-1', 'ITEC_CLOUD_DEV_DC2_04', trigram='trv',
        hostname=response["output"][0]["hostname"]
    )
    cleaner.run()
    assert len(cleaner.dns_database) == 0


def init_params_for_get_ip():
    run_kwargs1 = {
        "env": "dev",
        "region_cloud": "EU France (Greater Paris)",
        "az_cloud": "eu-fr-paris-1",
        "network_id": "ITEC_CLOUD_DEV_DC2_04",
        "trigram": "trv",
        "hostname": "dtrvlx001",
        "max_retries": 1
    }
    run_kwargs2 = {
        "env": "dev",
        "region_cloud": "EU France (Greater Paris)",
        "az_cloud": "eu-fr-paris-1",
        "network_id": "ITEC_CLOUD_DEV_DC2_04",
        "trigram": "trv",
        "hostname": "dtrvlx002",
        "max_retries": 2
    }
    run_kwargs3 = {
        "env": "dev",
        "region_cloud": "EU France (Greater Paris)",
        "az_cloud": "eu-fr-paris-1",
        "network_id": "ITEC_CLOUD_DEV_DC2_04",
        "trigram": "trv",
        "hostname": "dtrvlx003",
        "max_retries": 3
    }
    return [
        (
            'get_ip_in_first_attempt', MockedIdmWrapper, MockedConnectionHelperImpl, MockedFeederdodv1,
            MockedUpdaterdodv1, MockedCleanerdodv1, run_kwargs1, "dtrvlx001"
        ),
        (
            'get_ip_in_second_attempt', MockedIdmWrapper, MockedConnectionHelperImpl, MockedFeederdodv1,
            MockedUpdaterdodv1, MockedCleanerdodv1, run_kwargs2, "dtrvlx002"
        ),
        (
            'get_ip_in_third_attempt', MockedIdmWrapper, MockedConnectionHelperImpl, MockedFeederdodv1,
            MockedUpdaterdodv1, MockedCleanerdodv1, run_kwargs3, "dtrvlx003"
        ),
    ]


@pytest.mark.parametrize('test_type, idm, connexion_helper, feeder, updater, cleaner, run_kwargs, expect',
    init_params_for_get_ip()
)
def test_manage_ip_get_ip(test_type, idm, connexion_helper, feeder, updater, cleaner, run_kwargs, expect):
    print("Name test : " + test_type)
    feeder = ManageIP(idm, connexion_helper, feeder, updater, cleaner)
    response = feeder.run(
        **run_kwargs
    )
    assert response["output"][0]["hostname"] == expect


def test_manage_ip_whats_hostname_conflict():
    run_kwargs = {
        "env": "dev",
        "region_cloud": "EU France (Greater Paris)",
        "az_cloud": "eu-fr-paris-1",
        "network_id": "ITEC_CLOUD_DEV_DC2_04",
        "trigram": "trv",
        "hostname": "dtrvlx004",
        "max_retries": 1
    }
    feeder = ManageIP(
        MockedIdmWrapper, MockedConnectionHelperImpl, MockedFeederdodv1,
        MockedUpdaterdodv1, MockedCleanerdodv1
    )
    try:
        feeder.run(
            **run_kwargs
        )
        assert False
    except Exception as err:
        assert "IP conflict with whats_hostname" in err.args[0]


def test_manage_ip_ssh_conflict():
    insert_record(hostname="dtrvlx100")
    run_kwargs = {
        "env": "dev",
        "region_cloud": "EU France (Greater Paris)",
        "az_cloud": "eu-fr-paris-1",
        "network_id": "ITEC_CLOUD_DEV_DC2_04",
        "trigram": "trv",
        "hostname": "dtrvlx005",
        "max_retries": 1
    }
    feeder = ManageIP(
        MockedIdmWrapper, MockedConnectionHelperImpl, MockedFeederdodv1,
        MockedUpdaterdodv1, MockedCleanerdodv1
    )
    try:
        feeder.run(
            **run_kwargs
        )
        assert False
    except Exception as err:
        assert "IP conflict with unix server:" in err.args[0]


def test_manage_ip_rdp_conflict():
    run_kwargs = {
        "env": "dev",
        "region_cloud": "EU France (Greater Paris)",
        "az_cloud": "eu-fr-paris-1",
        "network_id": "ITEC_CLOUD_DEV_DC2_04",
        "trigram": "trv",
        "hostname": "dtrvlx006",
        "max_retries": 1
    }
    feeder = ManageIP(
        MockedIdmWrapper, MockedConnectionHelperImpl, MockedFeederdodv1,
        MockedUpdaterdodv1, MockedCleanerdodv1
    )
    try:
        feeder.run(
            **run_kwargs
        )
        assert False
    except Exception as err:
        assert "IP conflict with windows server:" in err.args[0]


def test_manage_ip_suppress_ghost_entries_in_case_of_unknwon_error():
    run_kwargs = {
        "env": "dev",
        "region_cloud": "EU France (Greater Paris)",
        "az_cloud": "eu-fr-paris-1",
        "network_id": "ITEC_CLOUD_DEV_DC2_04",
        "trigram": "trv",
        "hostname": "dtrvlx007",
        "max_retries": 1
    }
    feeder = ManageIP(
        MockedIdmWrapperUnknownError, MockedConnectionHelperImpl, MockedFeederdodv1,
        MockedUpdaterdodv1, MockedCleanerdodv1
    )
    try:
        feeder.run(
            **run_kwargs
        )
        assert False
    except Exception as err:
        try:
            SHARED_DATABASE["A"]["dtrvlx007"]
        except KeyError:
            pass
        assert "Unknown Error" in err.args[0]

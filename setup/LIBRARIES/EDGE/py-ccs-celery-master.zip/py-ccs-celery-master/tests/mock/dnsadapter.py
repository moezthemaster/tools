class MockFeeder():

    def __init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname):
        self.changed = True

    def run(self, ):
        return {'output':[{'ip': '1.2.3.4','hostname': 'dpgalxtest01'}]}

class MockUpdater():

    def __init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname):
        self.changed = True

    def run(self, cause):
        return 'Entry updated: {}'.format(cause)

class MockCleaner():

    def __init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname):
        self.changed = True

    def run(self):
        return 'Entry cleaned'

#!/bin/bash
#
####################################
# Main authors: Damien Mirguet Philippe Guffroy Kisananth Kirupananthan
# co-Author Arnauld FRACHE
# Date : 18/01/2019
# LLD PostGres
# Discover CLUSTER / DBPORT
# Ver : 1.4
# Use :  sudo -u postgres /etc/zabbix/zabbix_agentd.d/PGS/zbx_PG_discover.sh
# Need : sudoers
# walle : ALL=(postgres)NOPASSWD:/etc/zabbix/zabbix_agentd.d/PGS/zbx_PG_discover.sh
#
# Output example:
# {
#   "data": [
#       {"{#CLUSTER_NAME}": "PPARADBD171","{#PG_PORT}": "5433"},
#       {"{#CLUSTER_NAME}": "PPARADBD172","{#PG_PORT}": "5434"}
#   ]
# }
#
###################################
#
# set -x
#
#
# 
# For ex retail
PATH_ENV='/produits/pgsql/env'
#
###################################
### ex-Market  or PGAAS
###################################

if [ $(find /*/postgres/ -maxdepth 1 -name pgtab 2>/dev/null | wc -l 2>/dev/null) -ge 1 ]; then
  echo -en "{\\n  \"data\": ["
  for i in $(cat /*/postgres/pgtab | grep -v '^#' | sort | uniq | cut -d: -f1)
  do
      (( line++ ))
      if [ $line -gt 1 ]
      then
        echo -en ",\\n    {"
      else
        echo -en "\\n    {"
      fi
      CLUSTERNAME=$i
      PGPORT=`grep '^port' $(cat /*/postgres/pgtab | grep -v '^#' | grep $CLUSTERNAME | uniq | cut -d: -f3)/postgresql.conf | cut -d= -f2 | sed -r 's/\s+//g'`
      echo -en "\""{#CLUSTER_NAME}\": \"${CLUSTERNAME}\",\"{#PG_PORT}\": \"${PGPORT}\"}
  done
  echo -en "\\n  ]\\n}\\n"
  echo ""
  /usr/bin/zabbix_sender -c /etc/zabbix/zabbix_agentd.conf -s $HOSTNAME -k disc.unknown.std -o 0 >/dev/null 2>&1
  exit 0

###################################
### ex-Retail
###################################
elif [ $(find $PATH_ENV -maxdepth 1 -name env_* 2>/dev/null | wc -l 2>/dev/null) -ge 1 ]; then
  cd $PATH_ENV 2> /dev/null
  echo -en "{\\n  \"data\": ["
  #echo ""

  
for POSTGRES_INSTANCE in env_*
  do
      (( line++ ))
# comma mecanism - no comma for the last line
#echo $line
    if [ $line -gt 1 ]
      then
        comma=",\\n"
      else
        comma="\\n"
      fi
#####
    if [ -f $PATH_ENV/$POSTGRES_INSTANCE ]; then
        . $PATH_ENV/$POSTGRES_INSTANCE 2>&1 > /dev/null
	echo -en "$comma  " " {\""{#CLUSTER_NAME}\": \"${DBNAME}\",\"{#PG_PORT}\": \"${PGPORT}\"}
	fi
  done
  #echo ""
  echo -en "\\n  ]\\n}\\n"
  /usr/bin/zabbix_sender -c /etc/zabbix/zabbix_agentd.conf -s $HOSTNAME -k disc.unknown.std -o 0 >/dev/null 2>&1
  exit 0


###################################
### EDGE
###################################
elif [ $(find /usr/local/bin -maxdepth 1 -name pgenv 2>/dev/null | wc -l 2>/dev/null) -ge 1 ]; then
  . /usr/local/bin/pgenv 2>/dev/null 1>/dev/null
  CLUSTERNAME=`echo $BASE | sed 's/.*\///'`
  echo -en "{\\n  \"data\": ["
  echo -en "\\n    {"
  echo -en "\""{#CLUSTER_NAME}\": \"${CLUSTERNAME}\",\"{#PG_PORT}\": \"${PGPORT}\"}
  echo -en "\\n  ]\\n}\\n"
  echo ""
  /usr/bin/zabbix_sender -c /etc/zabbix/zabbix_agentd.conf -s $HOSTNAME -k disc.unknown.std -o 0 >/dev/null 2>&1
  exit 0


###################################
### Unknown standard
###################################


else
  # echo "Unknown standard"
  /usr/bin/zabbix_sender -c /etc/zabbix/zabbix_agentd.conf -s $HOSTNAME -k disc.unknown.std -o 1
  exit 1
fi
#
#######END#####


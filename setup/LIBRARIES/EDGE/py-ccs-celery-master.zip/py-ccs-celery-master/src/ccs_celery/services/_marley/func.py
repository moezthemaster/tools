
import time

from ccs_celery.abstract import TaskServiceManager
from ccs_celery.services.rollback import RollBackMixins
from ccs_celery.services._marley.module import marley_module


class MarleyMixins(object):

    def on_failure(self, exc, kwargs, excinfo):
        try:
            self.rollback()
        except Exception as err:
            self.logger.error("Rollback for {} module has failded".format(str(err)))
        finally:
            self.data.services[self._task_name]["finished_at"] = time.time()
            self.data.services[self._task_name]["status"] = "FAILED"
            self.data.services[self._task_name]["exception_class"] = str(type(exc))
            self.data.services[self._task_name]["exception_msg"] = str(exc)
            self.data.services[self._task_name]["exception_traceback"] = str(excinfo)

    def on_success(self, result, kwargs):
        self.data.services[self._task_name]["finished_at"] = time.time()
        self.data.services[self._task_name]["status"] = "SUCCESS"
        self.data.services[self._task_name]["return_value"] = result

    def _set_up(self):
        self.data.services[self._task_name] = {
            "changed": False,
            "launch_at": time.time(),
            "service_kwargs": {}
        }
        if self.data.kwargs["state"] == "present":
            self.data.services[self._task_name]["service_kwargs"]["marley_operation"] = "create"
        elif self.data.kwargs["state"] == "absent":
            self.data.services[self._task_name]["service_kwargs"]["marley_operation"] = "decom"
        self.data.services[self._task_name]["service_kwargs"]["vm_hostname"] = self.data.shared_data["vm_hostname"]
        self.data.services[self._task_name]["service_kwargs"]["vm_os"] = self.data.shared_data["vm_os"]
        self.data.services[self._task_name]["service_kwargs"]["vm_profile"] = self.data.shared_data["vm_profile"]
        self.data.services[self._task_name]["service_kwargs"]["code_irt"] = self.data.shared_data["code_irt"]
        self.data.services[self._task_name]["service_kwargs"]["endClient"] = self.data.shared_data["endClient"]
        self.data.services[self._task_name]["service_kwargs"]["app_env"] = self.data.shared_data["app_env"]
        self.data.services[self._task_name]["service_kwargs"]["disk_size"] = self.data.shared_data["data_disk"]
        self.data.services[self._task_name]["service_kwargs"]["vm_backup"] = self.data.shared_data["vm_backup"]
        if self.data.shared_data["state"] == "absent":
            self.data.services[self._task_name]["rollback_kwargs"] = dict(
                **{x: self.data.services[self._task_name]["service_kwargs"][x] \
                   for x in self.data.services[self._task_name]["service_kwargs"].keys() if x != "state"}
            )
            self.data.services[self._task_name]["rollback_kwargs"]["marley_operation"] = "create"

    def task(self):
        self._set_up()
        self.logger.info("Invoke {} module with kwargs={}".format(
            self._task_name,
            self.data.services[self._task_name]["service_kwargs"])
        )
        result = marley_module(**self.data.services[self._task_name]["service_kwargs"])
        self.data.services[self._task_name]["changed"] = result[0]
        return result


class MarleyTask(MarleyMixins, TaskServiceManager, RollBackMixins):

    def __init__(self, data):
        TaskServiceManager.__init__(self, "Marley", data)


class MarleyDecomTask(MarleyMixins, TaskServiceManager, RollBackMixins):
    def __init__(self, data):
        TaskServiceManager.__init__(self, "MarleyDecom", data)

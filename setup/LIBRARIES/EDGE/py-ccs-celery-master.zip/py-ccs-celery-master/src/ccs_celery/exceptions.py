

class PyCcsCeleryError(Exception):
    pass


class ImproperlyConfigured(PyCcsCeleryError):
    pass

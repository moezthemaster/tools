
import io
import os
import sys
import logging
import datetime
import traceback

if "TREE_DIR" in os.environ.keys():
    ANSIBLE_MODULES_PATH = [
        os.path.join(os.environ["TREE_DIR"], 'roles/edge'),
        os.path.join(os.environ["TREE_DIR"], "library"),
        os.path.join(os.environ["TREE_DIR"], 'roles/zabaw'),
        os.path.join(os.environ["TREE_DIR"], 'roles/py_edge_vault')
    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/edge',
        './roles/zabaw',
        './roles/py_edge_vault'
    ]

for path in ANSIBLE_MODULES_PATH:
    sys.path.append(path)

from ansible.module_utils.basic import AnsibleModule
from zabaw.zabbix import zbxApi
from edge.kpi.elk import Loader
from edge.zabbix.zabbix import ZbxCtrl

formatter = logging.Formatter(fmt='%(asctime)s %(levelname)-8s %(message)s',
                              datefmt='%Y-%m-%d %H:%M:%S')
logstream = io.StringIO()
handler = logging.StreamHandler(logstream)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.addHandler(handler)
logger.setLevel(logging.WARNING)


def index_error_kpi(kpi_data, kpi_start_time):
    try:
        kpi_end_time = datetime.datetime.now()
        kpi_data['duration'] = (kpi_end_time - kpi_start_time).seconds
        loader = Loader()
        loader.index_data(
            id_execution=kpi_data['id_execution'], timestamp=kpi_data['timestamp'],
            duration=kpi_data['duration'], service=kpi_data['service'],
            hostname=kpi_data['vm_hostname'], status="failure",
            category=kpi_data['category'], client=kpi_data['endClient'],
            trigram=kpi_data['app_id'], environment=kpi_data['app_env'],
            error=kpi_data['error'], playbook_version=kpi_data['playbook_version']
        )
    except Exception:
        pass


class ZbxCtrlImpl(ZbxCtrl):
    def __init__(self, hostname):
        ZbxCtrl.__init__(self, hostname)
        self._zbxapi = zbxApi(self.zabbix_api_url)

    def get_host_id(self, hostname):
        return self._zbxapi.zbxGetHosts(hostname)[0]['hostid']

    def get_template_id(self, name):
        return self._zbxapi.zbxGetTemplateId(name)

    def link_host_to_template(self, host_id, template_id):
        return self._zbxapi.zbxLinkHostToTemplate(host_id, template_id)

    def unlink_host_to_template(self, host_id, template_id):
        return self._zbxapi.zbxUnlinkHostToTemplate(host_id, template_id)

    def get_templates_linked_to_host(self, host_id):
        return [v['templateid'] for v in self._zbxapi.zbxGetTemplatesLinkedToHostid(host_id)[0]["parentTemplates"]]

    def create_user_macro(self, **kwargs):
        return self._zbxapi.zbx_user_macro_create(**kwargs)

    def update_user_macros(self, **kwargs):
        return self._zbxapi.zbx_user_macro_update(**kwargs)

    def get_user_macro(self, host_id):
        return self._zbxapi.zbx_get_user_macros(host_id)

    def delete_user_macro(self, macroid):
        return self._zbxapi.zbx_delete_user_macros(macroid)

    def get_host_group(self, group_name):
        return self._zbxapi.zbx_get_hostgroup(group_name)

    def insert_in_hostgroup(self, group_id, host_id):
        return self._zbxapi.zbx_hostgroup_msadd(group_id, host_id)

    def remove_from_hostgroup(self, group_id, host_id):
        return self._zbxapi.zbx_hostgroup_msremove(group_id, host_id)

    def zbx_get_interfaces(self, host_id):
        return self._zbxapi.zbxGetInterfaces(host_id)

    def zbx_create_item(self, **params):
        return self._zbxapi.zbxCreateItem(**params)

    def zbx_search_item(self, host_id, search_data=None, params_data=None):
        return self._zbxapi.zbxSearchItem(host_id, search_data=search_data, params_data=params_data)

    def zbx_delete_item(self, item_id):
        return self._zbxapi.zbxDeleteItem(item_id)

    def zbx_create_trigger(self, params):
        return self._zbxapi.zbxCreateTrigger(params)

    def zbx_search_trigger(self, host_id, search_by_desc):
        return self._zbxapi.zbxSearchTrigger(host_id, search_by_desc)

    def zbx_delete_trigger(self, trigger_id):
        return self._zbxapi.zbxDeleteTrigger(trigger_id)

    def zbx_create_application(self, host_id, name):
        return self._zbxapi.zbxCreateApplication(host_id, name)

    def zbx_search_application(self, host_id, search_by_name):
        return self._zbxapi.zbxSearchApplication(host_id, search_by_name)

    def zbx_delete_application(self, application_id):
        return self._zbxapi.zbxDeleteApplication(application_id)


FIELDS = {
    "zbx_data": {
        "type": "dict",
        "required": True
    },
    "kpi_data": {
        "type": "dict"
    }
}


def main():
    module = AnsibleModule(argument_spec=FIELDS)
    if module._verbosity == 1:
        logger.setLevel(logging.INFO)
    if module._verbosity == 3:
        logger.setLevel(logging.DEBUG)
    kpi_data = module.params['kpi_data']
    zbx_data = module.params['zbx_data']
    if isinstance(kpi_data, dict):
        kpi_data['service'] = "Supervision"
        kpi_data['category'] = "Install Zabbix"
    kpi_start_time = datetime.datetime.now()
    zbx = ZbxCtrlImpl(zbx_data['host'])
    try:
        response = zbx.run(zbx_data)
        module.exit_json(changed=response['changed'], meta=response, debug_out=logstream.getvalue())
    except Exception as err:
        if module.params['zbx_data'].get('test_agent_zbx', None):
            kpi_data['error'] = err.args[0]
            index_error_kpi(kpi_data, kpi_start_time)
        if module._verbosity == 3:
            module.fail_json(msg=err.args[0], exception=traceback.format_exc())
        module.fail_json(msg=err.args[0], exception=traceback.format_exc())


if __name__ == '__main__':
  main()

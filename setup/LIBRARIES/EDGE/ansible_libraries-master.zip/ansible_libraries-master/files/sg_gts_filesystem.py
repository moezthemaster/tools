#!/usr/bin/env python

import sys
import subprocess
import re
import json
import pwd
import grp
import os

dict_extract_regex = re.compile('([A-Z]+)=(?:"(.*?)")')

def get_disk_infos():
    """
    Get informations on target disk. run lsbk command
    :rtype: object
    """
    blocks = []
    output = subprocess.check_output([
        "sudo", "lsblk", "-P", "--nodeps", "-o",
        "NAME,SIZE", "-I", "8", "-b"])
    for line in output.strip().splitlines():
        blocks.append(dict([(k.lower(), v) for k, v in dict_extract_regex.findall(line)]))

    return [x for x in blocks if 'sd' in x["name"]]


def get_vg_infos():
    """
    get vg name, size, freesize and pv from target machine
    :rtype: object
    """
    blocks = []
    pvs = []
    output = subprocess.check_output([
        "sudo", "pvs", "--noheadings", "--nosuffix",
        "--units", "b", "--separator", ";", "-o",
        "pv_name,vg_name,pv_size"])
    for l in output.splitlines():
        fields = l.strip().split(';')
        pvs.append({"name": fields[0], "vg": fields[1], "size": fields[2]})

    output = subprocess.check_output([
        "sudo", "vgdisplay", "-C", "--noheadings", "--nosuffix",
        "--units", "b", "--separator", ";", "-o",
        "vg_name,vg_size,vg_free"])
    for l in output.strip().splitlines():
        fields = l.strip().split(';')
        pv_in_vg = [x for x in pvs if x['vg'] == fields[0]]
        blocks.append({"name": fields[0], "size": fields[1], "freeSize": fields[2],
                       "pvs": pv_in_vg})

    #try:
        #list_vg = lvm.listVgNames()
        #for vg in list_vg:
        #    vg_desc = lvm.vgOpen(vg, 'r')
        #    pv_in_vg = []
        #    for pv in vg_desc.listPVs():
        #        pv_in_vg.append({"name": pv.getName(), "uuid": pv.getUuid(), "size": pv.getSize()})

        #    blocks.append({"name": vg, "size": vg_desc.getSize(),
        #                    "freeSize": vg_desc.getFreeSize(), "pvs": pv_in_vg})
        #    vg_desc.close()
    #except:
    #    raise

    return blocks


def get_fs_infos():
    """
    get fs info from target machine
    :rtype: object
    """
    blocks = []
    output = subprocess.check_output([
        "sudo", "lsblk", "-P", "-o",
        "NAME,UUID,SIZE,MOUNTPOINT,FSTYPE", "-I", "8", "-b"])
    for l in output.strip().splitlines():
        blocks.append(dict([(k.lower(), v) for k, v in dict_extract_regex.findall(l)]))

    return [x for x in blocks if "mountpoint" in x.keys() and re.match('^/.*$', x["mountpoint"])]
    # return blocks


def get_infos():
    """
    get needed inforamtions to create/extend file systems
    :rtype: object
    """
    result = {}
    result['disks'] = get_disk_infos()
    result['vg'] = get_vg_infos()
    result['fs'] = get_fs_infos()

    return result


def vg_create(vg, disk):
    """
    extend vg
    :rtype: object
    """
    infos = get_vg_infos()
    infos_vg = [x for x in infos if x['name'] == vg]

    disks = get_disk_infos()
    infos_disk = [x for x in disks if x['name'] == disk]
    if len(infos_vg) != 0 or len(infos_disk) == 0:
        raise ValueError("VG already created or unknown disk")
    output = subprocess.check_output(
        ["sudo", "vgcreate", vg, "/dev/{}".format(disk)])


def vg_extend(vg, disk):
    """
    extend vg
    :rtype: object
    """
    infos = get_vg_infos()
    infos_vg = [x for x in infos if x['name'] == vg]

    disks = get_disk_infos()
    infos_disk = [x for x in disks if x['name'] == disk]
    if len(infos_vg) == 0 or len(infos_disk) == 0:
        raise ValueError("VG not defined or unknown disk")
    output = subprocess.check_output(
        ["sudo", "vgextend", vg, "/dev/{}".format(disk)])

    #try:
    #    vg_desc = lvm.vgOpen(vg, 'w')
    #except lvm.LibLVMError, e:
    #    vg_desc = lvm.vgCreate(vg)

    #if not re.match('^/dev/', disk):
    #    vg_desc.extend("/dev/{}".format(disk))
    #else:
    #    vg_desc.extend(disk)
    #vg_desc.close()


def fs_resize(mountpoint, size, uid, gid, file_mode):
    """
    resize vg
    :rtype: object
    """
    infos = get_fs_infos()
    infos_fs = [x for x in infos if x['mountpoint'] == mountpoint]
    if len(infos_fs) == 0:
        return
    existing_fs = infos_fs[0]
    if existing_fs['fstype'] == 'ext4':
        output = subprocess.check_output(
            ["sudo", "lvextend", "-r", "-L", size, "/dev/mapper/{}".format(existing_fs['name'])])


def fs_create(mountpoint, size, vg, uid, gid, file_mode):
    """
    create lv
    :rtype: object
    """
    lv_name = "EDGE_LV{}".format(str(mountpoint).replace('/', '_'))
    output = subprocess.check_output(["sudo", "lvcreate", "-y", "-W", "y",
                                      "-Z", "y", "-L", size, "-n", lv_name, vg])

    # create fs
    output = subprocess.check_output(["sudo", "mkfs.ext4", "/dev/mapper/{}-{}".format(vg, lv_name)])
    output = subprocess.check_output(["sudo", "mkdir", "-p", mountpoint])
    fstab_entry = '/dev/mapper/{}-{} {} ext4 defaults 1 1'.format(vg, lv_name, mountpoint)
    f = open("/etc/fstab", 'a')
    f.write(fstab_entry + "\n")
    f.close()
    output = subprocess.check_output(["sudo", "mount", mountpoint])
    if uid != "-1":
        uid = pwd.getpwnam(uid).pw_uid
    if uid != "-1":
        gid = grp.getgrnam(gid).gr_gid
    os.chown(mountpoint, uid, gid)
    if file_mode != "-1":
        os.chmod(mountpoint, int(file_mode, 8))


if __name__ == "__main__":
    try:
        if sys.argv[1] == "vg_create":
            vg_create(sys.argv[2], sys.argv[3])
        if sys.argv[1] == "vg_extend":
            vg_extend(sys.argv[2], sys.argv[3])
        if sys.argv[1] == "fs_resize":
            fs_resize(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6])
        if sys.argv[1] == "fs_create":
            fs_create(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6], sys.argv[7])
    except:
        pass

    infos = get_infos()
    print("{}".format(json.dumps(infos)))

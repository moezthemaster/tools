**Conf tools for Edge**

Deux scripts python sont utilisables pour manipuler les fichiers de mapping :

---------------------------------------

*python2map.py*

Pour transformer la variable MAPPING du fichier ../network_mapping.py en csv
L'output se fait sur la sortie standard, a rediriger dans un fichier au besoin

    python python2map.py > network_mapping.csv

----------------------------------------

*map2python.py*

Pour transformer un fichier csv en fichier python utilisable par EDGE
L'output se fait sur la sortie standard, a rediriger dans un fichier .py

    python map2python.py ./network_mapping.csv > network_mapping.py

Le fichier généré sera à déplacer dans edge/edge/conf

----------------------------------------

*map2wiki.py*

Pour transformer un fichier csv en format wiki de sgithub 
L'output se fait sur la sortie standard, a copier/coller ensuite dans la page
wiki correspondante

    python map2wiki.py ./network_mapping.csv 



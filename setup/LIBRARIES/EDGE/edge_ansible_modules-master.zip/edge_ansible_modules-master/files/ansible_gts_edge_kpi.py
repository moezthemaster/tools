import os
import sys
import datetime

if "TREE_DIR" in os.environ.keys() :
    ANSIBLE_MODULES_PATH = [
        os.path.join(os.environ["TREE_DIR"], 'roles/edge'),
        os.path.join(os.environ["TREE_DIR"], "library"),
        os.path.join(os.environ["TREE_DIR"], 'roles/py_edge_vault'),

    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/edge',
        './roles/py_edge_vault'
    ]

for path in ANSIBLE_MODULES_PATH:
  sys.path.append(path)


from edge.kpi.elk import Loader
from ansible.module_utils.basic import AnsibleModule

PRESENT, INFO = 'present', 'info'

FIELDS = {
    "id_execution": {
        "required": False,
        "type": "str",
        "default": None
    },
    "timestamp": {
        "required": False,
        "type": "str",
        "default": None
    },
    "end_timestamp": {
        "required": False,
        "type": "str",
        "default": None
    },
    "service": {
        "required": False,
        "type": "str"
    },
    "vm_hostname": {
        "required": False,
        "type": "str"
    },
    "status": {
        "required": False,
        "type": "str"
    },
    "category": {
        "required": False,
        "type": "str"
    },
    "endClient": {
        "required": False,
        "type": "str"
    },
    "app_env": {
        "type": "str",
        "choices": [
            'uat',
            'tst',
            'int',
            'dev',
            'hml',
            'prd'
        ],
        "default": "prd"
    },
    "app_id": {
        "required": False,
        "type": "str"
    },
    "error": {
        "required": False,
        "type": "str"
    },
    "playbook_version":{
        "required": False,
        "type": "str"
    },
    "state": {
        "default": PRESENT,
        "choices": [
            PRESENT,
            INFO,
        ],
        "type": "str"
    }
}

def main():
    module = AnsibleModule(argument_spec=FIELDS)
    kpi_id_execution = module.params['id_execution']
    kpi_timestamp = module.params['timestamp']
    kpi_end_timestamp = module.params['end_timestamp']
    kpi_service = module.params['service']
    kpi_hostname = module.params['vm_hostname']
    kpi_status = module.params['status']
    kpi_category = module.params['category']
    kpi_client = module.params['endClient']
    kpi_environment = module.params['app_env']
    kpi_trigram = module.params['app_id']
    kpi_state = module.params['state']
    kpi_error = module.params['error']
    kpi_playbook_version = module.params['playbook_version']
    try:
        if kpi_state == PRESENT:
            loader = Loader()
            #print(kpi_timestamp)
            #print(kpi_end_timestamp)
            time_start = datetime.datetime.strptime(kpi_timestamp,'%Y-%m-%dT%H:%M:%S')
            #print(time_start)
            time_end = datetime.datetime.strptime(kpi_end_timestamp,'%Y-%m-%dT%H:%M:%S')
            #print(time_end)
            kpi_duration = (time_end - time_start).seconds
            #print(kpi_duration)
            response = kpi_duration
            response = loader.index_data(id_execution=kpi_id_execution, timestamp=kpi_timestamp, duration= kpi_duration, service=kpi_service,
                                      hostname=kpi_hostname, status=kpi_status,
                                      category=kpi_category, client=kpi_client,
                                      trigram=kpi_trigram, environment=kpi_environment, error=kpi_error, playbook_version=kpi_playbook_version)
            module.exit_json(changed=True, meta=response)
        elif kpi_state == INFO:
            loader = Loader()
            response = loader.get_data(kpi_hostname)
            module.exit_json(changed=True, meta=response)
    except Exception as e:
        module.fail_json(msg=e)


if __name__ == '__main__':
    main()


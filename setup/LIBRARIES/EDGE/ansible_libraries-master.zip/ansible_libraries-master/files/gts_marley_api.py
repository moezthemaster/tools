#!/usr/bin/python
# -*- coding: utf-8 -*-

import json
import time
import requests
import urlparse
import logging
from datetime import datetime, timedelta
from sg_gts_tools.read_settings import read_settings


# Exception related to GtsCloudApi
class GtsMarleyApiError(Exception):
    def __init__(self, msg, original):
        super(GtsMarleyApiError, self).__init__(msg + (": %s" % original))
        self.original = original

class GtsMarleyApi(object):

    def __init__(self, config_file = "gts_marley_api.cfg"):
        logger = logging.getLogger()
        logger.debug("GtsMarleyApi constructor")
        self.config = read_settings(config_file)
        self.credentials = read_settings(self.config["MARLEY_CONFIG_credential_file"])
       
 
    def __del__(self):
        pass
        

    def get_hostnames_from_trigram(self, trigram):

        auth = requests.auth.HTTPBasicAuth(self.credentials["MARLEY_PROD_CREDENTIALS_user"],
                                           self.credentials["MARLEY_PROD_CREDENTIALS_password"])
        params={'fields':'asset_id,building,environment,hardware_type,hostname_ret,main_ip,applis,os_revision,os_name,room,status,team,ican','format':'json'}
        params.update({'filters':'team,status,hostname_ret','values':'=ret/unx,=active,=^([dhp]' + trigram + 'lx.*)$'})

        try:
            r = requests.get(self.config["MARLEY_PRD_url"], auth=auth, params=params, verify=False)
        except Exception, e:
            raise GtsMarleyApiError("Impossible to get Marley information for {}".format(hostname), e)

        return r.json()
        
        
    def get_hostname_infos(self, hostname):
        
        auth = requests.auth.HTTPBasicAuth(self.credentials["MARLEY_PROD_CREDENTIALS_user"],
                                           self.credentials["MARLEY_PROD_CREDENTIALS_password"])
        params={'fields':'asset_id,building,environment,hardware_type,hostname_ret,main_ip,applis,os_revision,os_name,room,status,team,ican','format':'json'}
        params.update({'filters':'team,status,hostname_ret','values':'=ret/unx,=active,=^(' + hostname + ')$'})

        try:
            r = requests.get(self.config["MARLEY_PRD_url"], auth=auth, params=params, verify=False)
        except Exception, e:
            raise GtsMarleyApiError("Impossible to get Marley information for {}".format(hostname), e)

        return r.json()


if __name__ == '__main__':
    pass

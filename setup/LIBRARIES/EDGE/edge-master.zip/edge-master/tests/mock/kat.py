from edge.interfaces import Kat

KAT_DICT = {
    'PGA' : 'RESG/GTS/RET/API/VDF',
    'CLD' : 'ITIM/ASI/SDC',
    'SFA' : 'RESG/BSC/DCO/VDF',
    'PTA': 'ITEC/FCC/TRA',
    'FOO' : 'BAR'
}


class MockedKat(Kat):
    def get_single_component_data(self, trigram, irt_code):
        response = []
        if trigram in KAT_DICT:
            response.append({'client_ME': KAT_DICT[trigram]})
        return response


import re

from edge.connection.connectionhelper import ConnectionHelper


class ConnectionModuleError(Exception):
    pass


class ConnectionHelperImp(ConnectionHelper):
    def __init__(self):
        ConnectionHelper.__init__(self)
    def set_pubkey(self, ip_address, remote_user, remote_group, pubkey):
        response = self.authorized_key(
            ip_address=ip_address, remote_user=remote_user, remote_group=remote_group,
            pubkey=pubkey
        )
        return response


PRESENT, STATUS = 'present', 'status'


def connection_module(ip, vm_hostname, pubkey, remote_user="automation", remote_group="automation", state="present"):
    cnxhelper = ConnectionHelperImp()
    if state == PRESENT:
        response = cnxhelper.set_pubkey(
            ip_address=ip,
            remote_user=remote_user,
            remote_group=remote_group,
            pubkey=pubkey
        )
        try:
            response = response.decode("utf-8")
        except AttributeError:
            pass
        return cnxhelper.has_changed, response
    elif state == STATUS:
        response = cnxhelper.check_ip_address(ip)
        match_hostname = re.match(r'^({0}\..*)|({0})$'.format(vm_hostname), response)
        if response == "No host responding in RDP" or match_hostname:
            return cnxhelper.has_changed, "No IP conflict"
        else:
            raise ConnectionModuleError("Another host has been found for this IP address : {}".format(response))

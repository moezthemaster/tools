#!/usr/bin/ksh
force_delete() {
 # mkdir -p logs
 # nohup ansible-playbook -vvv force_delete.yml -e @defaults/delete.yml -e "vm_hostname='$1'" >logs/fdelete_$1.log &
 ansible-playbook force_delete.yml -e @defaults/delete.yml -e "vm_hostname='$1'"
}

force_delete_dpgalx() {
  for i in $*; do
    force_delete dpgalx$i
  done
}


force_delete_hpgalx() {
  for i in $*; do
    force_delete hpgalx$i
  done
}

force_delete_ppgalx() {
  for i in $*; do
    force_delete ppgalx$i
  done
}

force_delete_file() {
  cat $1 | tr -d '\r' | while read server; do
    force_delete $server
  done
}

force_delete_file liste.txt

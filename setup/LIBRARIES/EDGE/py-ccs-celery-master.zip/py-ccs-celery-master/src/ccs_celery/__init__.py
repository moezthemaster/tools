# -*- coding: utf-8 -*-

"""Top-level package for py-ccs-celery."""

__author__ = """GTSMKTCLD"""
__email__ = 'list.par-resg-gts-cld-ops@sgcib.com'
__version__ = '0.0.1'

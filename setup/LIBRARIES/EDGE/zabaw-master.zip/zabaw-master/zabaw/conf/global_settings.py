'''
Default settings. Override these with settings in the .py file pointed to
by the ZABAW_CONFIG_FILE environment variable.
'''


###########
# LOGGING #
###########

LOGGER_LEVEL = 'WARN'

#############
#  ZABBIX  #
#############

ZABBIX_CREDENTIALS_GROUP = 'zabbix'  # ZABBIX_PROD_CREDENTIALS
ZABBIX_URL_RET = ''
ZABBIX_URL_MKT = ''

#############
#  PUBKEY  #
#############

PUBKEY_CREDENTIALS_GROUP = 'root_key'  # by default ROOT_KEY

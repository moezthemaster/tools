#!/usr/bin/env python
# -*- coding: utf-8 -*-

''' Main census module. '''

__author__ = "FT Edge"
__version__ = "0.1.0"

import logging
import logzero

from logzero import logger

import argparse
import os
import os.path
import re
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning

# FILE_EXPORT find path
dirname = os.path.dirname(os.path.realpath(__file__))
if not dirname:
    FILE_EXPORT = 'file_export.cfg'
    FILE_EXPORT_PROD = 'file_export_prod.cfg'
else:
    FILE_EXPORT = os.path.join(dirname, 'file_export.cfg')
    FILE_EXPORT_PROD = os.path.join(dirname, 'file_export_prod.cfg')
os.environ["DODAW_CONFIG_FILE"] = FILE_EXPORT
os.environ["CLOUDAW_CONFIG_FILE"] = FILE_EXPORT
os.environ["EDGE_CONFIG_FILE"] = FILE_EXPORT
os.environ["INCUBAW_CONFIG_FILE"] = FILE_EXPORT

from dodaw.dod import DodWrapper
import cloudaw
from cloudaw.resource import Resource
from cloudaw.token import Token
from edge.interfaces import Dod, CloudVra
from edge.inventory.dod_inventory import Extractor as ExtractorDod
from edge.inventory.cloud_vra_inventory import Extractor as ExtractorCloud
from incubaw.bobaw import Bobaw

os.environ["CLOUDAW_CONFIG_FILE"] = FILE_EXPORT_PROD  # no remove
logging.getLogger("requests").setLevel(logging.DEBUG)

class DodImpl(Dod):
    def __init__(self):
        self.dod_wrapper = DodWrapper()
        requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
        # logging.captureWarnings(True)

    def search_dns_record(self, record_type="", **kwargs):
        return self.dod_wrapper.search_record(record_type, **kwargs)


class DodInventoryImpl(ExtractorDod, DodImpl):
    def __init__(self):
        DodImpl.__init__(self)
        ExtractorDod.__init__(self)
        requests.packages.urllib3.disable_warnings(InsecureRequestWarning)


class CloudVraImpl(CloudVra):
    def __init__(self):
        self.token = Token()
        self.resource = Resource(self.token)

    def get_vra_resource_data(self):
        return self.resource.get_resource_data(self._sentence_filter)


class CloudImpl(ExtractorCloud, CloudVraImpl):
    def __init__(self, trigram, env, api_env):
        ExtractorCloud.__init__(self, trigram, env, api_env)
        CloudVraImpl.__init__(self)


def output_cloud_inventory(inventory):
    """
    [description] get errors report per ip and hostname Argument: inventory
        Returns: List of errors
    """
    for (hostname, val) in sorted(inventory.iteritems()):
        if val['comment'] is None:
            val['comment'] = ""
        if hostname:
            print(
                "{};{};{};{};{};{};{};{}".format(
                    hostname.encode('utf8'),
                    val['comment'].encode('utf8'),
                    val["ip"].encode('utf8'),
                    val["env"].encode('utf8'),
                    val["creation"].encode('utf8'),
                    val["expiration"].encode('utf8'),
                    val["blueprint"].encode('utf8'),
                    val["bg"].encode('utf8')
                )
            )


def init_logger(level):
    ''' Init logger base on level specified.'''
    if level is None:
        level = 0
    if level >= 2:
        logzero.loglevel(level=logging.DEBUG)
    elif level == 1:
        logzero.loglevel(level=logging.INFO)
    else:
        logzero.loglevel(level=logging.WARNING)


def main(args):
    ''' Main function for inventory.'''
    init_logger(level=args.verbose)

    if len(args.trigram) >= 1:
        # Inventaire cloud en 2 etapes pour les BG hors prod et prod
        cloud_inventory = {}
        if not args.skip_uat_vra:   # not = "== false"
            logger.debug("Debut inventaire cloud UAT")
            cloud_uat_inventory_dev = CloudImpl(args.trigram, "dev", "UAT")
            cloud_uat_inventory_prd = CloudImpl(args.trigram, "prd", "UAT")
            cloud_uat_inventory_hml = CloudImpl(args.trigram, "hml", "UAT")
        if not args.skip_prod_vra:
            logger.debug("Debut inventaire cloud PROD")
            cloud_inventory_dev = CloudImpl(args.trigram, "dev", "PROD")
            cloud_inventory_prd = CloudImpl(args.trigram, "prd", "PROD")
            cloud_inventory_hml = CloudImpl(args.trigram, "hml", "PROD")
        if not args.skip_uat_vra:
            object_cloud_uat_inventory_dev = \
                cloud_uat_inventory_dev.get_cloud_inventory()
            object_cloud_uat_inventory_prd = \
                cloud_uat_inventory_prd.get_cloud_inventory()
            object_cloud_uat_inventory_hml = \
                cloud_uat_inventory_hml.get_cloud_inventory()
            if args.cloud_inventory:
                print("Inventory for UAT VRA")
                print("---------------------")
                output_cloud_inventory(object_cloud_uat_inventory_dev)
                output_cloud_inventory(object_cloud_uat_inventory_prd)
                output_cloud_inventory(object_cloud_uat_inventory_hml)
                print("")
            # //////////reload for change url UAT to PROD
            reload(cloudaw.conf)
            reload(cloudaw.resource)
            reload(cloudaw.base)
            reload(cloudaw.token)
            from cloudaw import resource, base, conf, token # no remove
            # //////////reload for change url UAT to PROD
        if not args.skip_prod_vra:
            object_cloud_inventory_dev = cloud_inventory_dev.get_cloud_inventory()
            object_cloud_inventory_prd = \
                cloud_inventory_prd.get_cloud_inventory()
            object_cloud_inventory_hml = \
                cloud_inventory_hml.get_cloud_inventory()
            if args.cloud_inventory:
                print("Inventory for PROD VRA")
                print("----------------------")
                output_cloud_inventory(object_cloud_inventory_dev)
                output_cloud_inventory(object_cloud_inventory_prd)
                output_cloud_inventory(object_cloud_inventory_hml)
                print("")
        print("Checking for inconsistencies")
        #logger.debug("object_cloud_uat_inventory_prd %r", object_cloud_uat_inventory_prd)
        #logger.debug("object_cloud_uat_inventory_dev %r", object_cloud_uat_inventory_dev)
        #logger.debug("object_cloud_uat_inventory_hml %r", object_cloud_uat_inventory_hml)
        #logger.debug("object_cloud_inventory_prd %r", object_cloud_inventory_prd)
        #logger.debug("object_cloud_inventory_dev %r", object_cloud_inventory_dev)
        #logger.debug("object_cloud_inventory_hml %r", object_cloud_inventory_hml)
        object_cloud_inventory = {}
        for (key, value) in object_cloud_uat_inventory_dev.iteritems():
            if key in object_cloud_inventory:
                object_cloud_inventory[key].append(value)
            else:
                object_cloud_inventory[key] = [ value ]
        for (key, value) in object_cloud_uat_inventory_hml.iteritems():
            if key in object_cloud_inventory:
                object_cloud_inventory[key].append(value)
            else:
                object_cloud_inventory[key] = [ value ]
        for (key, value) in object_cloud_uat_inventory_prd.iteritems():
            if key in object_cloud_inventory:
                object_cloud_inventory[key].append(value)
            else:
                object_cloud_inventory[key] = [ value ]
        for (key, value) in object_cloud_inventory_dev.iteritems():
            if key in object_cloud_inventory:
                object_cloud_inventory[key].append(value)
            else:
                object_cloud_inventory[key] = [ value ]
        for (key, value) in object_cloud_inventory_hml.iteritems():
            if key in object_cloud_inventory:
                object_cloud_inventory[key].append(value)
            else:
                object_cloud_inventory[key] = [ value ]
        for (key, value) in object_cloud_inventory_prd.iteritems():
            if key in object_cloud_inventory:
                object_cloud_inventory[key].append(value)
            else:
                object_cloud_inventory[key] = [ value ]

        logger.debug("object_cloud_inventory %r", object_cloud_inventory)
        for (hostname, val) in object_cloud_inventory.iteritems():
            if len(val) >= 2:
                print("{}: hostname exists on UAT vRA and PROD vRA" .format(hostname))

    # Inventaire DNS pour le trigramme
    DoD_inventory = DodInventoryImpl().search_DoD(
        record_type='', trigram=args.trigram, env="d")
    DoD_inventory += DodInventoryImpl().search_DoD(
        record_type='', trigram=args.trigram, env="p")
    DoD_inventory += DodInventoryImpl().search_DoD(
        record_type='', trigram=args.trigram, env="h")


    # Inventaire DNS pour chacunes des IP de l'inventaire cloud
    ip_list = [val['ip']
               for hostname in object_cloud_inventory.keys()
                   for val in object_cloud_inventory[hostname] ]
    logger.debug("size ip_list => %d", len(ip_list))

    DoD_inventory_ip = []
    start = 0
    page_size = 128
    while start <= len(ip_list):
        DoD_inventory_ip.append(DodInventoryImpl().search_DoD('ptr', ip_list[start:start+page_size]))
        start += page_size
    # print(DoD_inventory_ip)

    # Inventaire Marley pour le trigramme
    bobaw = Bobaw()
    marley_inventory = bobaw.get_infos(trigram=args.trigram)

    for (hostname, val) in object_cloud_inventory.iteritems():
        marley_record = bobaw.get_infos(hostname=hostname)
        if len(marley_record) == 0:
            print("{}: VM not registered in Marley".format(hostname))

        # Incoherences entre cloud et DNS
        for ip in val:
            errors = DodInventoryImpl().check_dns_entries(
                                hostname, ip["ip"], DoD_inventory)
            if len(errors) > 0:
                for e in errors:
                    print(e)

            ip_cloud = ip['ip']

            records_for_ip = [
                r for ptr_record in DoD_inventory_ip for r in ptr_record if r['ip'] == ip_cloud]
            for r in records_for_ip:
                if r['hostname'] != hostname:
                    print("{}: IP {} is registered for {}. id = {}".format(
                        hostname, ip_cloud, r['hostname'], r['id']))


        break

        # Verifier que la VM est creee avec le bon BG
        if re.match("^p", hostname) and not re.match(".*[-_]PRD$", val["bg"]):
            print(
                "{}: Production VM not created in production cloud"
                .format(hostname))
        if re.match("^[dh]", hostname) and re.match(".*[-_]PRD$", val["bg"]):
            print("{}: development VM created in production cloud"
                  .format(hostname))

    # Liste des serveurs du DNS pour le trigramme  non crees dans le cloud
    for record in DoD_inventory:
        if (record["type"] == "A" or record["type"] == "PTR") and\
                not object_cloud_inventory.get(record["hostname"], None):
            print("{}: hostname not created in cloud. {} id = {}".format(
                record["hostname"], record["type"], record["id"]))
        if record["type"] == "CNAME" and \
                not object_cloud_inventory.get(record["alias"], None):
            print("{}: hostname not created in cloud. CNAME id = {}"
                  .format(record["alias"], record["id"]))

    # Liste des serveurs dans Marley qui ne sont pas crees

    for marley_entry in marley_inventory:
        if not object_cloud_inventory.get(marley_entry["Hostname RET"], None):
            print("{}:VM in marley, but not in cloud. {}".format(
                marley_entry["Hostname RET"], marley_entry["Asset ID"]))


if __name__ == '__main__':
    """ This is executed when run from the command line """

    parser = argparse.ArgumentParser()

    # Required positional argument
    parser.add_argument("trigram", help="The trigram to inventory")

    # Optional verbosity counter (eg. -v, -vv, -vvv, etc.)
    parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Verbosity (-v, -vv, etc)")

    # Specify output of "--version"
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s (version {version})".format(version=__version__))

    parser.add_argument("-c", "--cloud-inventory",
                        action="store_true", dest="cloud_inventory",
                        default=False,
                        help="Output cloud inventory")
    parser.add_argument("-d", "--dns_inventory",
                        action="store_true", dest="dns_inventory",
                        default=False,
                        help="Output DNS inventory")
    parser.add_argument("--no_uat",
                        action="store_true", dest="skip_uat_vra",
                        default=False,
                        help="Skip calls to UAT VRA")
    parser.add_argument("--no_prod",
                        action="store_true", dest="skip_prod_vra",
                        default=False,
                        help="Skip calls to PROD VRA")

    args = parser.parse_args()
    main(args = args)


import logging
import io
import sys
import os
import datetime
import traceback

if "TREE_DIR" in os.environ.keys():
    ANSIBLE_MODULES_PATH = [
        os.path.join(os.environ["TREE_DIR"], 'roles/edge'),
        os.path.join(os.environ["TREE_DIR"], 'roles/cloudaw'),
        os.path.join(os.environ["TREE_DIR"], "library"),
        os.path.join(os.environ["TREE_DIR"], 'roles/py_edge_vault'),

    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/edge',
        './roles/cloudaw',
        './roles/py_edge_vault'
    ]
for path in ANSIBLE_MODULES_PATH:
    sys.path.append(path)

from ansible.module_utils.basic import AnsibleModule

import edge.interfaces
from edge.cloud_vm.vm import Vm
from cloudaw.token import Token
from edge.kpi.elk import Loader
from cloudaw.catalog import Catalog
from cloudaw.resource import Resource
from cloudaw.request import VmRequest, WorkflowRequest
from edge.conf.cloud_network import find_network_infos

formatter = logging.Formatter(fmt='%(asctime)s %(levelname)-8s %(message)s',
                              datefmt='%Y-%m-%d %H:%M:%S')
logstream = io.StringIO()
handler = logging.StreamHandler(logstream)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.addHandler(handler)
logger.setLevel(logging.WARNING)


class CloudVraImpl(edge.interfaces.CloudVra):
    def __init__(self):
        self.token = Token()
        self.resource = Resource(self.token)
        self.catalog = Catalog(self.token)
        self.vm_request = VmRequest(self.token)
        self.workflow_request = WorkflowRequest(self.token)

    def get_vra_resource_data(self, filter_sentence):
        return self.resource.get_resource_data(filter_sentence)

    def get_vra_catalog(self, filter_sentence):
        return self.catalog.get_vra_catalog(filter_sentence)

    def vra_create_vm(self, wait, machine_item, vm_config, requested_for, provider_owner, business_group):
        return self.vm_request.create(wait, machine_item, vm_config, requested_for, provider_owner, business_group)

    def vra_destroy_vm(self, wait, hostname_id, operation_id, organization):
        return self.vm_request.destroy(wait, hostname_id, operation_id, organization)

    def vra_workflow_request(self, wait, workflow_item, trigram, app_env):
        return self.workflow_request(wait, workflow_item, trigram, app_env)


class VmImpl(Vm, CloudVraImpl):
    def __init__(self, hostname):
        CloudVraImpl.__init__(self)
        Vm.__init__(self, hostname)


PRESENT, ABSENT, INFOS = 'present', 'absent', "infos"

FIELDS = {
    "app_id": {
        "type": "str"
    },
    "vm_hostname": {
        "type": "str"
    },
    "vm_desc": {
        "default": " ",
        "type": "str"
    },
    "app_env": {
        "default": "prd",
        "choices": [
            'uat',
            'tst',
            'int',
            'dev',
            'hml',
            'prd'
        ],
        "type": "str",
    },
    "vm_profile": {
        "default": "Micro 1vCPU-1GB",
        "choices": ['Micro 1vCPU-1GB', 'Small 1vCPU-2GB', 'Small-mem4 1vCPU-4GB', 'Medium-mem2 2vCPU-2GB',
                    'Medium 2vCPU-4GB', 'Medium-mem8 2vCPU-8GB', 'Medium-mem16 2vCPU-16GB', 'Medium-mem32 2vCPU-32GB',
                    'Large 4vCPU-8GB', 'Large-mem16 4vCPU-16GB', 'Large-mem32 4vCPU-32GB', 'XLarge 8vCPU-16GB',
                    'XLarge-mem32 8vCPU-32GB', 'XLarge-mem64 8vCPU-64GB', 'XLarge-mem128 8vCPU-128GB'],
        "type": "str",
    },
    "ip_address": {
        "type": "str"
    },
    "vm_subnet": {
        "type": "str"
    },
    "vm_region": {
        "default": "EU France (Greater Paris)",
        "choices": ['EU France (Greater Paris)', 'EU France (North)'],
        "type": "str",
    },
    "vm_az": {
        "default": "eu-fr-paris-1",
        "choices": ['eu-fr-paris-1', 'eu-fr-paris-2', 'eu-fr-north-1'],
        "type": "str",
    },
    "vm_os": {
        "default": "CENTOS_7.5_x64-RET-EDGE",
        "choices": [
            'RHEL_7.5_x64-RET-EDGE',
            'RHEL_7.5_x64-CLOUDCELL-RET-EDGE',
            'RHEL_7.5_x64-WEBCELL-RET-EDGE',
            'RHEL_7.5_x64-WEBCELL-BAD-EDGE',
            'RHEL_7.5_x64-TRANSVERSE-RCR',
            'CENTOS_7.5_x64-RET-EDGE',
            'CENTOS_7.5_x64-CLOUDCELL-RET-EDGE',
            'CENTOS_7.5_x64-WEBCELL-RET-EDGE',
            'CENTOS_7.5_x64-WEBCELL-BAD-EDGE',
            'CENTOS_7.5_x64-TRANSVERSE-RCR'
        ],
        "type": "str",
    },
    "data_disk": {
        "default": 0,
        "type": "int",
        "choices": [0, 20, 60, 160, 300, 500, 750, 1000, 2000],
    },
    "vm_replication": {
        "default": False,
        "type": "bool",
    },

    "vm_backup": {
        "default": "none",
        "choices": ['none', 'daily-31d-2AM', 'daily-31d-4AM'],
        "type": "str",
    },
    "extended_infos": {
        "default": False,
        "type": "bool",
    },
    "state": {
        "default": PRESENT,
        "choices": [PRESENT, ABSENT, INFOS],
        "type": "str",
    },
    "kpi_data": {
        "type": "dict"
    }
}

REQUIRED_FIELDS = [
    ["state", PRESENT, ["app_id", "vm_hostname", "ip_address", "vm_subnet"]],
    ["state", ABSENT, ["vm_hostname"]],
    ["state", INFOS, ["vm_hostname"]]
]

INFOS_FIELDS = {
    'resourceData': {'MachineName': 'vm_hostname',
                     'MachineCPU': 'vm_cpu',
                     'MachineMemory': 'vm_memory',
                     'ip_address': 'ip_address',
                     'MachineGroupName': 'vm_bg',
                     'MachineBlueprintName': 'vm_os',
                     'MachineStatus': 'vm_status',
                     },
    'extended': {'provider-AvailabilityZone': 'vm_az',
                 'provider-Region': 'vm_region',
                 'provider-Description': 'vm_desc',
                 'provider-Subnet': 'vm_subnet',
                 'provider-Replication': 'vm_replication',
                 'provider-Backup': 'vm_backup',
                 'provider-Environment': 'vm_env'
                 }
}

REGIONS_MAP = {"eu-fr-paris": "EU France (Greater Paris)",
               "eu-fr-north": "EU France (North)"
               }

PROFILES_MAP = {
    "1": {"1024": "Micro 1vCPU-1GB", "2048": "Small 1vCPU-2GB", "4096": "Small-mem4 1vCPU-4GB"},
    "2": {"2048": "Medium-mem2 2vCPU-2GB", "4096": "Medium 2vCPU-4GB", "8192": "Medium-mem8 2vCPU-8GB",
          "16384": "Medium-mem16 2vCPU-16GB", "32768": "Medium-mem32 2vCPU-32GB"},
    "4": {"8192": "Large 4vCPU-8GB", "16384": "Large-mem16 4vCPU-16GB", "32768": "Large-mem32 4vCPU-32GB"},
    "8": {"16384": "XLarge 8vCPU-16GB", "32768": "XLarge-mem32 8vCPU-32GB",
          "65536": "XLarge-mem64 8vCPU-64GB", "131072": "XLarge-mem128 8vCPU-128GB"}
}

BACKUP_MAP = {
    "Daily | 31d retention | 02h00 AM": "daily-31d-2AM",
    "Daily | 31d retention | 04h00 AM": "daily-31d-4AM"
}

def index_error_kpi(kpi_data, kpi_start_time):
    try:
        kpi_end_time = datetime.datetime.now()
        kpi_data['duration'] = (kpi_end_time - kpi_start_time).seconds
        loader = Loader()
        loader.index_data(
            id_execution=kpi_data['id_execution'], timestamp=kpi_data['timestamp'],
            duration=kpi_data['duration'], service=kpi_data['service'],
            hostname=kpi_data['vm_hostname'], status="failure",
            category=kpi_data['category'], client=kpi_data['endClient'],
            trigram=kpi_data['app_id'], environment=kpi_data['app_env'],
            error=kpi_data['error'], playbook_version=kpi_data['playbook_version']
        )
    except Exception:
        pass


def get_disk_size(json_infos, disk_id):
    disk_infos = [disk for disk in json_infos['resourceData']['entries'] if disk['key'] == "DISK_VOLUMES"]

    for disk_vol in disk_infos:
        for disk in disk_vol['value']['items']:
            if disk['values']['entries'][0]['key'] == "DISK_INPUT_ID" and \
                            disk['values']['entries'][0]['value']['value'] == disk_id:
                if disk['values']['entries'][1]['key'] == "DISK_CAPACITY":
                    return disk['values']['entries'][1]['value']['value']

    return 0


def main():
    module = AnsibleModule(argument_spec=FIELDS, required_if=REQUIRED_FIELDS)
    if module._verbosity == 1:
        logger.setLevel(logging.INFO)
    if module._verbosity == 3:
        logger.setLevel(logging.DEBUG)
    logger.info('module sg_gts_cloud_vm2 called')
    kpi_data = module.params['kpi_data']

    kpi_start_time = datetime.datetime.now()

    try:
        state = module.params['state']
        if isinstance(kpi_data, dict):
            kpi_data['service'] = 'sg_gts_cloud_{}'.format(state)
        vm = VmImpl(module.params['vm_hostname'])
        if state == PRESENT:
            response = vm.create(
                vm_os=module.params['vm_os'],
                trigram=module.params['app_id'],
                app_env=module.params['app_env'],
                vm_profile=module.params['vm_profile'],
                data_disk=module.params['data_disk'],
                vm_desc=module.params['vm_desc'],
                ip_address=module.params['ip_address'],
                vm_region=module.params['vm_region'],
                vm_az=module.params['vm_az'],
                vm_subnet=module.params['vm_subnet'],
                vm_replication=module.params['vm_replication'],
                vm_backup=module.params['vm_backup']
            )
            module.exit_json(changed=vm.has_changed, meta=response, debug_out=logstream.getvalue())
        elif state == ABSENT:
            response = vm.destroy()
            # ajout boucle sur vm.hostname_data
            # raise Exception si attente max atteinte
            module.exit_json(changed=vm.has_changed, meta=response, debug_out=logstream.getvalue())
        elif state == INFOS:
            output = {}
            response = vm.get_infos(refresh=True, extended=module.params['extended_infos'])

            for subkey in INFOS_FIELDS:
                for key in INFOS_FIELDS[subkey].values():
                    output[key] = 'N/A'

            if response:
                for subkey in INFOS_FIELDS:
                    if response.get(subkey, None) and response[subkey]['entries']:
                        for entry in response[subkey]['entries']:
                            if entry['key'] in INFOS_FIELDS[subkey]:
                                output[INFOS_FIELDS[subkey][entry['key']]] = entry['value']["value"]
            else:
                module.exit_json(changed=vm.has_changed, meta=output, debug_out=logstream.getvalue())

            if str(output["vm_cpu"]) in PROFILES_MAP and \
                            str(output["vm_memory"]) in PROFILES_MAP[str(output["vm_cpu"])]:
                output['vm_profile'] = PROFILES_MAP[str(output["vm_cpu"])][str(output["vm_memory"])]

            if output['vm_backup'] in BACKUP_MAP:
                output['vm_backup'] = BACKUP_MAP[output['vm_backup']]

            output["data_disk"] = get_disk_size(json_infos=response, disk_id="DISK_INPUT_ID2")

            if output['ip_address'] != 'N/A':
                try:
                    if output['vm_region'] in REGIONS_MAP:
                        output['vm_region'] = REGIONS_MAP[output['vm_region']]
                    if output['vm_az'] == "N/A":
                        env, region_cloud, az_cloud, network_id, network_cidr, dns_zone, dns_cname = find_network_infos(
                            output['ip_address'])
                        output['vm_az'] = az_cloud
                        output['vm_region'] = region_cloud
                    else:
                        env, region_cloud, az_cloud, network_id, network_cidr, dns_zone, dns_cname = find_network_infos(
                            output['ip_address'], vm_region=output['vm_region'], vm_az=output['vm_az'])
                    output['vm_network'] = network_id
                    output['vm_subnet'] = network_cidr
                    output['vm_zone'] = dns_zone
                    output['dns_publish'] = dns_cname
                except:
                    pass

            module.exit_json(changed=vm.has_changed, meta=output, debug_out=logstream.getvalue())
    except Exception as e:
        if isinstance(kpi_data, dict):
            kpi_data['error'] = e.args[0]
            index_error_kpi(kpi_data, kpi_start_time)
        if module._verbosity == 3:
            module.fail_json(msg=e.args[0], exception=traceback.format_exc())
        module.fail_json(msg=e.args[0], debug_out=logstream.getvalue())
    finally:
        try:
            vm.token.delete()
        except NameError:
            pass


if __name__ == '__main__':
    main()

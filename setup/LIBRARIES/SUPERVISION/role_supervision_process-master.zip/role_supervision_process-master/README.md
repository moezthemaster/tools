Role Role_supervision_process
=========

Monitor a process using the Patrol Agent or Zabbix Agent.

This role is an applicative monitoring role.

If no action is specified when calling this role, it will execute the following action :

**create.yml** : Configuring Patrol Agent or Zabbix Agent to monitore the process.

Here's a description of the other task that can be executed in this role, filling the *patrol_action* with the name of the task requested :

**delete.yml** : Removing the process monitoring from Patrol Agent or Zabbix Agent.

* Removing process monitoring from Patrol agent or Zabbix agent.

This role is developped for **FastIT & PAAP projects**. Some updates may have to be done for other needs : contact us :email: List.FR-Admin-Monitoring-L3@socgen.com, or Fork it.

Requirements
------------

Facts gathering shouldn't be disabled.

Target servers must be Linux.

Patrol Agent or Zabbix Agent should be installed and add to the monitoring infra.


Role Variables
--------------

Here are the requested values for each action :

**create.yml**

- `pat_label : label of the process (ie. apache_domaineSPV)`
- `pat_min : minimum number of the process`
- `pat_max : maximum number of the process`
- `pat_owner : owner of the process`
- `pat_cmd : command line to match (ie DdomaineSPV)`
- `pat_severity in 'warning' or 'critical' for patrol and 'high' for zabbix`

Nota Bene:

In case of Zabbix, pat_label is used to identify the process which will be supervised. Zabbix uses /proc/<pid>/status in order to count lines that contains pat_label (process name).
But, the process name in status file is truncated to 15 characters. Because of this limit and also if the length of pat_label is more than 15, it is recommended to provide pat_cmd (command line that is used to run your process) in order to find the process.
Having failed to match the process name from status file the Zabbix agent turns to /proc/<pid>/cmdline file.

pat_cmd is also used to identify specific process in a set of process with the same pat_label name.

Eg: In case of you have multiple instances of httpd launched by different commands, you can specify via pat_cmd which process you want to supervise.

For more informations : https://www.zabbix.com/documentation/3.4/manual/appendix/items/proc_mem_num_notes

**delete.yml**

- `pat_label : label of the process (ie. apache_domaineSPV)`

Dependencies
------------

None

Example Playbook
----------------


      - hosts: server_to_monitor
        gather_facts: yes
        roles:     
           - { role: role_supervision_process,
                   patrol_action: "create",
                   pat_label: "apache_domaineSPV",
                   pat_min: "1",
                   pat_max: "2",
                   pat_owner: "patrol",
                   pat_cmd: "DdomaineSPV",
                   pat_severity: "warning"
              }


Generated Alarms
----------------


    host      |objectClass    |object       |parameter    |parameterValue     |message
    *         |PROCPRES       |*            |PROCPPCount  |*                  |There is %mc_parameter_value% process %mc_object%

Troubleshooting
---------------

In case of troubleshooting or for more information, you contact the Feature Team EDGE :email: list.fr-ret-edge-automation@socgen.com


Author Information
------------------

Yanis BEKRAR

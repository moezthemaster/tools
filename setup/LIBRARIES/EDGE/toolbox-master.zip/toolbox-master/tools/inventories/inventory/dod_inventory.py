import os
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from logzero import logger

dirname = os.path.dirname(os.path.realpath(__file__))
if not dirname:
    FILE_EXPORT = os.path.join('conf', 'settings_prod.cfg')
else:
    FILE_EXPORT = os.path.join(dirname, 'conf', 'settings_prod.cfg')
os.environ["DODAW_CONFIG_FILE"] = FILE_EXPORT
os.environ["EDGE_CONFIG_FILE"] = FILE_EXPORT
os.environ["VAULT_CONFIG_FILE"] = FILE_EXPORT

from dodaw.dod import DodWrapper
from edge.interfaces import Dod
from edge.inventory.dod_inventory import Extractor as ExtractorDod


class DodImpl(Dod):
    def __init__(self):
        self.dod_wrapper = DodWrapper()
        requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
        # logging.captureWarnings(True)

    def search_dns_record(self, record_type="", **kwargs):
        return self.dod_wrapper.search_record(record_type, **kwargs)


class DodInventoryImpl(ExtractorDod, DodImpl):
    def __init__(self):
        DodImpl.__init__(self)
        ExtractorDod.__init__(self)
        requests.packages.urllib3.disable_warnings(InsecureRequestWarning)


class DodInventory(DodInventoryImpl):
    def __init__(self):
        super(DodInventory, self).__init__()
        self._inventory = {}
        self._reverse = {}

    def is_absent(self, entry):
        shortname=entry['hostname'].split('.')[0]
        if shortname in self._inventory:
            for e in self._inventory[shortname]:
                if e['id'] == entry['id']:
                    return False
        return True


    def is_absent_reverse(self, entry):
        if entry['ip'] in self._reverse:
            for e in self._reverse[entry['ip']]:
                if e['id'] == entry['id']:
                    return False
        return True


    def add_infos(self, inv):
        for entry in inv:
            if entry['type'] != 'CNAME' and entry['hostname'] is not None:
                shortname=entry['hostname'].split('.')[0]
                if shortname in self._inventory:
                    if self.is_absent(entry):
                        self._inventory[shortname].append(entry)
                else:
                    self._inventory[shortname] = [entry]
            if entry['type'] == 'CNAME' and entry['alias'] is not None:
                if entry['alias'] in self._inventory:
                    if self.is_absent(entry):
                        self._inventory[entry['alias']].append(entry)
                else:
                    self._inventory[entry['alias']] = [entry]
            if 'ip' in entry and entry['ip'] is not None:
                if entry['ip'] in self._reverse:
                    if self.is_absent_reverse(entry):
                        self._reverse[entry['ip']].append(entry)
                else:
                    self._reverse[entry['ip']] = [entry]

    def search(self, trigram):
        self.add_infos(super(DodInventory, self).search_DoD(
            record_type='', trigram=trigram, env='d'))
        self.add_infos(super(DodInventory, self).search_DoD(
            record_type='', trigram=trigram, env='h'))
        self.add_infos(super(DodInventory, self).search_DoD(
            record_type='', trigram=trigram, env='p'))

    def search_from_vra(self, vra_inventory):
        ip_list = [val['ip']
                   for hostname in vra_inventory._inventory.keys()
                   for val in vra_inventory._inventory[hostname]]

        start = 0
        page_size = 128
        while start <= len(ip_list):
            records_page = super(DodInventory, self).search_DoD(
                record_type='PTR', ip_list=ip_list[start:start + page_size])
            for rec in records_page:
                self.add_infos(rec)
            records_page = super(DodInventory, self).search_DoD(
                record_type='A', ip_list=ip_list[start:start + page_size])
            for rec in records_page:
                self.add_infos(rec)
            start += page_size


    def check_status(self, status_inventory):
        logger.debug("check status")
        for (hostname, entries) in self._inventory.iteritems():
            status_host = status_inventory.check_status(hostname)
            for entry in entries:
                if entry['type'] == 'A' or entry['type'] == 'PTR':
                    status_ip = status_inventory.check_status(entry["ip"])
                    entry['status_host'] = status_host
                    entry['status_ip'] = status_ip

        for (hostname, entries) in self._reverse.iteritems():
            status_ip = status_inventory.check_status(hostname)
            for entry in entries:
                status_host = status_inventory.check_status(entry["hostname"])
                entry['status_host'] = status_host
                entry['status_ip'] = status_ip

    def output(self):
        for (key, entries) in sorted(self._inventory.iteritems()):
            for entry in entries:
                if  entry['type'] != 'CNAME' and 'status_host' in entry:
                    print("{} : {}:{}:{}:{}:{}:{}:{}".format(key,
                                                      entry['ip'],
                                                      entry['zone'],
                                                      entry['type'],
                                                      entry['id'],
                                                      entry['alias'],
                                                      entry['hostname_fqdn'],
                                                      entry['status_host']['alive']))
                else:
                    print("{} : {}:{}:{}:{}:{}:{}".format(key,
                                                      entry['ip'],
                                                      entry['zone'],
                                                      entry['type'],
                                                      entry['id'],
                                                      entry['alias'],
                                                      entry['hostname_fqdn']))

        for (key, entries) in sorted(self._reverse.iteritems()):
            for entry in entries:
                print("{} : {}:{}:{}:{}:{}:{}:{}".format(key,
                                                      entry['hostname'],
                                                      entry['zone'],
                                                      entry['type'],
                                                      entry['id'],
                                                      entry['alias'],
                                                      entry['hostname_fqdn'],
                                                      entry['status_ip']['alive']))


    def check_ghost_records(self, vra_inventory):
        logger.debug("check Ghost records in DNS")
        # Record in DNS, but no VM in cloud
        for (key, entries) in sorted(self._inventory.iteritems()):
            shortname=key.split('.')[0]
            if shortname not in vra_inventory._inventory:
                ghost_ids = []
                for entry in entries:
                    if entry['type'] != 'CNAME' and entry['status_ip']['alive'] != 'Alive':
                        ghost_ids.append(entry['id'])
                if len(ghost_ids) > 0:
                    for entry in entries:
                        if entry['type'] == 'CNAME':
                            ghost_ids.append(entry['id'])
                    print("{}:DNS:Ghost entries:{}".format(
                        key, ",".join(ghost_ids)))

    def check_incorrect_records(self, vra_inventory):
        logger.debug("check incorrect records in DNS")
        for (key, entries) in sorted(vra_inventory._inventory.iteritems()):
            if key not in self._inventory:
                print("{}:DNS:Missing all records".format(key))
            else:
                records_A = [
                    dns_record for dns_record in self._inventory[key] if dns_record['type'] == 'A']
                if len(records_A) == 0:
                    print("{}:DNS:Missing A record".format(key))
                elif len(records_A) > 1:
                    A_ids = [entry['id'] for entry in records_A]
                    print("{}:DNS:Too many A records:{}".format(key, A_ids))
                elif records_A[0]['ip'] != entries[0]['ip']:
                    print("{}:DNS:Wrong ip in A record:{}:{}:{}"
                          .format(key,
                                  records_A[0]['id'],
                                  records_A[0]['ip'],
                                  entries[0]['ip']))

                records_PTR = [
                    dns_record for dns_record in self._inventory[key] if dns_record['type'] == 'PTR']
                if len(records_PTR) == 0:
                    print("{}:DNS:Missing PTR record".format(key))
                elif len(records_PTR) > 1:
                    PTR_ids = [entry['id'] for entry in records_PTR]
                    print("{}:DNS:Too many PTR records:{}".format(key, PTR_ids))
                elif records_PTR[0]['ip'] != entries[0]['ip']:
                    print("{}:DNS:Wrong ip in PTR record:{}:{}:{}"
                          .format(key,
                                  records_PTR[0]['id'],
                                  records_PTR[0]['ip'],
                                  entries[0]['ip']))

                records_CNAME = [
                    dns_record for dns_record in self._inventory[key] if dns_record['type'] == 'CNAME']
                if len(records_CNAME) == 0:
                    print("{}:DNS:Missing CNAME record".format(key))
                elif len(records_A) == 1:
                    for cname in records_CNAME:
                        if cname['hostname'] != records_A[0]['hostname_fqdn']:
                            print("{}:DNS:Wrong zone in CNAME:{}:{}".format(
                                key,
                                cname['hostname'],
                                records_A[0]['hostname_fqdn']))

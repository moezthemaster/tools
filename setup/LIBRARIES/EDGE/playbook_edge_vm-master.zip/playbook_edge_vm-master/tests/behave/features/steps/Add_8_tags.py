#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
import ansible_play 


@when('Add 8 tags')
def step_impl(context):

  become_user_password = 'foo-whatever'
  run_data = {
    'state': 'present',
    'hostname': context.params['vm_hostname'],
    'tags_list': context.params['tag_list']
  }

  runner = ansible_play.Runner(
    hostnames='localhost',
    playbook='roles/role_tags_vm/tasks/main.yml',
    private_key_file=params.private_key,  
    run_data=run_data,
    become_pass=become_user_password,
    verbosity=100
  )

  stats = runner.run()

  print("Debug")
  run_success = True
  hosts = sorted(stats.processed.keys())
  for h in hosts:
      t = stats.summarize(h)
      print("{} => {}".format(h, t))
      if t['unreachable'] > 0 or t['failures'] > 0:
          run_success = False


  assert run_success is True
 

# the inclusion of the tests module is not meant to offer best practices for
# testing in general, but rather to support the `find_packages` example in
# setup.py that excludes installing the "tests" package

from {{ cookiecutter.project_slug }}.{{ cookiecutter.project_slug }} import PoliteClass


def test_hello_phrase():
    username = 'john'
    expected = 'Hello john'
    assert PoliteClass.hello_phrase(username) == expected

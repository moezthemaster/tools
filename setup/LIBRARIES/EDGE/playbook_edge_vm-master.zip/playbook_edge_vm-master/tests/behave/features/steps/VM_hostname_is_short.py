#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
import testinfra


@then('Hostname is short')
def step_impl(context):
    print("Test VM hostname is short\n")

    server = testinfra.get_host('ssh://automation@' + context.params['vm_ipaddr'])
    #server = testinfra.get_host('ssh://automation@' + '192.88.65.34')

    command_short_hostname = server.run('hostname -s')
    command_hostname = server.run('hostname')

    if command_short_hostname.stdout.strip() == command_hostname.stdout.strip():

        assert context.failed is False
    else:
        assert context.failed is True

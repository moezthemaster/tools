#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
from time import sleep
import testinfra


@then('zabbix is installed')
def step_impl(context):
    if context.params['vm_supervision'] == 'none':
        print("Skipping Zabbix check as no supervision has been set\n")
        return

    print("Test user walle is created and Zabbix Agent is well installed\n")

    server = testinfra.get_host('ssh://automation@' + context.params['vm_ipaddr'])

    # Test if /etc/zabbix/zabbix_agentd.conf is present
    test = server.file('/etc/zabbix/zabbix_agentd.conf').exists

    if test:
        assert context.failed is False
    else:
        assert context.failed is True

    # Test if user zabbix is created
    user = server.user('walle').exists

    if user:
        assert context.failed is False
    else:
        assert context.failed

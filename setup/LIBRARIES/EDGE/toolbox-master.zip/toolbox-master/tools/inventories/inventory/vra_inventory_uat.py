import os
from logzero import logger

dirname = os.path.dirname(os.path.realpath(__file__))
if not dirname:
    FILE_EXPORT = os.path.join('conf', 'settings_uat.cfg')
else:
    FILE_EXPORT = os.path.join(dirname, 'conf', 'settings_uat.cfg')
os.environ["CLOUDAW_CONFIG_FILE"] = FILE_EXPORT
os.environ["EDGE_CONFIG_FILE"] = FILE_EXPORT

import cloudaw
from cloudaw.resource import Resource
from cloudaw.token import Token
from edge.interfaces import CloudVra
from edge.inventory.cloud_vra_inventory import Extractor as ExtractorCloud

class CloudVraImpl(CloudVra):
    def __init__(self):
        logger.debug("__init__")
        try:
            self.token = Token()
            self.resource = Resource(self.token)
        except cloudaw.exception.CloudError:
            logger.warning("UAT VRa not responding, skipping inventory", trigram)
            self.token = None

    def get_vra_resource_data(self):
        logger.debug("get_vra_resource")
        return self.resource.get_resource_data(self._sentence_filter)


class CloudImpl(ExtractorCloud, CloudVraImpl):
    def __init__(self, trigram, env, api_env):
        logger.debug("__init__ %s %s %s", trigram, env, api_env)
        ExtractorCloud.__init__(self, trigram, env, api_env)
        CloudVraImpl.__init__(self)


class VRAInventory(object):
    def __init__(self, trigram):
        logger.debug("__init__ %s", trigram)
        self._inventory = {}
        self._extractor_prod = CloudImpl(trigram, "prd", "UAT")
        if self._extractor_prod.token is None:
            self.token = None
            return
        self.token = self._extractor_prod.token
        self._extractor_hml = CloudImpl(trigram, "hml", "UAT")
        self._extractor_dev = CloudImpl(trigram, "dev", "UAT")

    def get_infos(self):
        logger.debug("get infos")
        if self.token is None:
            return None
        os.environ["CLOUDAW_CONFIG_FILE"] = FILE_EXPORT
        os.environ["EDGE_CONFIG_FILE"] = FILE_EXPORT
        reload(cloudaw.conf)
        reload(cloudaw.resource)
        reload(cloudaw.base)
        reload(cloudaw.token)
        from cloudaw import resource, base, conf, token # no remove
        inv = self._extractor_prod.get_cloud_inventory()
        inv.update(self._extractor_hml.get_cloud_inventory())
        inv.update(self._extractor_dev.get_cloud_inventory())
        return inv

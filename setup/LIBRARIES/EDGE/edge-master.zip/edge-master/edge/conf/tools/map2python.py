#!/usr/bin/python
# -*- coding: utf-8 -*-

#

''' Module to recreate network mapping from python file.'''

from __future__ import print_function
import argparse
import autopep8
import json

MAPPING = {}

FILE_HEADER = """
#!/usr/bin/python
# -*- coding: utf-8 -*-
#

'''
Mapping automatically generated with edge tools. Do not edit manually
'''

# keys: network_index, env, region_cloud, zone_cloud, network_id
"""

def add_to_mapping(env, region, az, network, **kwargs):
    if env not in MAPPING:
        MAPPING[env] = {}
    if region not in MAPPING[env]:
        MAPPING[env][region] = {}
    if az not in MAPPING[env][region]:
        MAPPING[env][region][az] = {}
    if network not in MAPPING[env][region][az]:
        MAPPING[env][region][az][network] = {}

    for key, val in kwargs.iteritems():
        #print("'{} => {}'".format(key, val))
        if val != '':
            if key == 'bp_names':
                #print("'{} => {}'".format(key, val))
                MAPPING[env][region][az][network][key] = json.loads(val)
            else:
                MAPPING[env][region][az][network][key] = val

def parse_networks(filename):
    with open(filename) as fid:
        headers = map(str.strip, fid.readline().split(';'))
        for line in fid:
            network = map(str.strip, line.split(';'))
            values = dict(zip(headers[4:],network[4:]))
            add_to_mapping(env=network[0], region=network[1],
                           az=network[2], network=network[3],
                           **values)

def main(args):
    ''' Main function for map2python.'''

    if args.csv_file:
        parse_networks(args.csv_file)
        output = "{}\nMAPPING = {}".format(FILE_HEADER, MAPPING)
        output_pep8 = autopep8.fix_code(output, options={'aggressive': 4})

        print(output_pep8)


if __name__ == '__main__':
    """ This is executed when run from the command line """

    parser = argparse.ArgumentParser()

    # Required positional argument
    parser.add_argument("csv_file", help="A file containing the network list")

    args = parser.parse_args()
    main(args = args)


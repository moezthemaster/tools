#!/usr/bin/python
# -*- coding: utf-8 -*-

import re
import time
import struct
import socket
import logging

from edge.interfaces import DodV1

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

REGEX_IP = r"^\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b$"



class SearchResultObj:

    class _InfosObj:
        def __init__(self):
            self.ip = None
            self.hostname = None
            self.domain = None
            # not relevant
            self.reverse = "reverse"
            self.map_filename = "map_filename"

    def __init__(self):
        self.ip = None
        self.infos = self._InfosObj()


def get_all_ip(subnet):
    """
    get all ip address for subnet
    eg:
    192.168.56.0/24 => yield 192.168.56.1 -> 192.168.56.254
    """
    (ip, cidr) = subnet.split("/")
    cidr = int(cidr)
    host_bits = 32 - cidr
    i = struct.unpack(">I", socket.inet_aton(ip))[0]
    start = (i >> host_bits) << host_bits
    end = i | ((1 << host_bits) - 1)
    for i in range(start, end):
        ip = socket.inet_ntoa(struct.pack(">I", i))
        if ip.endswith(".0") or ip.endswith(".255"):
            continue
        yield socket.inet_ntoa(struct.pack(">I", i))


class MockDod(DodV1):
    """
        dns'records of hosts
        {
            "A": {
                "hostname1": "IP1",
                "hostname2": "IP2"
            },
            "PTR": {
                "IP1": "hostname1",
                "IP2": "hostname2"
            }
        }
    """

    _shared_database_dodv1 = {
        "A": dict(),
        "PTR": dict()
    }
    _LIST_NETWORK_SUBNET_DODV1 = set()
    _LIST_IP_RECORDED_DODV1 = set()
    _LIST_FQDN_RECORDED_DODV1 = set()

    def __init__(self, share_database=False, shared_database=None):
        if isinstance(shared_database, dict):
            self._share_database_dodv1 = True
            self.dns_database_dodv1 = shared_database
            self.LIST_IP_RECORDED_DODV1 = self._LIST_IP_RECORDED_DODV1
            self.LIST_NETWORK_SUBNET_DODV1 = self._LIST_NETWORK_SUBNET_DODV1
            self.LIST_FQDN_RECORDED_DODV1 = self._LIST_FQDN_RECORDED_DODV1
        else:
            if share_database:
                self._share_database_dodv1 = True
                self.dns_database_dodv1 = self._shared_database_dodv1
                self.LIST_IP_RECORDED_DODV1 = self._LIST_IP_RECORDED_DODV1
                self.LIST_NETWORK_SUBNET_DODV1 = self._LIST_NETWORK_SUBNET_DODV1
                self.LIST_FQDN_RECORDED_DODV1 = self._LIST_FQDN_RECORDED_DODV1
            else:
                self.dns_database_dodv1 = {
                    "A": dict(),
                    "PTR": dict()
                }
                self.LIST_IP_RECORDED_DODV1 = set()
                self.LIST_NETWORK_SUBNET_DODV1 = set()
                self.LIST_FQDN_RECORDED_DODV1 = set()
        self.feed_dns_records()

    def feed_dns_records(self):
        for ip in get_all_ip("192.160.72.0/21"):
            self.LIST_IP_RECORDED_DODV1.add(ip)
            self.dns_database_dodv1["A"]["dtrvhost{}".format(ip.replace(".", ""))] = ip

    def get_next_free_ip(self, subnet, subnetUse="srv"):
        self.LIST_NETWORK_SUBNET_DODV1.add(subnet)
        for ip in get_all_ip(subnet):
            if ip not in self.LIST_IP_RECORDED_DODV1:
                return ip
        raise Exception("ip not found within subnet={}".format(subnet))

    def host_add(self, hostname, domain, subnet, ipRange="srv",
            inA=True, inPTR=True, ip="", ttl="", force=False
        ):
        fqdn = hostname
        logger.debug('Trying to add host={h}'.format(h=hostname))
        if ip == "":
            ip = self.get_next_free_ip(subnet, subnetUse=ipRange)
        time.sleep(1.5)
        if ip in self.LIST_IP_RECORDED_DODV1:
            raise Exception("The Ip (%s) already exists" % ip)
        if fqdn in self.LIST_FQDN_RECORDED_DODV1:
            raise Exception("The Hostname (%s) already exists" % hostname)
        if re.match(REGEX_IP, ip):
            self.LIST_IP_RECORDED_DODV1.add(ip)
            self.LIST_FQDN_RECORDED_DODV1.add(fqdn)
            if inA:
                self.dns_database_dodv1["A"][fqdn] = ip
            if inPTR:
                self.dns_database_dodv1["PTR"][ip] = fqdn
            return True
        return False

    def host_update(self, hostname, ip, domain, newHostname="",
            newIp="", newDomain="", newTTL="", force=False
        ):
        search = self.host_search_infos(hostname)
        if search:
            self.host_delete(hostname, domain)
            self.host_add(
                newHostname,
                domain,
                "",
                ip=search[0].ip,
            )
            return True
        return False

    def host_search_infos(self, pattern):
        results = []
        for (hostname, ip) in self.dns_database_dodv1['A'].items():
            if pattern == hostname:
                host_infos = SearchResultObj()
                host_infos.ip = ip
                host_infos.infos.ip = ip
                host_infos.infos.hostname = hostname
                host_infos.infos.domain = "fr.world.socgen"
                # not relevant
                host_infos.infos.reverse = "reverse"
                host_infos.infos.map_filename = "map_filename"
                results.append(host_infos)
        return results

    def host_delete(self, hostname, domain, ip="", inA=True, inPTR=True):
        try:
            ip = self.dns_database_dodv1["A"].pop(hostname)
            del self.dns_database_dodv1["PTR"][ip]
            self.LIST_IP_RECORDED_DODV1.remove(ip)
            self.LIST_FQDN_RECORDED_DODV1.remove(hostname)
        except KeyError:
            pass
        return True

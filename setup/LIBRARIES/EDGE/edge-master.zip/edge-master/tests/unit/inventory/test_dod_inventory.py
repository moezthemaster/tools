#!/usr/bin/python
# -*- coding: utf-8 -*-
#
import pytest

from edge.inventory.dod_inventory import Extractor
from tests.mock.mock import MockDod

HOSTNAME = 'dpgalx200'
record_type = 'A'
# ip_list = ['111.80.12.{}'.format(ip_last_bit)
#            for ip_last_bit in range(0, 1000)]
ip_list = ['111.80.16.2', '111.80.16.1', '111.80.16.3']


class MockedExtractor(Extractor, MockDod):
    def __init__(self):
        MockDod.__init__(self, ('A', 'PTR', 'CNAME'), HOSTNAME)


class TestDodInventory(object):
    def test_get_DoD_inventory_for_trigram(self):
        extractor = MockedExtractor()
        result = extractor.search_DoD(
            record_type, trigram="pga", env="d")
        print(result)
        assert HOSTNAME in result[0]['hostname']

    # TO DO, never work
    # def test_get_DoD_inventory_for_ip(self):
    #     extractor = MockedExtractor()
    #     result1 = extractor.search_DoD(record_type, ip_list)
    #     assert '111.80.16.1' in result1[0]['ip']
    #     assert result1 is not False

#!/usr/bin/python
# -*- coding: utf-8 -*-

#

DOCUMENTATION = '''
---
'''

EXAMPLES = '''
'''
    
from dodaw.conf import settings
from py_edge_vault import secrets

def get_user_pwd(context):
    vault_secret = secrets.get_secrets(context=context, env=settings.ENV)
    username = vault_secret['username']
    password = vault_secret['password']
    return username, password
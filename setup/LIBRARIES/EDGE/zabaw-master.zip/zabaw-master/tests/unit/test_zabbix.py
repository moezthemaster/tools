import json
import requests
import pytest
import unittest

try:
    from unittest import mock
except ImportError:
    import mock
from py_edge_vault import secrets
from requests.models import Response
from tests.mock.zabbix import mock_vault, mock_token, mock_request, MockedzbxApi

LOGIN_METHOD = 'user.login'
GET_HOST_ID_METHOD = 'host.get'
GET_TEMPLATE_ID_METHOD = 'template.get'
LINK_HOST_METHOD = 'host.massadd'
UNLINK_HOST_METHOD = 'host.massremove'
DELETE_HOST_METHOD = 'host.delete'
CREATE_USER_MACRO_METHOD = 'usermacro.create'
UPDATE_USER_MACRO_METHOD = 'usermacro.update'
GET_USER_MACRO_METHOD = 'usermacro.get'
DELETE_USER_MACRO_METHOD = 'usermacro.delete'
GET_HOST_GROUP_METHOD = 'hostgroup.get'
INSERT_IN_HOST_GROUP_METHOD = 'hostgroup.massadd'
REMOVE_FROM_HOST_GROUP_METHOD = 'hostgroup.massremove'

HOSTNAME = "dpgalxunit001"
ZABBIX_URL = "url.socgen.test"


@mock.patch('py_edge_vault.secrets.get_secrets')
class TestZbxApi(unittest.TestCase):

    @mock.patch('requests.post')
    def test_get_template_id(self, mock_post, mock_creds):
        mock_creds.return_value = mock_vault()
        mock_post.return_value = mock_request(GET_TEMPLATE_ID_METHOD)
        mock_token.return_value = mock_token()
        zbx = MockedzbxApi(zbx_url=ZABBIX_URL, zbx_user=mock_creds.return_value['username'],
                           zbx_password=mock_creds.return_value['password'])
        r = zbx.zbxGetTemplateId('EDGE_TEMPLATE')
        assert r == str(10001)

    @mock.patch('requests.post')
    def test_link_host_to_template(self, mock_post, mock_creds):
        mock_creds.return_value = mock_vault()
        mock_post.return_value = mock_request(LINK_HOST_METHOD)
        mock_token.return_value = mock_token()
        zbx = MockedzbxApi(zbx_url=ZABBIX_URL, zbx_user=mock_creds.return_value['username'],
                           zbx_password=mock_creds.return_value['password'])
        r = zbx.zbxLinkHostToTemplate(zbxHosId=1, zbxTemplateId=10001)
        assert r['hostids'][0] == str(10160)

    @mock.patch('requests.post')
    def test_unlink_host_to_template(self, mock_post, mock_creds):
        mock_creds.return_value = mock_vault()
        mock_post.return_value = mock_request(UNLINK_HOST_METHOD)
        mock_token.return_value = mock_token()
        zbx = MockedzbxApi(zbx_url=ZABBIX_URL, zbx_user=mock_creds.return_value['username'],
                           zbx_password=mock_creds.return_value['password'])
        r = zbx.zbxLinkHostToTemplate(zbxHosId=1, zbxTemplateId=10001)
        assert r['hostids'][0] == str(69665)

    @mock.patch('requests.post')
    def test_get_host_id(self, mock_post, mock_creds):
        mock_creds.return_value = mock_vault()
        mock_post.return_value = mock_request(GET_HOST_ID_METHOD)
        mock_token.return_value = mock_token()
        zbx = MockedzbxApi(zbx_url=ZABBIX_URL, zbx_user=mock_creds.return_value['username'],
                           zbx_password=mock_creds.return_value['password'])
        r = zbx.zbxGetHosts(HOSTNAME)
        assert r[0]['hostid'] == str(10160)

    @mock.patch('requests.post')
    def test_get_templates_linked_to_host(self, mock_post, mock_creds):
        mock_creds.return_value = mock_vault()
        mock_post.return_value = mock_request(GET_HOST_ID_METHOD)
        mock_token.return_value = mock_token()
        zbx = MockedzbxApi(zbx_url=ZABBIX_URL, zbx_user=mock_creds.return_value['username'],
                           zbx_password=mock_creds.return_value['password'])
        r = zbx.zbxGetHosts(HOSTNAME)
        assert r[0]['parentTemplates']['templateid'] == str(30051)

    @mock.patch('requests.post')
    def test_create_user_macro(self, mock_post, mock_creds):
        mock_creds.return_value = mock_vault()
        mock_post.return_value = mock_request(CREATE_USER_MACRO_METHOD)
        mock_token.return_value = mock_token()
        zbx = MockedzbxApi(zbx_url=ZABBIX_URL, zbx_user=mock_creds.return_value['username'],
                           zbx_password=mock_creds.return_value['password'])
        macros = [
            {
                "hostid": 10160,
                "macro": "{$MACRO_TEST}",
                "value": 'edge_test_macro'
            },
            ]
        for macro in macros:
            r = zbx.zbx_user_macro_create(**macro)
            assert r['result']['hostmacroids'][0] == str(11)

    @mock.patch('requests.post')
    def test_update_user_macros(self, mock_post, mock_creds):
        mock_creds.return_value = mock_vault()
        mock_post.return_value = mock_request(UPDATE_USER_MACRO_METHOD)
        mock_token.return_value = mock_token()
        zbx = MockedzbxApi(zbx_url=ZABBIX_URL, zbx_user=mock_creds.return_value['username'],
                           zbx_password=mock_creds.return_value['password'])
        r = zbx.zbx_user_macro_update(hostmacroid=11, value='test')
        assert r['result']['hostmacroids'][0] == str(11)

    @mock.patch('requests.post')
    def test_get_user_macro(self, mock_post, mock_creds):
        mock_creds.return_value = mock_vault()
        mock_post.return_value = mock_request(GET_USER_MACRO_METHOD)
        mock_token.return_value = mock_token()
        zbx = MockedzbxApi(zbx_url=ZABBIX_URL, zbx_user=mock_creds.return_value['username'],
                           zbx_password=mock_creds.return_value['password'])
        r = zbx.zbx_get_user_macros(14)
        assert r['result'][0]['hostmacroid'] == str(11)

    @mock.patch('requests.post')
    def test_delete_user_macro(self, mock_post, mock_creds):
        mock_creds.return_value = mock_vault()
        mock_post.return_value = mock_request(DELETE_USER_MACRO_METHOD)
        mock_token.return_value = mock_token()
        zbx = MockedzbxApi(zbx_url=ZABBIX_URL, zbx_user=mock_creds.return_value['username'],
                           zbx_password=mock_creds.return_value['password'])
        r = zbx.zbx_delete_user_macros(hostmacroid=32)
        assert r['result']['hostmacroids'][0] == str(32)

    @mock.patch('requests.post')
    def test_get_host_group(self, mock_post, mock_creds):
        mock_creds.return_value = mock_vault()
        mock_post.return_value = mock_request(GET_HOST_GROUP_METHOD)
        mock_token.return_value = mock_token()
        zbx = MockedzbxApi(zbx_url=ZABBIX_URL, zbx_user=mock_creds.return_value['username'],
                           zbx_password=mock_creds.return_value['password'])
        r = zbx.zbx_get_hostgroup(group_name='EDGE/TEST')
        assert r['result'][0]['groupid'] == str(1)

    @mock.patch('requests.post')
    def test_insert_in_hostgroup(self, mock_post, mock_creds):
        mock_creds.return_value = mock_vault()
        mock_post.return_value = mock_request(INSERT_IN_HOST_GROUP_METHOD)
        mock_token.return_value = mock_token()
        zbx = MockedzbxApi(zbx_url=ZABBIX_URL, zbx_user=mock_creds.return_value['username'],
                           zbx_password=mock_creds.return_value['password'])
        r = zbx.zbx_hostgroup_msadd(group_id=1, host_id=10160)
        assert r['result']['groupids'][0] == str(5)
        assert r['result']['groupids'][1] == str(6)

    @mock.patch('requests.post')
    def test_remove_from_hostgroup(self, mock_post, mock_creds):
        mock_creds.return_value = mock_vault()
        mock_post.return_value = mock_request(REMOVE_FROM_HOST_GROUP_METHOD)
        mock_token.return_value = mock_token()
        zbx = MockedzbxApi(zbx_url=ZABBIX_URL, zbx_user=mock_creds.return_value['username'],
                           zbx_password=mock_creds.return_value['password'])
        r = zbx.zbx_hostgroup_msremove(group_id=1, host_id=10160)
        assert r['result']['groupids'][0] == str(5)
        assert r['result']['groupids'][1] == str(6)

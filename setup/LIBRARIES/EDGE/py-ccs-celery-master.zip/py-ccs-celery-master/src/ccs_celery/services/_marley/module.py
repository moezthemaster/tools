
import edge.interfaces
from incubaw.hpoo import HpooAW
from edge.marley.manage_asset import MarleyLoader


class MarleyHPOOImpl(edge.interfaces.MarleyHPOO):
    def __init__(self):
        self.hpoo = HpooAW()

    def marley_hpoo_execute(self, **params):
        return self.hpoo.execute(**params)


class MarleyLoaderImpl(MarleyLoader, MarleyHPOOImpl):
    pass


def marley_module(marley_operation, vm_hostname, vm_os, vm_profile, code_irt, endClient, app_env, disk_size, vm_backup):
    marley = MarleyLoaderImpl()
    response = marley.invoc_step_marley_v5(
        marley_operation=marley_operation,
        vm_hostname=vm_hostname,
        vm_os=vm_os,
        vm_profile=vm_profile,
        code_irt=code_irt,
        endClient=endClient,
        app_env=app_env,
        disk_size=disk_size,
        vm_backup=vm_backup
    )
    return True, response

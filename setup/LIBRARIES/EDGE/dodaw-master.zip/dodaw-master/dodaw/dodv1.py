#!/usr/bin/python
# -*- coding: utf-8 -*-


import logging
import requests
from dodaw.conf import settings
from dodaw.transports import DodClient
from dodaw.credential import get_user_pwd
from dodaw.exception import DodError, DodClientError
from requests.packages.urllib3.exceptions import InsecureRequestWarning

logging.basicConfig(level=logging.getLevelName(settings.LOGGER_LEVEL))
logger = logging.getLogger(__name__)


class DodWrapper:

    def __init__(self, client=DodClient):
        if not hasattr(settings, 'DOD_V1_URL'):
            raise DodError("Variable DOD_V1_URL not found in settings")
        user, pwd = get_user_pwd(settings.CREDENTIALS_GROUP_MKT)
        try:
            self._client = client(
                user, pwd, settings.DOD_V1_URL
            )
        except DodClientError as err:
            raise DodError(err.args[0], "")
        requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

    def get_next_free_ip(self, subnet, subnetUse="srv"):
        """
        Obtain next free IP in specified subnet for specified usage
        :param subnet: Subnet IP/Mask
        :param subnetUse: oneOf(net/srv/dyn)
        :return: Ip available or false
        """
        ip = self._client.service.get_next_free_ip(subnet, subnetUse)
        if ip is False:
            raise DodError("ip not found within subnet={}".format(subnet), "")
        return ip

    def host_add(self, hostname, domain, subnet, ipRange="srv",
            inA=True, inPTR=True, ip="", ttl="", force=False
        ):
        """

        :param hostname: The hostname
        :param domain: The domain where to add
        :param subnet: Subnet IP/Mask
        :param ipRange: oneOf(net/srv/dyn)
        :param inA: record In A if True
        :param inPTR: record In PTR if True
        :param ip: provided ip or get_next_free_ip
        :param ttl: Don't use default TTL (Default: map default TTL)
        :param force: Force add, even if subnet not found for specified domain (advanced users only)
        :return: True on success
        """
        logger.info(
            "try to record field for hostname={}, domain={}".format(
                hostname,
                domain
            )
        )
        try:
            result = self._client.service.host_add(
                hostname, domain, subnet, ipRange,
                inA, inPTR, ip, ttl, force
            )
        except DodClientError as err:
            logger.error(
                "fail to record field for hostname={}, ip={}, domain={}: {}".format(
                    hostname,
                    ip or "get_next_free_ip",
                    domain,
                    err.args[0]
                )
            )
            raise DodError(err.args[0], "")
        if result:
            logger.info(
                "success to record for hostname={}, ip={}, domain={}".format(
                    hostname,
                    ip or "get_next_free_ip",
                    domain
                )
            )
        else:
            logger.info(
                "fail to record field for hostname={}, ip={}, domain={}".format(
                    hostname,
                    ip or "get_next_free_ip",
                    domain
                )
            )
        return result

    def host_delete(self, hostname, domain, ip="", inA=True, inPTR=True):
        """

        :param hostname: The hostname to delete
        :param domain: The DNS domain
        :param ip: Ip of the hostname
        :param inA: Delete A record if True
        :param inPTR: Delete PTR record if True
        :return: True on success
        """
        logger.info(
            "try to delete field for hostname={}, domain={}".format(
                hostname,
                domain
            )
        )
        result = self._client.service.host_delete(
            hostname, domain, ip, inA, inPTR
        )
        if result:
            logger.info(
                "success to delete for hostname={}, domain={}".format(
                    hostname,
                    ip or "get_next_free_ip",
                    domain
                )
            )
        return result

    def host_search_infos(self, pattern):
        """
        :param pattern: Pattern to search for (hostname or IP)
        :return: Return value assocHostInfoArray: List of matching hostnames
        """
        logger.info("try to get infos for pattern={}".format(pattern))
        result = self._client.service.host_search_infos(pattern)
        if result is None:
            return []
        return result

    def host_update(self, hostname, ip, domain, newHostname="",
            newIp="", newDomain="", newTTL="", force=False
        ):
        """

        :param hostname: The hostname
        :param ip: the host IP
        :param domain: The DNS Domain
        :param newHostname: the new name[OPTIONNAL]
        :param newIp: the new IP[OPTIONNAL]
        :param newDomain: the new domain[OPTIONNAL]
        :param newTTL: the new TTL [OPTIONNAL]
        :param force: Advanced users only

        :return: True on success
        """
        logger.info(
            "try to update field for hostname={}, domain={}, ip={}".format(
                hostname, domain, ip)
        )
        try:
            result = self._client.service.host_update(
                hostname, ip, domain, newHostname,
                newIp, newDomain, newTTL, force
            )
        except DodClientError as err:
            logger.error(
                "fail to record field for hostname={}, ip={}, domain={}: {}".format(
                    hostname, ip, domain, err.args[0])
            )
            raise DodError(err.args[0], "")
        if result:
            logger.info(
                "success to update for hostname={}, ip={}, domain={}".format(
                    hostname, ip, domain)
            )
        else:
            logger.info(
                "fail to update field for hostname={}, ip={}, domain={}".format(
                    hostname, ip, domain)
            )
        return result

#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import sys
import logging

sys.path.append(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
)

from files.sg_gts_manage_ip import DnsFeederAdapter, DnsCleanerAdapter, DnsUpdaterAdapter

logging.basicConfig(level=logging.DEBUG)

logger = logging.getLogger(__name__)

HOSTNAME = 'dtrvlxtestfromedgeansiblemodule'


class TestDns1(object):

    def test_delete_dns(self):
        cleaner = DnsCleanerAdapter(
            'dev', 'EU France (Greater Paris)', 'eu-fr-paris-1', 'SGCIB_DEV2',
            trigram="trv", hostname=HOSTNAME
        )
        logger.info('Cleaning DOD')
        response = cleaner.run()
        assert cleaner.changed
        assert response["msg"] == "record A, PTR for hostname={} have been deleted".format(HOSTNAME)

    def test_create_delete_dns(self):
        feeder = DnsFeederAdapter(
            'dev', 'EU France (Greater Paris)', 'eu-fr-paris-1', 'SGCIB_DEV2',
            trigram="trv", hostname=HOSTNAME,
        )
        cleaner = DnsCleanerAdapter(
            'dev', 'EU France (Greater Paris)', 'eu-fr-paris-1', 'SGCIB_DEV2',
            trigram="trv", hostname=HOSTNAME
        )
        logger.info('Cleaning DOD')
        init_response = cleaner.run()
        logger.info('Dod cleaned - response: {}'.format(init_response))
        logger.info('Loading records')
        feeder_response = feeder.run()
        logger.info('Dod loaded - response: {}'.format(feeder_response))
        assert feeder.changed
        #clean  again
        cleaner.changed = False
        cleaner.run()
        logger.info('Dod cleaned again')
        assert cleaner.changed

    def test_update_dns(self):
        feeder = DnsFeederAdapter(
            'dev', 'EU France (Greater Paris)', 'eu-fr-paris-1', 'SGCIB_DEV2',
            trigram="trv", hostname=HOSTNAME
        )
        updater = DnsUpdaterAdapter(
            'dev', 'EU France (Greater Paris)', 'eu-fr-paris-1', 'SGCIB_DEV2',
            trigram="trv", hostname=HOSTNAME, new_hostname='{}_new'.format(HOSTNAME)
        )
        cleaner = DnsCleanerAdapter(
            'dev', 'EU France (Greater Paris)', 'eu-fr-paris-1', 'SGCIB_DEV2',
            trigram="trv", hostname=HOSTNAME
        )
        logger.info('Cleaning DOD')
        init_response = cleaner.run()
        logger.info('Dod cleaned - response: {}'.format(init_response))
        logger.info('Loading records')
        feeder_response = feeder.run()
        updater_response = updater.run('Dummy')
        logger.info('Dod loaded - response: {}'.format(feeder_response))
        assert feeder.changed
        assert updater.changed
        assert feeder_response["output"][0]["ip"] == updater_response["output"][0]["ip"]
        assert feeder_response["output"][0]["domain"] == updater_response["output"][0]["domain"]
        #clean  again
        cleaner.changed = False
        cleaner.hostname = updater.new_hostname
        cleaner.run()
        logger.info('Dod cleaned again')
        assert cleaner.changed

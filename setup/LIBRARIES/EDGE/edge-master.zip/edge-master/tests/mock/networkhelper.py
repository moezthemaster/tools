#!/usr/bin/python
# -*- coding: utf-8 -*-

from edge.network.networkhelper import NetworkHelper

def mocked_vault():
    return   {
        'user': 'UserX',
        'private_root_key': u"private_key"
    }



class VmDatabase(object):
    def __init__(self, shared_database=None):
        if isinstance(shared_database, list):
            self.vm_database = shared_database
        else:
            self.vm_database = []    

    def search_vm(self, ip):
        try:
            index = list(map(lambda x: x["ip"], self.vm_database)).index(ip)
        except ValueError:
            return None
        vm = self.vm_database[index]
        return vm

class MockedNetworkHelper(VmDatabase):

    def __init__(self, shared_database=None, **kwargs):
        VmDatabase.__init__(self, shared_database, **kwargs)
    
    def update_etc_host(self, ip_address, network_id):
        vm = self.search_vm(ip_address)
        if vm == None:
            raise Exception(ip_address)
        else:
            return "OK"

    def update_dns_config(self, ip_address, geo_domain, network_id, network_envi):
        vm = self.search_vm(ip_address)
        if vm == None:
            raise Exception("SSHException: {}".format(ip_address))
        else:
            return (0,"1\n","")      

    def configure_ntp(self, ip_address, network_id):
        vm = self.search_vm(ip_address)
        if vm is None:
            raise Exception("SSHException: {}".format(ip_address))

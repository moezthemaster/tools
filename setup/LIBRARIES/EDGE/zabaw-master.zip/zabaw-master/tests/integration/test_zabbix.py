from zabaw.zabbix import zbxApi
from zabaw.conf import settings


HOSTNAME = 'dacdlx034'
TEMPLATE_NAMES = ['SG_MongoDB_EDGE', 'SG_POSTGRESQL', 'SG_POSTGRESQL_PGHOARD', 'SG_MongoDB_EDGE_ARBITER']


class Zabbix(object):
    """instanciate zabbix object"""
    def __init__(self):
        try:
            self._zbx = zbxApi(
                zbxUrl=settings.ZABBIX_URL_RET,
            )
        except Exception:
            raise

    def get_host_group(self, group_name):
        return self._zbx.zbx_get_hostgroup(group_name)

    def get_host_id(self, hostname):
        return self._zbx.zbxGetHosts(hostname)

    def get_template_id(self, name):
        return self._zbx.zbxGetTemplateId(name)

    def link_host_to_template(self, host_id, template_id):
        return self._zbx.zbxLinkHostToTemplate(host_id, template_id)

    def update_user_macros(self, **kwargs):
        return self._zbx.zbx_user_macro_update(**kwargs)

    def unlink_host_to_template(self, host_id, template_id):
        return self._zbx.zbxUnlinkHostToTemplate(host_id, template_id)

    def get_templates_linked_to_host(self, host_id):
        return [v['templateid'] for v in self._zbx.zbxGetTemplatesLinkedToHostid(host_id)[0]["parentTemplates"]]

    def create_user_macro(self, **kwargs):
        return self._zbx.zbx_user_macro_create(**kwargs)

    def delete_user_macro(self, macroid):
        return self._zbx.zbx_delete_user_macros(macroid)

    def get_user_macro(self, host_id):
        return self._zbx.zbx_get_user_macros(host_id)


class TestZabbix():
    """ """

    def test_get_host_id(self):
        zbx = Zabbix()
        r = zbx.get_host_id(hostname=HOSTNAME)
        assert r[0]['hostid'] == str(17467)
        assert HOSTNAME in r[0]['host']

    def test_get_template_id(self):
        zbx = Zabbix()
        expected_templates_ids = str([15909, 12615, 12616, 15074])
        for template in TEMPLATE_NAMES:
            r = zbx.get_template_id(name=template)
            assert r in expected_templates_ids

    def test_get_host_group(self):
        zbx = Zabbix()
        r = zbx.get_host_group(group_name='SG_SGDB/SG_MGDB_EDGE')
        assert r['result'][0]['groupid'] == str(76)

    def test_link_host_to_template(self):
        zbx = Zabbix()
        r = zbx.link_host_to_template(host_id=17467, template_id=15909)
        assert r['hostids']
        assert r['hostids'][0] == 17467

    def test_get_templates_linked_to_host(self):
        zbx = Zabbix()
        expected_tpl_id = 15909
        r = zbx.get_templates_linked_to_host(host_id=17467)
        assert str(expected_tpl_id) in r

    def test_unlink_host_to_template(self):
        zbx = Zabbix()
        r = zbx.unlink_host_to_template(host_id=17467, template_id=15909)
        assert r['hostids']
        assert r['hostids'][0] == 17467

    def test_create_user_macro(self):
        zbx = Zabbix()
        macros = [
            {
                "hostid": 17467,
                "macro": "{$MACRO_TEST}",
                "value": 'edge_test_macro'
            },
            ]

        for macro in macros:
            r = zbx.create_user_macro(**macro)
            assert r['result']['hostmacroids'][0]

    def test_delete_user_macro(self):
        zbx = Zabbix()
        r = zbx.get_user_macro(host_id=17467)
        macro = r['result'][0]['hostmacroid']
        d = zbx.delete_user_macro(macroid=macro)
        assert d['result']['hostmacroids'][0] == macro

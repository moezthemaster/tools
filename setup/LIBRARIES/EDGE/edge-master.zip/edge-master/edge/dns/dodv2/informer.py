#!/usr/bin/python
# -*- coding: utf-8 -*-

#

DOCUMENTATION = '''




'''

EXAMPLES = '''
    see test_dns_informer.py
'''

import re
import logging

import edge.interfaces
from edge.conf import settings
from edge.exception import EdgeException
from edge.conf.cloud_network import find_network_infos, find_network_infos_by_zone


KWARGS_SEARCH = {
    'dns_service':settings.DOD_DNS_SERVICE,
    'view': 'production',
}
A = 'A'
DEFAULT_IP_ADDRESS = '127.0.0.1'
DEFAULT_FQDN = 'localhost.localdomain'


logger = logging.getLogger(__name__)


class DnsInformer(edge.interfaces.Dod):
    def __init__(self, hostname, region_cloud=None, az_cloud=None):
        try:
            assert re.search(r'^edge_conflict_(ssh|rdp|whats)_[0-9]+$', hostname) or hostname.isalnum()
        except:
            raise EdgeException("hostname must be alphanumeric")
        self.hostname = hostname
        self.region_cloud = region_cloud
        self.az_cloud = az_cloud
        self.changed = False

    def run(self):
        '''
        First get ip addess of host.
        Then retrieve network informations from mapping file.
        :return: list of dict
        '''
        types_hosts = [
            ('A', '^%s$' % self.hostname),
        ]
        infos = []
        try: 
            for record_type, host in types_hosts:
                logger.debug('Retrieving record type {} for hostname {}'.format(record_type, host))
                records = self.search_dns_record(
                    record_type='^{}$'.format(record_type),
                    dns_service=settings.DOD_DNS_SERVICE,
                    hostname=host,
                    view='production'
                )
                for record in records:
                    logger.error("record = {}".format(record))
                    if record.get('ip', None) is not None:
                        if record.get('zone', None) is not None:
                            env, region_cloud, az_cloud, network_id, network_cidr, dns_zone, dns_cname = \
                                find_network_infos_by_zone(record['ip'], record['zone'])
                        else:
                            env, region_cloud, az_cloud, network_id, network_cidr, dns_zone, dns_cname = \
                                find_network_infos(record['ip'], self.region_cloud, self.az_cloud)
                        infos.append(
                            {
                                "vm_hostname" : self.hostname, "ip_address": record['ip'],
                                "vm_env": env, "vm_region": region_cloud, "vm_az": az_cloud,
                                "vm_network": network_id, "vm_subnet": network_cidr,
                                "vm_zone": dns_zone, "dns_publish": dns_cname
                            }
                        )
        except:
            raise 

        return infos

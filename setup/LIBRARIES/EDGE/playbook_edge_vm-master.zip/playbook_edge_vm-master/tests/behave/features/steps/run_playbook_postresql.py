#!/usr/bin/env python
# -*- coding: utf-8 -*-

import ansible_play
from behave import *


@when('Run playbook postgresql')
def step_impl(context):

    run_data = {
        'vm_hostname': context.params['vm_hostname'],
        'fs_list': context.params['fs_list'],
        'postgresql_version': context.params['postgres_version'],
        'postgresql_cluster_name': context.params['cluster_name'],
        'postgresql_superuser_password': context.params['superuser_password'],
        'postgresql_encoding': context.params['cluster_encoding'],
        'postgresql_locale': context.params['cluster_locale'],
        'postgresql_db_name': context.params['db_name'],
        'postgresql_db_user': context.params['db_user'],
        'postgresql_db_password': context.params['db_password'],
        'postgresql_remote_db_password': context.params['remote_db_password'],
        'postgresql_db_extensions': context.params['db_extensions'],
        'module_vm_ip_address': context.params['vm_ipaddr'],
        'ip_address': context.params['vm_ipaddr']

    }
    become_user_password = 'foo-whatever'

    runner = ansible_play.Runner(
        hostnames='localhost',
        playbook="run_postgres.yml",
        tags="",
        private_key_file=context.private_key,
        run_data=run_data,
        become_pass=become_user_password,
        verbosity=100,
        connection='smart'
    )

    stats = runner.run()

    print("Debug")
    run_success = True
    hosts = sorted(stats.processed.keys())
    for h in hosts:
        t = stats.summarize(h)
        print("{} => {}".format(h, t))
        if t['unreachable'] > 0 or t['failures'] > 0:
            run_success = False

    assert run_success is True
    context.vm_suid_installed= True


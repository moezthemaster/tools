from werkzeug.local import LocalProxy
from flask import g, current_app as app

from sg_datalake import DatalakeLog


def get_logger():
    logger = getattr(g, '_logger', None)
    if logger is None:
        logger = g._logger = DatalakeLog(
            conffile=app.config['DL_LOGGER_CONFFILE'])
    return logger


dl_logger = LocalProxy(get_logger)

#!/usr/bin/python
# -*- coding: utf-8 -*-

# (c) 2016, Danny AFAHOUNKO <danny.afahounko-ext@socgen.com>
#

DOCUMENTATION = '''
---


'''

EXAMPLES = '''
# Create 

'''

# import module snippets
from ansible.module_utils.basic import *
import re
import json
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from requests.auth import HTTPBasicAuth
import ConfigParser
import time
import datetime
import random
import string
import yaml


if "TREE_DIR" in os.environ.keys() : 
     ANSIBLE_MODULES_PATH = [
       './roles/ansible_libraries/files',  
       os.path.join(os.environ["TREE_DIR"], "library"),
        ]
else:
  ANSIBLE_MODULES_PATH = [
     './roles/ansible_libraries/files'
     ]

for path in ANSIBLE_MODULES_PATH:
  sys.path.append(path)

import sg_gts_tools.sg_gts_init



CONFIG_ROOT = '/etc/ansible'

GTS_CONFIG = 'gts_cloud_vm.cfg'




def default_config(params):


  isError, log, out = sg_gts_tools.sg_gts_init.read_settings(CONFIG_ROOT, GTS_CONFIG)

  global SETTINGS

  vOutput = {


    'catalog_url': "{}{}" . format(out['TOKEN_urlroot'], out['CATALOG_catalogsuffix']),
    'catalog_consumer': "{}{}" . format(out['TOKEN_urlroot'], out['CATALOG_consumersuffix']),
    'catalog_query': "{}{}" . format(out['TOKEN_urlroot'], out['CATALOG_querysuffix']),
    'catalog_filter': out['CATALOG_filter'],

  }


  SETTINGS.update( vOutput )

  # RETURN
  return isError, log, out





def get_vm_info(params):


  result = {}
  isError = False
  hasChanged = False

  #TOKEN
  token = { 'Authorization': "Bearer {}" . format(params['token']) }

  #GET VM CATALOG
  url = SETTINGS['catalog_query']
  status, output = sg_gts_tools.sg_gts_init.get_vm_catalog_json(url, params['vm_hostname'], **token)

  result['json'] = output
  #result['code_status'] = status
  #result['settings'] = SETTINGS
  requestId = 'Not-a-requestId'
  try:
    requestId = output['content'][0]['requestId']
  except Exception, e:
    #raise e
    pass

  #GET VM REQUEST
  url = "{}/{}" . format(SETTINGS['catalog_consumer'], requestId)
  data = {}
  output = {}
  if requestId != 'Not-a-requestId' :
    status, output = sg_gts_tools.sg_gts_init.submit_url_json('GET', url, data , **token)
  

  result['request'] = output
  result['code_status'] = status


  return isError, hasChanged, result




def main():

  fields = { 

     "token": {"required": True, "type": "str"},

     "vm_hostname": {"required": True, "type": "str"},
     "vm_ipaddress": {"required": False, "type": "str"},
     
     "state": {
        "default": "present",
        "choices": ['present'],
        "type": "str"
     },
  }



  choice_map = {
     "present": get_vm_info,
  }



  module = AnsibleModule(argument_spec=fields)

  #Config settings
  isError, logOutput, output = default_config(module.params)

  if isError:
    module.fail_json(msg=logOutput)

  #state  
  isError, hasChanged, result = choice_map.get( module.params['state'])(module.params)

  if not isError:
    module.exit_json(changed=hasChanged, meta=result)

  else:
    module.fail_json(msg="Error request cannot be completed", meta=result)


"""
"""
SETTINGS = {}

if __name__ == '__main__':
  main()



import edge.interfaces
from edge.cloud_vm.vm import Vm
from cloudaw.token import Token
from cloudaw.catalog import Catalog
from cloudaw.resource import Resource
from cloudaw.request import VmRequest, WorkflowRequest
from edge.conf.cloud_network import find_network_infos

from ccs_celery.tools import set_missing_keys_to_none


class CloudVraImpl(edge.interfaces.CloudVra):
    def __init__(self):
        self.token = Token()
        self.resource = Resource(self.token)
        self.catalog = Catalog(self.token)
        self.vm_request = VmRequest(self.token)
        self.workflow_request = WorkflowRequest(self.token)

    def get_vra_resource_data(self, filter_sentence):
        return self.resource.get_resource_data(filter_sentence)

    def get_vra_catalog(self, filter_sentence):
        return self.catalog.get_vra_catalog(filter_sentence)

    def vra_create_vm(self, wait, machine_item, vm_config, requested_for, provider_owner, business_group):
        return self.vm_request.create(wait, machine_item, vm_config, requested_for, provider_owner, business_group)

    def vra_destroy_vm(self, wait, hostname_id, operation_id, organization):
        return self.vm_request.destroy(wait, hostname_id, operation_id, organization)

    def vra_workflow_request(self, wait, workflow_item, trigram, app_env):
        return self.workflow_request(wait, workflow_item, trigram, app_env)


class VmImpl(Vm, CloudVraImpl):
    def __init__(self, hostname):
        CloudVraImpl.__init__(self)
        Vm.__init__(self, hostname)


PRESENT, ABSENT, INFOS = 'present', 'absent', "infos"

REQUIRED_FIELDS = [
    ["state", PRESENT, ["app_id", "vm_hostname", "ip_address", "vm_subnet"]],
    ["state", ABSENT, ["vm_hostname"]],
    ["state", INFOS, ["vm_hostname"]]
]

INFOS_FIELDS = {
    'resourceData': {'MachineName': 'vm_hostname',
                     'MachineCPU': 'vm_cpu',
                     'MachineMemory': 'vm_memory',
                     'ip_address': 'ip_address',
                     'MachineGroupName': 'vm_bg',
                     'MachineBlueprintName': 'vm_os',
                     },
    'extended': {'provider-AvailabilityZone': 'vm_az',
                 'provider-Region': 'vm_region',
                 'provider-Description': 'vm_desc',
                 'provider-Subnet': 'vm_subnet',
                 'provider-Replication': 'vm_replication',
                 'provider-Backup': 'vm_backup',
                 'provider-Environment': 'vm_env'
                 }
}

REGIONS_MAP = {
    "eu-fr-paris": "EU France (Greater Paris)",
    "eu-fr-north": "EU France (North)"
}

PROFILES_MAP = {
    "1": {"1024": "Micro 1vCPU-1GB", "2048": "Small 1vCPU-2GB", "4096": "Small-mem4 1vCPU-4GB"},
    "2": {"2048": "Medium-mem2 2vCPU-2GB", "4096": "Medium 2vCPU-4GB", "8192": "Medium-mem8 2vCPU-8GB",
          "16384": "Medium-mem16 2vCPU-16GB", "32768": "Medium-mem32 2vCPU-32GB"},
    "4": {"8192": "Large 4vCPU-8GB", "16384": "Large-mem16 4vCPU-16GB", "32768": "Large-mem32 4vCPU-32G"},
    "8": {"16384": "XLarge 8vCPU-16GB", "32768": "XLarge-mem32 8vCPU-32GB",
          "65536": "XLarge-mem64 8vCPU-64GB", "131072": "XLarge-mem128 8vCPU-128GB"}
}

BACKUP_MAP = {
    "Daily | 31d retention | 02h00 AM": "daily-31d-2AM",
    "Daily | 31d retention | 04h00 AM": "daily-31d-4AM"
}


def get_disk_size(json_infos, disk_id):
    disk_infos = [disk for disk in json_infos['resourceData']['entries'] if disk['key'] == "DISK_VOLUMES"]
    for disk_vol in disk_infos:
        for disk in disk_vol['value']['items']:
            if disk['values']['entries'][0]['key'] == "DISK_INPUT_ID" and \
                    disk['values']['entries'][0]['value']['value'] == disk_id:
                if disk['values']['entries'][1]['key'] == "DISK_CAPACITY":
                    return disk['values']['entries'][1]['value']['value']
    return 0


# ugly decorator
# used due to constraint delivery time
# To improve
@set_missing_keys_to_none(
    (
        "app_id", "vm_hostname", "vm_desc", "app_env", "vm_profile", "ip_address",
        "vm_subnet", "vm_region", "vm_az", "vm_os", "data_disk", "vm_backup", "vm_replication", "extended_infos",
        "state"
    )
)
def cloud_module(app_id, vm_hostname, vm_desc, app_env, vm_profile, ip_address, vm_subnet, vm_region, vm_az, vm_os,data_disk, vm_backup, vm_replication, extended_infos=False, state="present"):
    try:
        vm = VmImpl(vm_hostname)
        if state == PRESENT:
            response = vm.create(
                vm_os=vm_os,
                trigram=app_id,
                app_env=app_env,
                vm_profile=vm_profile,
                data_disk=data_disk,
                vm_desc=vm_desc,
                ip_address=ip_address,
                vm_region=vm_region,
                vm_az=vm_az,
                vm_subnet=vm_subnet,
                vm_replication=vm_replication,
                vm_backup=vm_backup
            )
            return vm.has_changed, response
        elif state == ABSENT:
            response = vm.destroy()
            return vm.has_changed, response
        elif state == INFOS:
            output = {}
            response = vm.get_infos(refresh=True, extended=extended_infos)
            for subkey in INFOS_FIELDS:
                for key in INFOS_FIELDS[subkey].values():
                    output[key] = 'N/A'
            if response:
                for subkey in INFOS_FIELDS:
                    if response.get(subkey, None) and response[subkey]['entries']:
                        for entry in response[subkey]['entries']:
                            if entry['key'] in INFOS_FIELDS[subkey]:
                                output[INFOS_FIELDS[subkey][entry['key']]] = entry['value']["value"]
            else:
                return vm.has_changed, output
            if str(output["vm_cpu"]) in PROFILES_MAP and \
                    str(output["vm_memory"]) in PROFILES_MAP[str(output["vm_cpu"])]:
                output['vm_profile'] = PROFILES_MAP[str(output["vm_cpu"])][str(output["vm_memory"])]
            if output['vm_backup'] in BACKUP_MAP:
                output['vm_backup'] = BACKUP_MAP[output['vm_backup']]
            output["data_disk"] = get_disk_size(json_infos=response, disk_id="DISK_INPUT_ID2")
            if output['ip_address'] != 'N/A':
                try:
                    if output['vm_region'] in REGIONS_MAP:
                        output['vm_region'] = REGIONS_MAP[output['vm_region']]
                    if output['vm_az'] == "N/A":
                        env, region_cloud, az_cloud, network_id, network_cidr, dns_zone, dns_cname = find_network_infos(
                            output['ip_address'])
                        output['vm_az'] = az_cloud
                        output['vm_region'] = region_cloud
                    else:
                        env, region_cloud, az_cloud, network_id, network_cidr, dns_zone, dns_cname = find_network_infos(
                            output['ip_address'], vm_region=output['vm_region'], vm_az=output['vm_az'])
                    output['vm_network'] = network_id
                    output['vm_subnet'] = network_cidr
                    output['vm_zone'] = dns_zone
                    output['dns_publish'] = dns_cname
                except:
                    pass
            return vm.has_changed, output
    finally:
        try:
            vm.token.delete()
        except NameError:
            pass

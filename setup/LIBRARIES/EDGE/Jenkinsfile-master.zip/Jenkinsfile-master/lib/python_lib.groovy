def withPyEnv(String pyPath, def body) {
    String path = pyPath + "/bin"
    String ldPath =properties.pythonPath + "/lib"
    withEnv(["PATH=${path}:$PATH",
            "LD_LIBRARY_PATH=${ldPath}"]) {
        body.call()
    }
}

def createVirtualenv(String venvName) {
    sh """
        virtualenv ${venvName}
        virtualenv --relocatable ${venvName}
        """
}

return this


import logging

import pytest

from tests.mock.mock import MockDod
from edge.dns.dodv2.feeder import DnsFeeder
from edge.dns.dodv2.informer import DnsInformer

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

LIST_HOSTNAMES = ('dpgalx200',)


class MockedFeeder(DnsFeeder, MockDod):
    def __init__(self, init_types, env, region_cloud, az_cloud, network_id, trigram, hostname=None):
        MockDod.__init__(self, init_types, hostname=hostname)
        DnsFeeder.__init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname)

mocked_dod_inits = (('A',),)


@pytest.fixture(params=mocked_dod_inits)
def mocked_dod_init(request):
    return request.param


class MockedInformer(MockDod, DnsInformer):

    def __init__(self, init_types, hostname):
        MockDod.__init__(self, init_types, hostname=hostname)
        DnsInformer.__init__(self, hostname)


class TestDnsInformer:

    def test_feed_dns_with_hostname_to_be_recorded(self, mocked_dod_init):
        feeder = MockedFeeder(init_types=mocked_dod_init, env='dev', region_cloud='EU France (Greater Paris)',
                              az_cloud='eu-fr-paris-1', network_id='CDN', trigram='pga', hostname=LIST_HOSTNAMES[0])
        feeder.run()

    def test_get_infos_dns(self, mocked_dod_init):
        infos = MockedInformer(init_types=mocked_dod_init, hostname=LIST_HOSTNAMES[0]).run()
        assert infos[0]["vm_hostname"] == LIST_HOSTNAMES[0]

    def test_get_infos_dns_with_fake_hostname(self, mocked_dod_init):
        try:
            MockedInformer(init_types=mocked_dod_init, hostname='fake_hostname')
            assert False
        except Exception as err:
            assert "hostname must be alphanumeric" == err.args[0]

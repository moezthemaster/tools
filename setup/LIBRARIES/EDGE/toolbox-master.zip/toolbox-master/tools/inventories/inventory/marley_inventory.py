import os
from logzero import logger
from . import manage_marley

dirname = os.path.dirname(os.path.realpath(__file__))
if not dirname:
    FILE_EXPORT = os.path.join('conf', 'settings_prod.cfg')
else:
    FILE_EXPORT = os.path.join(dirname, 'conf', 'settings_prod.cfg')
os.environ["INCUBAW_CONFIG_FILE"] = FILE_EXPORT
os.environ["EDGE_CONFIG_FILE"] = FILE_EXPORT
os.environ["CLOUDAW_CONFIG_FILE"] = FILE_EXPORT

from incubaw.bobaw import Bobaw


class MarleyInventory:
    def __init__(self):
        logger.debug("__init__")
        self._bobaw = Bobaw()
        self._inventory = {}

    def add_infos(self, inv):
        for entry in inv:
            if 'Hostname RET' in entry and \
                            entry['Hostname RET'] in self._inventory:
                self._inventory[entry['Hostname RET']].append(entry)
            else:
                self._inventory[entry['Hostname RET']] = [entry]

    def get_infos(self, trigram):
        logger.debug("get_infos")
        self.add_infos(self._bobaw.get_infos(trigram=trigram))

    def check_status(self, status_inventory):
        logger.debug("check status")
        for (hostname, entries) in self._inventory.iteritems():
            status_host = status_inventory.check_status(hostname)
            for entry in entries:
                entry['status_host'] = status_host

    def output(self):
        for (key, entries) in sorted(self._inventory.iteritems()):
            for entry in entries:
                print("{} : {}".format(key, entry))

    def check_ghost_records(self, vra_inventory, trigram):
        logger.debug("Check ghost assets")
        for (key, entries) in sorted(self._inventory.iteritems()):
            for entry in entries:
                if key not in vra_inventory._inventory:
                    if entry['status_host']['alive'] != 'Alive':
                        print("{}:MAR:Ghost asset:{}".format(
                            key, entry['Asset ID']))
                        manage_marley.manage_asset(hostname=key, trigram=trigram, state='decom')

    def check_missing_records(self, vra_inventory, trigram):
        logger.debug("Check missing assets")
        for (key, entries) in sorted(vra_inventory._inventory.iteritems()):
            for entry in entries:
                if key not in self._inventory:
                    print("{}:MAR:Missing asset".format(key))
                    manage_marley.manage_asset(hostname=key, trigram=trigram, state='create')

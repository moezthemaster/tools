#!/usr/bin/env python

"""
AUTHOR:
EDGE AUTOMATION

MODULE: sg_gts_idm

DESCRIPTION:
This module is user to enrole and unenrole servers in IDM.

"""

import warnings
import urllib3
import requests
import kerberos
from ansible.module_utils.basic import *
from requests_kerberos import HTTPKerberosAuth, REQUIRED

if "TREE_DIR" in os.environ.keys():
    ANSIBLE_MODULES_PATH = [
        './roles/ansible_libraries/files',
        os.path.join(os.environ["TREE_DIR"], "library"),
    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/ansible_libraries/files'
    ]

for path in ANSIBLE_MODULES_PATH:
    sys.path.append(path)

CONFIG_ROOT = "/etc/ansible"
for path in ANSIBLE_MODULES_PATH:
    if os.path.exists(os.path.join(path, 'config')):
        CONFIG_ROOT = os.path.join(path, 'config')

# CONFIG_ROOT = './roles/ansible_libraries/files/config'
IDM_CONFIG = 'gts_idm.cfg'

import sg_gts_tools.sg_gts_init


class ExplicitError(Exception):
    """
    raise customized errors
    """

    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)


def default_config(params):
    """
    :param params: environment
    :return: IDM configuration (from configuration file)
    """
    isError, log, out = sg_gts_tools.sg_gts_init.read_settings(CONFIG_ROOT, IDM_CONFIG)

    global SETTINGS
    environment = params['whats_environment']
    vOutput = {

        'user_username': out['USER_username'],
        'url_{}'.format(environment): out['URL_{}'.format(environment)],
        'urlfailover_{}'.format(environment): out['URLFAILOVER_{}'.format(environment)],
        'realm_{}'.format(environment): out['REALM_{}'.format(environment)],
        'principal_{}'.format(environment): out['PRINCIPAL_{}'.format(environment)],
        'domain_{}'.format(environment): out['DOMAIN_{}'.format(environment)],
        'ssl_{}'.format(environment): out['SSL_{}'.format(environment)],
        'keytab_{}'.format(environment): out['KEYTAB_{}'.format(environment)],
    }

    SETTINGS.update(vOutput)
    return isError, log, out


def generate_kerberos_ticket(environment):
    """
    :param environment:
    :return: valid Token to call IDM API
    """
    is_error = False
    ticket = "DEFAULT_NONE_VALID_KERBEROS_TICKET"

    idm_user = '{}'.format(SETTINGS['user_username'])
    idm_realm = '{}'.format(SETTINGS['realm_{}'.format(environment)])
    idm_keytab = '{}'.format(SETTINGS['keytab_{}'.format(environment)])
    idm_principal = '{}'.format(SETTINGS['principal_{}'.format(environment)])

    try:
        kinit = subprocess.check_call('kinit {}@{} -k -t {}'.format(idm_user,
                                                                    idm_realm, idm_keytab), shell=True)

        if kinit == 0:
            try:
                __, krb_context = kerberos.authGSSClientInit(
                    'HTTP/{}@{}'.format(idm_principal, idm_realm))
                kerberos.authGSSClientStep(krb_context, "")

                negotiate_details = kerberos.authGSSClientResponse(krb_context)
                # kerberos.AUTH_GSS_COMPLETE
                ticket = negotiate_details

            except Exception, e:
                is_error = True
                return is_error, e
        else:
            is_error = True

        return is_error, ticket

    except subprocess.CalledProcessError, e:
        return e.returncode, e.cmd, e.output


def destroy_kerberos_ticket():
    """
    :return: destroys toeken
    """
    is_error = False
    try:
        subprocess.check_call('kdestroy -A', shell=True)
    except Exception, e:
        return e, is_error


def whats_present(params):
    """
    :param params: ansible role variables
    :return: IDM API call to pre_enrole servers
    """
    warnings.simplefilter('ignore', urllib3.exceptions.SecurityWarning)

    #    sslCertificate = SETTINGS['ssl_{}'.format(environment)]
    #   headers = {
    #       "Authorization": "Negotiate {}".format(ticket),
    #   }

    in_all = force = non_standard \
        = random = raw = 'false'

    os_version = 'Linux'
    pre_enrollement = 'iru_host_add'
    description = "EDGE SERVER"

    trigram = params['whats_trigram'].upper()
    ip_address = params['whats_ip']
    hostname = params['whats_hostname']
    environment = params['whats_environment']

    cert = SETTINGS['ssl_{}'.format(environment)]
    domain = SETTINGS['domain_{}'.format(environment)]
    realm = SETTINGS['realm_{}'.format(environment)]
    url = SETTINGS['url_{}'.format(environment)]
    urlfailover = SETTINGS['urlfailover_{}'.format(environment)]

    generate_kerberos_ticket(environment)

    kerberos_auth = HTTPKerberosAuth(mutual_authentication=REQUIRED)
    headers = {"Referer": url, "Content-type": "application/json",
               "Accept": "application/json"}

    data = {
        "id": 0,
        "method": pre_enrollement,
        "params": [
            [
                hostname
            ],
            {
                "all": in_all,
                "description": description,
                "force": force,
                "ip_address": ip_address,
                "non_standard": non_standard,
                "nsosversion": os_version,
                "random": random,
                "raw": raw,
                "tla": [
                    trigram
                ],
                "userpassword": "password",
                "version": "2.112"
            }
        ]
    }
    try:
        r = requests.post(url=url, auth=kerberos_auth, data=json.dumps(data),
                          verify=cert, headers=headers)
    except requests.exceptions.ConnectionError:
        headers = {"Referer": urlfailover, "Content-type": "application/json",
                   "Accept": "application/json"}

        r = requests.post(url=urlfailover, auth=kerberos_auth, data=json.dumps(data),
                          verify=cert, headers=headers)
    # TODO: implement bloc try to manage failover in case of enrolement failure. it will depends on return codes from API
    if r.status_code != 200:
        headers = {"Referer": urlfailover, "Content-type": "application/json",
                   "Accept": "application/json"}
        r = requests.post(url=urlfailover, auth=kerberos_auth, data=json.dumps(data),
                          verify=cert, headers=headers)

    destroy_kerberos_ticket()

    if r.status_code == 200:
        return False, True, {"status": "SUCCESS", "data": r.json(), "idm_realm": realm,
                             "idm_domain": domain, "idm_certificat": cert}
    else:
        meta = {"status": r.status_code, 'response': r.json()}
        return True, False, meta


def whats_absent(params):
    """
    :param params: ansible role variables
    :return: IDM API call to un_enrole servers
    """
    warnings.simplefilter('ignore', urllib3.exceptions.SecurityWarning)

    force = no_update_dns = 'false'
    un_enrollment = 'iru_host_del'

    hostname = params['whats_hostname']
    environment = params['whats_environment']

    url = SETTINGS['url_{}'.format(environment)]
    urlfailover = SETTINGS['urlfailover_{}'.format(environment)]

    generate_kerberos_ticket(environment)

    headers = {"Referer": url, "Content-type": "application/json",
               "Accept": "application/json"}
    kerberos_auth = HTTPKerberosAuth(mutual_authentication=REQUIRED)

    data = {
        "id": 0,
        "method": un_enrollment,
        "params": [
            [
                hostname
            ],
            {
                "force": force,
                "no_updatedns": no_update_dns,
                "version": "2.112"
            }
        ]
    }

    try:
        r = requests.post(url=url, auth=kerberos_auth, data=json.dumps(data),
                          verify=False, headers=headers)
    except requests.exceptions.ConnectionError:
        headers = {"Referer": urlfailover, "Content-type": "application/json",
                   "Accept": "application/json"}

        r = requests.post(url=urlfailover, auth=kerberos_auth, data=json.dumps(data),
                          verify=False, headers=headers)
    # TODO: implement bloc try to manage failover in case of enrolement failure. it will depends on return codes from API
    if r.status_code != 200:
        headers = {"Referer": urlfailover, "Content-type": "application/json",
                   "Accept": "application/json"}
        r = requests.post(url=urlfailover, auth=kerberos_auth, data=json.dumps(data),
                          verify=False, headers=headers)

    destroy_kerberos_ticket()

    if r.status_code == 200:
        return False, True, {"status": "SUCCESS", "data": r.json()}
    else:
        result = {"status": r.status_code, "data": r.json()}
        return True, False, result


def whats_check_ip(params):
    """
    :param params: ansible role variables
    :return: IDM API call to check if ip is already enroled
    """
    warnings.simplefilter('ignore', urllib3.exceptions.SecurityWarning)
    ipa_version = "2.112"
    ipa_method = "iru_ip4_exists"
    ip_address = params['whats_ip']
    environment = params['whats_environment']

    generate_kerberos_ticket(environment)

    url = SETTINGS['url_{}'.format(environment)]
    headers = {"Referer": url, "Content-type": "application/json",
               "Accept": "application/json"}
    kerberos_auth = HTTPKerberosAuth(mutual_authentication=REQUIRED)

    data = {
        "id": 0,
        "method": ipa_method,
        "params": [
            [
                ip_address
            ],
            {
                "version": ipa_version
            }
        ]
    }
    try:
        r = requests.post(url=url, auth=kerberos_auth, data=json.dumps(data),
                          verify=False, headers=headers)
        result = {"status": r.status_code, "data": r.json()}
        destroy_kerberos_ticket()
        return False, True, result
    except Exception, e:
        destroy_kerberos_ticket()
        return e


def whats_check_hostname(params):
    """
    :param params: ansible role variables
    :return: IDM API call to check if hostname is already enroled
    """
    warnings.simplefilter('ignore', urllib3.exceptions.SecurityWarning)
    ipa_version = "2.112"
    ipa_method = "iru_host_exists"
    hostname = params['whats_hostname']
    environment = params['whats_environment']

    generate_kerberos_ticket(environment)

    url = SETTINGS['url_{}'.format(environment)]
    headers = {"Referer": url, "Content-type": "application/json",
               "Accept": "application/json"}
    kerberos_auth = HTTPKerberosAuth(mutual_authentication=REQUIRED)

    data = {
        "id": 0,
        "method": ipa_method,
        "params": [
            [
                hostname
            ],
            {
                "version": ipa_version
            }
        ]
    }
    try:
        r = requests.post(url=url, auth=kerberos_auth, data=json.dumps(data),
                          verify=False, headers=headers)
        result = {"status": r.status_code, "data": r.json()}
        destroy_kerberos_ticket()
        return False, True, result
    except Exception, e:
        destroy_kerberos_ticket()
        return e


def main():
    """
    :return: role entry point
    """
    fields = {
        "whats_hostname": {"required": True, "type": "str"},
        "whats_ip": {"required": False, "type": "str"},
        "whats_trigram": {"required": False, "type": "str"},
        "whats_environment": {
            "default": "prd",
            "choices": ['dev', 'hml', 'prd'],
            "type": "str",
            "required": False,
        },

        "state": {
            "default": "present",
            "choices": ['present', 'absent', 'check_ip', 'check_hostname'],
            "type": 'str'
        },
    }

    choice_map = {
        "present": whats_present,
        "absent": whats_absent,
        "check_ip": whats_check_ip,
        "check_hostname": whats_check_hostname,
    }

    module = AnsibleModule(argument_spec=fields)

    isError, logOutput, output = default_config(module.params)

    if isError:
        module.fail_json(msg=logOutput)

    is_error, has_changed, result = choice_map.get(
        module.params['state'])(module.params)

    if not is_error:
        module.exit_json(changed=has_changed, meta=result)
    else:
        module.fail_json(msg="Error, failed request", meta=result)


SETTINGS = {}

if __name__ == '__main__':
    main()

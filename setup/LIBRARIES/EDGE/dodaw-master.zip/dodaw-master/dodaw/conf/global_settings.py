'''
Default settings. Override these with settings in the .cfg file pointed to
by the DODAW_CONFIG_FILE environment variable.
'''

DEBUG = False


URL = ''
DOD_V1_URL = ''
DNS_SERVICE = '' # PRD2 France RET, UAT France RET

###############
# CREDENTIALS #
###############
CREDENTIALS_GROUP_MKT = 'mkt_dodv1'
CREDENTIALS_GROUP_RET = 'ret-dodv2'
ENV = ''

#################
# DOD REQUESTS #
#################

SEARCH_PAGE_SIZE = 1000 #1000 is the maximum accepted by Dod v2, for higher values, 1000 rows are returned only
DELETE_LIMIT_ROWS = 10
MAX_RETRIES_ERROR_500 = 3

###########
# LOGGING #
###########

# Custom logging configuration.
LOGGER_LEVEL = "WARN"

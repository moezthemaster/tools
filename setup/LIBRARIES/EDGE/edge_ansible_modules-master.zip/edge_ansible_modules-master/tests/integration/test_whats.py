
import os
import sys
# import pytest
import logging
import re

sys.path.append(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
)

from files.sg_gts_whats import IdmImpl
from edge.exception import EdgeException

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

HOSTNAME = 'dpgalxtestwhats004'
IP_ADDRESS = '1.2.3.4'
TRIGRAM = 'pga'

class TestWhats(object):
    def setup_method(self, method):
        print ("\n{}:{}".format(type(self).__name__, method.__name__))

    def test_create_whats_ok(self):
        idm = IdmImpl(HOSTNAME)
        res = idm.create_whats(
                whats_hostname=HOSTNAME,
                whats_ip=IP_ADDRESS,
                whats_trigram='pga',
            )
        idm.destroy_token()
        print(res)                 
        assert res['error'] == None

    def test_create_whats_already_enrolled(self):
        idm = IdmImpl(HOSTNAME)
        res = idm.create_whats(
                whats_hostname=HOSTNAME,
                whats_ip=IP_ADDRESS,
                whats_trigram='pga',
            )
        idm.destroy_token()
        print(res)                    
        assert res['error']['code'] == 4002

    def test_create_whats_already_enrolled_with_another_ip(self):
        idm = IdmImpl(HOSTNAME)
        res = idm.create_whats(
                whats_hostname=HOSTNAME,
                whats_ip='1.4.4.6',
                whats_trigram='pga',
            )
        idm.destroy_token()   
        print(res)         
        assert res['error']['code'] == 4002

    def test_create_whats_already_enrolled_with_another_hostname(self):
        idm = IdmImpl(HOSTNAME)
        res = idm.create_whats(
                whats_hostname='dpgalxtest',
                whats_ip=IP_ADDRESS,
                whats_trigram='pga'
            )
        idm.destroy_token()   
        print(res)         
        assert res['error']['code'] == 4002

    def test_check_whats_already_exists_ok(self):
        idm = IdmImpl(HOSTNAME)
        res = idm.check_whats(
                whats_hostname=HOSTNAME,
                whats_ip=IP_ADDRESS,
            )
        idm.destroy_token()   
        print(res)         
        assert res['status'] == 200

    def test_check_whats_already_exists_with_anoter_ip(self):
        idm = IdmImpl(HOSTNAME)
        res = idm.check_whats(
                whats_hostname=HOSTNAME,
                whats_ip='1.4.6.7',
            )
        idm.destroy_token()   
        print(res)         
        assert res['status'] == 202

    def test_check_whats_already_exists_with_anoter_hostname(self):
        idm = IdmImpl(HOSTNAME)
        res = idm.check_whats(
                whats_hostname='dpgalxtest',
                whats_ip=IP_ADDRESS,
            )
        idm.destroy_token()   
        print(res)         
        assert res['status'] == 201

    def test_delete_whats(self):
        idm = IdmImpl(HOSTNAME)
        res = idm.delete_whats(HOSTNAME)
        idm.destroy_token() 
        print(res)
        assert res['error'] == None

    def test_delete_whats_doesnt_exists(self):
        idm = IdmImpl(HOSTNAME)
        res = idm.delete_whats(HOSTNAME)
        idm.destroy_token() 
        print(res)
        assert res['error']['code'] == 4001

    def test_check_whats_doesnt_exists(self):
        idm = IdmImpl(HOSTNAME)
        res = idm.check_whats(
                whats_hostname=HOSTNAME,
                whats_ip=IP_ADDRESS,
            )
        idm.destroy_token()   
        print(res)         
        assert res['status'] == 200
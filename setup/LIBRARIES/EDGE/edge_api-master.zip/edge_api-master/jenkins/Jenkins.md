# Manual steps for Pipeline plugin

1. Add libraries to the server global shared libraries. This has to be done once per master, and requires admin rights
2. Configure credentials. This has to be done once per repo, by the team
3. Create the actual pipeline job. This has to be done by the team
4. Parametrize the Jenkinsfile. Has to be done by the team too.

The step 4 can problably be improved by us. Maybe 3 too.

Check properties and stuff. What is the issue with default parameters?

# Creating a release Job

Here is a way to do a release of your appli.

This job will update the version of your app, and add a tag on sGitHub.

For this :

1. Create a SSH key pair
1. In your repo, add a file _.bumpversion.cfg_ (see example in this repo)
2. Add it with Read/Write rights on your Git repository
3. In jenkins, create a job cloning your repo
4. Checkout to a specific local branch (master probably)
5. Add (something like) this in your job :
```
export PATH=/MSVPRDITB04/itbox/tools/python3/bin/:${PATH}

pip install -r requirements.txt
# Python soft to bump the current version of the project. Basically a maven release perform.
# It also commits and tag the repo. 
bumpversion ${BUMP}
# Writing into build.properties to pass the variable to other Jenkins steps
echo VERSION=`cat .bumpversion.cfg | grep 'current_version = ' | awk '{print $NF}'` > build.properties
```
7. Add a step *Inject environment variable* with a _Property file path_ set to ```$WORKSPACE/build.properties```
8. Add a post build step *Git Publisher* and push the tag _${VERSION}_ and the branch _master_ (target remote name is origin)

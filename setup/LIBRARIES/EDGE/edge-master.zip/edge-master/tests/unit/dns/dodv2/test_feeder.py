#!/usr/bin/python
# -*- coding: utf-8 -*-

#

import logging

import pytest

import edge.dns.dodv2.feeder
import edge.exception
from tests.mock.mock import MockDod

#logging.basicConfig(level=logging.DEBUG)

logger = logging.getLogger(__name__)


class MockedFeeder(edge.dns.dodv2.feeder.DnsFeeder, MockDod):
    def __init__(self, init_types, env, region_cloud, az_cloud, network_id, trigram, hostname=None):
        MockDod.__init__(self, init_types, hostname=hostname)
        edge.dns.dodv2.feeder.DnsFeeder.__init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname)

#mocked_dod_inits = ([], ['A'], ['PTR'], ['CNAME'], ['A','PTR'], ['A','CNAME'], ['PTR', 'CNAME'], ['A', 'PTR', 'CNAME'])
mocked_dod_inits = ((), ('A',), ('PTR',), ('A','PTR'))

HOSTNAME='dpgalx200'


@pytest.fixture(params=mocked_dod_inits)
def mocked_dod_init(request):
    return request.param


class TestDnsFeeder(object):
    def test_create_records_with_hostname(self, mocked_dod_init):
        feeder = MockedFeeder(init_types=mocked_dod_init, env='dev', region_cloud='EU France (Greater Paris)',
                              az_cloud='eu-fr-paris-1', network_id='CDN', trigram='pga', hostname=HOSTNAME)
        start = len(feeder.dns_database)
        response = feeder.run()
        end = len(feeder.dns_database)
        assert end - start == 3 - len(mocked_dod_init)
        #check ip address
        if 'A' in mocked_dod_init:
            assert feeder.ip_address == feeder.search_dns_record('A', **edge.dns.dodv2.feeder.KWARGS_SEARCH)[0]['ip']
        else:
            assert feeder.ip_address == feeder.record_A['ip']

    def test_create_records_without_hostname(self):
        feeder = MockedFeeder(init_types=[], env='dev', region_cloud='EU France (Greater Paris)',
                              az_cloud='eu-fr-paris-1', network_id='CDN', trigram='pga')
        start = len(feeder.dns_database)
        response = feeder.run()
        end = len(feeder.dns_database)
        assert end - start == 3
        assert feeder.ip_address == feeder.record_A['ip']

    def test_CNAME_exists_same_zone(self):
        feeder = MockedFeeder(init_types=('A','PTR','CNAME'), env='dev', region_cloud='EU France (Greater Paris)',
                              az_cloud='eu-fr-paris-1', network_id='CDN', trigram='pga', hostname=HOSTNAME)
        feeder.run()
        assert len(feeder.dns_database) == 3

    def test_CNAME_exists_different_zone(self):
        feeder = MockedFeeder(init_types=('A','PTR','CNAME'), env='dev', region_cloud='EU France (Greater Paris)',
                              az_cloud='eu-fr-paris-1', network_id='CITS_2', trigram='pga', hostname=HOSTNAME)
        start = len(feeder.dns_database)
        with pytest.raises(edge.exception.EdgeException):
            feeder.run()
        end = len(feeder.dns_database)
        assert end == start
        logger.debug('zone ' + feeder.dns_zone)
        logger.debug('fqdn ' + feeder.fqdn)
        logger.debug('hostname ' + feeder.hostname)

    def test_feed_dns_with_fake_hostname(self):
        try:
            MockedFeeder(
                init_types=('A','PTR','CNAME'), env='dev', region_cloud='EU France (Greater Paris)',
                az_cloud='eu-fr-paris-1', network_id='CITS_2', trigram='pga', hostname='fake_hostname'
            )
            assert False
        except Exception as err:
            assert "fake_hostname must match this regex '^(d|h|p)pga[a-zA-Z0-9_-]+$'" == err.args[0]

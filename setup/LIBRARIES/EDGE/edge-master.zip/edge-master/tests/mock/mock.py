#!/usr/bin/python
# -*- coding: utf-8 -*-

#

import re
import time
import struct
import socket
import logging

from edge.interfaces import Dod


logger = logging.getLogger(__name__)


def get_all_ip(subnet):
    """
    get all ip address for subnet
    eg:
    192.168.56.0/24 => yield 192.168.56.1 -> 192.168.56.254
    """
    (ip, cidr) = subnet.split("/")
    cidr = int(cidr)
    host_bits = 32 - cidr
    i = struct.unpack(">I", socket.inet_aton(ip))[0]
    start = (i >> host_bits) << host_bits
    end = i | ((1 << host_bits) - 1)
    for i in range(start, end):
        ip = socket.inet_ntoa(struct.pack(">I", i))
        if ip.endswith(".0") or ip.endswith(".255"):
            continue
        yield socket.inet_ntoa(struct.pack(">I", i))


def record_factory(record_type, hostname, id, dns_zone='ppr.cdn.socgen', alias=None, ip=None, **kwargs):
    record = {
        'domain': None,
        'protocol': None,
        'weight': None,
        'zone': dns_zone,
        'ip': ip,
        'hostname': hostname,
        'comments': '',
        'class': 'IN',
        'port': None,
        'alias': alias,
        'service': None,
        'text': None,
        'preference': None,
        'ttl': None,
        'hostname_fqdn': '{}.{}.'.format(hostname, dns_zone),
        'type': record_type,
        'id': id,
        'view': 'production'
    }
    return record


def remove_regexp(filter, record_type):
    filter['type'] = record_type[1:-1] if record_type[0] == '^' else record_type
    try:
        filter.pop('dns_service')
    except KeyError:
        pass
    try:
        filter.pop('view')
    except KeyError:
        pass
    try:
        filter['alias'] = filter['alias'][1:-1] if filter['alias'][0] == '^' else filter['alias']
    except KeyError:
        pass


class MockDod(Dod):

    _shared_database = []
    _LIST_NETWORK_SUBNET = set()
    _LIST_IP_RECORDED = set()
    _id = 0

    def __init__(self, init_types, hostname, share_database=False, shared_database=None):
        '''
        :param hostname: used to load the database with records from init_types
        :param init_types: a list of types (A, PTR, CNAME) to init the database
        '''
        self._next_id = 0
        if isinstance(shared_database, list):
            self._share_database = True
            self.dns_database = shared_database
            self.LIST_IP_RECORDED = self._LIST_IP_RECORDED
            self.LIST_NETWORK_SUBNET = self._LIST_NETWORK_SUBNET
        else:
            if share_database:
                self._share_database = True
                self.dns_database = self._shared_database
                self.LIST_IP_RECORDED = self._LIST_IP_RECORDED
                self.LIST_NETWORK_SUBNET = self._LIST_NETWORK_SUBNET
            else:
                self.dns_database = []
                self.LIST_IP_RECORDED = set()
                self.LIST_NETWORK_SUBNET = set()

        if hostname:
            for record_type in init_types:
                id = self.next_id
                record_type = record_type[1:-1] if record_type[0] == '^' else record_type
                record = record_factory(record_type, hostname, id, "ppr.cdn.socgen")
                if record_type == "A":
                    ip = self.get_next_free_ip_dod_v2("111.80.16.0/24")
                    self.LIST_IP_RECORDED.add(ip)
                    record = record_factory(record_type, hostname, id, "ppr.cdn.socgen", ip=ip)
                if record_type == "CNAME":
                    hostname_alias = "{}.{}.".format(hostname, "ppr.cdn.socgen")
                    record = record_factory(record_type, hostname_alias, id, "ppr.cdn.socgen", alias=hostname)
                self.dns_database.append(record)
                logger.debug(
                    'init database with record type {} for hostname {}, total in database {}'.format(record_type, hostname,
                                                                                                 len(
                                                                                                     self.dns_database)))

    @property
    def next_id(self):
        if hasattr(self, "_share_database"):
            MockDod._id += 1
            return MockDod._id
        else:
            self._next_id += 1
            return self._next_id

    def search_dns_record(self, record_type, **kwargs):
        ''' Fairly simple search method
        Warning: does not handle regexp, the filter is simplified instead'''
        response = []
        filter = dict(kwargs)
        filter.pop('dns_service')
        filter.pop('view')
        remove_regexp(filter, record_type)
        logger.debug('Search dns records with filter {}'.format(filter))
        for record in self.dns_database:
            if record["type"] == filter["type"]:
                if filter.get('hostname', None):
                    if re.search(r'{}'.format(filter["hostname"]), record["hostname"]):
                        if filter.get('zone', None):
                            if re.search(r'{}'.format(filter["zone"]), record["zone"]):
                                response.append(record)
                        else:
                            response.append(record)
                else:
                    if all(item in record.items() for item in filter.items()):
                        response.append(record)
        return response

    def create_dns_record(self, dns_service, record_type, zone, view, hostname, **kwargs):
        id = self.next_id
        logger.debug('id = {}'.format(id))
        record_type = record_type[1:-1] if record_type[0] == '^' else record_type
        if record_type == "A":
            ip = self.get_next_free_ip_dod_v2("111.80.16.0/24")
            self.LIST_IP_RECORDED.add(ip)
            record = record_factory(record_type, hostname, id, zone, ip=ip, **kwargs)
        else:
            kwargs["ip"] = None
            record = record_factory(record_type, hostname, id, zone, **kwargs)
        self.dns_database.append(record)
        logger.debug('Created - dns record type {}, id {}, total in database {}'.format(record_type, id, len(self.dns_database)))
        return record

    def get_next_free_ip_dod_v2(self, subnet):
        self.LIST_NETWORK_SUBNET.add(subnet)
        for ip in get_all_ip(subnet):
            if ip not in self.LIST_IP_RECORDED:
                return ip
        raise Exception("ip not found within subnet={}".format(subnet))

    def delete_dns_record(self, dns_service, id):
        logger.debug('Deleted - dns record id %s' % id)
        for record in self.dns_database:
            if record['id'] == id:
                if record["type"] == "A":
                    self.LIST_IP_RECORDED.remove(record["ip"])
                self.dns_database.remove(record)
                break

    def search_and_delete_dns_records(self, dns_service, record_type, limit_rows=10, **kwargs):
        records = self.search_dns_record(record_type, dns_service=dns_service, **kwargs)
        for record in records:
            self.delete_dns_record(dns_service, record['id'])
        if len(records) > 0:
            return True

    def update_record(self, dns_service, id, record_type, zone, view, hostname, ip, **kwargs):
        logger.debug('Updating - dns record id %s' % id)
        found = list(filter(lambda record: record["id"] == id, self.dns_database))
        index = list(map(lambda record: record["id"], self.dns_database)).index(id)
        found[0].update({
            'dns_service': dns_service,
            'type': record_type,
            'zone': zone,
            'view': view,
            'hostname': hostname,
            'ip': ip,
        })
        self.dns_database[index] = found[0]
        return True

    def search_and_update_conflict_dns_records(self, dns_service, record_type, cause, **kwargs):
        timestamp = time.time()
        kwargs["dns_service"] = dns_service
        records = self.search_dns_record(record_type, **kwargs)
        response = []
        for record in records:
            id = record['id']
            hostname = "edge_conflict_{}_{}".format(cause, int(timestamp))
            record_type = record['type']
            zone = record['zone']
            view = record['view']
            ip = record['ip']
            result = self.update_record(dns_service, id, record_type, zone, view, hostname, ip)
            response.append("{} : {} - {}".format(id, hostname, ip))
        return response

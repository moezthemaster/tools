#!groovy

Properties props = new Properties()
props.load(new StringReader(readFileFromWorkspace('jenkins/job.properties')))

String root = props.appName
String gitRepo = props.gitRepo
String gitOrga = props.gitOrga
String gitRepository = props.gitRepository
String genericCreds = props.xldCreds
String gitCreds = props.gitCreds
String adGroup = props.adGroup

folder("${root}") {
    authorization {
        permissionAll("${adGroup}")
    }
}

multibranchPipelineJob("${root}/${root}") {
    branchSources {
        github {
            scanCredentialsId(genericCreds)
            repoOwner(gitOrga)
            repository(gitRepository)
            apiUri('https://sgithub.fr.world.socgen/api/v3/')
        }
    }
    orphanedItemStrategy {
        discardOldItems {
            numToKeep(5)
        }
    }
}

pipelineJob("${root}/GenerateDev") {
    parameters {
        stringParam('VM_HOSTNAME')
        stringParam('DEPLOYMENT_FOLDER')
        stringParam('BRANCH', 'master')
    }

    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(gitRepo)
                        credentials(gitCreds)
                    }
                }
            }
            scriptPath('jenkins/Jenkinsfile-generate-dev.groovy')
        }
    }
}

pipelineJob("${root}/GenerateDevItaas") {
    parameters {
        stringParam('DEPLOYMENT_FOLDER')
        stringParam('BRANCH', 'master')
    }

    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(gitRepo)
                        credentials(gitCreds)
                    }
                }
            }
            scriptPath('jenkins/Jenkinsfile-generate-dev-itaas.groovy')
        }
    }
}

pipelineJob("${root}/Promote") {
    parameters {
        stringParam('SOURCE', 'DEV')
        stringParam('DESTINATION', 'UAT')
        stringParam('APPLI', 'sample')
    }

    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(gitRepo)
                        credentials(gitCreds)
                    }
                }
            }
            scriptPath('jenkins/Jenkinsfile-promote.groovy')
        }
    }
}

pipelineJob("${root}/Release") {
    parameters {
        stringParam('RELEASE_TYPE', 'patch')
        stringParam('BRANCH', 'master')
    }

    definition {
        cpsScm {
            scm {
                git {
                    remote {
                        url(gitRepo)
                        credentials(gitCreds)
                    }
                }
            }
            scriptPath('jenkins/Jenkinsfile-release.groovy')
        }
    }
}

#!/usr/bin/env python
# -*- coding: utf-8 -*-

''' Analyze Errors from KPI '''

__author__ = "Feature Team Edge"
__version__ = "0.1.0"

import argparse
import json
import configparser
from datetime import date, timedelta, datetime
import time
from elasticsearch import Elasticsearch
#import xlsxwriter
import logging
import logzero
import socket
import paramiko
from paramiko.ssh_exception import BadHostKeyException, AuthenticationException, SSHException
import getpass
from logzero import logger
from operator import itemgetter


class KPI_Analyser(object):
    def __init__(self, cred_file, cred_section, server, **kwargs):
        config = configparser.ConfigParser()
        config.read(cred_file)

        user = config[cred_section]['username']
        password = config[cred_section]['password']

        self._es = Elasticsearch(
            [server], http_auth=(user, password),
            scheme="http", port=443,
            )
        self._args = kwargs

    def find_a4c_log_dir(self, trigram, server):
        username = self._args.get('remote_user', None)
        if username is None:
            username = getpass.getuser()
        keyfile = self._args.get('a4c_key', None)

        # Open a SSH connection to A4C VM
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            if keyfile is not None:
                client.connect(hostname='peatlx20.dns20.socgen', username=username, key_filename=keyfile)
            else:
                client.connect(hostname='peatlx20.dns20.socgen', username=username)
            command = "grep -ri {} /applis/eatp/logs/ansible/{}*/GTSCompute_* | cut -d':' -f1 | while read file; do dirname $file; done |  sort | uniq | while read file; do stat -c '%n:%Y' $file; done".format(server, trigram.upper())
            stdin, stdout, stderr = client.exec_command(command)
            res = stdout.read()
            client.close()
            return res
        except (BadHostKeyException, AuthenticationException, SSHException, socket.error) as e:
            print(e)
 
    def search_json_file(self, filename, timestamp_start, timestamp_end):
        with open(filename) as json_data:
            d = json.load(json_data)
            for q in d['query']['bool']['must']:
                if 'range' in q:
                    q['range']['timestamp']['gte'] = timestamp_start
                    q['range']['timestamp']['lte'] = timestamp_end
            res = self._es.search(index='edge', body=d)
            logger.info("%d documents found" % res['hits']['total'])
            return res

    def output_csv(self, filename):
        logger.info("output csv")
        sorted_records = sorted(self._records, key=itemgetter('datetime')) 
        for r in sorted_records:
            print("{};{};{};{};To be categorized;{};{};Edge accountable ?;".format(r['week'],
                                          datetime.strftime(r['datetime'], "%B %d %Y %H:%M:%S.%f"), 
                                          r['hostname'], 
                                          r['client'], 
                                          r['error'],
                                          r.get('status', "Check logs for analysis")))


    def output_xls(self, filename):
        logger.info("output xls")

    def output(self, filename):
        if self._args['output'] == 'xls':
            self.output_xls(filename)
        elif self._args['output'] == 'csv':
            self.output_csv(filename)


    def format_records(self, elk_res):
        self._records = []
        for doc in elk_res['hits']['hits']:
            record = {}
            record['timestamp'] = doc['_source']['timestamp']
            if record['timestamp']:
                logger.debug("Timestamp = {}".format(record['timestamp']))
                if record['timestamp'][-1] == 'Z':
                   record['timestamp'] = record['timestamp'][:-1] + 'UTC'
                try:
                    record['datetime'] = datetime.strptime(record['timestamp'], "%Y-%m-%dT%H:%M:%S.%f%Z" )
                except ValueError:
                    try:
                        record['datetime'] = datetime.strptime(record['timestamp'], "%Y-%m-%dT%H:%M:%S" )
                    except:
                        raise
                record['week'] = record['datetime'].isocalendar()[1]
                record['unix_ts'] = int(time.mktime(record['datetime'].timetuple()))
                record['unix_ts'] += 3600 #Add one hour correction for UTC 
            record['hostname'] = doc['_source']['hostname']
            record['client'] = doc['_source']['client']
            record['error'] = doc['_source']['error']
            if record['client'] == 'ITIM':
                logfiles = self.find_a4c_log_dir(doc['_source']['trigram'], record['hostname'])
                best_log_time = 0
                best_log_delta = 1000000
                best_log_name = ""
                if logfiles:
                    for line in logfiles.splitlines():
                        values = line.split(':')
                        #print(values[0], int(record['unix_ts']), values[1])
                        delta = int(values[1]) - int(record['unix_ts'])
                        if delta > 0 and delta < best_log_delta:
                            best_log_delta = delta
                            best_log_time = int(values[1])
                            best_log_name = values[0]
                    record['status'] = 'https://peatlx20.dns20.socgen/' + best_log_name[18:]
                    # print("best timestamp = {}, logfile : {}".format(best_log_time, record['status']))
            self._records.append(record)


def init_logger(level):
    ''' Init logger base on level specified.'''
    if level is None:
        level = 0
    if level >= 2:
        logzero.loglevel(level=logging.DEBUG)
    elif level == 1:
        logzero.loglevel(level=logging.INFO)
    else:
        logzero.loglevel(level=logging.WARNING)

def main(args):
    ''' Main function for analyzer.'''
    init_logger(level=args.verbose)

    if args.date:
        try:
            search_day = datetime.strptime(args.date, '%d%m%y')
        except ValueError:
            logger.error("Date value should be in format %d%m%y, ex 070318")
            return
    else:
        # by default search for yesterday
        search_day = date.today() - timedelta(1)

    analyser = KPI_Analyser('/etc/ansible/gts_edge_credentials.cfg', 
                            'ELASTIC_PROD_CREDENTIALS', 
                            'ppgalx002.dns20.socgen', **vars(args))

    start = int(time.mktime(search_day.timetuple()) * 1000)
    end = int(time.mktime((search_day + timedelta(1)).timetuple()) * 1000 - 1)
    try:
        res = analyser.search_json_file(filename='request.json', timestamp_start=start, timestamp_end=end)
        analyser.format_records(res)
        analyser.output(args.output_file)
    except:
       raise

if __name__ == '__main__':
    """ This is executed when run from the command line """

    parser = argparse.ArgumentParser()

    # Optional verbosity counter (eg. -v, -vv, -vvv, etc.)
    parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Verbosity (-v, -vv, etc)")

    # Specify output format
    parser.add_argument(
        "-d", "--date",
        type=str,
        help="Date for the extract. By default previous day is analyzed")

    # Specify output format
    parser.add_argument(
        "-o", "--output",
        type=str, choices=[ "csv", "xls" ], default="csv",
        help="Type of output, csv or excel file")

    # Specify output file
    parser.add_argument(
        "-f", "--output_file",
        type=str,
        help="Name for the output file")

    # Specify private ssh key for A4C logs
    parser.add_argument(
        "-k", "--a4c_key",
        type=str,
        help="private key file to connect to a4c")

    # Specify remote user
    parser.add_argument(
        "-r", "--remote_user",
        type=str,
        help="remote user to connect to a4c")

    # Specify output of "--version"
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s (version {version})".format(version=__version__))

    args = parser.parse_args()
    main(args = args)


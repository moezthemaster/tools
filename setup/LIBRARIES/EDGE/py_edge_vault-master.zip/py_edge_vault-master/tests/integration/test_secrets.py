import pytest
import requests

from py_edge_vault import secrets

from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
requests.packages.urllib3.disable_warnings()

COMMAND_STATIC = 'static'
COMMAND_DYNAMIC = 'dynamic' 

class Test_vault_secrets(object):
    def test_get_good_secrets(self):
        data = secrets.get_secrets(context='test_context', env='uat')
        response = {"password":"dummy","username":"test"}
        assert data == response

    def test_get_bad_secrets(self):
        with pytest.raises(Exception) as e:
            data = secrets.get_secrets(context='test_context')
            assert  'No data found in vault' in str(e.value)



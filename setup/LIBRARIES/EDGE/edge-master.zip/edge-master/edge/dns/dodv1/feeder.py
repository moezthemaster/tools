#!/usr/bin/python
# -*- coding: utf-8 -*-

import logging

from edge.conf import settings
from edge.conf.cloud_network import get_details
from edge.dns.dodv2.hostname import is_valide_hostname
from edge.exception import EdgeException

from . import mixins

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


class DnsFeeder(mixins.Mixin):

    def __init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname):
        is_valide_hostname(trigram, hostname)
        self.env = env
        self.trigram = trigram
        self.hostname = hostname
        cloud_network_dict = get_details(env, region_cloud, az_cloud, network_id)
        if cloud_network_dict.get("network_tag", None) != "mkt":
            raise EdgeException(
                "combination env={}, region_cloud={}, az_cloud={}, network_id={} is not a network mkt".format(
                    env, region_cloud, az_cloud, network_id
                )
            )
        self.domain = cloud_network_dict["dns_zone"]
        self.subnet = cloud_network_dict["network_cidr"]
        self.ipRange = "srv"
        self.inA = True
        self.inPTR = True
        self.ip = ""
        self.ttl = ""
        self.force = False
        self.fqdn = "{}.{}.".format(self.hostname, self.domain)
        self.alias_zone = "dns20.socgen" if self.env.lower().startswith("p") else "dns21.socgen"
        self.changed = False

    def _record_cname(self, retries=15):
        for num in range(1, (retries + 1)):
            logger.debug("Essay num°{}: try to record CNAME field for hostname={} in DodV2".format(
                num, self.hostname)
            )
            try:
                cname = self._search_cname()
                if not cname:
                    created = self.create_dns_record(
                        record_type="CNAME",
                        alias=self.hostname,
                        hostname=self.fqdn,
                        zone=self.alias_zone,
                        dns_service=settings.DOD_DNS_SERVICE,
                        view="production"
                    )
                    assert created["alias"] == self.hostname
                    logger.debug("Success to record CNAME field for hostname={} in DodV2".format(
                        self.hostname)
                    )
                break
            except Exception:
                pass

    def _rollback(self):
        '''
        Clean records created previously, CNAME record is cleaned first for dependencies
        :return: None
        '''
        logger.debug('Rollback started')
        try:
            records = self._search_cname()
            if len(records) >= 10:
                raise Exception('Too many cname for deleting for hostname={} in DodV2'.format(self.hostname))
            for record in records:
                if record:
                    self.delete_dns_record(
                        dns_service=settings.DOD_DNS_SERVICE, id=record['id']
                )
        except Exception as err:
            logger.error('Rollback has raised an exception: {}'.format(err.args[0]))
            raise Exception('Rollback has raised an exception: {}'.format(err.args[0]))
        logger.debug('Rollback ended correctly')

    def _feed_dns(self, retries=15):
        host_infos = dict()
        for num in range(1, (retries + 1)):
            try:
                logger.debug("Essay num°{}: try to record fields={} for hostname={}".format(
                    num, self._get_fields(), self.hostname)
                )
                search = self.host_search_infos(self.hostname)
                if search:
                    host_infos["output"] = [
                        {
                            "ip": search[0].infos.ip,
                            "hostname": search[0].infos.hostname,
                            "domain": search[0].infos.domain,
                            "zone": search[0].infos.domain,
                            "reverse": search[0].infos.reverse,
                            "map_filename": search[0].infos.map_filename
                        }
                    ]
                    host_infos["ip_address"] = search[0].infos.ip
                    host_infos["subnet"] = self.subnet
                    host_infos["fqdn"] = "{}.{}".format(self.hostname, self.domain)
                    self._record_cname()
                    return host_infos
                created = self.host_add(
                    self.hostname, self.domain, self.subnet, ipRange=self.ipRange,
                    inA=self.inA, inPTR=self.inPTR, ip=self.ip, ttl=self.ttl, force=self.force
                )
                if created:
                    logger.debug("Essay num°{}: success to record fields={} for hostname={}".format(
                        num, self._get_fields(), self.hostname)
                    )
                    result = self.host_search_infos('{}'.format(self.hostname))
                    host_infos["output"] = [
                        {
                            "ip": result[0].infos.ip,
                            "hostname": result[0].infos.hostname,
                            "domain": result[0].infos.domain,
                            "zone": result[0].infos.domain,
                            "reverse": result[0].infos.reverse,
                            "map_filename": result[0].infos.map_filename
                        }
                    ]
                    host_infos["ip_address"] = result[0].infos.ip
                    host_infos["subnet"] = self.subnet
                    host_infos["fqdn"] = "{}.{}".format(self.hostname, self.domain)
                    self._record_cname()
                    self.changed = True
                    return host_infos
            except Exception as err:
                if "The Ip" in err.args[0]:
                    logger.warn("Essay num°{} for hostname={}: {}".format(num, self.hostname, err.args[0]))
                    if self.ip != "":
                        self.ip = ""
                # for debug in mode devel
                # raise Exception(err.args[0])
        self._rollback()
        try:
            self.get_next_free_ip(self.subnet, subnetUse=self.ipRange)
        except Exception as err:
            if "ip not found" in err.args[0]:
                raise EdgeException(err.args[0])
        logger.error("Maximum attempts for recording dns for hostname={}".format(self.hostname))
        raise EdgeException(
            "Maximum attempts for recording dns for hostname={}".format(
                self.hostname
            )
        )

    def run(self):
        return self._feed_dns()

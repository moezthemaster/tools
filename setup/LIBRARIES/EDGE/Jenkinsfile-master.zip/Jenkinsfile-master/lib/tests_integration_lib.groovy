#!groovy
import static sgcib.coc.bootcamp.Git.*
import static sgcib.coc.bootcamp.Maven.*

class Utils2 {
    static Properties readProperties(script, String file, String default_file) {
        Properties default_props = new Properties()
        String default_prop_file = script.readFile default_file
        default_props.load (new StringReader(default_prop_file))

        Properties props = new Properties()
        String prop_file = script.readFile file
        props.load (new StringReader(prop_file))
        
        Properties merged = new Properties();
        merged.putAll(default_props);
        merged.putAll(props);
        merged
    }
}

def tests_integrations_lib(String script_path, Boolean toStage) {
	properties = Utils2.readProperties(this, 'jenkins/job.properties', "${script_path}/conf/default.properties",)
	String tests_integration_path = WORKSPACE + properties.tests_integration_path 
	

	def files = sh(script: "ls ${tests_integration_path} | grep ^[0-9]*_[A-z0-9]*.py | sort -n > listFiles", returnStdout: true)
	def tests_py = readFile( "listFiles" ).split( "\\r?\\n" );

	if(tests_py.size() == 1  && tests_py[0] == ""){
		println "No integrations tests founds in ${tests_integration_path}"
	}
	else{
		if(toStage){
			tests_py.each {
				stage("${it}"){
					sh """
						python ${tests_integration_path}${it}
					"""
					}
				}
		}else{
			tests_py.each {
				sh """
					python ${tests_integration_path}${it}
				"""		
			}
		}
	}

}

return this.&tests_integrations_lib

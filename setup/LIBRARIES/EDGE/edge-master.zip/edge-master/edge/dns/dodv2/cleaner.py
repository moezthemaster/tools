#!/usr/bin/python
# -*- coding: utf-8 -*-

#

DOCUMENTATION = '''




'''

EXAMPLES = '''
    see test_dns_feeder.py
'''

import re
import logging

import edge.interfaces
from edge.conf import settings
from edge.exception import EdgeException


KWARGS_SEARCH = {
    'dns_service':settings.DOD_DNS_SERVICE,
    'view': 'production',
}
A='A'
DEFAULT_IP_ADDRESS = '127.0.0.1'
DEFAULT_FQDN = 'localhost.localdomain'


logger = logging.getLogger(__name__)


class DnsCleaner(edge.interfaces.Dod):
    def __init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname):
        try:
            assert re.search(r'^edge_conflict_(ssh|rdp|whats)_[0-9]+$', hostname) or hostname.isalnum()
        except:
            raise EdgeException("hostname must be alphanumeric")
        self.trigram = trigram
        self.hostname = hostname
        cloud_network_dict = edge.conf.cloud_network.get_details(env, region_cloud, az_cloud, network_id)
        self.network_cidr = cloud_network_dict['network_cidr'] #other name: vm_subnet
        self.dns_zone = cloud_network_dict['dns_zone']
        self.changed = False

    def run(self):
        '''
        When VM is deleted, delete A record, PTR and CNAME.
        If error when VM is deleted, roll back DNS removed previously.
        :return: dict
        '''
        types_hosts = [
            ('CNAME', '^%s.%s.$' % (self.hostname, self.dns_zone)),
            ('PTR', '^%s$' % self.hostname),
            ('A', '^%s$' % self.hostname),
        ]
        
        for record_type, host in types_hosts:
            logger.debug('Deleting record type {} for hostname {}'.format(record_type, host))
            deleted = self.search_and_delete_dns_records(
                record_type='^{}$'.format(record_type),
                dns_service=settings.DOD_DNS_SERVICE,
                hostname=host,
                view='production'
            )
            if deleted:
                self.changed = True
        response = self._get_response()
        return response

    def _get_response(self):
        '''
        This class is a Mixin for other classes that inherit from edge.interfaces.Dod and
        handle the attribute self.records which is a dictionary
        :param vm_subnet:
        :return: a dictionary
        '''
        records_A_found = self.search_dns_record(
            record_type=A,
            hostname='^%s$' % self.hostname,
            dns_service=settings.DOD_DNS_SERVICE,
            view='production'
        )
        ip_addr = DEFAULT_IP_ADDRESS
        fqdn = DEFAULT_FQDN
        record_A_id = ''
        for record_A in records_A_found:
            ip_addr = record_A.get('ip', DEFAULT_IP_ADDRESS)
            fqdn = record_A.get('hostname_fqdn', DEFAULT_FQDN)
            if not record_A_id:
                record_A_id = record_A.get('id', '')
        response = {
            'output': records_A_found,
            'id': record_A_id,
            'ip_address': ip_addr,
            'subnet': self.network_cidr,
            'fqdn': fqdn,
        }
        return response
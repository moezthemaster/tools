Role Patrol_agt
=========

Creating a Patrol Agent.

This role is a prerequisite of applicative monitoring role

If no action is specified when calling this role, it will execute the following action :

**create.yml** : Creating Patrol Agent


Here's a description of the other task that can be executed in this role, filling the *patrol_action* with the name of the task requested :

**configure.yml** : Configuring Patrol Agent 

* Starting Patrol Agent
* Sending system stantard monitoring configuration to Patrol Agent
* Adding Patrol Agent to Monitoring Infrastructure
* Adding workinstruction for this server (optional)


**delete.yml** : Removing Patrol Agent

* Removing Patrol agent from Monitoring Infrastructure


This role is developped for **FastIT & PAAP projects**. Some updates may have to be done for other needs : contact us :email: list.FR-RET-edge-automation@socgen.com, or Fork it.


Requirements
------------

Facts gathering shouldn't be disabled.

Target servers must be Linux.

The role [role_patrol_fs](https://sgithub.fr.world.socgen/GTS-MFI-COMPOSANTS-EDGE/role_patrol_fs) is a pre-requisite to this role. You need to run it first.

When executing action "delete", a "delete" action should be executed from role [role_patrol_fs](https://sgithub.fr.world.socgen/GTS-MFI-COMPOSANTS-EDGE/role_patrol_fs) after this one.

Role Variables
--------------

Here are the requested values for each action :

**create.yml**

- `vm_hostname : 'server_to_monitor'`

**configure.yml**

- `vm_hostname : 'server_to_monitor'`
- `pat_envi : in 'dev','hml','prd','Developpement','Homologation','Production','Secours'`
- `pat_timeout : Time to wait for the patrol registration (by default 60->5min) (optionnal)`
- `pat_wiHO : action for Working Hour in 'JUMP', 'no_action' (optionnal)`
- `pat_wiHNO : action for Non Working Hour 'JUMP', 'CALL', 'no_action' (optionnal)`
- `pat_wigroup : the JUMP group (optionnal) by default 'KAT' (using the JUMP group in KAT)`
- `pat_witag : 'TAG_GIVEN_BY_SAO_TEAM' (optionnal) by default 'RETGDEVOPS001' (generic workinstruction for devops server)`
- `pat_witimeframe : in '*' (without non working hour) or 'heures_ouvrees' ( Working Hour from 8 AM to 6 PM in paris time set by default) (optionnal)`

**start.yml**

- `vm_hostname : 'server_to_monitor'`

**stop.yml**

- `vm_hostname : 'server_to_monitor'`

**delete.yml**

- `vm_hostname : 'server_to_monitor'` 
- `validate_decomissioning: yes`
- `pat_envi : in 'dev','hml','prd','Developpement','Homologation','Production','Secours'`

Dependencies
------------

None

Example Playbook
----------------


     - hosts: servers
      gather_facts: yes
      roles:
       - { role: role_patrol_agt,
           patrol_action: "create",
           vm_hostname: "server_to_monitor",
         }
       - { role: role_patrol_agt,
           patrol_action: "start",
           vm_hostname: "server_to_monitor",
         }
       - { role: role_patrol_agt,
           patrol_action: "configure",
           pat_envi: "Developpement",
           vm_hostname: "server_to_monitor",
         }


Thresholds
-------

See the below link : 
[Monitoring System Thresholds](https://sbc.safe.socgen/docs/DOC-283417)


Generated Alarms
----------------


    host      |objectClass    |object       |parameter    |parameterValue     |message  
    *         |CPU            |CPU          |CPUSharedPoolIdleTimeNorm  |*      |The available CPU pool is almost empty (%mc_parameter_value% \% remaining) 
    *         |PROCPRES       |*          |PROCPPCountCheck     |*      |The process \"%mc_object%\" is missing or wrong number of instances | In PatrolCentralWeb (link below): see Infobox of the process => Command field
    *         |PROCPRES       |*          |PROCPPMem          |*      |The process \"%mc_object%\" uses too much memory (at least %mc_parameter_value% kb)
    *         |POOL           |*          |POOLCpuUtil        |*      |The available CPU for Solaris 10 pool %mc_object% is almost empty (%mc_parameter_value% \% used)
    *         |CPU            |*          |CPUUtilPerVCpu       |*      |The micro-partition reached %mc_parameter_value%\% (Virtual CPU) 
    *         |CPU            |*          |CPUCpuUtil         |*      |CPU used at %mc_parameter_value%\% 
    *         |CPU            |*          |CPUSysTime         |*      |System CPU time reached %mc_parameter_value%\% 
    *         |CPU            |*          |CPUWio           |*      |I/O CPU time reached %mc_parameter_value%\% 
    *         |CPU            |*          |CPULoad          |*      |CPU load is too high (load: %mc_parameter_value%) 
    *         |CPU            |*          |CPUUserTime        |*      |CPU time used for the Users reached %mc_parameter_value%\% 
    *         |CPU            |*          |CPUVMCpuUtil       |*      |The CPU of the VM reached %mc_parameter_value%\% (Virtual CPU) 
    *         |CPU            |*          |CPURunQSize        |*      |RunQ is too high (%mc_parameter_value%) 
    *         |SMP            |*          |SMPIdlePercent       |*      |Power available is low on the processor %mc_object% (%mc_parameter_value%\% free) 
    *         |FILESYSTEM     |*          |FSMountStatus        |1      |FS %mc_object% unmounted 
    *         |FILESYSTEM     |*          |FSMountStatus        |2      |The mounting of the FS %mc_object% is in an unknown status 
    *         |FILESYSTEM     |*          |FSMountStatus        |*      |The FS %mc_object% has a mounting problem (status = %mc_parameter_value%) 
    *         |FILESYSTEM     |*          |FSCapacity         |*      |FS %mc_object% is filling up (at least %mc_parameter_value%\%) 
    *         |FILESYSTEM     |*          |FSCapacity         |100    |FS %mc_object% full (100\%) 
    *         |FILESYSTEM     |*          |FSInodeUsedPercent     |*      |There almost no more inodes available in the FS %mc_object% (at least %mc_parameter_value%\% used) 
    *         |FILESYSTEM     |*          |FSInodeUsedPercent     |100    |There no more inodes available in the FS %mc_object% (at least %mc_parameter_value%\% used) 
    *         |FILESYSTEM     |*          |FSAvailableSpaceMB     |0      |FS %mc_object% full (0Mb available) 
    *         |FILESYSTEM     |*          |FSAvailableSpaceMB     |*      |FS %mc_object%  is filling up (no more than %mc_parameter_value%Mb available) 
    *         |KERNEL       |*          |*              |*      |Kernel configuration problem 
    *         |MEMORY       |*          |MEMUsedMemPerc       |*      |Memory used at %mc_parameter_value%\% 
    *         |MEMORY       |*          |MEMFreeMem         |*      |%mc_parameter_value% memory pages available 
    *         |MEMORY       |*          |MEMPageFreed       |*      |Problem of Memory Pages release 
    *         |MEMORY       |*          |MEMPageIn          |*      |The machine lacks memory and paginates too much (%mc_parameter_value% pages entering the Swap every second) 
    *         |MEMORY       |*          |MEMPageOut         |*      |The machine lacks memory and paginates too much (%mc_parameter_value% pages exiting the Swap every second) 
    *         |MEMORY       |*          |MEMAppUsablePerc     |0      |The real memory available to applications is empty (0\%) 
    *         |MEMORY       |*          |MEMAppUsablePerc     |*      |The real memory available to applications is too low (less than %mc_parameter_value%\%) 
    *         |NFS        |*          |*              |*      |NFS degraded performances 
    *         |PROCESS      |*          |PROCNoZombies        |*      |There are %mc_parameter_value% zombie processes 
    *         |PROCPRES     |*          |PROCPPCPUPerc        |*      |CPU overconsumption of the process %mc_object% 
    *         |PROCPRES     |*          |PROCPPCount        |*      |There is %mc_parameter_value% process %mc_object% 
    *         |PROCESS_MONITOR  |*          |nbProcess          |*      |There is %mc_parameter_value% process %mc_object% 
    *         |SWAP       |*          |SWPTotSwapUsedPercent    |*      |The swap is used excessively (full at %mc_parameter_value% \%)
    *         |DCM        |*          |ProcessCollStatus      |*      |Patrol: defect on the collector DCM-%mc_parameter% 
    *         |DCM        |*          |MemCollStatus        |*      |Patrol: defect on the collector DCM-%mc_parameter% 
    *         |DCM        |*          |SwapCollStatus       |*      |Patrol: defect on the collector DCM-%mc_parameter% 
    *         |DCM        |*          |KernelCollStatus     |*      |Patrol: defect on the collector DCM-%mc_parameter% 
    *         |DCM        |DCM        |DCMStatus          |0      |Patrol: The agent collects its parameters normally 
    *         |DCM        |DCM        |DCMStatus          |*      |Patrol: defect on DCM collectors 
    *         |COLLECTORS     |*          |*              |*      |Patrol: defect on PSL collectors 
    *         |PRINTER      |*          |PRNQLength         |*      |%mc_parameter_value% application jobs stuck in the print queue %mc_object% 


Troubleshooting
---------------

In case of troubleshooting or for more information, you contact the Feature Team EDGE :email: list.fr-ret-edge-automation@socgen.com


Author Information
------------------

Yanis BEKRAR

        
        

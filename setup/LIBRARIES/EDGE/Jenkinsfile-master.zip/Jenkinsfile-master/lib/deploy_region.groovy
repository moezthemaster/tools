#!groovy
import static sgcib.coc.bootcamp.Git.*
import static sgcib.coc.bootcamp.Maven.*
import static java.util.Calendar.YEAR
import static java.util.Calendar.DATE
import groovy.json.JsonSlurperClassic

@NonCPS
def jsonParse(String json) {
  def object = new JsonSlurperClassic().parseText(json)
//   if(object instanceof groovy.json.internal.LazyMap) {
//       return new HashMap<>(object)
//   }
  return object
}

def call(String script_path, String region,String env, String version, Boolean rollback) {
    properties = Utils.readProperties(this, 'jenkins/job.properties', "${script_path}/conf/default.properties",)

    String appName = properties.appName
    String artifactoryUrl = properties.artifactoryUrl
    String artifactoryCreds = properties.artifactoryCreds

    def pythonPath = properties.pythonPath

    String sgConnectCreds =properties.sgConnectCreds

    Map infra = null

    def env_bg = [
        "DEV" : "BG_GTS-MKT-CLO",
        "UAT" : "BG_GTS-MKT-CLO",
        "PRD" : "BG_GTS-MKT-CLO_PRD"
    ]

    def region_domain = [
        "eu-fr-paris":"eur.msd.world.socgen",
        "eu-fr-north":"eur.msd.world.socgen",
        "hk-hongkong":"asi.msd.world.socgen",
        "us-east-newyork":"ame.msd.world.socgen"
    ]

    if(rollback==true){
        error("Build aborted. Rollback currently not implemented")
        version = rollbackTag
    }else{
        stage("${env}:${region}:Deploy Infrastructure (VM+LB)"){
            withEnv(["PATH+PYTHON=${pythonPath}"]){
                withCredentials([usernamePassword(credentialsId: artifactoryCreds, passwordVariable: 'ARTI_PASSWORD', usernameVariable: 'ARTI_USER')]){	
                    def bg = env_bg[env]
                    def domain = region_domain[region]			
                    sh "tepid --vra-login '${ARTI_USER}' --vra-password '${ARTI_PASSWORD}' --vra-domain ${domain} --vra-business-group ${bg} ${appName} ${version} ${env} etc/IaC/${env}/${region}.yaml --deploy"
                    def infraSTR = sh(script: 'cat ${WORKSPACE}/infra.json', returnStdout: true)
                    def infraJSON = jsonParse(infraSTR)
                    infra = [:]
                    infra.putAll(infraJSON)
                }
            }
        }
      
        stage("${env}:${region}:Applying puppet module"){
            withEnv(["PATH+PYTHON=${pythonPath}"]){
                withCredentials([usernamePassword(credentialsId: sgConnectCreds, passwordVariable: 'SGCONNECT_PASSWORD', usernameVariable: 'SGCONNECT_USER')]){
                    withCredentials([usernamePassword(credentialsId: artifactoryCreds, passwordVariable: 'ARTI_PASSWORD', usernameVariable: 'ARTI_USER')]){
                        infra["vm"].each { vmName ->
                            FILE_PATH = "etc/IaC/${env}/puppet.json"
                            FILE_PATH_OUTPUT = "etc/IaC/${env}/puppet-${vmName}.json"
                            file = readFile "${FILE_PATH}"
                            newConfig = file.replace("{{ VM_HOSTNAME }}", "${vmName}")
                            writeFile file: "${FILE_PATH_OUTPUT}", text: newConfig
                            gts_itaas clientIDSGConnect: "${SGCONNECT_USER}", clientSecretSGConnect: "${SGCONNECT_PASSWORD}", iacFile: "${FILE_PATH_OUTPUT}", login: "${ARTI_USER}", password: "${ARTI_PASSWORD}"
                        }
                    }
                }
            }
        }
            
        //sleep(200)

        stage("${env}:${region}:Configuring these servers"){
            withCredentials([usernamePassword(credentialsId: artifactoryCreds, passwordVariable: 'ARTI_PASSWORD', usernameVariable: 'ARTI_USER')]){
                infra["vm"].each {
                    sshagent(['49602051-83ef-46b3-867b-3e87950d7f90']) {
                        sh """ssh -oStrictHostKeyChecking=no -T cldprd03@${it} '
                        pkill python
                        virtualenv PythonEnv
                        curl -s -u "${ARTI_USER}":"${ARTI_PASSWORD}" -O 'https://cdp-artifactory.fr.world.socgen/artifactory/pypi-local-resg-gts-mkt-cld/${appName}/${version}/${appName}_${version}.tar.gz'
                        cp -r /SERVICE/python .
                        mkdir '${appName}'
                        tar -xf '${appName}'_${version}.tar.gz -C '${appName}'
                        tar -xf '${appName}'/site-packages.tar.gz -C python/lib/python3.6
                        rm '${appName}'/site-packages.tar.gz

                        curl -s -u "${ARTI_USER}":"${ARTI_PASSWORD}" -O 'https://cdp-artifactory.fr.world.socgen/artifactory/pypi-local-resg-gts-mkt-cld/PythonEnv/python2/site-packages.tar.gz'
                        tar -xf site-packages.tar.gz -C PythonEnv/lib/python2.7/
                        mkdir -p var/lock
                        mkdir -p var/log/'${appName}''"""
                        sh """scp -r -oStrictHostKeyChecking=no /CLDPRDAP192/work/configs/${appName}/${env}/${region}/* cldprd03@${it}:${appName}/ | true"""
                        sh """ssh -oStrictHostKeyChecking=no -T cldprd03@${it} '
                        chmod +x '${appName}'/setup_temp.sh
                        cd '${appName}'
                        ./setup_temp.sh
                        cd ..
                        source PythonEnv/bin/activate
                        python PythonEnv/lib/python2.7/site-packages/supervisor/supervisord.py -c '${appName}'/etc/supervisor/supervisor.conf | true
                        '
                        """
                    }
                }			
            }
        }

        stage("${env}:${region}:Changing lease and disabling old RS"){
            withEnv(["PATH+PYTHON=${pythonPath}"]){
                withCredentials([usernamePassword(credentialsId: artifactoryCreds, passwordVariable: 'ARTI_PASSWORD', usernameVariable: 'ARTI_USER')]){
                    def bg = env_bg[env]
                    def domain = region_domain[region]

                    infra["lb"].each { lbName ->
                        print(lbName)
                        def lbSTR = sh(script: "vra lb show --vra-login '${ARTI_USER}' --vra-password '${ARTI_PASSWORD}' --vra-domain ${domain} --vra-business-group ${bg} ${lbName} --full --format json", returnStdout: true)
                        print(lbSTR)
                        def lbJSON = jsonParse(lbSTR)
                        def dateOld = new Date()
                        def dateNew = new Date()
                        dateOld[DATE] = dateOld[DATE] + 3
                        dateNew[YEAR] = dateNew[YEAR] + 10
                        dateOld = dateOld.format("YYYY-MM-dd")
                        dateNew = dateNew.format("YYYY-MM-dd")
                        lbJSON["Real Servers"].each { vmInfo ->
                            def vmName = vmInfo.value["name"]
                            print(vmName)
                            print(infra["vm"])
                            print(dateNew)
                            if (vmName in infra["vm"]) {
                                sh(script:  "vra vm lease change --vra-login '${ARTI_USER}' --vra-password '${ARTI_PASSWORD}' --vra-domain ${domain} --vra-business-group ${bg} ${vmName} ${dateNew} | true", returnStdout: true)
                            } else {
                                sh(script: "vra lb rs remove --vra-login '${ARTI_USER}' --vra-password '${ARTI_PASSWORD}' --vra-domain ${domain} --vra-business-group ${bg} ${lbName} ${vmName} | true", returnStdout: true)
                                sh(script:  "vra vm lease change --vra-login '${ARTI_USER}' --vra-password '${ARTI_PASSWORD}' --vra-domain ${domain} --vra-business-group ${bg} ${vmName} ${dateOld} | true", returnStdout: true)
                            }
                        }
                    }
                }
            }
        }    
    }    
}

return this.&call

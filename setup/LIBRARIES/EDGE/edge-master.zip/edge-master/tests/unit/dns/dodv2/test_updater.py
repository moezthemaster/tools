
import logging

import pytest

from tests.mock.mock import MockDod
from edge.dns.dodv2.updater import DnsUpdater

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

LIST_HOSTNAMES = ('dpgalx200',)

mocked_dod_inits = (('A',),)


@pytest.fixture(params=mocked_dod_inits)
def mocked_dod_init(request):
    return request.param


class MockedUpdater(MockDod, DnsUpdater):

    def __init__(self, init_types, env, region_cloud, az_cloud, network_id, trigram, hostname):
        MockDod.__init__(self, init_types, hostname=hostname)
        DnsUpdater.__init__(
            self, env=env, region_cloud=region_cloud, az_cloud=az_cloud,
            network_id=network_id, trigram=trigram, hostname=hostname
        )


class TestDnsUpdater:

    def test_update_dns_with_fake_hostname(self, mocked_dod_init):
        try:
            MockedUpdater(
                init_types=mocked_dod_init, env='dev', region_cloud='EU France (Greater Paris)',
                az_cloud='eu-fr-paris-1', network_id='CITS_2', trigram='pga', hostname='fake_hostname'
            )
            assert False
        except Exception as err:
            assert "fake_hostname must match this regex '^(d|h|p)pga[a-zA-Z0-9_-]+$'" == err.args[0]
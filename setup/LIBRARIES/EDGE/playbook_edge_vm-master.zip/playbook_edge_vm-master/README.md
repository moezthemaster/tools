<h1>Playbook Edge VM</h1>
=========

These playbooks can be used to create, configure and delete an Edge VM in the GTS cloud. 

WARNING: The creation and destruction of up to 10 VM in parallel have been tested and validated with these playbooks. Above that number, creation is not warranted.

<h2>Creation process: <b>create.yml</b></h2>

The creation process includes :
- DNS record managment, 
- VM creation in the GTS cloud, 
- Installation of automation key
- Network configuration
- Whats enrolment, 
- Marley registration, 

in this precise order. None of these steps can be skipped.

Any error in one of these steps triggers a rollback of all the steps, trying to exit with the exact same state as before the call.

<h2>Calcul hostname</h2>

Le calcul de hostname coté ex-RET est pris en charge par le code ci-dessous quand le client ne fournit pas de hostname pour la création de vm.
https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge/blob/master/edge/dns/dodv2/hostname.py

Ce calcul est determiné en prenant en compte l'ensemble des hostnames présents dans le dod et incrémente selon le premier slot disponible.
C'est à dire si nous avons trois hostnames terminant par 001, 002, 003 le prochaint sera 004.
Si nous avons trois hostnames terminant par 001, 002, 004 le prochaint sera 003.

Pareil pour la cloudcell qui utilise le même système.

Générallement côté ex-ret, c'est le réseau CITS qui est plein au niveau des adresses ip disponibles.

Pour le moment les réseaux ex-Mkt ne disposent pas de calcul de hostname automatique, le client doit fournir obligatoirement un hostname. Ceci est due au fait que Pgaas était le premien client pour le déploiement des vms coté ex-MKT et eux ils prennent en charge ce calcul automatique de hostname avant de le fournir à notre service.

<h2>Configuration process: <b>configure.yml</b></h2>

Configuration consists of :
- Patrol installation, if input variable vm_supervision is set to "patrol",
- Filesystem creation, if input variable is set,
- Basic sudoers configuration,
- Flexera installation
in this order. 

During the step of configuration, multiple users might be created:
- patrol: Used to start the patrol agent, and allow the patrol console to connect to the agent

In addition to these users, there are others who come with the template:
- flexera: Allow the flexera agent to connect to oracle databases to inventory products installed on the server (Configured to nologin)
- automation: Used by the VM Create Requester to access it.
- intadm: Edge service account that is used to perform VM post provisioning actions
- tower_admin: Used to deploy automation key on legacy servers (Core) **Will be deleted next Sprint**

<h2>Deletion process: <b>delete.yml</b></h2>

Deletion of an Edge VM is done in this order :
- Check if vm_pubkey is conform to the one installed on the VM,
- Uninstallation of patrol, if vm_supervision is set to "patrol",
- Unregister from Marley,
- Unregister from Whats,
- Deletion of VM in cloud,
- Removal of records in DNS

Any error in one of these steps triggers a rollback of all the steps, trying to exit with the exact same state as before the call (i.e. in the worst case, it can trigger a recreation of the VM).




<h2>Inputs create.yml</h2>

|   Variable           | Description                                |choices                     |default                |  Required         |
|:-----------------:|:---------------------------------------------:|:--------------------------:|:---------------------:|:------------------|
|  vm_hostname      | Your Server name                              |                            |    " "                |    False           |
|  vm_desc          | Your server description                       |                            |    " "                |    False           |
|  app_id           | Your applicative trigram                      |                            |                       |    True           |
|  vm_pubkey          | Your public key                      |         |                  |    True          |
|  app_env          | Your server environement                      |  'dev', 'hml', 'prd'       |    'prd'              |    False          |
|  code_irt          | Your applicative code                       |                            |                    |    True           |
|  deprecated_endClient          | Fallback client value    |  See below for detailed explanation |                    |  False          |
|  vm_profile       | Your server profile                           | [Profiles](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge/wiki/GTS_Profiles)       | Micro 1vCPU-1GB       |    False          |
|  vm_network        | Your server network                            | Networks [ex-RET](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge/wiki/GTS-NETWORKS#available-regions-azs-and-networks-ex-ret) and [ex-MKT](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge/wiki/GTS-NETWORKS#available-regions-azs-and-networks-ex-mkt)                          |                       |    True          |
|  vm_region        | Your server region                            | [EU France (Greater Paris), EU France (North)](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge/wiki/GTS-NETWORKS)                            | EU France (Greater Paris)                      |    False          |
|  vm_az            | Your server Availability zone                 | [eu-fr-paris-1, eu-fr-paris-2, eu-fr-north-1](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge/wiki/GTS-NETWORKS)                           | "eu-fr-paris-1"                      |    False          |
|  vm_os            | Your server operationg system                 | [OS Blueprints](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/edge/wiki/GTS_os_blueprints)       | "CENTOS_7.5_x64-RET-EDGE"                       |    False          |
|  data_disk        | Your server data disk size                    | 0, 20, 60, 160, 300, 500, 750, 1000, 2000                           |       0                |    False          |
|  vm_supervision   | Supervision product to configure   |    "none", "patrol", "zabbix"                        |    undefined                   |    False          |
|  fs_list   | Dictionnary of filesystems to create   |                            |     undefined                  |    False          |
|  vm_replication   | Replication state for the server   |    True , False                        |    False                   |    False          |
|  vm_backup        | Backup mode for the server   | 'none', 'daily-31d-2AM', 'daily-31d-4AM'                           |    none                   |    False          |

<h2>Inputs delete.yml and delete_mkt.yml</h2>

|   Variable           | Description                                |choices                     |default                |  Required         |
|:-----------------:|:---------------------------------------------:|:--------------------------:|:---------------------:|:------------------|
|  vm_hostname      | Your Server name                              |                            |                    |    True           |
|  code_irt          | Your applicative code                       |                            |                    |    True           |
|  app_id           | Your applicative trigram                      |                            |                       |    True           |
|  vm_pubkey          | Your public key                      |         |                  |    True          |
|  deprecated_endClient          | Fallback client value    |  See below for detailed explanation |                    |  Optional          |
|  vm_supervision   | Supervision product to configure   |    "none", "patrol","zabbix"                       |    undefined                   |    Optional          |

All other parameters which may be passed as input will not generate errors, but will simply be ignored.

<h2>Extra informations</h2>

- [Creation of vm in ex-MKT](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/playbook_edge_vm/wiki/How-to-create-EDGE-vm-in-ex-mkt-networks-%3F)

- Creation and configuration can be combined by using the playbook <b>create_full.yml</b>

- create_ITIM.yml, configure_ITIM.yml and delete_ITIM.yml are specifically designed to be called from cloudify. They must not be used from Ansible Tower or with ansible-playbook.

- deprecated_endClient is used as a fallback value when the ME client found in KAT does not contain ITIM, BSC, GTS or ITEC (SGCIB). It is not used if a value can be extracted from the trigram definition.

- You can find informations about other roles used during provisionning, or roles available for customization in the [wiki page](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/playbook_edge_vm/wiki) of this repository

<h2>Example input file</h2>

    ---
    app_env: 'dev'
    app_id: 'pga'
    code_irt: 'A7048'
    #deprecated_endClient: 'GTS'
    data_disk: '20'
    vm_az: 'eu-fr-paris-1'
    vm_desc: 'Test RET-859'
    vm_hostname: ''
    vm_network: 'CITS_2'
    vm_profile: 'Micro 1vCPU-1GB'
    vm_region: 'EU France (Greater Paris)'
    vm_supervision: 'patrol'
    vm_os: 'CENTOS_7.0_x64-RET-EDGE'
    vm_pubkey: 'ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAyLXUQ9eoPr8Akx+WeJzRgAOMyUbTQ3/RDu44N2svQTa7I0ZKzqelNrSqqsgSmNN7giQGRyIvx/XgUwi9UjrxFX0XRTvwjAcXNHV2pxybbhPb8/2jiAfFTCjkwQBwtoSTEL1I5noAIgapQDZghYFkv0GUiAkebKzl0A+cNqm5Zc2UXXXXXXXXXX5Uid+XOdECHan29Iyow0f+O/2O6mZKBGvWFJbRLCokKLUrTmhbgWIiWgQGp/PnF0XVVPiQgRfbRz1xH08JNiQz1lnvZ4ME4BhQoxSK1O8QL+dQsSXhvQyjfO8yYI+X4X73Ie9yBfZpPiGAZLo3hTVha46veVfZGw== '
    vm_backup: 'none'
    vm_replication: False

    fs_list:
       - { mountpoint: "/produits/patrol", size: "3G" }

This file can then be injected in Ansible Tower job extra vars, or as extra vars file with ansible-playbook.

<h2>How create and delete vm in cloudcell ?</h2>

[Here, the provisionning of vm in cloudcell](https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/playbook_edge_cloudcell_vm)

<h2>Add disk on virtual machine</h2>
To add a disk on an existant virual machine, you can use the playbook sg_gts_add_storage.

Variables:

    vm_hostname: your target machine
    disk_size: the disk size that you want to add

<h2>License</h2>
BSD

<h2>Author Information</FONT></h2>

GTS Feature Team


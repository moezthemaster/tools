#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
import socket

@then('VM is not registered in DNS')
def step_impl(context):
    print("Check DNS for VM {}, IP {}\n".format(context.params['vm_hostname'], context.params['vm_ipaddr']))
    try:
        addr = socket.gethostbyname(context.params['vm_hostname'])    
        if addr == context.params['vm_ipaddr']:
          # si adresse trouvée on sort en erreur
          assert context.failed is True
        else:
          assert context.failed is False

    except:
      assert context.failed is False



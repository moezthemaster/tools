#!/usr/bin/python
# -*- coding: utf-8 -*-

import logging

import pytest
import unittest
try:
    from unittest import mock
except ImportError:
    import mock
import requests
from py_edge_vault import secrets
from tests.mock.dodaw import DodDatabase, mock_vault, mock_request_get, mock_request_post, mock_request_put, mock_request_delete
from dodaw.dod import DodWrapper
from dodaw.conf import settings

HOSTNAME = 'dpgalxtest4100'

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class TestDod(unittest.TestCase):
    dod_db = DodDatabase()
    db = dod_db.database

    @mock.patch('requests.post')
    @mock.patch('py_edge_vault.secrets.get_secrets')
    def test_create_record(self, mock_creds, mock_post):
        mock_creds.return_value = mock_vault()
        mock_post.return_value = mock_request_post(hostname=HOSTNAME, shared_db=self.__class__.db)
        dod = DodWrapper()
        record_created = dod.create_record(record_type='A',
                                    dns_service=settings.DNS_SERVICE,
                                    hostname=HOSTNAME,
                                    view='production',
                                    zone='dns21-3.socgen',
                                    ip_subnet='111.80.16.0/22',
                                    ip_range='server')
        assert record_created['hostname'] ==  HOSTNAME

    @mock.patch('requests.delete')
    @mock.patch('requests.put')
    @mock.patch('requests.get')
    @mock.patch('py_edge_vault.secrets.get_secrets')      
    def test_search_and_update_and_delete(self, mock_creds, mock_get, mock_put, mock_delete):

        mock_creds.return_value = mock_vault()
        mock_get.return_value = mock_request_get(hostname=HOSTNAME, shared_db=self.__class__.db)

        dod = DodWrapper()
        records_found = dod.search_record(record_type='A',
                        dns_service=settings.DNS_SERVICE,
                        hostname=HOSTNAME,
                        view='production')
        assert records_found != []

        update_data = {
            'dns_service': settings.DNS_SERVICE,
            'id' : records_found[0]['id'],
            'record_type' : records_found[0]['type'],
            'zone' : records_found[0]['zone'],
            'ip' : records_found[0]['ip'],
            'hostname':HOSTNAME+"_updated",
            'view': u'production'
        }

        mock_put.return_value = mock_request_put(data=update_data, shared_db=self.__class__.db)

        record_updated = dod.update_record(
                            dns_service=update_data['dns_service'],
                            id = update_data['id'],
                            record_type = update_data['record_type'],
                            zone = update_data['zone'],
                            ip = update_data['ip'],
                            hostname=update_data['hostname'],
                            view=update_data['view'],
        )
        assert record_updated[0]['hostname'] == HOSTNAME+"_updated"

        mock_delete.return_value = mock_request_delete(id=record_updated[0]['id'], shared_db=self.__class__.db)

        dod.delete_record(settings.DNS_SERVICE, record_updated[0]['id'])

    @mock.patch('requests.get')
    @mock.patch('py_edge_vault.secrets.get_secrets')  
    def test_search_no_record_found(self, mock_creds, mock_get):
        mock_creds.return_value = mock_vault()
        mock_get.return_value = mock_request_get(hostname=HOSTNAME, shared_db=self.__class__.db)
        dod = DodWrapper()
        with pytest.raises(Exception):
            dod.search_record(record_type='A',
                              dns_service=settings.DNS_SERVICE,
                              hostname=HOSTNAME,
                              view='production'
            )

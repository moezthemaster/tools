VAULT_CONFIG = {
    'application': 'edge-001',
    'role_id': 'edge-001-login-read',
    'vault_url': 'https://vault-prod.fr.world.socgen/v1',
    'vault_context': 'tower'
}

ANSIBLE_TOWER_CONFIG = {
    'ansible_tower_base_url': 'https://tower32.safe.socgen/api/v1',
    'job_template_create_edge_vm': 1121,
    'job_template_delete_edge_vm': 1122
}

#!/usr/bin/python
# -*- coding: utf-8 -*-

#
import unittest
import pytest

from edge.inventory.cloud_vra_inventory import Extractor
from . import mock_vra_catalog

# dict1 = {u'ppgalx001': {
#     'comment': u'Test new template EDGE',
#     'blueprint': u'RHEL_7.2_x64-RET-EDGE',
#     'bg': u'BG_GTS-RET',
#     'ip': u'192.197.96.136',
#     'creation': u'2017-03-07T14:10:45.725Z',
#     'expiration': u'2027-10-07T15:25:03.663Z',
#     'env': 'UAT'}
# }


class MockedExtractor(Extractor, mock_vra_catalog.MockCloudVra):
    pass


class TestExtractor(object):
    def test_get_cloud_inventory(self):
        extractor = MockedExtractor(trigram='pga',
                                    env='dev',
                                    api_env='PROD')
        result = extractor.get_cloud_inventory()
        assert "192.88.70.137" in result["dpgalx001"].values()
        assert "Test new template EDGE" in result["dpgalx001"].values()
        assert "dpgalx001" in result.keys()
        assert "ip" in result["dpgalx001"].keys()

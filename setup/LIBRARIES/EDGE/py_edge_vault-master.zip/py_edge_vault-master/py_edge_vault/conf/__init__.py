'''
Settings and configuration for Edge.
Read values from the .py file specified by the EDGE_CONFIG_FILE environment variable,
 and then from edge.conf.global_settings.
See the global_settings.py for a list of all possible variables.
'''

import os

try:
    import ConfigParser
except ImportError:
    import configparser as ConfigParser

import py_edge_vault.conf.global_settings
from py_edge_vault.exception import ImproperlyConfigured


ENVIRONMENT_VARIABLE = 'VAULT_CONFIG_FILE'
SECTION_NAME = 'VAULT'


class Settings(object):
    def __init__(self):
        '''
        Load settings from global_settings then override the settings module pointed to by the environment variable.
        '''
        settings_cfg_file = os.environ.get(ENVIRONMENT_VARIABLE)
        if not settings_cfg_file:
            raise ImproperlyConfigured(
                'Requested settings, but settings are not configured. '
                'You must define the environment variable %s to point to a settings file '
                'and override global_settings.py'
                % ENVIRONMENT_VARIABLE)
        # update this object from global settings (but only for ALL_CAPS settings)
        for setting in dir(global_settings):
            if setting.isupper():
                setattr(self, setting, getattr(global_settings, setting))
        # update this object from settings cfg file

        parser = ConfigParser.SafeConfigParser()

        parsed_files = parser.read(settings_cfg_file)
        if not parsed_files:
            raise ImproperlyConfigured('Cannot find or access file {}'.format(settings_cfg_file))
        try:
            for (key, val) in parser.items(SECTION_NAME):
                setattr(self, key.upper(), val)
        except ConfigParser.NoSectionError as e:
            raise ImproperlyConfigured('Section [{}] not found in file {}'.format(SECTION_NAME, settings_cfg_file))

settings = Settings()

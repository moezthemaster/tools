Role Patrol_ism
=========

Monitor an url using the Patrol Agent.

This role is an applicative monitoring role

If no action is specified when calling this role, it will execute the following action :

**create.yml** : Installing the KM files needed by the Patrol Agent


Here's a description of the other task that can be executed in this role, filling the *patrol_action* with the name of the task requested :

**configure.yml** : Configuring Patrol Agent to monitor url

* Starting Patrol Agent
* Sending system standard monitoring configuration for url to Patrol Agent
* Restarting the Patrol Agent


**delete.yml** : Removing the url monitoring from Patrol Agent

* Removing url monitoring from Patrol agent


This role is developed for **FastIT & PAAP projects**. Some updates may have to be done for other needs : contact us :email: List.FR-Admin-Monitoring-L3@socgen.com, or Fork it.


Requirements
------------

Facts gathering shouldn't be disabled.

Target servers must be Linux.

Patrol Agent should be install and add to the monitoring infra.


Role Variables
--------------

Here are the requested values for each action :

**create.yml**


**configure.yml**

| Variable                      | Required          |  Description                                              |
|:-----------------------------:|:-----------------:|:----------------------------------------------------------|
| pat_hostname                  | Yes               | Name of the web server                                    |
| pat_protocole                 | Yes               | 'http' or 'https'                                         |
| pat_ip                        | Yes               | IP adress of the web server                               |
| pat_label                     | Yes               | label of the url (ie. website_domaineSPV)                 |
| pat_url                       | Yes               | the url you need to monitor ( ie. / or /admin)            |
| pat_port                      | Yes               | Port of the url server                                    |
| pat_expression                | No                | Searching expression in the monitored webpage (by default '200 OK'). if you want to monitor json like '"toto":"titi"' you need to escape special character so you need to write '\\\"toto\\\":\\\"titi\\\"'`      |
| pat_severity_pagestatus       | No                | This parameter indicates the URL status (warning, or critical). Default value is critical|
| pat_severity_httpmonitor      | No                | The httpMonitor parameter performs client connections to an HTTP-based Web server. If the httpMonitor parameter encounters an error or warning, the textual of the problem is set as the parameter's value. The parameter then issues an alarm or warning for the duration of the problem. Default value is critical|
| pat_severity_contentstatus    | No                | This parameter indicates the URL status (warning, or critical). Default value is critical                                    |

If you want to monitor multiple URL's, you need to create a list variable `pat_list_url` which takes the configure variables as values.

Example:
```yaml
pat_list_url:
#First URL to monitor
- pat_hostname : 'Name of the web server'
  pat_protocole: 'http or https'
  pat_ip : 'first IP address'
  pat_label : 'first label'
  pat_url : 'first url'
  pat_port : 'first port'
  pat_severity_pagestatus: 'first severity pagestatus'
#Second URL to monitor
- pat_hostname : 'Name of the web server'
  pat_protocole: 'http or https'
  pat_ip : 'second IP address'
  pat_label : 'second label'
  pat_url : 'second url'
  pat_port : 'second port'
  pat_severity_pagestatus: 'second severity pagestatus'
```
for more comprehension, see the playbook example (Monitor multiple URL's).

**delete.yml**

- `pat_label : label of the url (ie. website_domaineSPV)`

Dependencies
------------

None

Example Playbook
----------------
Monitor one URL:
```yaml
- hosts: server_to_monitor
  gather_facts: yes
  roles:
    - { role: role_patrol_ism,
             patrol_action: "create",
         }
    - { role: role_patrol_ism,
           patrol_action: "configure",
           pat_hostname: "pnetreloaded.dns22.socgen",
           pat_protocole: "HTTPS",
           pat_ip: "192.64.10.96",
           pat_label: "url_domaineSPV",
           pat_url: "/",
           pat_port: "443",
           pat_expression: "\\\"Database\\\":\\\"OK\\\"",
      }
```

Monitor multiple URL's:
```yaml
- hosts: server_to_monitor
  gather_facts: yes
  vars:
    pat_list_url:
        #First URL to monitor
        - pat_hostname : 'dpgalx005'
          pat_protocole: 'https'
          pat_ip : '127.0.0.1 '
          pat_label : 'ism_test1'
          pat_url : '/'
          pat_port : '8443'
          pat_severity_pagestatus: 'warning'
          
        #Second URL to monitor
        - pat_hostname : 'pbox.si.socgen'
          pat_protocole: 'http'
          pat_ip : '192.131.14.79'
          pat_label : 'maintenance'
          pat_url : '/BEM_MAINTENANCE'
          pat_port : '80'
          pat_expression: "\\\"Database\\\":\\\"OK\\\""
          pat_severity_httpmonitor: 'warning'
          
        #Third URL to monitor
        - pat_hostname : 'pnetreloaded'
          pat_protocole: 'https'
          pat_ip : '192.64.10.96'
          pat_label : 'pnetreloaded'
          pat_url : '/'
          pat_port : '443'
          pat_expression: 'OK'
          pat_severity_contentstatus: 'warning'
  roles:
    - { role: role_patrol_ism, patrol_action: "create"}
    - { role: role_patrol_ism, patrol_action: "configure"}
```
Stop monitoring one URL's:
```yaml
- hosts: server_to_monitor
  gather_facts: yes
  roles:
    - { role: role_patrol_ism,
              patrol_action: "delete",
              pat_label: "url_domaineSPV"  }

```

Stop monitoring multiple URL's:
```yaml
- hosts: server_to_monitor
  gather_facts: yes
  roles:
    - { role: role_patrol_ism,
              patrol_action: "delete",
              pat_label:["ism_test1", "maintenance", "pnetreloaded"]  }

```
or:
```yaml
- hosts: server_to_monitor
  gather_facts: yes
  vars:
    pat_label:
      # List of multiple URLs to stop monitoring
      - ism_test1
      - maintenance
      - pnetreloaded
  roles:
    - { role: role_patrol_ism, patrol_action: "delete" }

```

Thresholds
-----------

| CLASS       | Parametre  | Unité   | Homo     | Prod              | 
|:-----------:|:----------:|:-------:|:--------:|:-----------------:| 
| INET_Web_Application | pageStatus  | 0=OK</br>1=WARN</br>2=ALARM | 1 to 1:Warn after 5min </br> 2 to 2:Alarm after 5 min | 1 to 1:Warn after 5min </br> 2 to 2:Alarm after 5 min | 
| INET_Web_Application | pageContentStatus  | 0=OK1</br>=Not OK   | ≠ 0 :Alarm after 5 min | > 0 :Alarm after 5 min | 
|  INET_Web_Server   | httpMonitor  | 0=OK</br>1=Not OK  | ≠ 0 :Alarm after 5 min  | > 0 :Alarm after 5 min  | 
| INET_Web_Server  | certDaysLeft   | Day   | 2 to 31 : Warn  </br> 0 to 1 :Alarm  | 2 to 31 : Warn  </br> 0 to 1 :Alarm  | 
| INET_Dns_Server  | dnsStatus | 0=OK</br>1=Not OK      | ≠ 0 :Alarm | > 0 :Alarm  | 
| INET_Dns_Server  | dnsDownTime | Seconds | 5 to 100 :Warn   </br>  > 100 :Alarm | 5 to 100 :Warn   </br>  > 100 :Alarm | 
| INET_Dns_Server | dnsResponseTime | Milliseconds | 300 to 6000:Warn </br>  > 6000 :Alarm | 300 to 6000:Warn </br>  > 6000 :Alarm | 
| INET_Dns_Remote | remoteDnsStatus | 0=OK</br>1=Not OK | ≠ 0 :Alarm | > 0 :Alarm | 
| INET_Dns_Remote | remoteDnsDownTime  | Seconds | 5 to 100 :Warn   </br>  > 100 :Alarm  | 5 to 100 :Warn   </br>  > 100 :Alarm | 
| INET_Dns_Remote | remoteDnsResponseTime | Milliseconds | 300 to 6000:Warn </br>  > 6000 :Alarm  | 300 to 6000:Warn </br>  > 6000 :Alarm  | 
| INET_Dns_Application | dnsCheckStatus | 0=OK</br>1=Not OK | > 0 :Alarm after 3 min | > 0 :Alarm after 3 min | 
| INET_Dns_Application | dnsCheckContentStatus | 0=OK</br>2=Not OK | ≠ 0 :Alarm after 3 min | > 0 :Alarm after 3 min | 
| INET_Dns_Application | dnsCheckDownTime | Seconds | 5 to 100 :Warn   </br>  > 100 :Alarm | 5 to 100 :Warn   </br>  > 100 :Alarm | 
| INET_Dns_Application | dnsCheckResponseTime  | Milliseconds | 300 to 6000:Warn </br>  > 6000 :Alarm | 300 to 6000:Warn </br>  > 6000 :Alarm | 
| INET_Portmon_Inst | portDownTime | Seconds | > 5000 :Alarm |  > 5000 :Alarm | 
| INET_Portmon_Inst | portStatus | 0=OK</br>1=Not OK  | ≠ 0 :Alarm after 10 min | > 0 :Alarm after 10 min | 
| INET_Ldap_Server | ldapDownTime | Seconds | > 5000 :Alarm | > 5000 :Alarm | 
| INET_Ldap_Server | ldapStatus | 0=OK</br>1=Not OK | ≠ 0 :Alarm after 10 min | > 0 :Alarm after 10 min | 

Generated Alarms
----------------


    host      |objectClass    |object       |parameter    |parameterValue     |message  
    *       |INET_WEB_AccLog    |*        |*              |*      |Defect detected on AccessLog of the WEB server %mc_object% 
    *       |INET_Web_Application |*        |httpDownTime       |*      |No response of the Web server %mc_object% 
    *       |INET_Web_Application |*        |pageDownTime       |*      |No response of a page on the Web server %mc_object% 
    *       |INET_Web_Application |*        |pageStatus         |2      |Page inaccessible on the Web server %mc_object%
    *       |INET_Web_Application |*        |pageStatus         |1      |The Web server %mc_object% responds with an incorrect HTTP code
    *       |INET_Web_Application |*        |pageStatus         |0      |Valid status of a page on the Web server %mc_object%
    *       |INET_Web_Application |*        |pageContentStatus      |*      |The Web page %mc_object% does not contain the expected result
    *       |INET_Web_Server    |*        |*              |*      |Check the operation of the Web server on %mc_object%
    *       |INET_Web_Server    |*        |HttpError          |*      |Error detected in the errorlog of the Web server on %p_origin%
    *       |INET_Web_Server    |*        |pageStatus         |2      |Page inaccessible on Web server %mc_object%
    *       |INET_Web_Server    |*        |pageStatus         |1      |The Web server %mc_object% responds with an incorrect HTTP code
    *       |INET_Web_Server    |*        |pageStatus         |0      |Normal status page on WEB server %mc_object%
    *       |INET_Web_Server    |*        |httpMonitor        |*      |Problem detected on HTTP monitor of the WEB server %mc_object% on %p_origin%
    *       |INET_Web_Server    |*        |httpStatus         |*      |Invalid status of the Web server %mc_object%
    *       |INET_Web_Server    |*        |httpBusyThreads      |*      |Overconsumption of threads on the WEB server %mc_object%
    *       |INET_Web_Server    |*        |certDaysLeft       |*      |The SSL certificate of the WEB server %mc_object% will expire in %mc_parameter_value% days
    *       |INET_MS_ASP      |*        |AspRuntimeErrorRate    |*      |Abnormal ASP error rate on IIS server
    *       |INET_MS_ASP      |*        |AspRqtQueued       |*      |ASP engine of IIS server is overloaded (at least %mc_parameter_value% \% of the total of the requests put in the queue)
    *       |INET_Web_ErrLog    |*        |*              |*      |An error was detected in the errorlog of the WEB server %mc_object%
    *       |INET_Dns_Remote    |*        |remoteDnsStatus      |*      |A DNS server (%mc_object%) does not respond
    *       |INET_Dns_Remote    |*        |remoteDnsResponseTime    |*      |A DNS server (%mc_object%) responds too slowly
    *       |INET_Dns_Remote    |*        |remoteDnsDownTime      |*      |A remote DNS server (%mc_object%) cannot be reached
    *       |INET_Dns_Remote    |*        |*              |*      |A DNS server (%mc_object%) has problems
    *       |INET_Dns_Server    |*        |*              |*      |Defect on the local DNS server (%mc_object%)
    *       |INET_Dns_Application |*        |dnsCheckContentStatus    |*      |The local DNS server (%mc_object%) does not respond properly to a query
    *       |INET_Dns_Application |*        |dnsCheckStatus       |*      |The local DNS server (%mc_object%) does not respond to a query
    *       |INET_Dns_Application |*        |dnsCheckDownTime     |*      |A DNS request (%mc_object%) still does not respond correctly after %mc_parameter_value% s
    *       |INET_Dns_Application |*        |dnsCheckResponseTime   |*      |The local DNS server (%mc_object%) responds too slowly to a query
    *       |INET_Ftp_Server    |*        |*              |*      |The FTP server on %p_origin% is in defect
    *       |INET_Ftp_Server    |*        |ftpDownTime        |*      |The FTP server on %p_origin% is inaccessible
    *       |INET_Ftp_Server    |*        |ftpStatus          |*      |The FTP server on %p_origin% is in defect
    *       |INET_Mail_Server   |*        |*              |*      |The MAIL server on %p_origin% is in defect
    *       |INET_Portmon_Inst    |*        |portStatus         |*      |No more response from the listen port %mc_object%
    *       |INET_Portmon_Inst    |*        |portDownTime       |*      |No more response from the listen port %mc_object% for %mc_parameter_value% seconds
    *       |INET_Ldap_Server   |*        |ldapStatus         |*      |No more response from LDAP directory %mc_object%
    *       |INET_Ldap_Server   |*        |ldapDownTime       |*      |No more response from LDAP directory %mc_object% for %mc_parameter_value% seconds


Troubleshooting
---------------

In case of troubleshooting or for more information, you contact the Feature Team EDGE :email: list.fr-ret-edge-automation@socgen.com

Author Information
------------------

Yanis BEKRAR

class IncubawException(Exception):
    pass


class ImproperlyConfigured(IncubawException):
    '''ZABAW is somehow improperly configured'''
    pass
#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
import testinfra 

@then('VM is connected to WHATS')
def step_impl(context):

    test_user='a335427'
    print("Test existance of user {} \n".format(test_user))

    server=testinfra.get_host('ssh://automation@'+context.params['vm_ipaddr'])

    # Test the id of known user
    cmd_id=server.run("id {}".format(test_user) ) 
   
    print("stdout => "+cmd_id.stdout+"\n")
    print("stderr => "+cmd_id.stderr+"\n")
 
    if 'no such user' in cmd_id.stderr:
      assert context.failed is True
    else:
      assert context.failed is False

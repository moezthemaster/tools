
import attr


@attr.s
class SharedDataOfVm(object):
    return_value = attr.ib(default=attr.Factory(str))
    log_file = attr.ib(default=attr.Factory(str))
    log_level = attr.ib(default=attr.Factory(str))
    created_at = attr.ib(default=attr.Factory(float))
    finished_at = attr.ib(default=attr.Factory(float))
    task_id = attr.ib(default=attr.Factory(str))
    task_name = attr.ib(default=attr.Factory(str))
    task_full_name = attr.ib(default=attr.Factory(str))
    args = attr.ib(default=attr.Factory(list))
    kwargs = attr.ib(default=attr.Factory(dict))
    original_kwargs = attr.ib(default=attr.Factory(dict))
    shared_data = attr.ib(default=attr.Factory(dict))
    services = attr.ib(default=attr.Factory(dict))
    rollback_on = attr.ib(default=attr.Factory(dict))
    exception_msg = attr.ib(default=attr.Factory(str))
    exception_class = attr.ib(default=attr.Factory(str))
    exception_traceback = attr.ib(default=attr.Factory(str))

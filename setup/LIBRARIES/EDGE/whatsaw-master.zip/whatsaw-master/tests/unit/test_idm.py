import json
import requests
import pytest
import unittest
try:
    from unittest import mock
except ImportError:
    import mock
from whatsaw.token import Token
from py_edge_vault import secrets
from requests.models import Response
from tests.mock.idm import mock_vault, mock_get_exitcode_stdout_stderr, mock_request, mock_request_error, MockedIdmWrapper

HOSTNAME = "dpgalxunit001"
IP_ADDRESS = "1.5.95.2"
TRIGRAM = 'pga'

ADD_HOST_METHOD = "iru_host_add"
CHECK_IP_METHOD = "iru_ip4_exists"
CHECK_HOSTNAME_METHOD = "iru_host_exists"
UNROLE_HOSTNAME_METHOD = "iru_host_del"


@mock.patch('whatsaw.token.get_exitcode_stdout_stderr')
@mock.patch('py_edge_vault.secrets.get_secrets')
class TestIdm(unittest.TestCase):
    @mock.patch('requests.post')
    def test_enrole_hostname_in_idm(self, mock_post, mock_creds, mock_token):

        mock_creds.return_value = mock_vault()
        mock_token.return_value = mock_get_exitcode_stdout_stderr()
        mock_post.return_value = mock_request(ADD_HOST_METHOD)

        idm = MockedIdmWrapper(HOSTNAME)
        r = idm.enroller(HOSTNAME, IP_ADDRESS, TRIGRAM)
        assert r['error'] is None 

    @mock.patch('requests.post')
    def test_enrole_hostname_already_in_idm(self, mock_post, mock_creds, mock_token):
        mock_creds.return_value = mock_vault()
        mock_token.return_value = mock_get_exitcode_stdout_stderr()
        mock_post.return_value = mock_request_error(ADD_HOST_METHOD)

        idm = MockedIdmWrapper(HOSTNAME)
        r = idm.enroller(HOSTNAME, IP_ADDRESS, TRIGRAM)
        assert r['error']['code'] == 4002

    @mock.patch('requests.post')
    def test_check_whats_ip_exists(self, mock_post, mock_creds, mock_token):

        mock_creds.return_value = mock_vault()
        mock_token.return_value = mock_get_exitcode_stdout_stderr()
        mock_post.return_value = mock_request(CHECK_IP_METHOD)

        idm = MockedIdmWrapper(HOSTNAME)
        r = idm.ip_checker(HOSTNAME, IP_ADDRESS)
        assert r["result"]["value"] == IP_ADDRESS

    @mock.patch('requests.post')
    def test_check_whats_hostname_exists(self, mock_post, mock_creds, mock_token):

        mock_creds.return_value = mock_vault()
        mock_token.return_value = mock_get_exitcode_stdout_stderr()
        mock_post.return_value = mock_request(CHECK_HOSTNAME_METHOD)

        idm = MockedIdmWrapper(HOSTNAME)
        r = idm.host_checker(HOSTNAME)
        assert r["result"]["value"] == HOSTNAME + '.' + idm.get_domain()

    @mock.patch('requests.post')
    def test_unrole_hostname_from_idm(self, mock_post, mock_creds, mock_token):

        mock_creds.return_value = mock_vault()
        mock_token.return_value = mock_get_exitcode_stdout_stderr()
        mock_post.return_value = mock_request(UNROLE_HOSTNAME_METHOD)

        idm = MockedIdmWrapper(HOSTNAME)
        r = idm.unroller(HOSTNAME)
        assert r['error'] is None

    @mock.patch('requests.post')
    def test_unrole_an_unknow_hostname_from_idm(self, mock_post, mock_creds, mock_token):

        mock_creds.return_value = mock_vault()
        mock_token.return_value = mock_get_exitcode_stdout_stderr()
        mock_post.return_value = mock_request_error(UNROLE_HOSTNAME_METHOD)

        idm = MockedIdmWrapper(HOSTNAME)
        r = idm.unroller(HOSTNAME)
        assert r['result'] is None

    @mock.patch('requests.post')
    def test_check_whats_ip_doesnt_exist(self, mock_post, mock_creds, mock_token):

        mock_creds.return_value = mock_vault()
        mock_token.return_value = mock_get_exitcode_stdout_stderr()
        mock_post.return_value = mock_request_error(CHECK_IP_METHOD)

        idm = MockedIdmWrapper(HOSTNAME)
        r = idm.ip_checker(HOSTNAME, IP_ADDRESS)
        assert r["error"]["code"] == 4001

    @mock.patch('requests.post')
    def test_check_whats_hostname_doesnt_exist(self, mock_post, mock_creds, mock_token):

        mock_creds.return_value = mock_vault()
        mock_token.return_value = mock_get_exitcode_stdout_stderr()
        mock_post.return_value = mock_request_error(CHECK_HOSTNAME_METHOD)

        idm = MockedIdmWrapper(HOSTNAME)
        r = idm.host_checker(HOSTNAME)
        assert r["error"]["code"] == 4001
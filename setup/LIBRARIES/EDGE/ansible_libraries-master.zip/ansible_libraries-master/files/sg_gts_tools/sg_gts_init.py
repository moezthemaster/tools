#!/usr/bin/python
# -*- coding: utf-8 -*-

# (c) 2016, Danny AFAHOUNKO <danny.afahounko-ext@socgen.com>
#
import ConfigParser
import string
import os

import re
import json
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning


def read_settings( cfg_path, cfg_name ):

  output = {}

  isError = False
  log = ""

  config = ConfigParser.SafeConfigParser()

  conf_path = "{}/{}" . format(cfg_path, cfg_name)


  if not os.path.exists(conf_path):
    conf_path = "{}/{}" . format(os.path.dirname(os.path.realpath(__file__)), cfg_name)

  if os.path.exists(conf_path):

    config.read(conf_path)

    for each_section in config.sections():
      for (each_key, each_val) in config.items(each_section):
        label = "{}_{}" . format(each_section, each_key)
        try:
          output[label] = config.get(each_section, each_key)
        except Exception, e:
          #raise e
          pass
        
  else:
    isError = True
    log = "Oops. I cannot open {}/{}" . format(cfg_path, cfg_name)

  output['os_dir'] = os.path.dirname(os.path.realpath(__file__))

  # RETURN
  return isError, log, output





def submit_url_json(method, url, data, **kwargs):

    output = {}

    headers = {'Content-type': 'application/json', 'Accept': 'application/json'}
    for key, value in kwargs.iteritems():
       headers.update({key:value})
    
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

    if method.lower() == 'post':
       r = requests.post(url, data=json.dumps(data), headers=headers, verify=False)
    elif method.lower() == 'delete':
       r = requests.delete(url, data=json.dumps(data), headers=headers, verify=False)
    else:
       r = requests.get(url, data=json.dumps(data), headers=headers, verify=False)
       
    
    output['headers'] = r.headers
    output['status_code'] = r.status_code

    try:
      output['json'] = r.json()
    except Exception, e:
      output['json'] = r.text
      output['exception'] = str(e)
      


    return output['status_code'], output


def get_vm_catalog_json(url, name, **headerAuth):
  
  urlSuffix = "&$filter=(name%20eq%20'{}')" . format(name)
  data = {}

  url = "{}{}" . format(url, urlSuffix) 

  statusCode, jsonOutput = submit_url_json('get', url, data, **headerAuth)

  return statusCode, jsonOutput['json']
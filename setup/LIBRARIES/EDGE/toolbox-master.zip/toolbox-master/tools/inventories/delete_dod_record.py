#!/usr/bin/python
# -*- coding: utf-8 -*-
#

import sys
import re
import json
import os
import logging
from sets import Set
from optparse import OptionParser

sys.path.append("ansible_libraries/files")

import gts_dod_api


def delete_record(id):
    dod = gts_dod_api.GtsDoDApi()
    dod.delete_record_id(id)


if __name__ == '__main__':

    parser = OptionParser()
    parser.add_option("-v",
                      "--verbose",
                      action="store_true",
                      dest="verbose",
                      default=False,
                      help="mode debug")

    (options, args) = parser.parse_args()
    if options.verbose is True:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.WARNING)
    logger = logging.getLogger()

    if len(args) >= 1:
        for id in args:
            delete_record(id)

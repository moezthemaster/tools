
from edge.network.networkhelper import NetworkHelper


class NetworkModuleError(Exception):
    pass


class NetworkHelperImp(NetworkHelper):
    def __init__(self):
        NetworkHelper.__init__(self)

    def configure_network(self, ip, network_id, geo_domain, network_envi):
        response = self.update_etc_host(ip_address=ip, network_id=network_id)
        if response != "OK":
           return "Update error for /etc/host"
        response = self.update_dns_config(ip_address=ip,geo_domain=geo_domain,network_id=network_id,network_envi=network_envi)
        if response != "OK":
           return "Update error for DNS configuration"
        response = self.configure_ntp(ip_address=ip,network_id=network_id)
        if response != "OK":
           return "Update error for NTP configuration"
        return "OK"


PRESENT = 'present'


def network_module(ip, geo_domain, network_id, network_envi, state="present"):
    networkhelper = NetworkHelperImp()
    if state == PRESENT:
        response = networkhelper.configure_network(
            ip=ip,
            geo_domain=geo_domain,
            network_id=network_id,
            network_envi=network_envi
        )
        if response == "OK":
           return networkhelper.has_changed, response
        else:
            raise NetworkModuleError(response)

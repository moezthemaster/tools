import logging
import sys
import os

if "TREE_DIR" in os.environ.keys():
    ANSIBLE_MODULES_PATH = [
        os.path.join(os.environ["TREE_DIR"], 'roles/edge'),
        os.path.join(os.environ["TREE_DIR"], 'roles/dodaw'),
        os.path.join(os.environ["TREE_DIR"], "library"),
        os.path.join(os.environ["TREE_DIR"], 'roles/py_edge_vault'),
    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/edge',
        './roles/dodaw',
        './roles/py_edge_vault'
    ]
for path in ANSIBLE_MODULES_PATH:
    sys.path.insert(0, path)

from ansible.module_utils.basic import AnsibleModule


from edge.interfaces import Dod
from edge.kpi.elk import Loader
from dodaw.dod import DodWrapper
from edge.dns.dodv2.feeder import DnsFeeder
from edge.dns.dodv2.cleaner import DnsCleaner
from edge.dns.dodv2.informer import DnsInformer


logger = logging.getLogger(__name__)


class DodImpl(Dod):
    def __init__(self):
        self.dod_wrapper = DodWrapper()

    def search_dns_record(self, record_type, **kwargs):
        print('search record type{} kwargs {}'.format(record_type, kwargs))
        return self.dod_wrapper.search_record(record_type, **kwargs)

    def create_dns_record(self, dns_service, record_type, zone, view, hostname, **kwargs):
        return self.dod_wrapper.create_record(dns_service, record_type, zone, view, hostname, **kwargs)

    def delete_dns_record(self, dns_service, id):
        logger.debug('Delete id {}'.format(id))
        return self.dod_wrapper.delete_record(dns_service, id)

    def search_and_delete_dns_records(self, dns_service, record_type, limit_rows=10, **kwargs):
        return self.dod_wrapper.search_and_delete_records(dns_service, record_type, limit_rows, **kwargs)


class DnsFeederImpl(DnsFeeder, DodImpl):
    def __init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname=None):
        DodImpl.__init__(self)
        DnsFeeder.__init__(self, env, region_cloud, az_cloud, network_id, trigram, hostname)


class DnsCleanerImpl(DnsCleaner, DodImpl):
    def __init__(self, env, region_cloud, az_cloud, network_id, hostname=None):
        DodImpl.__init__(self)
        DnsCleaner.__init__(self, env, region_cloud, az_cloud, network_id, hostname)

class DnsInformerImpl(DnsInformer, DodImpl):
    def __init__(self, hostname):
        DodImpl.__init__(self)
        DnsInformer.__init__(self, hostname)

PRESENT, ABSENT, INFOS = 'present', 'absent', 'infos'

FIELDS = {
    "vm_hostname": {
        "type": "str",
        "default": None
    },
    "vm_network": {
        "type": "str"
    },
    "vm_subnet": {
        "type": "str"
    },
    "dns_zone": {
        "type": "str"
    },
    "dns_publish": {
        "type": "str"
    },
    "vm_region": {
        "default": "EU France (Greater Paris)",
        "choices": [
            'EU France (Greater Paris)',
            'EU France (North)'
        ],
        "type": "str",
    },
    "vm_az": {
        "default": "eu-fr-paris-1",
        "choices": [
            'eu-fr-paris-1',
            'eu-fr-paris-2',
            'eu-fr-north-1'
        ],
        "type": "str",
    },
    "app_id": {
        "type": "str"
    },
    "app_env": {
        "type": "str",
        "choices": [
            'uat',
            'tst',
            'int',
            'dev',
            'hml',
            'prd'
        ],
        "default": "prd",
    },
    "kpi_data": {
        "type": "dict"
    },
    "state": {
        "default": PRESENT,
        "choices": [
            PRESENT,
            ABSENT,
            INFOS,
        ],
        "type": "str",
    },
}

REQUIRED_FIELDS = [
    ["state", PRESENT, ["app_id", "vm_network"]],
    ["state", ABSENT, ["vm_hostname"]],
    ["state", INFOS, ["vm_hostname"]]
]


def index_error_kpi(kpi_data):
    try:
        try:
            kpi_hostname = kpi_data['vm_hostname']
        except KeyError:
            kpi_hostname = ""
        loader = Loader()
        loader.index_data(
            id_execution=kpi_data['id_execution'], timestamp=kpi_data['timestamp'], service=kpi_data['service'],
            hostname=kpi_hostname, status="failure",
            category=kpi_data['category'], client=kpi_data['endClient'],
            trigram=kpi_data['app_id'], environment=kpi_data['app_env'],
            error=kpi_data["error"], playbook_version=kpi_data['playbook_version']
        )
    except Exception:
        pass


def main():
    module = AnsibleModule(argument_spec=FIELDS, required_if=REQUIRED_FIELDS)
    hostname = module.params['vm_hostname']
    state = module.params['state']
    region_cloud = module.params['vm_region']
    az_cloud = module.params['vm_az']
    env = module.params['app_env']
    kpi_data = module.params['kpi_data']
    if isinstance(kpi_data, dict):
        kpi_data['service'] = 'sg_gts_dod2_{}'.format(state)
    try:
        if state == PRESENT:
            trigram = module.params['app_id'].lower()
            network_id = module.params['vm_network']
            feeder = DnsFeederImpl(env, region_cloud, az_cloud, network_id, trigram, hostname)
            response = feeder.run()
            module.exit_json(changed=feeder.changed, meta=response)
        elif state == ABSENT:
            network_id = module.params['vm_network']
            cleaner = DnsCleanerImpl(env, region_cloud, az_cloud, network_id, hostname)
            response = cleaner.run()
            module.exit_json(changed=cleaner.changed, meta=response)
        elif state == INFOS:
            informer = DnsInformerImpl(hostname)
            response = informer.run()
            module.exit_json(changed=informer.changed, meta=response)
    except Exception as e:
        if isinstance(kpi_data, dict):
            kpi_data["error"] = e.args[0]
            index_error_kpi(kpi_data)
        module.fail_json(msg=e.args[0])


if __name__ == '__main__':
  main()

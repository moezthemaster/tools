#!/bin/sh 
#
# $Id: S50PatrolAgent.sh,v 1.21 2006/09/11 09:55:24 mneharka Exp $
#
#--------------------------------------------------------------
# Description:  PatrolAgent
# This shell script takes care of starting and stopping
# PatrolAgent.
#--------------------------------------------------------------
# Author            :
# Creation date     :
#
# Last check-in date: $Date: 2006/09/11 09:55:24 $
#
# Copyright (c) 2004 BMC Software, Inc.
#--------------------------------------------------------------
#
# Make sure umask is sane
#The next two lines perform the equivalent operation of ksh builtin umask o-w
#
#-------------------------------------------------------------------------------------
#
# V4.05 : Updated by Merouane AGAR & Yanis BEKRAR for Société Générale 
#         Adding Applicative Agent management
# 
#-------------------------------------------------------------------------------------
#
temp_umask=`umask`
umask `/usr/bin/expr ${temp_umask} / 2 % 2 \* ${temp_umask} \| ${temp_umask} + 2`

#----------------------------------------------------------------------
# Set up a default search path.
PATH="/usr/sbin:/usr/bin:/bin:"$PATH
export PATH

#----------------------------------------------------------------------
#initilize the RETVAL
RETVAL=0
PROCESS_FOUND=0

#----------------------------------------------------------------------
#replace PA_BASEDIR=CHANGME with installation path
#PA_BASEDIR=CHANGME
PA_BASEDIR=/produits/patrol/PATROL_AGT/

PA_DIRNAME=`basename $PA_BASEDIR`
BMC_DEFINSTBASE=`dirname $PA_BASEDIR`

#----------------------------------------------------------------------
# Log file containing the portnum for previous running instance of 
# PatrolAgent
INST_LOG_FILE=$PA_BASEDIR/log/instance.log

#------------------------------------------------------------------------
if [ ! -f "$PA_BASEDIR/target" ]
then
  echo "[MSG]$PA_BASEDIR/target script missing!"
  exit 1
fi

TARGET=`$PA_BASEDIR/target`


#----------------------------------------------------------------------
PA_BINDIR=$PA_BASEDIR/$TARGET/bin
PA_LOGDIR=$PA_BASEDIR/$TARGET/log
PA_LIBDIR=$PA_BASEDIR/$TARGET/lib

#----------------------------------------------------------------------
#turn off detection of unset variables
set +u 
  
#----------------------------------------------------------------------
#use UNAME to determine OS type for PS command options
UNAME=`uname`

#----------------------------------------------------------------------
#Test how newline is suppressed in echo.

if [ `echo -n|grep -c n` -gt 0 ]
then
        C="\c"
        N=""
else
        C=""
        N="-n"
fi


#----------------------------------------------------------------------
#
set_patrol_env() {
#set Patrol environment variables
  PATROL_HOME=${PA_BASEDIR}/${TARGET}; export PATROL_HOME
  PATH=$PATH:$PA_BINDIR; export PATH
  BMC_PATROL_HOST_DOMAIN_NAME=`grep -i domain /etc/resolv.conf | awk '{print $2}'`
  if [ "$BMC_PATROL_HOST_DOMAIN_NAME" = "" ]; then
  BMC_PATROL_HOST_DOMAIN_NAME=`grep -i search /etc/resolv.conf | awk '{print $2}' | sed s'/[.]$//'`
  fi
  export BMC_PATROL_HOST_DOMAIN_NAME

  if [ -f ${PA_BINDIR}/PatrolAgent -a -z "${PATROL_ADMIN-}" -a -f ${PA_LIBDIR}/config.default ]; then
     PATROL_ADMIN=`grep "/AgentSetup/defaultAccount" ${PA_LIBDIR}/config.default | grep -v "^!" | awk '{print $4}' | awk -F"=" '{print $2}' | awk -F"\"" '{print $2}' | awk -F"/" '{print $1}'`
     export PATROL_ADMIN
  fi
}

#----------------------------------------------------------------------
#Get Default Accout from /AgentSetup/defaultAccount
get_default_user ()
{
  if [ ! -f ${PA_LIBDIR}/config.default ]
  then
    echo "[LOG][NA] - Exiting S50PatrolAgent.sh script!"
    exit 0
  fi

  #default for /AgentSetup/defaultAccount and PATROL_ADMIN is "patrol"
  DEF_ACCT=`grep "/AgentSetup/defaultAccount" ${PA_LIBDIR}/config.default | grep -v "^!" | awk '{print $4}' | awk -F"=" '{print $2}' | awk -F"\"" '{print $2}' | awk -F"/" '{print $1}'`

  DEF_ACCT_GROUP=`id $DEF_ACCT | awk -F\) '{ print $2 }' | awk -F\( '{ print $2 }'`
}

#----------------------------------------------------------------------
#
host_cmds() {

  for d in `echo $PATH | sed 's/:/ /g'`
  do
     if [ -x $d/whoami ]; then 
       USER=`$d/whoami` 
     fi
  
     if [ -x $d/id ]; then 
       USER=`id | awk -F\) '{ print $1 }' | awk -F\( '{ print $2 }'` 
     fi
  done
   
  case "$UNAME" in
      SunOS)
   UNAMER=`uname -r`
   if [ "$UNAMER" = "5.10" ] || [ "$UNAMER" = "5.11" ]; then
      ZONENAME=`zonename`   
      PS_CMD="ps -e -o pid -o ppid -o pgid -o args -o zone"
            PIDL=`${PS_CMD} | grep -v grep | grep lAgent | grep ${ZONENAME} | awk '( ($4 ~ /lAgent/)) { print $1 }' | sort -u`
   else
      PS_CMD="ps -e -o pid -o ppid -o pgid -o args"
      PIDL=`${PS_CMD} | grep -v grep | grep lAgent | awk '( ($4 ~ /lAgent/)) { print $1 }' | sort -u`
         fi
         AGT_KILL_CMD="true"
         ;;
      HP-UX)
         test_result=`ps -ex >/dev/null 2>&1; echo $?`
         if [ $test_result -gt 0 ]
         then
            PS_CMD="ps -ef"
            PIDL=`${PS_CMD} | grep -v grep | grep lAgent | awk '( ($8 ~ /lAgent/) ) { print $2 }' | sort -u`
         else
            PS_CMD="ps -ex"
            PIDL=`${PS_CMD} | grep -v grep | grep lAgent | awk '( ($4 ~ /lAgent/) ) { print $1 }' | sort -u`
         fi
         ;;
      Linux)
         PS_CMD="ps -e -o pid -o ppid -o pgid -o args"
         PIDL=`${PS_CMD} | grep -v grep | grep lAgent | awk '( ($4 ~ /lAgent/)) { print $1 }' | sort -u`
         ;;
      AIX)
         PS_CMD="ps -e -o pid -o ppid -o pgid -o args"
         PIDL=`${PS_CMD} | grep -v grep | grep lAgent | awk '( ($4 ~ /lAgent/)) { print $1 }' | sort -u`
         ;;
      OSF1)
         PS_CMD="ps -e -o pid -o ppid -o pgid -o args"
         PIDL=`${PS_CMD} | grep -v grep | grep lAgent | awk '( ($4 ~ /lAgent/)) { print $1 }' | sort -u`
         ;;
   esac
}


#----------------------------------------------------------------------
#
bmc_status() {
   host_cmds
   AGENT_LIST=
   PROCESS_FOUND=0
   LOG_FILE_LIST=`ls $PA_LOGDIR/*.errs 2>/dev/null`

     for GPID in $PIDL
     do
        if [ x"$LOG_FILE_LIST" != "x" ]; then
           for LOG_FILE in $LOG_FILE_LIST
           do
             LOG_FILE_PID=`head -2 $LOG_FILE | tail -1 | sed -e 's/[^0-9]*\([0-9][0-9]*\)[^0-9].*/\1/g'`
             if [ x"$LOG_FILE_PID" = x"$GPID" ]; then
               PROC_PORT_NUM=`basename $LOG_FILE .errs | tr '-' '/' | xargs basename`
               if [ "$ARG2_FLAG" = "1" -a "$PROC_PORT_NUM" != "$AGENT_PORTNUM" ]; then
                 continue
               fi
               PROCESS_FOUND=`expr $PROCESS_FOUND + 1`
               AGENT_LIST="${AGENT_LIST} ${PROC_PORT_NUM}:${GPID}"
               if [ "$ARG2_FLAG" = "1" ]; then
                  break 2
               fi
             fi
           done
        fi
     done
} 
  
#----------------------------------------------------------------------
#
print_status() {
   if [ "$PROCESS_FOUND" != "0" ]; then
      for AGENT in ${AGENT_LIST}
      do
         # split up the agent information
         aPORT=`echo $AGENT | cut -f 1 -d :`
         aPID=`echo $AGENT | cut -f 2 -d :`
         echo "[LOG]PatrolAgent process $aPID found running on port $aPORT."
      done
   else 
     if [ "$ARG2_FLAG" = "1" ]; then
        echo "[LOG]No PatrolAgent running on port $AGENT_PORTNUM for this installation."
     else
        echo "[LOG]No PatrolAgent processes found running for this installation."
     fi
   fi
}


#----------------------------------------------------------------------
#
bmc_start() {
   echo "[LOG]Agent Startup Requested"

   host_cmds
   
   cd $PA_BASEDIR
   if [ ! -f "./PatrolAgent" ]
   then
      echo "[ABORT_EXIT]Cannot find PatrolAgent script!"
      exit 1
   fi
   
   # This fixes the pathname in the case of replicated PatrolAgent scripts
   # which may contain pathnames from a different host.
   PATH_LINE=`grep "search key" ./PatrolAgent | awk '{print $2}'`
   if [ "$PATH_LINE" != "$PA_BASEDIR" ]
   then
      cat ./PatrolAgent | sed -e "s^$PATH_LINE^$PA_BASEDIR^" > ./PatrolAgent.new
      mv -f ./PatrolAgent ./PatrolAgent.old
      mv -f ./PatrolAgent.new ./PatrolAgent
      chmod 755 ./PatrolAgent
      if [ x"$USER" = x"root" ]
      then
  get_default_user
  chown $DEF_ACCT:$DEF_ACCT_GROUP ./PatrolAgent
      fi
      rm PatrolAgent.old 
   fi

   /produits/patrol/PATROL_AGT/Linux-2-6-x86-64-nptl/bin/fix_hist & 
   
   if [ "$AGENT_PORTNUM" = "ALL" -o "$AGENT_PORTNUM" = "All" -o "$AGENT_PORTNUM" = "all" ] &&  [ ! -f $INST_LOG_FILE ]
   then
       echo "[LOG]Attempt: Starting PatrolAgent on port 14451"
     
    NAME=`grep PATROL_VIRTUALNAME_14451 ~patrol/.profile | awk -F"=" '{ print $2 }' | tr '[:lower:]' '[:upper:]'`
    if [ "$NAME" = "" ]
      then NAME=`uname -n |awk -F"." '{ print $1 }'| tr '[:lower:]' '[:upper:]'`
    fi
       $PA_BASEDIR/PatrolAgent -port 14451 -id ${NAME}_14451 
       #$PA_BASEDIR/PatrolAgent -port 14451 -id ${NAME}_14451 &
   elif [ "$AGENT_PORTNUM" = "ALL" -o "$AGENT_PORTNUM" = "All" -o "$AGENT_PORTNUM" = "all" ]; then
      for PORTNUM in `cat $INST_LOG_FILE`
      do
         echo "[LOG]Attempt: Starting PatrolAgent on port $PORTNUM"
     NAME=`grep PATROL_VIRTUALNAME_$PORTNUM ~patrol/.profile | awk -F"=" '{ print $2 }' | tr '[:lower:]' '[:upper:]'`
    if [ "$NAME" = "" ]
      then NAME=`uname -n |awk -F"." '{ print $1 }'| tr '[:lower:]' '[:upper:]'`
    fi
         $PA_BASEDIR/PatrolAgent -port $PORTNUM -id ${NAME}_$PORTNUM 
         #$PA_BASEDIR/PatrolAgent -port $PORTNUM -id ${NAME}_$PORTNUM &
         sleep 5
      done

      ## List all process started so far
      ARG2_FLAG=0   ## This flag is used to mark the presence of valid port number. resetting this as portnum is 'all'.
      bmc_status
      for AGENT in ${AGENT_LIST}
      do
         aPORT=`echo $AGENT | cut -f 1 -d :`
         aPID=`echo $AGENT | cut -f 2 -d :`
         echo ""
         echo "[LOG]PatrolAgent started on port $aPORT, PID is $aPID"

      done
      return
   else   
    NAME=`grep PATROL_VIRTUALNAME_${AGENT_PORTNUM} ~patrol/.profile | awk -F"=" '{ print $2 }' | tr '[:lower:]' '[:upper:]'`
    if [ "$NAME" = "" ]
      then NAME=`uname -n |awk -F"." '{ print $1 }'| tr '[:lower:]' '[:upper:]'`
    fi 
      $PA_BASEDIR/PatrolAgent -port $AGENT_PORTNUM  -id ${NAME}_${AGENT_PORTNUM} 
      #$PA_BASEDIR/PatrolAgent -port $AGENT_PORTNUM  -id ${NAME}_${AGENT_PORTNUM} &

    exit
   fi
   
   echo "[LOG]PatrolAgent process started." 
   sleep 5

   #give PatrolAgent additional time to startup the PatrolAgent process
   i=120
   secs=`expr $i \* 5`
   echo "[LOG]Waiting a maximum of $secs seconds for the PatrolAgent processes to start. "
   while [ $i -gt 0 ] 
   do
      bmc_status
      if [ "$PROCESS_FOUND" != "0" ]; then 
         if [ "$AGENT_PORTNUM" != "ALL" -a "$AGENT_PORTNUM" != "All" -a "$AGENT_PORTNUM" != "all" ]; then
            for AGENT in ${AGENT_LIST}
            do
               aPORT=`echo $AGENT | cut -f 1 -d :`
               aPID=`echo $AGENT | cut -f 2 -d :`
               if [ $AGENT_PORTNUM = "$aPORT" ]; then
                  echo ""
                  echo "[LOG]PatrolAgent started on port $aPORT, PID is $aPID"

                  RETVAL=0
                  return
               fi
            done
         fi
      fi
      i=`expr $i - 1`
      sleep 5
      echo $N ". " $C
   done

   if [ "$PROCESS_FOUND" = "0" ]; then 
      echo ""
      echo "[ABORT_EXIT]Agent PID not found!"
      exit 1
   fi

   return $RETVAL
}


#----------------------------------------------------------------------
#
bmc_stop() {
   echo "[LOG]PatrolAgent Shutdown Requested"
    
   set_patrol_env
   bmc_status

   echo "" > $INST_LOG_FILE

   get_default_user
   chown $DEF_ACCT:$DEF_ACCT_GROUP $INST_LOG_FILE
   
   if [ "$PROCESS_FOUND" = "0" ]; then
      echo "[LOG]No PatrolAgent processes found running for this installation."
      exit 0
   fi

   echo "[LOG]Stopping PatrolAgent processes." 
   # loop through all the agents and kill'em...somehow...
   for AGENT in ${AGENT_LIST}
   do
      # split up the agent information
      aPORT=`echo $AGENT | cut -f 1 -d :`
      aPID=`echo $AGENT | cut -f 2 -d :`

      #use UNIX kill command to issue TERM signal to pgid 
      if [ "$USER" = "root" ]; then 
         kill -TERM $aPID
         RETVAL=$?
      else #attempt killing agent using pconfig command
         if [ x"$AGT_KILL_CMD" = "xtrue" ]; then 
            echo "[LOG]Killing PatrolAgent on port $aPORT."
            kill $aPID
            RETVAL=$?
         else
            echo "[LOG]Stopping PatrolAgent on port $aPORT."
            $PA_BINDIR/pconfig +KILL -port $aPORT 2>/dev/null 
            PCONFIG_RESULT=$? 
            #if pconfig connection fails try issuing a kill
            if [ x"$PCONFIG_RESULT" != x"0" ]; then
               echo "[LOG]Connection failed, killing PatrolAgent on port $aPORT."
               kill $aPID
               RETVAL=$?
            fi
         fi
      fi
      echo " $aPORT" >> $INST_LOG_FILE
   done
     


   # check to see if we actually succeeded in stopping all the required agents
   bmc_status 
   if [ "$PROCESS_FOUND" != "0" ]; then 
      #give PatrolAgent additional time to shutdown processes
      i=10
      secs=`expr $i \* 5`
      echo "[LOG]Waiting a maximum of $secs seconds for the PatrolAgent process to exit. "
      while [ $i -gt 0 ]
      do
         bmc_status
         if [ "$PROCESS_FOUND" = "0" ]; then 
            echo ""
            echo "[LOG]PatrolAgent processes stopped" 
            RETVAL=0
            return
         fi
         i=`expr $i - 1`
         sleep 5
         echo $N ". " $C
      done
   fi


   #check to see if PatrolAgent is running a final time and report status
   if [ "$PROCESS_FOUND" != "0" ]; then
      echo ""
      echo "[SCRIPT_FAIL]Installation is terminating because the"
      echo "[ERROR]PatrolAgent process is still running."
      echo "[ERROR]The installation is unable to stop PatrolAgent " 
      echo "[ERROR]process or it require more than $secs to stop." 
   fi
  return $RETVAL

}


#----------------------------------------------------------------------
# MAIN
#
# See how we were called.
ACTION=$1
if [ "$2" != "" ]; then
  ARG2_FLAG=1 
else 
  ARG2_FLAG=0
fi

if [ "$BASH_ENV" != "" ]; then
   unset BASH_ENV
fi
 
AGENT_PORTNUM=${2:-"14451"}

case "$ACTION" in
   start)
      bmc_start
      ;;
   stop)
      bmc_stop
      ;;
   restart|reload)
      bmc_stop
      bmc_start
      RETVAL=$?
      ;;
   status)
      bmc_status
      print_status
      ;;
   *)
      echo $"Usage: $0 Action {start|stop|restart|status} "
      echo $"          Agent Port {portnum}"
      echo $"          "
      echo $"Note: 'ALL' value for 'portnum' with 'start' Action will"
      echo $"      attempt to start PatrolAgent on all ports where it"
      echo $"      was running before stopping them with this script."
      echo $"      'ALL' value is invalid with 'stop' Action."
      echo $"          "
      exit 1
esac

if [ x"$RETVAL" != x"0" ]
then
   echo "[ABORT_EXIT]$0 script Failure."
   exit 1
else
   echo "[LOG]$0 completed successfully."
   exit 0
fi
#--------------------------------------------------------
# Modification History:
# Revision SG 2017/07/05 Merouane AGAR
# prendre en compte les agent applicatif et le id des agent patrol
#
# $Log: S50PatrolAgent.sh,v $
# Revision 1.21  2006/09/11 09:55:24  mneharka
# Installation in Solaris 10 global zone fails, if agents are running
# in non-global zones.
# Vantive: 516532
#
# Revision 1.20  2005/04/08 18:04:56  jwilliam
# added code to stop multiple agent instances
# Vantive: 489158
#
# Revision 1.19  2004/12/22 16:29:56  jwilliam
# fix misspelling
# Vantive: 476964
#
# Revision 1.18  2004/10/15 15:38:48  jwilliam
# + change to a universal method for setting the umask to o-w
# Vantive: 466330
#
# Revision 1.17  2004/10/01 19:37:06  vjavalag
#      + Introduced the CVS template
# Vantive: NONE
#
#
#
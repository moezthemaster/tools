
import os
import glob
import logging
import requests
try:
    from urlparse import urlparse
except ImportError:
    from urllib.parse import urlparse
from zeep import xsd
from zeep import Client
from requests import Session
from zeep.exceptions import Fault
from zeep.transports import Transport
from requests.auth import HTTPBasicAuth
from requests.exceptions import ConnectionError, HTTPError
from requests.packages.urllib3.exceptions import InsecureRequestWarning

from dodaw.conf import settings
from dodaw.exception import DodClientError

logger = logging.getLogger(__name__)
logger.setLevel(logging.getLevelName(settings.LOGGER_LEVEL))


def get_files_name(path):
    return [os.path.basename(x) for x in glob.glob(path)]


class SingletonDecorator:

    def __init__(self,klass):
        self.klass = klass
        self.instance = None

    def __call__(self,*args,**kwds):
        if self.instance == None:
            self.instance = self.klass(*args,**kwds)
        return self.instance


@SingletonDecorator
class _DecoratorService:
    """
        decorator for service of zeep's client to add automatically session header
        eg:
        <soap-env:Header>
            <SessionHeader>
                <dns_group>France MKT</dns_group>
            </SessionHeader>
        </soap-env:Header>
    """
    def __init__(self, service):
        self.service = service

    def _dec_header_value(self, obj_proxy):
        class Wrapper:
            header = xsd.ComplexType([
                xsd.Element(
                    'SessionHeader',
                    xsd.ComplexType([
                        xsd.Element('dns_group', xsd.String())
                    ])
                )
            ])
            header_value = header(SessionHeader={'dns_group': 'France MKT'})

            def __init__(self, proxy_object):
                self._proxy_object = proxy_object

            def __call__(self, *args, **kwargs):
                kwargs['_soapheaders'] = [self.header_value]
                try:
                    return self._proxy_object(*args, **kwargs)
                except Fault as err:
                    raise DodClientError(err.args[0])

            def __getattr__(self, item):
                return getattr(self._proxy_object, item)

        return Wrapper(obj_proxy)

    def __getattr__(self, item):
        return self._dec_header_value(
            getattr(self.service, item)
        )


class _TransPortContextDod(Transport):
    """
        The purpose of this class is to serve content of given urls in URLS_DIR to by pass
        on
    """

    URLS_DIR = os.path.join(
        os.path.dirname(__file__), 'conf', 'xmls_dodv1'
    )

    def __init__(self, **kwargs):
        super(_TransPortContextDod, self).__init__(**kwargs)

    @classmethod
    def _cache_urls_path_file(cls):
        if not hasattr(cls, '_list_urls_xml'):
            list_urls_xml = get_files_name(cls.URLS_DIR + '/*')
            setattr(cls, '_list_urls_xml', list_urls_xml)
            return list_urls_xml
        return cls._list_urls_xml

    def load(self, url):
        logger.info("try to load url: {}".format(url))
        if not url:
            raise ValueError("No url given to load")
        if "socgen" in url:
            return super(_TransPortContextDod, self).load(url)
        parsed_url = urlparse(url)
        if parsed_url.scheme in ('http', 'https'):
            netloc = parsed_url.netloc
            if netloc in self._cache_urls_path_file():
                with open(os.path.join(self.URLS_DIR, netloc), 'rb') as fh:
                    return fh.read()
            else:
                raise ValueError("file {} not found in {}".format(netloc, self.URLS_DIR))


class DodClient:
    """
        dodv1 client for soap requests on given api's url
    """

    def __init__(self, username, password, url):
        session = Session()
        session.auth = HTTPBasicAuth(username, password)
        requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
        if hasattr(settings, 'DOD_V1_CHECK_SSL'):
            session.verify = os.path.join(
                os.path.abspath(os.path.dirname(__file__)), "files", "dodv1cacert.pem"
            )
        else:
            session.verify = False
        try:
            logger.info("try to establish connection with {}".format(url))
            self.client = Client(
                url,
                transport=_TransPortContextDod(session=session), strict=False
            )
        except HTTPError as err:
            logger.error(err.args[0])
            raise DodClientError(err.args[0])
        except ConnectionError as err:
            logger.error("cannot established connection with {} : {}".format(url, err.args[0]))
            raise DodClientError("cannot established connection with {}: {}".format(url, err.args[0]))
        logger.info("success to establish connection with {}".format(url))

    def __getattr__(self, item):
        if item == "service":
            return _DecoratorService(self.client.service)
        return getattr(self.client, item)

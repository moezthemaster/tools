#!/bin/bash


#Creation de la configuration de Patrol pour Apache
#envoi des info en paramètre
#creation du fichier de config
#envoi de la configuration a l'agent Patrol
#restart de l'agent Patrol
###
###
#   Process : 
#   LABEL - JAVAHOME - JBOSSHOME - PORT - USERNAME - PASSWORD
#
#
####################
cd /produits/patrol/PATROL_AGT
. ./patrolrc.sh

PATROL_DIR=/produits/patrol/PATROL_AGT/config

LOG=${PATROL_DIR}/config_jboss.log
jboss_file_default=${PATROL_DIR}/config_standard_jboss

check_agent(){

    if [ `ps -ef |grep PatrolAgent |grep -v grep | grep -c 14451` != 1 ]
    then
        sudo systemctl start patrol.service
    fi
    cpt=0
    while [ `pconfig +tcp +get -p 14451 | wc -l ` == 1 ] && [ $cpt != 6 ]
    do
        sleep 10
        ((cpt++))
    done
}


make_jboss () {


echo "Modification du fichier de configuration JBOSS" >>$LOG

sed -i -e "s/LABEL/$label/g" $jboss_file
sed -i -e "s#JAVAHOME#$javahome#g" $jboss_file
sed -i -e "s/PORT/$port/g" $jboss_file
sed -i -e "s#JBOSSHOME#$jbosshome#g" $jboss_file
sed -i -e "s/USERNAME/$username/g" $jboss_file
sed -i -e "s/PASSWORD/$password/g" $jboss_file

}

add_jboss () {

	check_agent
	echo "Apply JBOSS configuration" >> $LOG 
	pconfig +tcp -p 14451 $jboss_file >> $LOG

}

restart_agt () {
        
	check_agent
	echo "Patrol Agent restarting" >> $LOG 
	pconfig +tcp -p 14451 +RESTART
}


rm_jboss () {

    echo "Modification du fichier de configuration JBOSS" >>$LOG

	sed -i -e "s/REPLACE.*}/DELETE }/g" $jboss_file
	sed -i -e "s/MERGE/DELETE/g" $jboss_file


}

USAGE ()
{
  echo
  echo "Usage: $progname <action> <args>*"
  echo "        action: Add ou Remove"
  echo "        args: "
  echo
  exit 1
}

echo `date` >>$LOG
echo "Launching script.." >>$LOG



while test -n "$1"; do
    case "$1" in
        --usage|-u)
            USAGE
            exit 0
            ;;
        -JVH)
            javahome=$2
            echo "$javahome" >>$LOG
            shift
            ;;
        -JBH)
            jbosshome=$2
            echo "$jbosshome" >>$LOG
            shift
            ;;
        -P)
            port=$2
            echo "$port" >>$LOG
            shift
            ;;
        -USR)
            username=$2
            echo "$username" >>$LOG
            shift
            ;;
        -PWD)
            password=$2
            echo "$password" >>$LOG
            shift
            ;;      
        -LBL)
            label=$(echo $2 | sed 's/ //g')
            echo "$label" >>$LOG 
            shift
            ;;
        -ACT)
            action_config=$2
            echo "Action : $action_config" >>$LOG 
            shift
            ;;
        *)
            echo "Argument inconnu: $1"
            print_usage
            exit 3
            ;;
    esac
    shift
done

if [ "$label" == "" ]
then
    USAGE
fi

jboss_file="${jboss_file_default}_${label}"

case ${action_config} in 
	Add)
        
		#Initialisation des fichiers de conf
		rm -f ${jboss_file} 
		cp ${jboss_file_default}.save ${jboss_file}	
		make_jboss
		add_jboss
		restart_agt
		;;
	Remove) 
		rm_jboss
		add_jboss
		restart_agt
		;;
	*)	 
		USAGE
        ;;
esac


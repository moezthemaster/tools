# !/usr/bin/python
# -*- coding: utf-8 -*-
#
import logging

from edge.interfaces import CloudVra
from edge.conf import settings

logger = logging.getLogger(__name__)

logging.basicConfig(level=logging.getLevelName(settings.LOGGER_LEVEL))


class Extractor(CloudVra):
    def __init__(self, trigram, env, api_env):
        self.trigram = trigram
        self.env = env
        self.api_env = api_env
        self._make_item_filter()

    def _make_item_filter(self):
        hostname_regex = "{}{}lx".format(self.env[0].lower(), self.trigram)
        self._sentence_filter = \
            "substringof('{}', name)".format(hostname_regex)

    def get_cloud_inventory(self):
        """
        [description]
            get machine existing in SG cloud
        Returns:
            dict of info at Cloud VM
        """

        logger.info("get_cloud_inventory")
        info_resource = self.get_vra_resource_data()
        logger.debug("Got {} servers in cloud request".
                     format(len(info_resource)))
        cloud_vm = {}
        for entry in info_resource:
            ip = "None"
            expiration_date = ""
            blueprint = ""
            bg = ""
            logger.debug("{}".format(entry))
            comment = entry['description']
            creation_date = entry['dateCreated']
            for data in entry['resourceData']['entries']:
                if data['key'] == "NETWORK_LIST":
                    for item in data['value']['items']:
                        try:
                            for subitem, subvalue in item['values'].iteritems():
                                for subsubitem in item['values'][subitem]:                                

                                    if subsubitem['key'] == 'NETWORK_ADDRESS':
                                        ip = subsubitem['value'].get(
                                            "value", "None")
                        except AttributeError:
                            for subitem, subvalue in item['values'].items():
                                for subsubitem in item['values'][subitem]:
                                    if subsubitem['key'] == 'NETWORK_ADDRESS':
                                        ip = subsubitem['value'].get(
                                            "value", "None")

                if data["key"] == "MachineGroupName":
                    if "value" in data:
                        if data["value"] is not None:
                            bg = data["value"]["value"]
                if data["key"] == "MachineExpirationDate":
                    if "value" in data:
                        if data["value"] is not None:
                            expiration_date = data["value"]["value"]
                if data["key"] == "MachineBlueprintName":
                    if "value" in data:
                        if data["value"] is not None:
                            blueprint = data["value"]["value"]
                cloud_vm[entry['name']] = {
                    "ip": ip, "bg": bg,
                    "creation": creation_date,
                    "expiration": expiration_date,
                    "comment": comment,
                    "blueprint": blueprint,
                    "env": self.api_env
                }
        logger.debug("Found {} servers".format(len(cloud_vm)))
        return cloud_vm

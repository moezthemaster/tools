"""Initialize Flask."""
from functools import wraps
from flask import request, g
from flask_restplus import Resource

from sg_datalake import DatalakeRecord
import sg_connect_client
import sg_cacert_file

from sample.core.exception import InvalidUsage
from sample.core.utils import dl_logger


def log_request(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        """ Set up logger with sg_datalake
            Register logger in g.logger
            Log request information
        """
        dl_logger.info(DatalakeRecord.init_from_request(request))
        return func(*args, **kwargs)
    return wrapper


def auth_login(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        """ Ask authorization to SGConnect
            Register token to g.token
            Throws InvalidUsage exceptions
        """
        auth_bearer = request.headers.get('Authorization')
        if not auth_bearer:
            raise InvalidUsage("Access Token not valid", 401)
        access_token = auth_bearer.split()[1]
        token_info = sg_connect_client.get_token_info(access_token)
        if token_info:
            if not token_info.login_ad():
                raise InvalidUsage("Cannot retrieve AD login from your \
                                    SGConnect token", 400)
            else:
                g.token = token_info
                dl_logger.info(DatalakeRecord.init_from_user_token(token_info))
        else:
            raise InvalidUsage("Cannot retrieve information from your SGConnect \
                                token, token may have expired", 400)
        return func(*args, **kwargs)
    return wrapper


class DecoratedResource(Resource):
    method_decorators = [auth_login, log_request]

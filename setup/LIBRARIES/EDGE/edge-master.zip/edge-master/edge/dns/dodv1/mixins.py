#!/usr/bin/python
# -*- coding: utf-8 -*-

from edge.conf import settings


class Mixin:

    def _get_fields(self):
        str_fields = []
        if self.inA:
            str_fields.append("A")
        if self.inPTR:
            str_fields.append("PTR")
        if str_fields:
            return str(tuple(str_fields))
        return "(,)"

    def _search_cname(self):
        search = self.search_dns_record(
            record_type="^CNAME$",
            hostname='^{}$'.format(self.fqdn),
            dns_service=settings.DOD_DNS_SERVICE,
            view="production"
        )
        return search

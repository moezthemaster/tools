#!/usr/bin/python
# -*- coding: utf-8 -*-

import json
from requests.models import Response
from zabaw.zabbix import zbxApi
from zabaw.conf import settings

HOSTNAME = "dpgalxunit001"

class MockedzbxApi(zbxApi):
    def __init__(self, zbx_url, zbx_user, zbx_password):
        zbxApi.__init__(self, zbx_url, zbx_user, zbx_password)


def mock_vault():
    return {'username': 'zbx_user', 'password': 'zbx_pass'}


def mock_token():
    return {'token': '0424bd59b807674191e7d77572075f33'}


def mock_request(method):
    token = mock_token()['token']
    if method == 'user.login':
        result = {
            "jsonrpc": "2.0",
            "result": "{}".format(token),
            "id": 1
        }
    elif method == 'hostgroup.get':
        result = {
            "jsonrpc": "2.0",
            "result": [
                {
                    "groupid": "1",
                    "name": "EDGE servers unit test",
                    "internal": "0"
                },
            ],
            "id": 1
        }
    elif method == 'template.get':
        result = {
            "jsonrpc": "2.0",
            "result": [
                {
                    "proxy_hostid": "0",
                    "host": "Template OS Linux",
                    "status": "3",
                    "disable_until": "0",
                    "error": "",
                    "available": "0",
                    "errors_from": "0",
                    "lastaccess": "0",
                    "ipmi_authtype": "0",
                    "ipmi_privilege": "2",
                    "ipmi_username": "",
                    "ipmi_password": "",
                    "ipmi_disable_until": "0",
                    "ipmi_available": "0",
                    "snmp_disable_until": "0",
                    "snmp_available": "0",
                    "maintenanceid": "0",
                    "maintenance_status": "0",
                    "maintenance_type": "0",
                    "maintenance_from": "0",
                    "ipmi_errors_from": "0",
                    "snmp_errors_from": "0",
                    "ipmi_error": "",
                    "snmp_error": "",
                    "jmx_disable_until": "0",
                    "jmx_available": "0",
                    "jmx_errors_from": "0",
                    "jmx_error": "",
                    "name": "EDGE_TEMPLATE",
                    "flags": "0",
                    "templateid": "10001",
                    "description": "",
                    "tls_connect": "1",
                    "tls_accept": "1",
                    "tls_issuer": "",
                    "tls_subject": "",
                    "tls_psk_identity": "",
                    "tls_psk": ""
                },
            ],
            "id": 1
        }

    elif method == 'host.massadd':
        result = {
            "jsonrpc": "2.0",
            "result": {
                "hostids": [
                    "10160"
                ]
            },
            "id": 1
        }

    elif method == 'host.massremove':
        result = {
            "jsonrpc": "2.0",
            "result": {
                "hostids": [
                    "69665"
                ]
            },
            "id": 1
        }

    elif method == 'host.get':
        result = {
            "jsonrpc": "2.0",
            "result": [
                {
                    "maintenances": [],
                    "hostid": "10160",
                    "proxy_hostid": "0",
                    "host": "Zabbix server",
                    "status": "0",
                    "disable_until": "0",
                    "error": "",
                    "available": "0",
                    "errors_from": "0",
                    "lastaccess": "0",
                    "ipmi_authtype": "-1",
                    "ipmi_privilege": "2",
                    "ipmi_username": "",
                    "ipmi_password": "",
                    "ipmi_disable_until": "0",
                    "ipmi_available": "0",
                    "snmp_disable_until": "0",
                    "snmp_available": "0",
                    "maintenanceid": "0",
                    "maintenance_status": "0",
                    "maintenance_type": "0",
                    "maintenance_from": "0",
                    "ipmi_errors_from": "0",
                    "snmp_errors_from": "0",
                    "ipmi_error": "",
                    "snmp_error": "",
                    "jmx_disable_until": "0",
                    "jmx_available": "0",
                    "jmx_errors_from": "0",
                    "jmx_error": "",
                    "name": "Zabbix server",
                    "description": "The Zabbix monitoring server.",
                    "parentTemplates":
                        {
                            "templateid": "30051",
                        },

                    "tls_connect": "1",
                    "tls_accept": "1",
                    "tls_issuer": "",
                    "tls_subject": "",
                    "tls_psk_identity": "",
                    "tls_psk": ""
                },
            ],
            "id": 1
        }

    elif method == 'usermacro.create':
        result = {
            "jsonrpc": "2.0",
            "result": {
                "hostmacroids": [
                    "11"
                ]
            },
            "id": 1
        }

    elif method == 'usermacro.update':
        result = {
            "jsonrpc": "2.0",
            "result": {
                "hostmacroids": [
                    "11"
                ]
            },
            "id": 1
        }
    elif method == 'usermacro.get':
        result = {
            "jsonrpc": "2.0",
            "result": [
                {
                    "hostmacroid": "11",
                    "hostid": "10160",
                    "macro": "{$MACRO_TEST}",
                    "value": "edge_test_macro"
                }
            ],
            "id": 1
        }

    elif method == 'usermacro.delete':
        result = {
            "jsonrpc": "2.0",
            "result": {
                "hostmacroids": [
                    "32"
                ]
            },
            "id": 1
        }

    elif method == 'hostgroup.get':
        result = {
            "jsonrpc": "2.0",
            "result": [
                {
                    "groupid": "2",
                    "name": "EDGE/TEST",
                    "internal": "0"
                }
            ],
            "id": 1
        }

    elif method == 'hostgroup.massadd':
        result = {
            "jsonrpc": "2.0",
            "result": {
                "groupids": [
                    "5",
                    "6"
                ]
            },
            "id": 1
        }

    elif method == 'hostgroup.massremove':
        result = {
            "jsonrpc": "2.0",
            "result": {
                "groupids": [
                    "5",
                    "6"
                ]
            },
            "id": 1
        }

    else:
        result = {}

    resp = Response()
    resp.status_code = 200
    resp._content = json.dumps(result).encode()
    return resp
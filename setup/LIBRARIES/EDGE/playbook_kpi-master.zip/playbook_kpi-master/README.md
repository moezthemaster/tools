<p align="center"> <img src="https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/playbook_kpi/blob/master/imgs/kpi.jpeg" width="400px"> </p>

Playbook-KPI
=========

Install Elasticsearch, Kibana and Nginx.

**create-full.yml**

 * Install and configure Elastic stack with Nginx

**delete.yml** : Removing the Elastic stack and reseting configuration

**logstash_play.yml** : used only for demo purpose, used to extract and transform data from a csv file. In case you want to use it, please uncomment the part that installs logstash in the role es_kibana

Requirements
------------

python-passlib package must be present in the yum repo

Target server must be Linux.


Role Usage
--------------
Please refer to the role <a href="https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/playbook_kpi/blob/master/roles/es_kibana/README.md">ReadMe</a>

Author Information
------------------

Abdessamad BAYZI

#!/usr/bin/env python
import os
import re
import json
import sys
import argparse
import subprocess
from libzabbix.zbxapi import zbxApi
from libzabbix.config import zbxConfig


def get_zabbix_url():

    try:
        #ip_expression = "^192.1(6[0-3])+"
        hostname = subprocess.Popen(['hostname -s'], shell=True, stdout=subprocess.PIPE).stdout.read()
        cmd = "nslookup {} | grep 'Name'".format(hostname.strip())
        fqdn = subprocess.check_output("{}".format(cmd), shell=True)
        #ip_address = subprocess.Popen(['hostname -i'], shell=True, stdout=subprocess.PIPE).stdout.read()
        if "fr.world.socgen" in fqdn: # and re.match(ip_expression, ip_address):
            zabbix_api_url = "zbxApiUrlMKT"
        else:
            zabbix_api_url = "zbxApiUrlRET"
        return zabbix_api_url
    except Exception as e:
        raise ZabbixError('Something goes wrong to get zabbix url. error: {}'.format(e.args[0]))


class ZabbixError(Exception):
    pass


class Zabbix(object):
    def __init__(self):
        try:
            cf = zbxConfig(
                os.path.join(os.path.dirname(__file__), 'libzabbix', 'config.ini')
            )
        except Exception as err:
            raise ZabbixError('Error while parsing conf : {}'.format(err))

        try:
            zabbix_api_url = get_zabbix_url()
            self._zbx = zbxApi(
                zbxUrl=cf.zbxGetApiConfig()['{}'.format(zabbix_api_url)],
                zbxUser=cf.zbxGetApiConfig()['zbxApiUser'],
                zbxPwd=cf.zbxGetApiConfig()['zbxApiUserPwd']
            )
            self._zbx.zbxLogin()
        except Exception as err:
            raise ZabbixError(
                'Error while trying to connect on zabbix url {}. err={}'.format(cf.zbxGetApiConfig()['zbxApiUrl'], err)
            )

    def get_host_id(self, hostname):
        return self._zbx.zbxGetHosts(hostname)[0]['hostid']

    def get_template_id(self, name):
        return self._zbx.zbxGetTemplateId(name)

    def link_host_to_template(self, host_id, template_id):
        return self._zbx.zbxLinkHostToTemplate(host_id, template_id)

    def unlink_host_to_template(self, host_id, template_id):
        return self._zbx.zbxUnlinkHostToTemplate(host_id, template_id)

    def get_templates_linked_to_host(self, host_id):
        return [v['templateid'] for v in self._zbx.zbxGetTemplatesLinkedToHostid(host_id)[0]["parentTemplates"]]

    def create_user_macro(self, **kwargs):
        return self._zbx.zbx_user_macro_create(**kwargs)

    def update_user_macros(self, **kwargs):
        return self._zbx.zbx_user_macro_update(**kwargs)

    def get_user_macro(self, host_id):
        return self._zbx.zbx_get_user_macros(host_id)

    def delete_user_macro(self, macroid):
        return self._zbx.zbx_delete_user_macros(macroid)

    def get_host_group(self, group_name):
        return self._zbx.zbx_get_hostgroup(group_name)

    def insert_in_hostgroup(self, group_id, host_id):
        return self._zbx.zbx_hostgroup_msadd(group_id, host_id)

    def remove_from_hostgroup(self, group_id, host_id):
        return self._zbx.zbx_hostgroup_msremove(group_id, host_id)


def main():
    parser = argparse.ArgumentParser(description='Zabbix : process some actions...')
    parser.add_argument('--host', type=str, help='Hostname to link')
    parser.add_argument('--tpl',
                        choices=('SG_POSTGRESQL', 'SG_POSTGRESQL_PGHOARD', 'SG_MongoDB_EDGE', 'SG_MongoDB_EDGE_ARBITER'), help='Template to link to hostname')
    parser.add_argument('--link-host-tpl', action='store_true', help='Link host to template')
    parser.add_argument('--unlink-host-tpl', action='store_true', help='unlink host to template')
    parser.add_argument('--dbhost', type=str, help='Hostname to link')
    parser.add_argument('--dbport', type=str, help='instance port')
    parser.add_argument('--dbusername', type=str, help='mongodb username')
    parser.add_argument('--dbpassword', type=str, help='mongodb password')
    parser.add_argument('--dbinstance', type=str, help='mongodb instance name')
    parser.add_argument('--test-if-host-exists-in-infra', action='store_true', help='Test if host is present in zabbix infra...')

    args = parser.parse_args()
    if args.link_host_tpl:
        if not args.host:
            raise Exception('Missing argument --host for --link-host-tpl')
        if not args.tpl:
            raise Exception('Missing argument --tpl for --link-host-tpl')
        else:
            if args.tpl == 'SG_MongoDB_EDGE':
                if not args.dbhost:
                    raise Exception('Missing argument --dbhost for --tpl')
                if not args.dbport:
                    raise Exception('Missing argument --dbport for --tpl')
                if not args.dbusername:
                    raise Exception('Missing argument --dbusername for --tpl')
                if not args.dbpassword:
                    raise Exception('Missing argument --dbpassword for --tpl')
                if not args.dbinstance:
                    raise Exception('Missing argument --dbinstance for --tpl')

                zbx = Zabbix()
                host_id = zbx.get_host_id(args.host)
                macros = [
                    {
                        "hostid": host_id,
                        "macro": "{$DBM_HOST}",
                        "value": args.dbhost
                    },
                    {
                        "hostid": host_id,
                        "macro": "{$DBM_PORT}",
                        "value": args.dbport
                    },
                    {
                        "hostid": host_id,
                        "macro": "{$DBM_USERNAME}",
                        "value": args.dbusername
                    },
                    {
                        "hostid": host_id,
                        "macro": "{$DBM_PASSWORD}",
                        "value": args.dbpassword
                    },
                    {
                        "hostid": host_id,
                        "macro": "{$DBM_INSTANCE}",
                        "value": args.dbinstance
                    },

                ]
                try:
                    user_macros = zbx.get_user_macro(host_id)['result']
                    if len(user_macros) == 0:
                        for macro in macros:
                            zbx.create_user_macro(**macro)
                    else:
                        for macro in user_macros:
                            zbx.delete_user_macro(macro['hostmacroid'])
                        for macro in macros:
                            zbx.create_user_macro(**macro)

                except Exception:
                    raise
                try:
                    get_host_group_id = zbx.get_host_group('SG_SGDB/SG_MGDB_EDGE')
                    host_group_id = get_host_group_id['result'][0]['groupid']
                    zbx.insert_in_hostgroup(group_id=host_group_id, host_id=host_id)
                except Exception:
                    raise

            elif args.tpl == 'SG_MongoDB_EDGE_ARBITER':
                if not args.dbhost:
                    raise Exception('Missing argument --dbhost for --tpl')
                if not args.dbinstance:
                    raise Exception('Missing argument --dbinstance for --tpl')

                zbx = Zabbix()
                host_id = zbx.get_host_id(args.host)
                macros = [
                    {
                        "hostid": host_id,
                        "macro": "{$DBM_HOST_A}",
                        "value": args.dbhost
                    },
                    {
                        "hostid": host_id,
                        "macro": "{$DBM_INSTANCE_A}",
                        "value": args.dbinstance
                    },

                ]

                try:
                    user_macros = zbx.get_user_macro(host_id)['result']
                    if len(user_macros) == 0:
                        for macro in macros:
                            zbx.create_user_macro(**macro)
                    else:
                        for macro in user_macros:
                            zbx.delete_user_macro(macro['hostmacroid'])
                        for macro in macros:
                            zbx.create_user_macro(**macro)

                except Exception:
                    raise
                try:
                    get_host_group_id = zbx.get_host_group('SG_SGDB/SG_MGDB_EDGE_ARB')
                    host_group_id = get_host_group_id['result'][0]['groupid']
                    zbx.insert_in_hostgroup(group_id=host_group_id, host_id=host_id)
                except Exception:
                    raise


        zbx = Zabbix()
        host_id = zbx.get_host_id(args.host)
        template_id = zbx.get_template_id(args.tpl)
        output = zbx.link_host_to_template(host_id, template_id)
        if output['hostids'][0] == host_id:
            sys.exit(0)
        else:
            try:
                error = str(output)
            except Exception:
                error = None
            raise ZabbixError(
                "Error while linking host={} with template={}, err={}".format(args.host, args.tpl, error)
            )

    elif args.unlink_host_tpl:
        if not args.host:
            raise Exception('Missing argument --host for --unlink-host-tpl')
        if not args.tpl:
            raise Exception('Missing argument --tpl for --unlink-host-tpl')
        else:
            if args.tpl == 'SG_MongoDB_EDGE' or args.tpl == 'SG_MongoDB_EDGE_ARBITER':
                zbx = Zabbix()
                host_id = zbx.get_host_id(args.host)
                try:
                    if args.tpl == 'SG_MongoDB_EDGE':
                        get_host_group_id = zbx.get_host_group('SG_SGDB/SG_MGDB_EDGE')
                        host_group_id = get_host_group_id['result'][0]['groupid']
                        zbx.remove_from_hostgroup(group_id=host_group_id, host_id=host_id)
                    elif args.tpl == 'SG_MongoDB_EDGE_ARBITER':
                        get_host_group_id = zbx.get_host_group('SG_SGDB/SG_MGDB_EDGE_ARB')
                        host_group_id = get_host_group_id['result'][0]['groupid']
                        zbx.remove_from_hostgroup(group_id=host_group_id, host_id=host_id)
                except Exception:
                    raise

        zbx = Zabbix()
        host_id = zbx.get_host_id(args.host)
        template_id = zbx.get_template_id(args.tpl)
        templates = zbx.get_templates_linked_to_host(host_id)
        if template_id not in templates:
            sys.exit(0)
        else:
            output = zbx.unlink_host_to_template(host_id, template_id)
            if output['hostids'][0] == host_id:
                sys.exit(0)
            else:
                try:
                    error = str(output)
                except Exception:
                    error = None
                raise ZabbixError(
                    "Error while unlinking host={} with template={}, err={}".format(args.host, args.tpl, error)
                )
    elif args.test_if_host_exists_in_infra:
        if not args.host:
            raise Exception('Missing argument --host for --test-if-host-exists-in-infra')
        zbx = Zabbix()
        try:
            print(zbx.get_host_id(args.host))
            sys.exit(0)
        except Exception as err:
            print(err.args[0])
            sys.exit(1)


if __name__ == '__main__':
    main()

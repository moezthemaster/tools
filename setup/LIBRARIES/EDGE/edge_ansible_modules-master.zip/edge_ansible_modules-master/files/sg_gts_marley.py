import os
import sys
import logging
import io
import datetime

if "TREE_DIR" in os.environ.keys():
    ANSIBLE_MODULES_PATH = [
        os.path.join(os.environ["TREE_DIR"], 'roles/edge'),
        os.path.join(os.environ["TREE_DIR"], 'roles/incubaw'),
        os.path.join(os.environ["TREE_DIR"], 'roles/py_edge_vault'),
        os.path.join(os.environ["TREE_DIR"], "library"),
    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/edge',
        './roles/incubaw',
        './roles/py_edge_vault'
    ]
for path in ANSIBLE_MODULES_PATH:
    sys.path.append(path)

import edge.interfaces
from edge.kpi.elk import Loader
from incubaw.hpoo import HpooAW
from edge.marley.manage_asset import MarleyLoader
from ansible.module_utils.basic import AnsibleModule

formatter = logging.Formatter(fmt='%(asctime)s %(levelname)-8s %(message)s',
                              datefmt='%Y-%m-%d %H:%M:%S')
logstream = io.StringIO()
handler = logging.StreamHandler(logstream)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.addHandler(handler)
logger.setLevel(logging.WARNING)


class MarleyHPOOImpl(edge.interfaces.MarleyHPOO):
    def __init__(self):
        self.hpoo = HpooAW()

    def marley_hpoo_execute(self, **params):
        return self.hpoo.execute(**params)

    def marley_hpoo_status(self, **params):
        return self.hpoo.check_completion_step(**params)


class MarleyLoaderImpl(MarleyLoader, MarleyHPOOImpl):
    pass



FIELDS = {
    "marley_operation": {
        "choices": ['create', 'decom'],
        "required": False,
        "type": "str"
    },
    "vm_hostname": {
        "required": False,
        "type": "str"
    },
    "vm_os": {
        "required": False,
        "type": "str"
    },
    "vm_profile": {
        "default": "Micro 1vCPU-1GB",
        "choices": ['Micro 1vCPU-1GB', 'Small 1vCPU-2GB', 'Small-mem4 1vCPU-4GB', 'Medium-mem2 2vCPU-2GB',
                    'Medium 2vCPU-4GB', 'Medium-mem8 2vCPU-8GB', 'Medium-mem16 2vCPU-16GB', 'Medium-mem32 2vCPU-32GB',
                    'Large 4vCPU-8GB', 'Large-mem16 4vCPU-16GB', 'Large-mem32 4vCPU-32GB', 'XLarge 8vCPU-16GB',
                    'XLarge-mem32 8vCPU-32GB', 'XLarge-mem64 8vCPU-64GB', 'XLarge-mem128 8vCPU-128GB'],
        "type": "str",
        "required": False
    },
    "code_irt": {
        "required": False,
        "type": "str"
    },
    "endClient": {
        "required": False,
        "type": "str"
    },
    "app_env": {
        "default": "prd",
        "choices": [
            'uat',
            'tst',
            'int',
            'dev',
            'hml',
            'prd'
        ],
        "type": "str",
        "required": False
    },
    "disk_size": {
        "default": 0,
        "type": "int",
        "choices": [0, 20, 60, 160, 300, 500, 750, 1000, 2000],
        "required": False
    },
    "vm_backup": {
        "default": "none",
        "choices": ['none', 'daily-31d-2AM', 'daily-31d-4AM'],
        "type": "str",
        "required": False
    },
    "kpi_data": {
        "type": "dict"
    },
    "state": {
        "default": "none",
        "choices": ['none', 'status'],
        "required": False
    },
    "id_execution": {
        "type": "int",
        "required": False
    },


}


def index_error_kpi(kpi_data,kpi_start_time):
    try:
        kpi_end_time = datetime.datetime.now()
        kpi_data['duration'] = (kpi_end_time - kpi_start_time).seconds
        loader = Loader()
        loader.index_data(
            id_execution=kpi_data['id_execution'], timestamp=kpi_data['timestamp'], 
            duration=kpi_data['duration'], service="sg_gts_marley",
            hostname=kpi_data['vm_hostname'], status="failure",
            category=kpi_data['category'], client=kpi_data['endClient'],
            trigram=kpi_data['app_id'], environment=kpi_data['app_env'],
            error=kpi_data['error'], playbook_version=kpi_data['playbook_version']
        )
    except Exception:
        pass

def main():
    module = AnsibleModule(argument_spec=FIELDS)
    if module._verbosity == 1:
        logger.setLevel(logging.INFO)
    if module._verbosity == 3:
        logger.setLevel(logging.DEBUG)
    logger.info('module sg_gts_marley called')
    kpi_data = module.params['kpi_data']
    kpi_start_time = datetime.datetime.now()
    state = module.params['state']

    if state == 'status':
        try:
            marley = MarleyLoaderImpl()
            response = marley.marley_hpoo_status(executionId=module.params['id_execution'])
            module.exit_json(changed=True, meta=response, debug_out=logstream.getvalue())
        except Exception:
            pass
    else:
        try:
            marley = MarleyLoaderImpl()
            response = marley.invoc_step_marley_v5(
                marley_operation=module.params['marley_operation'],
                vm_hostname=module.params['vm_hostname'],
                vm_os=module.params['vm_os'],
                vm_profile=module.params['vm_profile'],
                code_irt=module.params['code_irt'],
                endClient=module.params['endClient'],
                app_env=module.params['app_env'],
                disk_size=module.params['disk_size'],
                vm_backup=module.params['vm_backup']
            )
            module.exit_json(changed=True, meta=response, debug_out=logstream.getvalue())
        except Exception as e:
            if isinstance(kpi_data, dict):
                kpi_data['error'] = e.args[0]
                index_error_kpi(kpi_data,kpi_start_time)
            module.fail_json(msg=e.args[0], debug_out=logstream.getvalue())

if __name__ == '__main__':
    main()

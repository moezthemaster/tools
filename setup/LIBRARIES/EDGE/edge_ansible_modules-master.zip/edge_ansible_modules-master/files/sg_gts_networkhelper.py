import re
import os
import sys
import io
import logging
import datetime

if "TREE_DIR" in os.environ.keys():
    ANSIBLE_MODULES_PATH = [
        os.path.join(os.environ["TREE_DIR"], 'roles/edge'),
        os.path.join(os.environ["TREE_DIR"], 'roles/py_edge_vault'),
        os.path.join(os.environ["TREE_DIR"], "library"),
    ]
else:
    ANSIBLE_MODULES_PATH = [
        './roles/edge',
        './roles/py_edge_vault'
    ]
for path in ANSIBLE_MODULES_PATH:
    sys.path.append(path)

from edge.kpi.elk import Loader
from edge.network.networkhelper import NetworkHelper
from ansible.module_utils.basic import AnsibleModule

formatter = logging.Formatter(fmt='%(asctime)s %(levelname)-8s %(message)s',
                              datefmt='%Y-%m-%d %H:%M:%S')
logstream = io.StringIO()
handler = logging.StreamHandler(logstream)
handler.setFormatter(formatter)
logger = logging.getLogger(__name__)
logger.addHandler(handler)
logger.setLevel(logging.WARNING)


class NetworkHelperImp(NetworkHelper):
    def __init__(self):
        NetworkHelper.__init__(self)

    def configure_network(self, ip, network_id, geo_domain, network_envi, network_az=None):
        response = self.update_etc_host(ip_address=ip, network_id=network_id)
        if response != "OK":
            return "Update error for /etc/host"
        response = self.update_dns_config(
            ip_address=ip, geo_domain=geo_domain, network_id=network_id, network_envi=network_envi,
            network_az=network_az
        )
        if response != "OK":
            return "Update error for DNS configuration"
        response = self.configure_ntp(ip_address=ip, network_id=network_id, network_az=network_az)
        if response != "OK":
            return "Update error for NTP configuration"
        response = self.configure_rsyslog(ip_address=ip, network_id=network_id, network_az=network_az)
        if response != "OK":
            return "Error for RSYSLOG configuration"
        return "OK"


PRESENT = 'present'

FIELDS = {
    "ip": {"required": True, "type": "str"},
    "network_domain": {"required": True, "type": "str"},
    "network_id": {"required": False, "type": "str"},
    "state": {
        "default": "present",
        "choices": ['present'],
        "type": 'str'
    },
    "app_env": {
        "default": "prd",
        "choices": [
            'uat',
            'tst',
            'int',
            'dev',
            'hml',
            'prd'
        ],
        "type": "str",
        "required": False
    },
    "network_az": {
        "default": None,
        "required": False,
        "type": "str"
    },
    "endClient": {
        "required": False,
        "type": "str"
    },
    "kpi_data": {
        "type": "dict"
    }
}


def index_error_kpi(kpi_data,kpi_start_time):
    try:
        kpi_end_time = datetime.datetime.now()
        kpi_data['duration'] = (kpi_end_time - kpi_start_time).seconds
        loader = Loader()
        loader.index_data(
            id_execution=kpi_data['id_execution'], timestamp=kpi_data['timestamp'], 
            duration=kpi_data['duration'], service="sg_gts_network_helper",
            hostname=kpi_data['vm_hostname'], status="failure",
            category=kpi_data['category'], client=kpi_data['endClient'],
            trigram=kpi_data['app_id'], environment=kpi_data['app_env'],
            error=kpi_data['error'], playbook_version=kpi_data['playbook_version']
        )
    except Exception:
        pass

def main():
    module = AnsibleModule(argument_spec=FIELDS)
    if module._verbosity == 1:
        logger.setLevel(logging.INFO)
    if module._verbosity == 3:
        logger.setLevel(logging.DEBUG)
    logger.info('module sg_gts_networkhelper')
    kpi_data = module.params['kpi_data']
    kpi_start_time = datetime.datetime.now()

    try:
        state = module.params['state']
        networkhelper = NetworkHelperImp()

        if state == PRESENT:
            response = networkhelper.configure_network(
                ip=module.params['ip'],
                geo_domain=module.params['network_domain'],
                network_id=module.params['network_id'],
                network_envi=module.params['app_env'],
                network_az=module.params['network_az']
            )
            if response == "OK":
               module.exit_json(changed=networkhelper.has_changed, meta=response, debug_out=logstream.getvalue())
            else:
                if isinstance(kpi_data, dict):
                    kpi_data['error'] = response
                    index_error_kpi(kpi_data,kpi_start_time)
                module.fail_json(changed=networkhelper.has_changed, msg=response, debug_out=logstream.getvalue())

    except Exception as e:
        if isinstance(kpi_data, dict):            
            kpi_data['error'] = e.args[0]
            index_error_kpi(kpi_data,kpi_start_time)
        module.fail_json(msg=e.args[0], debug_out=logstream.getvalue())


if __name__ == '__main__':
    main()

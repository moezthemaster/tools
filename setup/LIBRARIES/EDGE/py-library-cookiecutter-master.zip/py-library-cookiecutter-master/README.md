# Cookie Cutter for Python libraries  - GTSMKTCLD Edition
This repository is a fork of https://sgithub.fr.world.socgen/BeAPI/py-library-cookiecutter adapted from [Pypa's sample project](https://github.com/pypa/sampleproject) and relying on [Cookie Cutter](https://github.com/audreyr/cookiecutter) for generation

This provide a template for a basic python library, adapted to our CI/CD needs and our jenkins slave particularity.
You'll have a sane basis to start your library, and to share it with ease.

## Features

:heavy_check_mark: Run **tests** at each push

:heavy_check_mark: Check **Pull Requests** automatically (with sGitHub integration)

:heavy_check_mark: Run **code analysis** with SonarQube, , etc...

:heavy_check_mark: Calculate **test coverage**

:heavy_check_mark: **Tag your releases** on Git

:heavy_check_mark: **Publish** to [Artifactory](https://cdp-artifactory.fr.world.socgen)

## How to use for yourself :

### Requirements :

* Access to sGitHub
* Access to a Jenkins instance
* A repo on Artifactory

If you miss something from the list, you can contact the team ITEC/ARC/LAB/CDP (in charge of the CD Platform) [here](http://go/cochd)

### Prepare Jenkins :

**This needs to be done only once per orga, so it's probably already done (if you're from BeAPI for example)**

To know if it's done, check on your Jenkins for two GitHub organization jobs with the name of your orga and orga-release

Use [this documentation](docs/Jenkins-setup.md) if it's not done already

### Prepare the repo :

1. Go to the working folder on your machine, and use the cookie cutter to set everything up :

    ```
    pip install cookiecutter
    cookiecutter https://sgithub.fr.world.socgen/GTS-RET-AUTOMATION-EDGE/py-library-cookiecutter.git
    ```

2. Answer honestly to all that is asked. Most of the default answers are ok for the GTSMKTCLD sgithub organization. You can check the default in the file cookiecutter.json file.
3. A folder matching your project name has been created. Now, on sGitHub, **create a repo starting with ```py-``` followed by the name of your folder** and on the orga you filled.
4. Got to your cookiecutted folder, init your git repo and push :

    ```
    git init
    git add *
    git commit -m "First push"
    git remote add origin https://sgithub.fr.world.socgen/<orga>/<repo>.git
    git push -u origin master
    ```

5. You're all set, start coding !

## What is happening ?

**Assuming the [Jenkins setup](docs/Jenkins-setup.md) is done**, the first time you'll push, Jenkins will be notified that a new repo has been created

It will scan for Jenkinsfile and create the associated jobs.

The job will run your tests do a Sonar Code analysis, update the version , create a tag if you don't release a development version, push the new version to github and deploy it to artifactory.

This allows you to make sure your code is always tested, linted, and that code quality is in check.

## How do I release ?

**Two settings must be set in jenkins/job.properties file.**

**release_type=dev**
**run_pipeline=false**

The **release_type** variable will update your version and can have the following values:
 - **dev** e.g. Increase dev version, e.g. 1.1.0.dev0 to 1.1.0.dev1
 - **patch** e.g. push 1.1.0 and switch 1.1.0.dev0 to 2.0.0.dev0
 - **minor** e.g. push 1.1.0 and switch 1.1.0.dev0 to 1.2.0.dev0
 - **major** e.g. push 1.1.0 and switch 1.1.0.dev0 to 1.1.1.dev0

The **run_pipeline** variable is evaluate at the very beginning of the pipeline to know if it will run. You must set it to **true** if you want to run the pipeline. At the end of the pipeline, it is reset to **false**

Currently, the Jenkinsfile is automatically called at each push and the pipeline **also** push which can cause deployment loop.
To avoid this issue, the **run_pipeline** variable exist and **must be set manually each time during your development.**
However, this will create two jenkins job for each commit. One full (with run_pipeline=true) and one aborted (with run_pipeline=false)

## What's that about code analysis, code coverage, etc... ?

On your continuous job, check for the SonarQube icon for each job and click on it :

![SonarQube icon on Jenkins](docs/resources/jenkins-sonar.PNG)

Which will lead you to the wonderful world of Sonar, providing you insight on your code :

![Sonar UI sample](docs/resources/sonar.PNG)

## I heard something about Pull Requests and GitHub integration ?

Whenever a pull request is done (or for each subsequent commit on the PR), the Continuous compile job will run
and tell you if everything is good.

![Pull Request validation](docs/resources/pr-validation.PNG)

## You also mentioned publishing on Artifactory

During a release, your package will be published in your repo in Artifactory. This means the latest version will automatically be made available to
everyone via a simple ```pip install <package>```

## Coding style

[Follow the book](https://www.python.org/dev/peps/pep-0008/), and remember : A Foolish Consistency is the Hobgoblin of Little Minds.


import time

from ccs_celery.abstract import TaskServiceManager
from ccs_celery.services._kat.module import kat_module


class KatTask(TaskServiceManager):
    def __init__(self, data):
        super().__init__("Kat", data)

    def on_failure(self, exc, kwargs, excinfo):
        self.data.services[self._task_name]["finished_at"] = time.time()
        self.data.services[self._task_name]["status"] = "FAILED"
        self.data.services[self._task_name]["exception_class"] = str(type(exc))
        self.data.services[self._task_name]["exception_msg"] = str(exc)
        self.data.services[self._task_name]["exception_traceback"] = str(excinfo)


    def on_success(self, result, kwargs):
        self.data.services[self._task_name]["finished_at"] = time.time()
        self.data.services[self._task_name]["status"] = "SUCCESS"
        self.data.services[self._task_name]["return_value"] = result

    def _set_up(self):
        interesting_keys = ('app_id', 'code_irt', 'deprecated_endClient')
        self.data.services[self._task_name] = {
            "changed": False,
            "launch_at": time.time(),
            "service_kwargs": {x: self.data.shared_data[x] for x in interesting_keys if x in self.data.shared_data},
        }
        self.data.services[self._task_name]["service_kwargs"]["state"] = "present"

    def task(self):
        self._set_up()
        self.logger.info("Invoke {} module with kwargs={}".format(
            self._task_name,
            self.data.services[self._task_name]["service_kwargs"])
        )
        result = kat_module(
            trigram=self.data.services[self._task_name]["service_kwargs"]["app_id"],
            irt_code=self.data.services[self._task_name]["service_kwargs"]["code_irt"],
            default_client=self.data.services[self._task_name]["service_kwargs"]["deprecated_endClient"]
        )
        self.data.shared_data["endClient"] = result
        return result

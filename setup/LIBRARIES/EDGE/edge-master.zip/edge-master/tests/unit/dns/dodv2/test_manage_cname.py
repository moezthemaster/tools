import logging

import pytest

import edge.exception
import edge.dns.dodv2.tools
from tests.mock.mock import MockDod

logging.basicConfig(level=logging.DEBUG)

logger = logging.getLogger(__name__)


class MockedManageCname(MockDod, edge.dns.dodv2.tools.ManageCname):
    def __init__(self, init_types, env=None, region_cloud=None, az_cloud=None, network_id=None, alias=None, alias_zone=None, hostname="dummy"):
        MockDod.__init__(self, init_types, hostname=hostname)
        edge.dns.dodv2.tools.ManageCname.__init__(self,
            env=env, region_cloud=region_cloud, az_cloud=az_cloud,
            network_id=network_id, hostname=hostname, alias=alias, alias_zone=alias_zone
        )


class MockedManageCname2(MockDod, edge.dns.dodv2.tools.ManageCname):
    def __init__(self, init_types, alias=None, alias_zone=None, hostname="dummy"):
        MockDod.__init__(self, init_types, hostname=hostname)
        edge.dns.dodv2.tools.ManageCname.__init__(self, hostname=hostname, alias=alias, alias_zone=alias_zone)

#mocked_dod_inits = ([], ['A'], ['PTR'], ['CNAME'], ['A','PTR'], ['A','CNAME'], ['PTR', 'CNAME'], ['A', 'PTR', 'CNAME'])
MOCKED_DOD_INITS = (("CNAME",),)

HOSTNAME = "dpgalx200"
HOSTNAME1 = "dpgalx201"


@pytest.fixture(params=MOCKED_DOD_INITS)
def mocked_dod_init(request):
    return request.param


@pytest.fixture(scope="class")
def mocked_manage_cname(request):
    request.cls.manage_cname = MockedManageCname(
        init_types=MOCKED_DOD_INITS, hostname="dummy", alias="dpgalx200alias",
        env='dev', region_cloud='EU France (Greater Paris)',
        az_cloud='eu-fr-paris-1', network_id='CDN',
        alias_zone="ppr.cdn.socgen"
    )

@pytest.fixture(scope="class")
def mocked_manage_cname_without_cloud_infos(request):
    request.cls.manage_cname = MockedManageCname2(
        init_types=MOCKED_DOD_INITS, hostname="dummy", alias="dpgalx200alias",
        alias_zone="ppr.cdn.socgen"
    )


@pytest.mark.usefixtures("mocked_manage_cname")
class TestManageCname(object):
    def test_create_alias(self):
        self.manage_cname.hostname = HOSTNAME
        self.manage_cname.create_dns_record(
            dns_service="UAT FRANCE RET",
            record_type="A",
            zone=self.manage_cname.hostname_zone,
            view="production",
            hostname=HOSTNAME
        )
        self.manage_cname.record_cname()
        searches = self.manage_cname.search_dns_record(record_type="CNAME", dns_service="UAT FRANCE RET", view="production")
        found_cname = next((item for item in searches if item["alias"] == self.manage_cname.alias), None)
        assert found_cname["alias"] == self.manage_cname.alias
        assert self.manage_cname.changed

    def test_create_same_alias(self):
        self.manage_cname.changed = False
        result = self.manage_cname.record_cname()
        assert self.manage_cname.changed is False
        assert result["alias"] == self.manage_cname.alias

    def test_create_same_alias_with_same_zone_and_different_hostname(self):
        self.manage_cname.changed = False
        self.manage_cname.hostname = HOSTNAME1
        self.manage_cname.create_dns_record(
            dns_service="UAT FRANCE RET",
            record_type="A",
            zone=self.manage_cname.hostname_zone,
            view="production",
            hostname=HOSTNAME1
        )
        self.manage_cname.record_cname()
        assert self.manage_cname.changed is False

    def test_create_same_alias_with_different_zone_and_different_hostname(self):
        self.manage_cname.changed = False
        self.manage_cname.hostname = HOSTNAME1
        self.manage_cname.network_id = "CITS"
        self.manage_cname.alias_zone = "dns21.socgen"
        self.manage_cname.create_dns_record(
            dns_service="UAT FRANCE RET",
            record_type="A",
            zone=self.manage_cname.hostname_zone,
            view="production",
            hostname=HOSTNAME1
        )
        self.manage_cname.record_cname()
        assert self.manage_cname.changed

    def test_delete_cname_of_HOSTNAME1(self):
        self.manage_cname.changed = False
        self.manage_cname.delete_cname()
        assert self.manage_cname.changed

    def test_redelete_cname_of_HOSTNAME1(self):
        self.manage_cname.changed = False
        self.manage_cname.delete_cname()
        assert self.manage_cname.changed is False

    def test_delete_cname_of_HOSTNAME(self):
        self.manage_cname.changed = False
        self.manage_cname.hostname = HOSTNAME
        self.manage_cname.network_id = "CDN"
        self.manage_cname.alias_zone = "ppr.cdn.socgen"
        self.manage_cname.delete_cname()
        assert self.manage_cname.changed

    def test_delete_cname_which_not_exist_of_HOSTNAME(self):
        self.manage_cname.changed = False
        self.manage_cname.hostname = HOSTNAME
        self.manage_cname.network_id = "CDN"
        self.manage_cname.alias = "aliasdoesnotexist"
        result = self.manage_cname.delete_cname()
        assert self.manage_cname.changed is False
        assert result["msg"] == "record CNAME {} does not exist, no record deleted for hostname {}".format(
            "{}.{}.".format(self.manage_cname.alias, "ppr.cdn.socgen"),
            HOSTNAME
        )

    def test_delete_cname_with_fake_newtork_id(self):
        self.manage_cname.changed = False
        self.manage_cname.hostname = HOSTNAME
        self.manage_cname.network_id = "FAKENETWORKID"
        self.manage_cname.alias = "aliasdoesnotexist"
        with pytest.raises(edge.exception.EdgeException):
            self.manage_cname.delete_cname()

    def test_create_alias_with_hostname_without_zone(self):
        self.manage_cname.hostname = "hostnamewithoutzone"
        self.manage_cname.alias = "hostnamewithoutzonealias"
        self.manage_cname.network_id = "CDN"
        self.manage_cname.alias_zone = "ppr.cdn.socgen"
        self.manage_cname.hostname_fqdn = "hostnamewithoutzone"
        self.manage_cname.create_dns_record(
            dns_service="UAT FRANCE RET",
            record_type="A",
            zone="ppr.cdn.socgen",
            view="production",
            hostname="hostnamewithoutzone"
        )
        self.manage_cname.record_cname()
        searches = self.manage_cname.search_dns_record(record_type="CNAME", dns_service="UAT FRANCE RET", view="production")
        found_cname = next((item for item in searches if item["alias"] == self.manage_cname.alias), None)
        assert found_cname["alias"] == self.manage_cname.alias
        assert self.manage_cname.changed

    def test_delete_cname_of_hostname_without_zone(self):
        self.manage_cname.changed = False
        self.manage_cname.hostname = "hostnamewithoutzone"
        self.manage_cname.alias = "hostnamewithoutzonealias"
        self.manage_cname.alias_zone = "ppr.cdn.socgen"
        self.manage_cname.network_id = "CDN"
        self.manage_cname.delete_cname()
        assert self.manage_cname.changed


@pytest.mark.usefixtures("mocked_manage_cname_without_cloud_infos")
class TestManageCname_Without_Cloud_Infos(object):
    def test_create_alias(self):
        self.manage_cname.hostname = HOSTNAME
        self.manage_cname.create_dns_record(
            dns_service="UAT FRANCE RET",
            record_type="A",
            zone="ppr.cdn.socgen",
            view="production",
            hostname=HOSTNAME
        )
        self.manage_cname.record_cname()
        searches = self.manage_cname.search_dns_record(record_type="CNAME", dns_service="UAT FRANCE RET", view="production")
        found_cname = next((item for item in searches if item["alias"] == self.manage_cname.alias), None)
        assert found_cname["alias"] == self.manage_cname.alias
        assert self.manage_cname.changed

    def test_create_same_alias(self):
        self.manage_cname.changed = False
        result = self.manage_cname.record_cname()
        assert self.manage_cname.changed is False
        assert result["alias"] == self.manage_cname.alias

    def test_create_same_alias_with_same_zone_and_different_hostname(self):
        self.manage_cname.changed = False
        self.manage_cname.hostname = HOSTNAME1
        self.manage_cname._hostname_zone = "dns21-3.socgen"
        self.manage_cname.create_dns_record(
            dns_service="UAT FRANCE RET",
            record_type="A",
            zone="dns21-3.socgen",
            view="production",
            hostname=HOSTNAME1
        )
        self.manage_cname.record_cname()
        assert self.manage_cname.changed is False

    def test_create_same_alias_with_different_zone_and_different_hostname(self):
        self.manage_cname.changed = False
        self.manage_cname.hostname = HOSTNAME1
        self.manage_cname.network_id = "CITS"
        self.manage_cname.alias_zone = "dns21.socgen"
        self.manage_cname.record_cname()
        assert self.manage_cname.changed

    def test_delete_cname_of_HOSTNAME1(self):
        self.manage_cname.changed = False
        self.manage_cname.delete_cname()
        assert self.manage_cname.changed

    def test_redelete_cname_of_HOSTNAME1(self):
        self.manage_cname.changed = False
        self.manage_cname.delete_cname()
        assert self.manage_cname.changed is False

    def test_delete_cname_of_HOSTNAME(self):
        self.manage_cname.changed = False
        self.manage_cname.hostname = HOSTNAME
        self.manage_cname.network_id = "CDN"
        self.manage_cname._hostname_zone = "ppr.cdn.socgen"
        self.manage_cname.alias_zone = "ppr.cdn.socgen"
        self.manage_cname.delete_cname()
        assert self.manage_cname.changed

    def test_delete_cname_which_not_exist_of_HOSTNAME(self):
        self.manage_cname.changed = False
        self.manage_cname.hostname = HOSTNAME
        self.manage_cname.network_id = "CDN"
        self.manage_cname.alias = "aliasdoesnotexist"
        result = self.manage_cname.delete_cname()
        assert self.manage_cname.changed is False
        assert result["msg"] == "record CNAME {} does not exist, no record deleted for hostname {}".format(
            "{}.{}.".format(self.manage_cname.alias, "ppr.cdn.socgen"),
            HOSTNAME
        )

    def test_create_alias_with_hostname_without_zone(self):
        self.manage_cname.hostname = "hostnamewithoutzone"
        self.manage_cname.alias = "hostnamewithoutzonealias"
        self.manage_cname.network_id = "CDN"
        self.manage_cname.alias_zone = "ppr.cdn.socgen"
        self.manage_cname.hostname_fqdn = "hostnamewithoutzone"
        self.manage_cname.create_dns_record(
            dns_service="UAT FRANCE RET",
            record_type="A",
            zone="ppr.cdn.socgen",
            view="production",
            hostname="hostnamewithoutzone"
        )
        self.manage_cname.record_cname()
        searches = self.manage_cname.search_dns_record(record_type="CNAME", dns_service="UAT FRANCE RET",
                                                       view="production")
        found_cname = next((item for item in searches if item["alias"] == self.manage_cname.alias), None)
        assert found_cname["alias"] == self.manage_cname.alias
        assert self.manage_cname.changed

    def test_delete_cname_of_hostname_without_zone(self):
        self.manage_cname.changed = False
        self.manage_cname.hostname = "hostnamewithoutzone"
        self.manage_cname.alias = "hostnamewithoutzonealias"
        self.manage_cname.alias_zone = "ppr.cdn.socgen"
        self.manage_cname.network_id = "CDN"
        self.manage_cname.delete_cname()
        assert self.manage_cname.changed

#!/bin/bash
##################################################
# Main authors: Arnauld FRACHE and Olivier ANSQUIN
# Description: zabbix mongodb monitor
# Date: 2018, september 18
# Version: 1.0
# Requirements: mongo, jq ,MongoDB account
# Example : ./zbx_MongoDB_Replicaset_Avail.sh localhost 12500 zabbix zabbix dauddaud

# Results : numbers ...
#
##################################################
# set -xv # Debug
#
DB_HOST=$1
DB_PORT=$2
DB_USERNAME=$3
DB_PASSWORD=$4
DB_INSTANCE=$5
#
#
##################################################
# ENV - path for Mongo DB
##################################################
#
MONGO=`which mongo`
#
########
# echo "verif path Mongo:" $MONGO # DEBUG use
JQ="/etc/zabbix/zabbix_agentd.d/MGDB_EDGE/jq"
#echo "verif path jq tool :" $JQ # DEBUG use
EXIT_ERROR=1
EXIT_OK=0
#
if [ ! -x "$MONGO" ] ; then
  echo "mongo not found"
  exit $EXIT_ERROR
elif [ ! -x "$JQ" ] ; then
  echo "jq not found"
  exit $EXIT_ERROR
elif [ $# -eq 0 ] ; then
  echo "No values pass"
  exit $EXIT_ERROR
fi
##########################################
# DATA COLLECTION
# Build request
RSSTATUS=0
RSSTATUS=`$MONGO --host $DB_HOST --port $DB_PORT --authenticationDatabase admin --username $DB_USERNAME --password $DB_PASSWORD --quiet<<<"db.adminCommand( { replSetGetStatus : 1 } ).myState"`
if [ -n "$RSSTATUS" ] ; then
echo $RSSTATUS
else
echo 99
fi
exit 0
### END

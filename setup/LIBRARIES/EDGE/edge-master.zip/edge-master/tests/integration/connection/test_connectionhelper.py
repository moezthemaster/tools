from edge.connection.connectionhelper import ConnectionHelper
from edge.tools.tools import VmSessionSsh
from edge.exception import EdgeException
import time


class TestConnectionHelper(object):

    def test_connection_to_host_ok(self):
    	ssh_helper = ConnectionHelper()
    	reponse = ssh_helper.check_ssh_connection('192.88.65.34')
    	assert reponse == "dpgalx5900"
    def test_Pubkey_already_there(self):
        ssh_helper = ConnectionHelper()
        pubkey = "ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAyLXUQ9eoPr8Akx+WeJzRgAOMyUbTQ3/RDu44N2svQTa7I0ZKzqelNrSqqsgSmNN7giQGRyIvx/XgUwi9UjrxFX0XRTvwjAcXNHV2pxybbhPb8/2jiAfFTCjkwQBwtoSTEL1I5noAIgapQDZghYFkv0GUiAkebKzl0A+cNqm5Zc2UPNTqsCtIAZ5Uid+XOdECHan29Iyow0f+O/2O6mZKBGvWFJbRLCokKLUrTmhbgWIiWgQGp/PnF0XVVPiQgRfbRz1xH08JNiQz1lnvZ4ME4BhQoxSK1O8QL+dQsSXhvQyjfO8yYI+X4X73Ie9yBfZpPiGAZLo3hTVha46veVfZGw== a373785@PXPLSV02"
        print ("copie de la cle : {}".format(pubkey))
        reponse = ssh_helper.authorized_key(ip_address="192.88.65.34",remote_user="automation",remote_group="automation",pubkey=pubkey)
        print("reponse : {} ".format(reponse))
        assert reponse == pubkey
    def test_new_Pubkey(self):
        ssh_helper = ConnectionHelper()
        pubkey = "ssh-rsa AAAAB3NzaC1yc2BAAAABIwAAAQEAyLXUQ9eoPr8Akx+WeJzRgAOMyUbTQ3/RDu44N2svQTa7I0ZKzqelNrSqqsgSmNN7giQGRyIvx/XgUwi9UjrxFX0XRTvwjAcXNHV2pxybbhPb8/2jiAfFTCjkwQBwtoSTEL1I5noAIgapQDZghYFkv0GUiAkebKzl0A+cNqm5Zc2UPNTqsCtIAZ5Uid+XOdECHan29Iyow0f+O/2O6mZKBGvWFJbRLCokKLUrTmhbgWIiWgQGp/PnF0XVVPiQgRfbRz1xH08JNiQz1lnvZ4ME4BhQoxSK1O8QL+dQsSXhvQyjfO8yYI+X4X73Ie9yBfZpPiGAZLo3hTVha46veVfZ{}Gw == a373785@PXPLSV02".format(str(time.time()).replace('.','0'))
        print ("copie de la cle : {}".format(pubkey))
        reponse = ssh_helper.authorized_key(ip_address="192.88.65.34",remote_user="automation",remote_group="automation",pubkey=pubkey)
        print("reponse : {} ".format(reponse))
        assert reponse == "dpgalx5900"
    def test_new_Pubkey_timeout(self):
        ssh_helper = ConnectionHelper()
        pubkey = "ssh-rsa AAAAB3NzaC1yc2BAAAABIwAAAQEAyLXUQ9eoPr8Akx+WeJzRgAOMyUbTQ3/RDu44N2svQTa7I0ZKzqelNrSqqsgSmNN7giQGRyIvx/XgUwi9UjrxFX0XRTvwjAcXNHV2pxybbhPb8/2jiAfFTCjkwQBwtoSTEL1I5noAIgapQDZghYFkv0GUiAkebKzl0A+cNqm5Zc2UPNTqsCtIAZ5Uid+XOdECHan29Iyow0f+O/2O6mZKBGvWFJbRLCokKLUrTmhbgWIiWgQGp/PnF0XVVPiQgRfbRz1xH08JNiQz1lnvZ4ME4BhQoxSK1O8QL+dQsSXhvQyjfO8yYI+X4X73Ie9yBfZpPiGAZLo3hTVha46veVfZ{}Gw == a373785@PXPLSV02".format(str(time.time()).replace('.','0'))
        try : 
            reponse = ssh_helper.authorized_key(ip_address="192.88.254.252",remote_user="automation",remote_group="automation",pubkey=pubkey)
        except Exception as e : 
            assert "Connection timeout during pubkey copy" in e.args[0]
    def test_connection_to_host_doesn_t_exist(self):
    	ssh_helper = ConnectionHelper()
    	try:
    		reponse=ssh_helper.check_ssh_connection("192.88.254.252")
    	except Exception as e :
            assert "SSH connection KO" in e.args[0]
    
    def test_connection_to_host_with_authentification_failed(self):
    	ssh_helper = ConnectionHelper()
    	try:
    		reponse=ssh_helper.check_ssh_connection('192.64.3.2')
    		print(reponse)
    	except Exception as e :
            assert "Authentication failed" in e.args[0]
    
    def test_connection_to_host_rdp_nok(self):
        rdp_helper = ConnectionHelper()
        response=rdp_helper.check_rdp_connection("192.64.3.2")
        assert response == "No host responding in RDP"
    
    def test_connection_to_host_ping_nok(self):
        ping_helper = ConnectionHelper()
        response = ping_helper.check_ping("1.1.1.1")
        assert response == "No host responding to Ping"

    def test_connection_to_host_ping_ok(self):
        ping_helper = ConnectionHelper()
        try:
             response = ping_helper.check_ping("192.64.3.2")
        except EdgeException as e : 
            print (e.args[0])
            assert True
            

    def test_connection_to_host_rdp_ok(self):        
        rdp_helper = ConnectionHelper()
        try: 
            response = rdp_helper.check_rdp_connection("pspvtm01")
        except EdgeException as e : 
            print (e.args[0])
            assert True

    def test_check_if_host_contains_pub_key(self):
        pbkey = "ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAyLXUQ9eoPr8Akx+WeJzRgAOMyUbTQ3/RDu44N2svQTa7I0ZKzqelNrSqqsgSmNN7giQGRyIvx/XgUwi9UjrxFX0XRTvwjAcXNHV2pxybbhPb8/2jiAfFTCjkwQBwtoSTEL1I5noAIgapQDZghYFkv0GUiAkebKzl0A+cNqm5Zc2UPNTqsCtIAZ5Uid+XOdECHan29Iyow0f+O/2O6mZKBGvWFJbRLCokKLUrTmhbgWIiWgQGp/PnF0XVVPiQgRfbRz1xH08JNiQz1lnvZ4ME4BhQoxSK1O8QL+dQsSXhvQyjfO8yYI+X4X73Ie9yBfZpPiGAZLo3hTVha46veVfZGw== a373785@PXPLSV02"
        vm_session = VmSessionSsh('dpgalx5900')
        assert vm_session.check_if_host_contains_pub_key(pbkey)

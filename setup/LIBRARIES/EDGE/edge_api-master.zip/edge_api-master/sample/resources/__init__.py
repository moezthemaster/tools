""" Database related functions """
from .base import db


def create_db():
    '''just a function which create the database according
    to classes imported'''
    db.create_all()

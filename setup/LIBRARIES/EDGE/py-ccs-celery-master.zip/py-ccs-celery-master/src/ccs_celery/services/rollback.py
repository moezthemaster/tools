
import traceback

from collections import OrderedDict

from ccs_celery.services._dod.module import dod_module
from ccs_celery.services._cloud.module import cloud_module
from ccs_celery.services._marley.module import marley_module
from ccs_celery.services._network.module import network_module
from ccs_celery.services._connection.module import connection_module
from ccs_celery.services._whats.module import whats_module, whats_client_module


class RollBackMixins(object):

    rollback_order_for_state = {
        "present": ("Dod", "Whats", "Cloud", "RegisterPubKey",
                    "ConfigureNetwork", "RegisterWhatsClient", "Marley", "VmInfos", "Flexera"),
        "absent": (
            "CloudInfos", "DodInfos", "WhatsInfos", "Kat", "MarleyDecom", "UnRegisterWhatsClient", "UnRegisterPubKey",
            "Whats", "ReConfigureNetwork", "Cloud", "UnRegisterDod"
        )
    }
    rollback_tasks_func = {
        "Dod": dod_module,
        "Whats": whats_module,
        "Cloud": cloud_module,
        "MarleyDecom": marley_module,
        "UnRegisterWhatsClient": whats_client_module,
        "UnRegisterDod": dod_module,
        "UnRegisterPubKey": connection_module,
        "ReConfigureNetwork": network_module
    }
    exclude_rollback_for = (
        "Kat", "Dod", "Flexera", "CloudInfos", "DodInfos", "MarleyDecom", "WhatsInfos", "ReConfigureNetwork", "VmInfos"
    )
    exclude_rollback_on = (
        "RegisterPubKey", "ConfigureNetwork", "RegisterWhatsClient", "Marley", "Flexera", "CloudInfos",
        "DodInfos", "Kat", "WhatsInfos", "VmInfos"
    )

    def _rollback_task(self, task):
        try:
            self.logger.info(
                "Rollback on {} for state={} with kwargs={}...".format(
                    task, self.nor_state(self.data.shared_data["state"]),
                    self.data.services[task]["rollback_kwargs"]
                )
            )
            # for debug
            # self.logger.info("{}".format(self.data.services[task]["rollback_kwargs"]))
            result = self.rollback_tasks_func[task](**self.data.services[task]["rollback_kwargs"])
            self.data.rollback_on[task] = {
                "status": "SUCCESS",
                "result": result[1]
            }
        except Exception as err:
            self.data.rollback_on[task]["status"] = "FAILED"
            self.data.rollback_on[task]["exception_msg"] = str(err)
            self.logger.error(
                "Rollback on {} for state={} has failded: {}".format(
                    task, self.nor_state(self.data.shared_data["state"]),
                    str(err)
                )
            )
            raise Exception(str(err))
        self.logger.info(
            "Rollback on {} for state={} has succeeded...".format(
                task, self.nor_state(self.data.shared_data["state"])
            )
        )

    def _launch_rollback(self, task):
        if self.data.shared_data["state"] == "present":
            if task not in self.exclude_rollback_on and self.data.services[task]["changed"]:
                self._rollback_task(task)
        elif self.data.shared_data["state"] == "absent":
            if task not in self.exclude_rollback_on:
                self._rollback_task(task)

    def rollback(self):
        if self._task_name not in self.exclude_rollback_for:
            self.data.rollback_on = OrderedDict((
                (task , {
                    "status": "UNLAUNCHED",
                    "result": None
                }) for task in self.rollback_order_for_state[self.data.shared_data["state"]] \
                    [:self.rollback_order_for_state[self.data.shared_data["state"]].index(self._task_name)]
            ))
            self.logger.info("Invoke Rollback for {} module".format(self._task_name))
            try:
                for t in self.exclude_rollback_on:
                    try:
                        self.data.rollback_on.pop(t)
                    except KeyError:
                        pass
                for k in reversed(self.data.rollback_on):
                    self._launch_rollback(k)
            except Exception as err:
                self.data.rollback_on["err"] = str(traceback.format_exc())
                raise Exception(str(err))
            self.logger.info("Rollback for {} module has succeeded".format(self._task_name))

class EdgeException(Exception):
    pass


class ImproperlyConfigured(EdgeException):
    '''EDGE is somehow improperly configured'''
    pass


class KpiImproperlyConfigured(ImproperlyConfigured):
    '''EDGE is somehow improperly configured'''
    pass


class CloudMappingError(EdgeException):
    pass


class DataMismatch(EdgeException):
    pass


class MarleyError(EdgeException):
    def __init__(self, message, details=''):
        super(MarleyError, self).__init__("{} {} ".format(message, details))
        self.details = details


class NoRecordFound(MarleyError):
    pass


class LimitRowsExceeded(EdgeException):
    pass


class DodClientError(EdgeException):
    pass

class VaultError(EdgeException):
    '''EDGE is somehow improperly configured'''
    pass

import logging

import edge.interfaces
from edge.cloud_vm.vm import GET_BG_LIST_FROM_TRIGRAM

logger = logging.getLogger(__name__)

BG_LIST_FROM_TRIGRAM_ID = u'5e535eb1-0bd8-450d-b7de-214020eeee25'
BG_LIST_FROM_TRIGRAM_SUBTENANT_REF = u'89b69827-655e-414c-96cd-e56ca0e09460'
MACHINE_ID = u'6675fc19-d01d-4de6-a13b-420a315ae1a0'
PROVIDER_BG = u'BG_BSC-ISA-ARM_PRD'
MACHINE_TENANT_REF = u'sgcloud'
MACHINE_SUBTENANT_REF = u'50957a48-141e-425a-afcc-b74d040bf61e'
WORKFLOW_ITEM = [
    {
        u'catalogItem': {
            u'status': u'PUBLISHED',
            u'description': u'This workflow returns all the BGs associated to a trigram.',
            u'callbacks': None,
            u'isNoteworthy': False,
            u'iconId': u'5e535eb1-0bd8-450d-b7de-214020eeee25',
            u'catalogItemTypeRef': {
                u'id': u'com.vmware.csp.core.designer.service.serviceblueprint',
                u'label': u'Advanced Service Blueprint'
            },
            u'serviceRef': {
                u'id': u'36f963b4-db1d-4931-bae6-81e093ecca83',
                u'label': u'Advanced Services'
            },
            u'dateCreated': u'2015-11-26T10:50:06.532Z',
            u'forms': {
                u'catalogRequestInfoHidden': True,
                u'requestFormScale': u'BIG',
                u'requestSubmission': {
                    u'type': u'external',
                    u'formId': u'com.vmware.csp.core.designer.service.serviceblueprint_Request.Submit'
                },
                u'itemDetails': {
                    u'type': u'external',
                    u'formId': u'com.vmware.csp.core.designer.service.serviceblueprint_ServiceBlueprint.Details'
                },
                u'requestDetails': {
                    u'type': u'external',
                    u'formId': u'com.vmware.csp.core.designer.service.serviceblueprint_Request.Details'
                }
            },
            u'providerBinding': {
                u'bindingId': u'0d02280f-06e4-4ab9-9199-0dc18938ef88',
                u'providerRef': {
                    u'id': u'8b8ff6ef-86bb-423a-be30-8e7a65395d25',
                    u'label': u'Advanced Designer Service'
                }
            },
            u'version': 2,
            u'lastUpdatedDate': u'2017-06-06T14:23:20.632Z',
            u'organization': {
                u'subtenantLabel': None,
                u'tenantLabel': u'sgcloud',
                u'subtenantRef': None,
                u'tenantRef': u'sgcloud'
            },
            u'statusName': u'Published',
            u'id': BG_LIST_FROM_TRIGRAM_ID,
            u'name': u'Get BG List From Trigram'
        },
        u'entitledOrganizations': [
            {
                u'subtenantLabel': u'BG_ITIM-PPM-UVP',
                u'tenantLabel': u'sgcloud',
                u'subtenantRef': BG_LIST_FROM_TRIGRAM_SUBTENANT_REF,
                u'tenantRef': u'sgcloud'
            },
            {
                u'subtenantLabel': u'BG_BSC-DCO-OPE_PRD',
                u'tenantLabel': u'sgcloud',
                u'subtenantRef': u'3f4bbd37-f6c8-4a45-ba0d-441925bcb037',
                u'tenantRef': u'sgcloud'
            }
        ],
        u'@type': u'ConsumerEntitledCatalogItem'
    }
]
MACHINE_ITEM = [
    {
        u'catalogItem': {
            u'status': u'PUBLISHED',
            u'description': u'',
            u'callbacks': None,
            u'isNoteworthy': False,
            u'iconId': u'6675fc19-d01d-4de6-a13b-420a315ae1a0',
            u'catalogItemTypeRef': {
                u'id': u'com.vmware.csp.core.designer.service.serviceblueprint',
                u'label': u'Advanced Service Blueprint'
            },
            u'serviceRef': {
                u'id': u'68bb0048-2bbe-4f83-afe6-afe4768dec76',
                u'label': u'Linux'
            },
            u'dateCreated': u'2017-02-06T14:43:39.363Z',
            u'forms': {
                u'catalogRequestInfoHidden': True,
                u'requestFormScale': u'BIG',
                u'requestSubmission': {
                    u'type': u'external',
                    u'formId': u'com.vmware.csp.core.designer.service.serviceblueprint_Request.Submit'
                },
                u'itemDetails': {
                    u'type': u'external',
                    u'formId': u'com.vmware.csp.core.designer.service.serviceblueprint_ServiceBlueprint.Details'
                },
                u'requestDetails': {
                    u'type': u'external',
                    u'formId': u'com.vmware.csp.core.designer.service.serviceblueprint_Request.Details'
                }
            },
            u'providerBinding': {
                u'bindingId': u'0c23f31e-d152-49e4-bb24-0560c694e811',
                u'providerRef': {
                    u'id': u'8b8ff6ef-86bb-423a-be30-8e7a65395d25',
                    u'label': u'Advanced Designer Service'
                }
            },
            u'version': 10,
            u'lastUpdatedDate': u'2017-09-29T07:30:04.647Z',
            u'organization': {
                u'subtenantLabel': None,
                u'tenantLabel': u'sgcloud',
                u'subtenantRef': None,
                u'tenantRef': u'sgcloud'
            },
            u'statusName': u'Published',
            u'id': MACHINE_ID,
            u'name': u'RHEL 7.2 x64 RET EDGE'
        },
        u'entitledOrganizations': [
            {
                u'subtenantLabel': u'BG_ITIM-PPM-UVP',
                u'tenantLabel': u'sgcloud',
                u'subtenantRef': u'89b69827-655e-414c-96cd-e56ca0e09460',
                u'tenantRef': u'sgcloud'
            },
            {
                u'subtenantLabel': u'BG_BSC-DCO-OPE_PRD',
                u'tenantLabel': u'sgcloud',
                u'subtenantRef': u'3f4bbd37-f6c8-4a45-ba0d-441925bcb037',
                u'tenantRef': u'sgcloud'
            },
            {
                u'subtenantLabel': PROVIDER_BG,
                u'tenantLabel': u'sgcloud',
                u'subtenantRef': MACHINE_SUBTENANT_REF,
                u'tenantRef': MACHINE_TENANT_REF
            }
        ],
        u'@type': u'ConsumerEntitledCatalogItem'
    }
]
REQUESTED_FOR = u'EAN_PRD_SVC@eur.msd.world.socgen'
PROVIDER_OWNER = u'EAN_PRD_SVC@eur.msd.world.socgen'
RESPONSE_GET_BG_REQUEST = {
    u'values': {
        u'entries': [
            {
                u'value': {
                    u'type': u'string',
                    u'value': u'PRD'
                },
                u'key': u'provider-environment'
            },
            {
                u'value': {
                    u'type': u'string',
                    u'value': u'sgcloud'
                },
                u'key': u'provider-__asd_tenantRef'
            },
            {
                u'value': {
                    u'items': [
                        {
                            u'type': u'string',
                            u'value': PROVIDER_BG
                        }
                    ],
                    u'elementTypeId': u'STRING',
                    u'type': u'multiple'
                },
                u'key': u'provider-BGResult'
            },
            {
                u'value': {
                    u'type': u'string',
                    u'value': u'c8667608-4c30-4a32-b122-7d6d1ee79c29'
                },
                u'key': u'provider-__asd_catalogRequestId'
            },
            {
                u'value': {
                    u'type': u'string',
                    u'value': u'RET'
                },
                u'key': u'provider-restrictedTo'
            },
            {
                u'value': {
                    u'type': u'string',
                    u'value': u'api'
                },
                u'key': u'provider-trigram'
            },
            {
                u'value': {
                    u'type': u'string',
                    u'value': REQUESTED_FOR
                },
                u'key': u'provider-__asd_requestedFor'
            },
            {
                u'value': {
                    u'type': u'string',
                    u'value': u'b12b07ac-56d8-4508-8eeb-33581c3ab013'
                },
                u'key': u'provider-__asd_subtenantRef'
            },
            {
                u'value': {
                    u'type': u'string',
                    u'value': PROVIDER_OWNER
                },
                u'key': u'provider-__asd_requestedBy'
            }
        ]
    },
    u'layout': {
        u'pages': [
            {
                u'state': {
                    u'facets': [

                    ],
                    u'dependencies': [

                    ]
                },
                u'sections': [
                    {
                        u'state': {
                            u'facets': [
                                {
                                    u'type': u'visible',
                                    u'value': {
                                        u'type': u'constantClause',
                                        u'value': {
                                            u'type': u'boolean',
                                            u'value': False
                                        }
                                    }
                                }
                            ],
                            u'dependencies': [

                            ]
                        },
                        u'rows': [
                            {
                                u'items': [
                                    {
                                        u'dataType': {
                                            u'typeId': u'STRING',
                                            u'type': u'primitive'
                                        },
                                        u'labelSize': 0,
                                        u'state': {
                                            u'facets': [
                                                {
                                                    u'type': u'visible',
                                                    u'value': {
                                                        u'type': u'constantClause',
                                                        u'value': {
                                                            u'type': u'boolean',
                                                            u'value': False
                                                        }
                                                    }
                                                }
                                            ],
                                            u'dependencies': [

                                            ]
                                        },
                                        u'displayAdvice': None,
                                        u'isMultiValued': False,
                                        u'type': u'field',
                                        u'id': u'provider-__ASD_PRESENTATION_INSTANCE',
                                        u'columns': [

                                        ],
                                        u'size': 2
                                    }
                                ]
                            }
                        ],
                        u'id': None
                    },
                    {
                        u'state': {
                            u'facets': [

                            ],
                            u'dependencies': [

                            ]
                        },
                        u'rows': [
                            {
                                u'items': [
                                    {
                                        u'description': u'trigram',
                                        u'dataType': {
                                            u'typeId': u'STRING',
                                            u'type': u'primitive'
                                        },
                                        u'labelSize': 2,
                                        u'label': u'trigram',
                                        u'state': {
                                            u'facets': [

                                            ],
                                            u'dependencies': [

                                            ]
                                        },
                                        u'displayAdvice': None,
                                        u'isMultiValued': False,
                                        u'type': u'field',
                                        u'id': u'provider-trigram',
                                        u'columns': [

                                        ],
                                        u'size': 2
                                    }
                                ]
                            },
                            {
                                u'items': [
                                    {
                                        u'description': u'restrictedTo',
                                        u'dataType': {
                                            u'typeId': u'STRING',
                                            u'type': u'primitive'
                                        },
                                        u'labelSize': 2,
                                        u'label': u'restrictedTo',
                                        u'state': {
                                            u'facets': [

                                            ],
                                            u'dependencies': [

                                            ]
                                        },
                                        u'displayAdvice': None,
                                        u'isMultiValued': False,
                                        u'type': u'field',
                                        u'id': u'provider-restrictedTo',
                                        u'columns': [

                                        ],
                                        u'size': 2
                                    }
                                ]
                            },
                            {
                                u'items': [
                                    {
                                        u'dataType': {
                                            u'typeId': u'STRING',
                                            u'type': u'primitive'
                                        },
                                        u'labelSize': 2,
                                        u'label': u'BGResult',
                                        u'state': {
                                            u'facets': [
                                                {
                                                    u'type': u'readOnly',
                                                    u'value': {
                                                        u'type': u'constantClause',
                                                        u'value': {
                                                            u'type': u'boolean',
                                                            u'value': True
                                                        }
                                                    }
                                                }
                                            ],
                                            u'dependencies': [

                                            ]
                                        },
                                        u'displayAdvice': u'SEARCHER',
                                        u'isMultiValued': True,
                                        u'type': u'field',
                                        u'id': u'provider-BGResult',
                                        u'columns': [

                                        ],
                                        u'size': 2
                                    }
                                ]
                            }
                        ],
                        u'id': None
                    }
                ],
                u'id': None,
                u'label': u'Step'
            }
        ]
    }
}
VRA_RESOURCE_DATA = [{
  u'operations': [
    {
      u'extensionId': None,
      u'name': u'Add Tags To VM',
      u'iconId': u'd5d4fa0a-247e-49af-83e8-531f33429071_icon',
      u'hasForm': True,
      u'bindingId': u'sgcloudhom!::!f055881a-37e0-4e35-bc33-c695c6a35e84',
      u'formScale': u'BIG',
      u'type': u'ACTION',
      u'id': u'1fc98ef8-c45f-4cd7-b4bb-d94de580590c',
      u'providerTypeId': u'com.vmware.csp.core.designer.service',
      u'description': u'REST API function to add a tag to an instance (Get the type and name from the id)'
    },
    {
      u'extensionId': None,
      u'name': u'Change Lease',
      u'iconId': u'machineChangeLease.png',
      u'hasForm': True,
      u'bindingId': u'Infrastructure.Machine.Action.ChangeLease',
      u'formScale': u'SMALL',
      u'type': u'ACTION',
      u'id': u'670f9fa9-a108-4aa1-8a91-4d605ea70af3',
      u'providerTypeId': u'com.vmware.csp.iaas.blueprint.service',
      u'description': u'Change the lease for a machine. Leave empty for indefinite.'
    },
    {
      u'extensionId': None,
      u'name': u'Change VM Backup Policy',
      u'iconId': u'1b8e8265-238c-4f26-a5fa-7f4d340e8b04_icon',
      u'hasForm': True,
      u'bindingId': u'sgcloudhom!::!86d47adb-ceb6-442e-b9ef-c87e318d4db6',
      u'formScale': u'BIG',
      u'type': u'ACTION',
      u'id': u'444e02aa-7e27-43d8-9c75-c668214e7399',
      u'providerTypeId': u'com.vmware.csp.core.designer.service',
      u'description': u''
    },
    {
      u'extensionId': None,
      u'name': u'Change VM Description',
      u'iconId': u'b6204ee0-7515-421f-b358-3c5e01cef573_icon',
      u'hasForm': True,
      u'bindingId': u'sgcloudhom!::!7b44148f-04cf-4e21-b673-f9fe11e6fbae',
      u'formScale': u'BIG',
      u'type': u'ACTION',
      u'id': u'ad3c8005-9836-4963-af98-ef65043a0cb8',
      u'providerTypeId': u'com.vmware.csp.core.designer.service',
      u'description': u''
    },
    {
      u'extensionId': None,
      u'name': u'Change VM Model',
      u'iconId': u'1f982830-0f4d-407b-9630-3b0b4ea7de44_icon',
      u'hasForm': True,
      u'bindingId': u'sgcloudhom!::!e5414149-6b8e-4bae-a3c1-3ce437d85baf',
      u'formScale': u'BIG',
      u'type': u'ACTION',
      u'id': u'6ff9c46d-3b4a-4812-ad85-16ea70c602dd',
      u'providerTypeId': u'com.vmware.csp.core.designer.service',
      u'description': u''
    },
    {
      u'extensionId': None,
      u'name': u'Change VM Owner',
      u'iconId': u'cafe_default_icon_genericResourceOperation',
      u'hasForm': True,
      u'bindingId': u'sgcloudhom!::!b3f613e3-c85f-42a8-b114-6a2575829bef',
      u'formScale': u'BIG',
      u'type': u'ACTION',
      u'id': u'd2e0c734-328b-42b5-a22a-6d2405d0c8d1',
      u'providerTypeId': u'com.vmware.csp.core.designer.service',
      u'description': u''
    },
    {
      u'extensionId': None,
      u'name': u'Destroy',
      u'iconId': u'virtualDestroy.png',
      u'hasForm': False,
      u'bindingId': u'Infrastructure.Virtual.Action.Destroy',
      u'formScale': None,
      u'type': u'ACTION',
      u'id': u'0570bb89-2e87-41c0-b72c-9d450cc53462',
      u'providerTypeId': u'com.vmware.csp.iaas.blueprint.service',
      u'description': u'Destroy a virtual machine.'
    },
    {
      u'extensionId': None,
      u'name': u'Get Tags From VM',
      u'iconId': u'b582dca7-ab08-4d1b-bfcc-b9ac6e481dd0_icon',
      u'hasForm': True,
      u'bindingId': u'sgcloudhom!::!e8ab7c78-7c80-4157-82d9-7f1225f1148a',
      u'formScale': u'BIG',
      u'type': u'ACTION',
      u'id': u'09bf3d30-f286-49ff-9971-1d4a5dd237d7',
      u'providerTypeId': u'com.vmware.csp.core.designer.service',
      u'description': u'REST API function to add a tag to an instance (Get the type and name from the id)'
    },
    {
      u'extensionId': None,
      u'name': u'Get VM Information',
      u'iconId': u'eeb0d977-1e6d-49f8-8b9f-d81f118d471d_icon',
      u'hasForm': True,
      u'bindingId': u'sgcloudhom!::!289855cf-2e8c-4cdb-850b-0483c45ec7c3',
      u'formScale': u'BIG',
      u'type': u'ACTION',
      u'id': u'106a89ad-e23c-44df-80d8-581dad1ed7ca',
      u'providerTypeId': u'com.vmware.csp.core.designer.service',
      u'description': u''
    },
    {
      u'extensionId': None,
      u'name': u'Get VM SG Attributes',
      u'iconId': u'fc3af52f-09bc-4a3f-85bc-e420b16fcf5c_icon',
      u'hasForm': True,
      u'bindingId': u'sgcloudhom!::!3f9845ed-2237-4864-b250-1f35a2d5317e',
      u'formScale': u'BIG',
      u'type': u'ACTION',
      u'id': u'b6b66014-0952-4a03-8d75-c6c854345645',
      u'providerTypeId': u'com.vmware.csp.core.designer.service',
      u'description': u'This workflow returns the list of All custom properties of a VM.'
    },
    {
      u'extensionId': None,
      u'name': u'Remove All Tags From VM',
      u'iconId': u'fbcd02fd-0e62-4d73-b9a0-92f653596253_icon',
      u'hasForm': True,
      u'bindingId': u'sgcloudhom!::!911c221f-d825-46fa-aa97-2229613bb485',
      u'formScale': u'BIG',
      u'type': u'ACTION',
      u'id': u'38ce2b0c-2db1-4597-a742-7ddf8c0ae7cb',
      u'providerTypeId': u'com.vmware.csp.core.designer.service',
      u'description': u'Function to update the tags on a VLB from the portal.'
    },
    {
      u'extensionId': None,
      u'name': u'Remove Tags From VM',
      u'iconId': u'afc82a1c-d34b-4e1f-a33a-01e332014006_icon',
      u'hasForm': True,
      u'bindingId': u'sgcloudhom!::!67b07863-58ad-4839-87f3-d824b8837a97',
      u'formScale': u'BIG',
      u'type': u'ACTION',
      u'id': u'e197abb4-b0b3-43aa-ac4c-09d1b2ab0ffa',
      u'providerTypeId': u'com.vmware.csp.core.designer.service',
      u'description': u'Function to update the tags on a VLB from the portal.'
    },
    {
      u'extensionId': None,
      u'name': u'Restart VM',
      u'iconId': u'aa5b0047-6025-49d1-9675-3a91370ec05d',
      u'hasForm': True,
      u'bindingId': u'sgcloudhom!::!d0d3eb1d-6135-4cd2-abe7-dad838181601',
      u'formScale': u'BIG',
      u'type': u'ACTION',
      u'id': u'aa5b0047-6025-49d1-9675-3a91370ec05d',
      u'providerTypeId': u'com.vmware.csp.core.designer.service',
      u'description': u'Restart a Virtual Machine'
    },
    {
      u'extensionId': None,
      u'name': u'Update Tags From VM',
      u'iconId': u'fa8ab11e-bcfa-4e9f-8f4f-c03cf0bbdb29_icon',
      u'hasForm': True,
      u'bindingId': u'sgcloudhom!::!cfc188d9-19f0-4790-b55a-1bd11dd78a20',
      u'formScale': u'BIG',
      u'type': u'ACTION',
      u'id': u'd07e5024-b1cf-48cf-a0bd-1921fb34f24b',
      u'providerTypeId': u'com.vmware.csp.core.designer.service',
      u'description': u'Function to update the tags on an object from the portal.'
    }
  ],
  u'destroyDate': u'2027-08-06T17:07:39.000Z',
  u'pendingRequests': [

  ],
  u'id': u'3ab9a46d-fbfe-4b5b-ae5c-98a651f1b20f',
  u'totalCost': {
    u'currencyCode': u'USD',
    u'type': u'money',
    u'amount': 0.0
  },
  u'parentResourceRef': {
    u'id': u'e4ed1ed1-b7c7-42b8-9e5b-8a64ca0eac5a',
    u'label': u'RHEL_7.2_x64-RET-EDGE-32050612'
  },
  u'hasChildren': False,
  u'iconId': u'cafe_default_icon_genericCatalogItem',
  u'forms': {
    u'catalogResourceInfoHidden': True,
    u'details': {
      u'extensionPointId': None,
      u'extensionId': u'csp.places.iaas.item.details',
      u'type': u'extension'
    }
  },
  u'providerBinding': {
    u'bindingId': u'8ffd74be-9eaf-4df7-96a8-98bcfea5ac64',
    u'providerRef': {
      u'id': u'9ce9e528-7bdb-4fb9-b189-504af520258d',
      u'label': u'Infrastructure Service'
    }
  },
  u'requestId': u'ca4cb466-9d24-4361-bb6c-c194db68a389',
  u'costToDate': {
    u'currencyCode': u'USD',
    u'type': u'money',
    u'amount': 0.0
  },
  u'lease': {
    u'start': u'2017-08-07T17:04:11.000Z',
    u'end': u'2027-08-05T17:07:39.000Z'
  },
  u'status': u'ACTIVE',
  u'description': u'[EDGE] Test Template',
  u'lastUpdated': u'2017-11-11T20:25:24.691Z',
  u'dateCreated': u'2017-08-07T17:07:03.757Z',
  u'catalogItem': {
    u'id': u'e14027e7-fedb-4762-b418-bbe67231576f',
    u'label': u'RHEL_7.2_x64-RET-EDGE'
  },
  u'leaseForDisplay': {
    u'amount': 3650,
    u'type': u'timeSpan',
    u'unit': u'DAYS'
  },
  u'owners': [
    {
      u'type': u'USER',
      u'tenantName': u'sgcloudhom',
      u'ref': u'EAN_PRD_SVC@eur.msd.world.socgen',
      u'value': u'Generic Account'
    }
  ],
  u'name': u'dpgalx044',
  u'hasCosts': True,
  u'resourceData': {
    u'entries': [
      {
        u'value': {
          u'type': u'boolean',
          u'value': True
        },
        u'key': u'ConnectViaSsh'
      },
      {
        u'value': {
          u'type': u'string',
          u'value': u'Red Hat Enterprise Linux 7 (64-bit)'
        },
        u'key': u'MachineGuestOperatingSystem'
      },
      {
        u'value': {
          u'type': u'integer',
          u'value': 1024
        },
        u'key': u'MachineMemory'
      },
      {
        u'value': {
          u'items': [
            {
              u'classId': u'dynamicops.api.model.DiskInputModel',
              u'typeFilter': None,
              u'componentTypeId': u'com.vmware.csp.component.iaas.proxy.provider',
              u'values': {
                u'entries': [
                  {
                    u'value': {
                      u'type': u'string',
                      u'value': u'DISK_INPUT_ID1'
                    },
                    u'key': u'DISK_INPUT_ID'
                  },
                  {
                    u'value': {
                      u'type': u'integer',
                      u'value': 40
                    },
                    u'key': u'DISK_CAPACITY'
                  }
                ]
              },
              u'type': u'complex',
              u'componentId': None
            },
            {
              u'classId': u'dynamicops.api.model.DiskInputModel',
              u'typeFilter': None,
              u'componentTypeId': u'com.vmware.csp.component.iaas.proxy.provider',
              u'values': {
                u'entries': [
                  {
                    u'value': {
                      u'type': u'string',
                      u'value': u'DISK_INPUT_ID2'
                    },
                    u'key': u'DISK_INPUT_ID'
                  },
                  {
                    u'value': {
                      u'type': u'integer',
                      u'value': 20
                    },
                    u'key': u'DISK_CAPACITY'
                  }
                ]
              },
              u'type': u'complex',
              u'componentId': None
            }
          ],
          u'elementTypeId': u'COMPLEX',
          u'type': u'multiple'
        },
        u'key': u'DISK_VOLUMES'
      },
      {
        u'value': {
          u'type': u'string',
          u'value': u'RHEL_7.2_x64-RET-EDGE'
        },
        u'key': u'MachineBlueprintName'
      },
      {
        u'value': {
          u'type': u'boolean',
          u'value': True
        },
        u'key': u'Suspend'
      },
      {
        u'value': {
          u'type': u'string',
          u'value': u'vSphere'
        },
        u'key': u'MachineInterfaceType'
      },
      {
        u'value': {
          u'type': u'integer',
          u'value': 1
        },
        u'key': u'MachineCPU'
      },
      {
        u'value': {
          u'type': u'dateTime',
          u'value': u'2027-08-05T15:07:39.230Z'
        },
        u'key': u'MachineExpirationDate'
      },
      {
        u'value': {
          u'type': u'boolean',
          u'value': True
        },
        u'key': u'PowerOff'
      },
      {
        u'value': {
          u'type': u'boolean',
          u'value': True
        },
        u'key': u'ConnectViaNativeVmrc'
      },
      {
        u'value': {
          u'type': u'boolean',
          u'value': False
        },
        u'key': u'IS_COMPONENT_MACHINE'
      },
      {
        u'value': {
          u'type': u'boolean',
          u'value': True
        },
        u'key': u'ChangeLease'
      },
      {
        u'value': {
          u'type': u'string',
          u'value': u'b8f4cc11-1296-4792-9039-c46c6d401f92'
        },
        u'key': u'endpointExternalReferenceId'
      },
      {
        u'value': {
          u'type': u'string',
          u'value': u'vSphere (vCenter)'
        },
        u'key': u'MachineInterfaceDisplayName'
      },
      {
        u'value': {
          u'type': u'string',
          u'value': u'502b15ae-56d0-a574-69cf-9c69fde45101'
        },
        u'key': u'VirtualMachine.Admin.UUID'
      },
      {
        u'value': {
          u'type': u'boolean',
          u'value': True
        },
        u'key': u'Destroy'
      },
      {
        u'value': {
          u'type': u'string',
          u'value': u'BG_GTS-RET-Res-3'
        },
        u'key': u'MachineReservationName'
      },
      {
        u'value': {
          u'items': [
            {
              u'classId': u'dynamicops.api.model.NetworkViewModel',
              u'typeFilter': None,
              u'componentTypeId': u'com.vmware.csp.component.iaas.proxy.provider',
              u'values': {
                u'entries': [
                  {
                    u'value': {
                      u'type': u'string',
                      u'value': u'192.88.72.52'
                    },
                    u'key': u'NETWORK_ADDRESS'
                  },
                  {
                    u'value': {
                      u'type': u'string',
                      u'value': u'RET_192-88-72-0_21'
                    },
                    u'key': u'NETWORK_NAME'
                  },
                  {
                    u'value': {
                      u'type': u'string',
                      u'value': u'00:50:56:ab:d7:0f'
                    },
                    u'key': u'NETWORK_MAC_ADDRESS'
                  }
                ]
              },
              u'type': u'complex',
              u'componentId': None
            }
          ],
          u'elementTypeId': u'COMPLEX',
          u'type': u'multiple'
        },
        u'key': u'NETWORK_LIST'
      },
      {
        u'value': {
          u'type': u'string',
          u'value': u'Machine'
        },
        u'key': u'Component'
      },
      {
        u'value': {
          u'type': u'boolean',
          u'value': True
        },
        u'key': u'Reset'
      },
      {
        u'value': {
          u'type': u'boolean',
          u'value': True
        },
        u'key': u'ConnectViaVmrc'
      },
      {
        u'value': {
          u'items': [

          ],
          u'elementTypeId': u'COMPLEX',
          u'type': u'multiple'
        },
        u'key': u'SNAPSHOT_LIST'
      },
      {
        u'value': {
          u'type': u'boolean',
          u'value': True
        },
        u'key': u'InstallTools'
      },
      {
        u'value': {
          u'type': u'string',
          u'value': u'On'
        },
        u'key': u'MachineStatus'
      },
      {
        u'value': {
          u'type': u'string',
          u'value': u'Virtual'
        },
        u'key': u'MachineType'
      },
      {
        u'value': {
          u'type': u'integer',
          u'value': 60
        },
        u'key': u'MachineStorage'
      },
      {
        u'value': {
          u'type': u'string',
          u'value': u'vm-3899'
        },
        u'key': u'EXTERNAL_REFERENCE_ID'
      },
      {
        u'value': {
          u'type': u'string',
          u'value': u'BG_GTS-RET'
        },
        u'key': u'MachineGroupName'
      },
      {
        u'value': {
          u'type': u'string',
          u'value': u'192.88.72.52'
        },
        u'key': u'ip_address'
      },
      {
        u'value': {
          u'type': u'boolean',
          u'value': True
        },
        u'key': u'Reboot'
      },
      {
        u'value': {
          u'type': u'boolean',
          u'value': True
        },
        u'key': u'ChangeOwner'
      },
      {
        u'value': {
          u'type': u'boolean',
          u'value': True
        },
        u'key': u'Expire'
      },
      {
        u'value': {
          u'type': u'string',
          u'value': u'8ffd74be-9eaf-4df7-96a8-98bcfea5ac64'
        },
        u'key': u'machineId'
      },
      {
        u'value': {
          u'type': u'string',
          u'value': u'dpgalx044'
        },
        u'key': u'MachineName'
      },
      {
        u'value': {
          u'type': u'dateTime',
          u'value': u'2027-08-06T15:07:39.230Z'
        },
        u'key': u'MachineDestructionDate'
      },
      {
        u'value': {
          u'type': u'boolean',
          u'value': True
        },
        u'key': u'Shutdown'
      },
      {
        u'value': {
          u'type': u'boolean',
          u'value': True
        },
        u'key': u'Reconfigure'
      },
      {
        u'value': {
          u'type': u'boolean',
          u'value': True
        },
        u'key': u'Reprovision'
      },
      {
        u'value': {
          u'type': u'boolean',
          u'value': True
        },
        u'key': u'CreateSnapshot'
      },
      {
        u'value': {
          u'type': u'decimal',
          u'value': 0.0
        },
        u'key': u'MachineDailyCost'
      }
    ]
  },
  u'expenseMonthToDate': None,
  u'@type': u'CatalogResource',
  u'costs': {
    u'leaseRate': {
      u'cost': {
        u'currencyCode': u'USD',
        u'type': u'money',
        u'amount': 0.0
      },
      u'type': u'moneyTimeRate',
      u'basis': {
        u'amount': 1,
        u'type': u'timeSpan',
        u'unit': u'DAYS'
      }
    }
  },
  u'resourceTypeRef': {
    u'id': u'Infrastructure.Virtual',
    u'label': u'Virtual Machine'
  },
  u'organization': {
    u'subtenantLabel': u'BG_GTS-RET',
    u'tenantLabel': u'sgcloudhom',
    u'subtenantRef': u'fe2f9e83-c8ac-4d43-b03e-f2779308cb96',
    u'tenantRef': u'sgcloudhom'
  },
  u'hasLease': True,
  u'requestState': u'SUCCESSFUL'
}]


class MockCloudVra(edge.interfaces.CloudVra):
    def __init__(self, resource_exists):
        self.resource_exists = resource_exists

    def get_vra_catalog(self, filter_sentence):
        logger.debug('get_vra_catalog method called from MockCloudVra')
        if filter_sentence == "(name eq '{}')".format(GET_BG_LIST_FROM_TRIGRAM):
            return WORKFLOW_ITEM
        else:
            return MACHINE_ITEM

    def vra_workflow_request(self, wait, workflow_item, trigram, app_env):
        if wait:
            logger.debug('vra_workflow_request method called from MockCloudVra with wait=True')
            return RESPONSE_GET_BG_REQUEST
        else:
            logger.debug('run_vra_request method called from MockCloudVra with wait=False')
            return 'https://cldcaccafep01.fr.world.socgen/catalog-service/api/consumer/requests/8a9f300e-dummy'

    def get_vra_resource_data(self, filter_sentence):
        logger.debug('get_vra_resource_data method called from MockCloudVra')
        if self.resource_exists:
            return VRA_RESOURCE_DATA
        else:
            return []

    def vra_create_vm(self, wait, machine_item, vm_config, requested_for, provider_owner, business_group):
        logger.debug('vra_create_vm method called from MockCloudVra')
        self.resource_exists = True

    def vra_destroy_vm(self, wait, hostname_id, operation_id, organization):
        logger.debug('vra_destroy_vm method called from MockCloudVra')
        self.resource_exists = False


class MockCloudVraNoBG(MockCloudVra):
    def vra_workflow_request(self, wait, workflow_item, trigram, app_env):
        return {}
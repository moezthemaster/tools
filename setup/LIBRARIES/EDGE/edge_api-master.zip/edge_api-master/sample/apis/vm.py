""" Vm API for manage vm """
from flask import jsonify
from threading import Timer
from flask_restplus import Namespace, fields, reqparse, marshal


from flask_restplus import Resource
from sample.core.exception import InvalidUsage


def async_create_vm(db, args):

    def create_vm(db, args):
        args["status"] = "created"
        db.set(args["hostname"], args)

    t = Timer(30.0, create_vm, [db, args])
    t.start()


namespace = Namespace(
    'vm', description='Manage vm')

contact_schema_post = namespace.model('Vm1', {
    'hostname': fields.String(
        description='Hostname for delete',
        required=True
    ),
    'trigram': fields.String(
        description='app trigram',
        required=True
    ),
    'desc': fields.String(
        description='description of hostname',
    ),
    'env': fields.String(
        description='env',
        required=True
    ),
    'os': fields.String(
        description='Centos or RH',
        required=True
    ),
    'network': fields.String(
        description='Network for hostname',
        required=True
    ),
})

contact_schema_get = namespace.model('Vm2', {
    'hostname': fields.String(
        description='Hostname for delete',
        required=True
    )
})

contact_schema_delete = contact_schema_get

@namespace.errorhandler(InvalidUsage)
def handle_invalid_usage(error):
    """ Catch and forward to app.errorhandler InvalidUsage exceptions """
    response = jsonify(error.to_dict())
    response.status_code = error.status_code
    return response


@namespace.route('/', methods=['POST', 'DELETE'])
@namespace.route('/<string:hostname>', methods=['GET'])
class Vm(Resource):
    """ Manage vm """

    @namespace.doc('vm infos',
        description='get vm info if exists'
    )
    def get(self, hostname):
        """ Get vm infos by hostname """
        return jsonify(self.get_vm_status(hostname))

    def get_vm_status(self, hostname):
        data = self.api._config["demo_db"].get(hostname)
        if data:
            return data
        return {
         "msg": "vm {} not exist".format(hostname)
        }

    def check_if_vm_exits(self, hostname):
        data = self.api._config["demo_db"].get(hostname)
        if data:
            return True
        return False

    @namespace.doc('create vm',
        description='create vm or get status if vm is on processing'
    )
    @namespace.expect(contact_schema_post, validate=True)
    def post(self):
        """Create vm or get status"""
        parser = reqparse.RequestParser()
        parser.add_argument('hostname', type=str)
        parser.add_argument('trigram', type=str)
        parser.add_argument('desc', type=str)
        parser.add_argument('env', type=str)
        parser.add_argument('os', type=str)
        parser.add_argument('network', type=str)
        args = parser.parse_args()
        if self.api._config["demo_db"].get(args["hostname"]):
            return self.get_vm_status(args["hostname"])
        args["status"] = "creation of vm in progress"
        self.api._config["demo_db"].set(args["hostname"], args)
        async_create_vm(self.api._config["demo_db"], args)
        return jsonify(args)

    @namespace.doc('delete vm',
                   description='delete vm if exists'
                   )
    @namespace.expect(contact_schema_delete, validate=True)
    def delete(self):
        """Delete vm"""
        parser = reqparse.RequestParser()
        parser.add_argument('hostname', type=str)
        args = parser.parse_args()
        if self.check_if_vm_exits(args["hostname"]):
            self.api._config["demo_db"].delete(args["hostname"])
            return jsonify({"msg": "vm {} has deleted".format(args["hostname"])})
        return jsonify({"msg": "vm {} not exist".format(args["hostname"])})

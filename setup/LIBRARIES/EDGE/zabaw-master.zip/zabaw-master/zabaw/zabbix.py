##############################################################################
#
# File		: zbxapi.py
#
# Date		: 12-12-2017
#
# Author	: Emmanuel TELECHEA - RESG/GTS/MKT/OPM
#
# Purpose	: Maintain Zabbix API def
#
##############################################################################
#
# History	:
#
# ET : 12-12-2017 : Creation
#
##############################################################################

import json
import logging

import requests
import urllib3
from zabaw.credential import get_credentials
# Do not check certificate validity => Getting errors even when using SG UniPass cert
urllib3.disable_warnings()


##############################################################################
# Class : zbxApi
# Use handle Zabbix API calls
##############################################################################


class zbxApiError(Exception):
    pass


class zbxApi(object):
    def __init__(self, zbxUrl, zbxUser=get_credentials()[0], zbxPwd=get_credentials()[1]):
        self.logger = logging.getLogger(__name__)
        self.zbxApiHeaders = {'Content-Type': 'application/json-rpc'}
        self.zbxUrl = zbxUrl
        self.zbxUser = zbxUser
        self.zbxPwd = zbxPwd
        self.zbxApiData = \
            {
                'jsonrpc': '2.0',
                'method': 'user.login',
                'params':
                    {
                        'user': self.zbxUser,
                        'password': self.zbxPwd
                    },
                'id': 1
            }
        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to open Zabbix API session with error code: {}' .format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to open Zabbix API session with error code : {}' .format(zbxReturnCode))

        self.logger.debug('[LOG] Opening session to Zabbix WS with result : {}'.format(zbxResponse.json()['result']))
        self.zbxLoginToken = zbxResponse.json()['result']

    # Method to retrieve GroupId from group name
    def zbxGetGroupId(self, zbxGroup):
        self.zbxApiData = \
            {
                'jsonrpc': '2.0',
                'method': 'hostgroup.get',
                'params':
                    {
                        'output': ['groupid'],
                        'filter':
                            {
                                'name': [zbxGroup]
                            }
                    },
                'auth': self.zbxLoginToken,
                'id': 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)
        zbxReturnCode = zbxResponse.status_code
        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to retreive groupId for group :{} with error code : {} '.format(zbxGroup, zbxReturnCode))
            raise SystemExit('[ERROR] Unable to retreive groupId for group :{} with error code : {} '.format(zbxGroup, zbxReturnCode))

        #zbxGroupId = zbxResponse.json()['result'][0]['groupid']
        zbxGroupId = zbxResponse.json()
        self.logger.debug('[LOG] Group : {}. id is : {} '.format(zbxGroup, zbxGroupId))

        return zbxGroupId

    ##############################################################################
    # Method to retrieve host list from group id
    def zbxGetHostFromGroup(self, zbxGroupId):
        self.zbxApiData = \
            {
                'jsonrpc': '2.0',
                'method': 'host.get',
                'params':
                    {
                        'output': ['host', 'status', 'groups'],
                        'selectGrloups': ['groupid'],
                        'selectInventory': ['os', 'deployment_status'],
                        'withInventory': 1,
                        'groupids': [zbxGroupId]
                    },
                'auth': self.zbxLoginToken,
                'id': 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)
        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to retreive hosts from group id : {} , with error code: {}'.format(zbxGroupId, zbxReturnCode))
            raise SystemExit('[ERROR] Unable to retreive hosts from group id : {} , with error code: {}'.format(zbxGroupId, zbxReturnCode))

        return zbxResponse.json()['result']

    ##############################################################################
    # Method to link host to template
    def zbxLinkHostToTemplate(self, zbxHosId, zbxTemplateId):
        self.zbxApiData = \
            {
                'jsonrpc': '2.0',
                'method': 'host.massadd',
                'params': {
                    "hosts": [
                        {
                            "hostid": zbxHosId
                        },
                    ],

                    'templates': [
                        {"templateid": zbxTemplateId}
                    ]
                },
                'auth': self.zbxLoginToken,
                'id': 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)
        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to link host to template, with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to link host to template, with error code : {}'.format(zbxReturnCode))
        # print zbxResponse.json()
        return zbxResponse.json()['result']

    ##############################################################################
    # Method to link host to template
    def zbxUnlinkHostToTemplate(self, zbxHosId, zbxTemplateId):
        self.zbxApiData = \
            {
                'jsonrpc': '2.0',
                'method': "host.massremove",
                'params': {
                    "hostids": [zbxHosId],
                    "templateids_clear": zbxTemplateId
                },
                'auth': self.zbxLoginToken,
                'id': 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)
        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to unlink host to template, with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to unlink host to template, with error code : {}'.format(zbxReturnCode))

        return zbxResponse.json()['result']

    ##############################################################################
    # Method to retrieve GroupId from group name
    def zbxGetTemplateId(self, zbxTemplate):
        self.zbxApiData = \
            {
                'jsonrpc': '2.0',
                'method': 'template.get',
                'params':
                    {
                        'output': ['templateid'],
                        'filter':
                            {
                                'name': [zbxTemplate]
                            }
                    },
                'auth': self.zbxLoginToken,
                'id': 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)
        zbxReturnCode = zbxResponse.status_code
        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to retreive templateId for template : {}, with error code :{}'.format(zbxTemplate, zbxReturnCode))
            raise SystemExit('[ERROR] Unable to retreive templateId for template : {}, with error code :{}'.format(zbxTemplate, zbxReturnCode))

        zbxTemplateId = zbxResponse.json()['result'][0]['templateid']
        self.logger.debug('[LOG] Template : {}. id: {}'.format(zbxTemplate, zbxTemplateId))

        return zbxTemplateId

    ##############################################################################
    # Method to remove host from discovery group
    def zbxManageHostInitialGroups(self, zbxHost, zbxDiscoveryGroupId, zbxTargetGroupIds):

        # Check if host already belongs to other group than the discovery one
        zbxHostNbGroup = len(zbxHost['groups'])
        self.logger.debug('Host {} OS {} belongs to {} group(s)'.format(zbxHost['host'], zbxHost['inventory']['os'], str(zbxHostNbGroup)))

        # Remove host from Discovery group if already member of other one
        if zbxHostNbGroup != 1:

            groupList = []
            for group in zbxHost['groups']:
                if group['groupid'] == zbxDiscoveryGroupId:
                    continue
                else:
                    groupList.append(group['groupid'])

            self.zbxApiData = \
                {
                    'jsonrpc': '2.0',
                    'method': 'host.update',
                    'params':
                        {
                            'hostid': zbxHost['hostid'],
                            'groups': groupList
                        },
                    'auth': self.zbxLoginToken,
                    'id': 1
                }

            zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                        verify=False)
            zbxReturnCode = zbxResponse.status_code
            if zbxReturnCode != 200:
                self.logger.error('[ERROR] Unable to remove host: {} from discovery group, with error code : {}'.format(zbxHost['host'], zbxReturnCode))
                raise SystemExit('[ERROR] Unable to remove host: {} from discovery group, with error code : {}'.format(zbxHost['host'], zbxReturnCode))

        # Moving host to according groups
        else:
            self.zbxApiData = \
                {
                    'jsonrpc': '2.0',
                    'method': 'host.update',
                    'params':
                        {
                            'hostid': zbxHost['hostid'],
                            'groups': [zbxTargetGroupIds]
                        },
                    'auth': self.zbxLoginToken,
                    'id': 1
                }

            zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                        verify=False)

            zbxReturnCode = zbxResponse.status_code
            if zbxReturnCode != 200:
                self.logger.error('[ERROR] Unable to remove host: {} from discovery group, with error code : {}'.format(zbxHost['host'], zbxReturnCode))
                raise SystemExit('[ERROR] Unable to remove host: {} from discovery group, with error code : {}'.format(zbxHost['host'], zbxReturnCode))

    ##############################################################################
    # zbxGetHosts method


    def zbxGetHosts(self, zbxHostName):
        self.zbxApiData = \
            {
                'jsonrpc': '2.0',
                'method': 'host.get',
                'params':
                    {
                        'output': ['host', 'status'],
                        'selectInterfaces': ['ip', 'dns', 'port'],
                        'search': {'host': [zbxHostName]}
                    },
                'auth': self.zbxLoginToken,
                'id': 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to open Zabbix API session with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to open Zabbix API session with error code : {}'.format(zbxReturnCode))

        zbxHostList = zbxResponse.json()['result']
        return zbxHostList

    ##############################################################################
    # zbxGetTemplatesLinkedToHostid

    def zbxGetTemplatesLinkedToHostid(self, zbxHostId):
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "host.get",
                "params": {
                    "output": ["hostid"],
                    "selectParentTemplates": [
                        "templateid"
                    ],
                    "hostids": zbxHostId
                },
                "id": 1,
                "auth": self.zbxLoginToken,
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to open Zabbix API session with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to open Zabbix API session with error code : {}'.format(zbxReturnCode))
        return zbxResponse.json()['result']

    ##############################################################################
    # zbxDeleteHost method
    def zbxDeleteHost(self, zbxHost):
        self.zbxApiData = \
            {
                'jsonrpc': '2.0',
                'method': 'host.delete',
                'params': [zbxHost['hostid']],
                'auth': self.zbxLoginToken,
                'id': 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to open Zabbix API session with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to open Zabbix API session with error code : {}'.format(zbxReturnCode))

    def zbx_user_macro_create(self, **kwargs):
        """

        :param args: [{
                    "hostid": zbxhostid,
                    "macro": zbxmacro,
                    "value": zbxvalue
                }],
        :return:
        """
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "usermacro.create",
                "params": kwargs,
                "auth": self.zbxLoginToken,
                "id": 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code
        # print zbxResponse.json()

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to create user macros with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to create user macros with error code : {}'.format(zbxReturnCode))
        return zbxResponse.json()

    def zbx_user_macro_update(self, hostmacroid, value):
        """

        :param kwargs:
        :return:
        """
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "usermacro.update",
                "params": {
                    "hostmacroid": hostmacroid,
                    "value": value
                },
                "auth": self.zbxLoginToken,
                "id": 1
            }

        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)
        zbxReturnCode = zbxResponse.status_code
        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to update user macros with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to update user macros with error code : {}'.format(zbxReturnCode))
        return zbxResponse.json()

    def zbx_get_user_macros(self, host_id):
        """

        :param kwargs:
        :return:
        """
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "usermacro.get",
                "params": {
                    "output": "extend",
                    "hostids": host_id
                },
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to get user macros id with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to get user macros id with error code : {}'.format(zbxReturnCode))
        return zbxResponse.json()

    def zbx_delete_user_macros(self, hostmacroid):
        """

        :return:
        """
        """

        :param kwargs:
        :return:
        """
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "usermacro.delete",
                "params": [
                    hostmacroid
                ],
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to get user macros id with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to get user macros id with error code : {}'.format(zbxReturnCode))
        return zbxResponse.json()

    def zbx_get_hostgroup(self, group_name):
        """

        :param host_group:
        :return:
        """
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "hostgroup.get",
                "params": {
                    "output": "extend",
                    "filter": {
                        "name": [
                            group_name,
                        ]
                    }
                },
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to get host group with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to get host group with error code : {}'.format(zbxReturnCode))
        return zbxResponse.json()

    def zbx_hostgroup_msadd(self, group_id, host_id):
        """

        :param group_id:
        :param host_id:
        :return:
        """
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "hostgroup.massadd",
                "params": {
                    "groups": [
                        {
                            "groupid": group_id
                        }
                    ],
                    "hosts": [
                        {
                            "hostid": host_id
                        }
                    ]
                },
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to associate host in host group with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to associate host in host group with error code : {}'.format(zbxReturnCode))
        return zbxResponse.json()

    def zbx_hostgroup_msremove(self, group_id, host_id):
        """

        :param group_id:
        :param host_id:
        :return:
        """
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "hostgroup.massremove",
                "params": {
                    "groupids": [
                        group_id,
                    ],
                    "hostids": [
                        host_id
                    ]
                },
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders,
                                    verify=False)

        zbxReturnCode = zbxResponse.status_code

        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to remove host from host group with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to remove host from host group with error code : {}'.format(zbxReturnCode))
        return zbxResponse.json()

    def zbxGetInterfaces(self, host_id):
        """
        :param host_id:
        :return:
        """
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "hostinterface.get",
                "params": {
                    "output": "extend",
                    "hostids": host_id,
                    "filter": {
                        "main": "1",
                        "type": "1"
                     }
                },
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(
            self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders, verify=False
        )
        zbxReturnCode = zbxResponse.status_code
        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to get interfaces with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to get interfaces with error code : {}'.format(zbxReturnCode))
        return zbxResponse.json()

    def zbxCreateItem(self, **params):
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "item.create",
                "params": params,
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(
            self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders, verify=False
        )
        zbxReturnCode = zbxResponse.status_code
        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to create item with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to create item with error code : {}'.format(zbxReturnCode))
        return zbxResponse.json()

    def zbxSearchItem(self, host_id, search_data=None, params_data=None):
        params = {
            "output": "extend",
            "hostids": host_id
        }
        if type(search_data) is dict:
            params["filter"] = search_data
        if type(params_data) is dict:
            params.update(params_data)
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "item.get",
                "params": params,
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(
            self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders, verify=False
        )
        zbxReturnCode = zbxResponse.status_code
        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to search item with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to search item with error code : {}'.format(zbxReturnCode))
        return zbxResponse.json()

    def zbxDeleteItem(self, item_id):
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "item.delete",
                "params": [
                    item_id
                ],
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(
            self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders, verify=False
        )
        zbxReturnCode = zbxResponse.status_code
        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to delete Item with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to delete Item with error code : {}'.format(zbxReturnCode))
        return zbxResponse.json()

    def zbxCreateTrigger(self, params):
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "trigger.create",
                "params": [
                    {
                        "description": params['description'],
                        "expression": params['expression'],
                        "priority": params.get("priority", 0)
                    }
                ],
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(
            self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders, verify=False
        )
        zbxReturnCode = zbxResponse.status_code
        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to Create Trigger with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to Create Trigger with error code : {}'.format(zbxReturnCode))
        return zbxResponse.json()

    def _zbxGetAllTriggersForHostid(self, host_id):
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "trigger.get",
                "params": {
                    "output": "extend",
                    "hostids": host_id,
                },
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(
            self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders, verify=False
        )
        zbxReturnCode = zbxResponse.status_code
        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to Get all triggers with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to Get all Triggers with error code : {}'.format(zbxReturnCode))
        return zbxResponse.json()

    def zbxSearchTrigger(self, host_id, search_by_desc):
        r = self._zbxGetAllTriggersForHostid(host_id)
        r['result'] = list(filter(lambda x: x["description"] == search_by_desc, r['result']))
        return r

    def zbxDeleteTrigger(self, trigger_id):
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "trigger.delete",
                "params": [
                    trigger_id
                ],
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(
            self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders, verify=False
        )
        zbxReturnCode = zbxResponse.status_code
        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to delete Trigger with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to delete Trigger with error code : {}'.format(zbxReturnCode))
        return zbxResponse.json()

    def zbxCreateApplication(self, host_id, name):
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "application.create",
                "params": {
                    "name": name,
                    "hostid": host_id
                },
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(
            self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders, verify=False
        )
        zbxReturnCode = zbxResponse.status_code
        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to create Application with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to create Application with error code : {}'.format(zbxReturnCode))
        return zbxResponse.json()

    def zbxSearchApplication(self, host_id, search_by_name):
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "application.get",
                "params": {
                    "output": "extend",
                    "hostids": host_id,
                    "filter": {
                        "name": search_by_name
                    }
                },
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(
            self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders, verify=False
        )
        zbxReturnCode = zbxResponse.status_code
        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to search Application with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to search Application with error code : {}'.format(zbxReturnCode))
        return zbxResponse.json()

    def zbxDeleteApplication(self, application_id):
        self.zbxApiData = \
            {
                "jsonrpc": "2.0",
                "method": "application.delete",
                "params": [
                    application_id
                ],
                "auth": self.zbxLoginToken,
                "id": 1
            }
        zbxResponse = requests.post(
            self.zbxUrl, data=json.dumps(self.zbxApiData), headers=self.zbxApiHeaders, verify=False
        )
        zbxReturnCode = zbxResponse.status_code
        if zbxReturnCode != 200:
            self.logger.error('[ERROR] Unable to search Application with error code : {}'.format(zbxReturnCode))
            raise SystemExit('[ERROR] Unable to search Application with error code : {}'.format(zbxReturnCode))
        return zbxResponse.json()

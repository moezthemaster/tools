#!/usr/bin/python
# -*- coding: utf-8 -*-

#

DOCUMENTATION = '''




'''

EXAMPLES = '''
    see test_dns_informer.py
'''

import re
import logging

from edge.exception import EdgeException
from edge.conf.cloud_network import find_network_infos


logger = logging.getLogger(__name__)


class DnsInformer(object):
    def __init__(self, hostname, region_cloud=None, az_cloud=None):
        try:
            assert re.search(r'^edge_conflict_(ssh|rdp|whats)_[0-9]+$', hostname) or hostname.isalnum()
        except:
            raise EdgeException("hostname must be alphanumeric")
        self.hostname = hostname
        self.region_cloud = region_cloud
        self.az_cloud = az_cloud
        self.changed = False

    def run(self):
        '''
        First get ip addess of host.
        Then retrieve network informations from mapping file.
        :return: list of dict
        '''
        infos = []
        logger.debug('Retrieving record type {} for hostname {}'.format("A", self.hostname))
        search = self.host_search_infos(self.hostname)
        for record in search:
            if record.ip:
                env, region_cloud, az_cloud, network_id, network_cidr, dns_zone, dns_cname = \
                    find_network_infos(record.ip, self.region_cloud, self.az_cloud)
                infos.append(
                    {
                        "vm_hostname" : self.hostname, "ip_address": record.ip,
                        "vm_env": env, "vm_region": region_cloud, "vm_az": az_cloud,
                        "vm_network": network_id, "vm_subnet": network_cidr,
                        "vm_zone": dns_zone, "dns_publish": "fr.world.socgen"
                    }
                )
        return infos

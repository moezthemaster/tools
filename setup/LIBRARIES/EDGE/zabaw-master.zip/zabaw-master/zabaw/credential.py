from py_edge_vault import secrets
from zabaw.conf import settings


def get_credentials():
    vault_secret = secrets.get_secrets(context=settings.ZABBIX_CREDENTIALS_GROUP)
    username = vault_secret['username']
    password = vault_secret['password']
    return username, password

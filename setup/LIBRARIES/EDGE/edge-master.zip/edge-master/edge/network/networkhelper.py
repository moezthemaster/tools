#!/usr/bin/python
# -*- coding: utf-8 -*-

import paramiko
import os
import re
from io import StringIO
from edge.conf import settings
from edge.exception import EdgeException
from edge.tools.tools import VmSessionSsh
from py_edge_vault import secrets



COMMAND_STATIC = 'static'
COMMAND_DYNAMIC = 'dynamic'


class NetworkHelper(object):
    '''
    '''
    def __init__(self):
        vault_secret = secrets.get_secrets(context=settings.PUBKEY_CREDENTIALS_GROUP)
        self.user = vault_secret['user']
        self.key = vault_secret['private_root_key']
        self.has_changed = False

    def update_etc_host(self, ip_address, network_id):
        vm_session = VmSessionSsh(ip_address)
        try:
            if network_id == "CDN": 
                cmd = 'sudo sh -c "grep -qF \'{line}\' \'{file}\' || echo \'{line}\' >> {file}"'.format(line="192.82.192.84 pxplux10 pxplux10.dns20.socgen", file="/etc/hosts")
                vm_session.execute_cmd(cmd, COMMAND_DYNAMIC)
                cmd = 'sudo sh -c "grep -qF \'{line}\' \'{file}\' || echo \'{line}\' >> {file}"'.format(line="192.88.36.156 pxplux20 pxplux20.dns20.socgen", file="/etc/hosts")
                vm_session.execute_cmd(cmd, COMMAND_DYNAMIC)
                cmd = 'sudo sh -c "grep -qF \'{line}\' \'{file}\' || echo \'{line}\' >> {file}"'.format(line="192.82.208.119 pxplux30 pxplux30.dns20.socgen", file="/etc/hosts")
                vm_session.execute_cmd(cmd, COMMAND_DYNAMIC)
                cmd = 'sudo sh -c "grep -qF \'{line}\' \'{file}\' || echo \'{line}\' >> {file}"'.format(line="192.88.36.2 pxplvs11 pxplvs11.dns20-1.socgen", file="/etc/hosts")
                vm_session.execute_cmd(cmd, COMMAND_DYNAMIC)
        except Exception as e:
            raise EdgeException("Error when adding repo IAS for cdn server : {}".format(e.args[0]))

        self.has_changed = True    
        return "OK"

    def update_dns_config(self, ip_address, geo_domain, network_id, network_envi, network_az=None):

        vm_session = VmSessionSsh(ip_address)
        try:
            cmd = 'a=`hostname -s|tail -c2`;test=$(($a % 2));echo $test'
            code_status, stdout, stderr = vm_session.execute_cmd(cmd, COMMAND_STATIC)
            stdout=stdout.rstrip()
        except Exception as e:
            raise EdgeException('Error while execution command {}: {}'.format(cmd, e.args[0]))

        try:
            key = paramiko.RSAKey.from_private_key(StringIO(self.key))    
            # Open a SSH connection to VM
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(hostname=ip_address, username=self.user, pkey=key) 

            domain = re.sub('[12-]', '', geo_domain)
            sftp = client.open_sftp()
            destination = "/tmp/resolv.conf"
            
            if network_id != "CDN" and domain != 'wce.bsc.socgen' and domain != 'wce.rbdf.socgen': 
               source = "{}/files/resolv_file".format(os.path.abspath(os.path.dirname(__file__)))
            if network_id == 'CDN' or network_id == 'CDN_HOB' or network_id == 'CDN_HOT': 
               source = "{}/files/resolv_file_CDN".format(os.path.abspath(os.path.dirname(__file__)))
            if (network_id == 'CDN' or network_id == 'CDN_HOB' or network_id == 'CDN_HOT') and (network_envi == 'dev' or network_envi == 'hml') and stdout == '0':
               source = "{}/files/resolv_file_CDN_devhom_pair".format(os.path.abspath(os.path.dirname(__file__)))
            if (network_id == 'CDN' or network_id == 'CDN_HOB' or network_id == 'CDN_HOT') and (network_envi == 'dev' or network_envi == 'hml') and stdout == '1':
               source = "{}/files/resolv_file_CDN_devhom_impair".format(os.path.abspath(os.path.dirname(__file__)))
            if (network_id == 'CDN' or network_id == 'CDN_HOB' or network_id == 'CDN_HOT') and network_envi == 'prd' and stdout == '0':
               source = "{}/files/resolv_file_CDN_prod_pair".format(os.path.abspath(os.path.dirname(__file__)))
            if (network_id == 'CDN' or network_id == 'CDN_HOB' or network_id == 'CDN_HOT') and network_envi == 'prd' and stdout == '1':
               source = "{}/files/resolv_file_CDN_prod_impair".format(os.path.abspath(os.path.dirname(__file__)))
            if network_id != 'CDN' and geo_domain == 'wce-1.bsc.socgen':
               source = "{}/files/resolv_file_BSC_webcell".format(os.path.abspath(os.path.dirname(__file__)))
            if network_id != 'CDN' and geo_domain == 'wce-2.bsc.socgen':
               source = "{}/files/resolv_file_BSC2_webcell".format(os.path.abspath(os.path.dirname(__file__)))
            if network_id != 'CDN' and geo_domain == 'wce-1.rbdf.socgen':
               source = "{}/files/resolv_file_RBDF_webcell".format(os.path.abspath(os.path.dirname(__file__)))
            if network_id != 'CDN' and geo_domain == 'wce-2.rbdf.socgen':
               source = "{}/files/resolv_file_RBDF2_webcell".format(os.path.abspath(os.path.dirname(__file__)))
            if network_id in ('TECH_CCELL_BSC', 'TECH_CCELL_ITIM', 'APP_CCELL_ITIM', 'APP_CCELL_BSC'):
                if network_az is None:
                    raise EdgeException("network_az must be provided for cloudcell networks...")
                if network_az == "eu-fr-north-1":
                    source = "{}/files/resolv_file_seclin_cloudcell".format(os.path.abspath(os.path.dirname(__file__)))
                elif network_az == "eu-fr-paris-2":
                    source = "{}/files/resolv_file_tigery_cloudcell".format(os.path.abspath(os.path.dirname(__file__)))
                else:
                    raise EdgeException("Cloudcell networks are not exist for this az={}...".format(network_az))

            sftp.put(source, destination)
            sftp.close()
            
            cmd = 'sudo sh -c "cp /tmp/resolv.conf /etc/resolv.conf"'
            vm_session.execute_cmd(cmd, COMMAND_STATIC, client=client)
            
        except paramiko.SSHException as e:
            raise EdgeException("SSHException: {}".format(e.args[0]))
        finally:
            client.close()
        return "OK"

    def configure_ntp(self, ip_address, network_id, network_az=None):
        
        vm_session = VmSessionSsh(ip_address)

        try: 
            key = paramiko.RSAKey.from_private_key(StringIO(self.key))   

            # Open a SSH connection to VM
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(hostname=ip_address, username=self.user, pkey=key)

            cmd = 'sudo sh -c "yum -y install autogen-libopts"'
            vm_session.execute_cmd(cmd, COMMAND_STATIC, client=client)
            cmd = 'sudo sh -c "yum -y install ntp"'
            vm_session.execute_cmd(cmd, COMMAND_STATIC, client=client)

            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(hostname=ip_address, username=self.user, pkey=key)
            
            sftp = client.open_sftp()
            destination="/tmp/ntp.conf"

            if network_id == 'CDN' or network_id == 'CDN_HOB' or network_id == 'CDN_HOT':
               source = "{}/files/ntp-cdn.conf".format(os.path.abspath(os.path.dirname(__file__)))
            elif network_id in ('TECH_CCELL_BSC', 'TECH_CCELL_ITIM', 'APP_CCELL_ITIM', 'APP_CCELL_BSC'):
                if network_az is None:
                    raise EdgeException("network_az must be provided for cloudcell networks...")
                if network_az == "eu-fr-north-1":
                    source = "{}/files/ntp-seclin-cloudcell.conf".format(os.path.abspath(os.path.dirname(__file__)))
                elif network_az == "eu-fr-paris-2":
                    source = "{}/files/ntp-tigery-cloudcell.conf".format(os.path.abspath(os.path.dirname(__file__)))
                else:
                    raise EdgeException("Cloudcell networks are not exist for this az={}...".format(network_az))
            else:
                source = "{}/files/ntp.conf".format(os.path.abspath(os.path.dirname(__file__)))
            sftp.put(source, destination)
            sftp.close()

            cmd = 'sudo sh -c "cp /tmp/ntp.conf /etc/ntp.conf"'
            vm_session.execute_cmd(cmd, COMMAND_STATIC, client=client)
            cmd = 'sudo sh -c "chmod 644 /etc/ntp.conf"'
            vm_session.execute_cmd(cmd, COMMAND_STATIC, client=client)
            cmd = 'sudo sh -c "systemctl restart ntpd"'
            vm_session.execute_cmd(cmd, COMMAND_STATIC, client=client)
            cmd = 'sudo sh -c "systemctl enable ntpd"'
            vm_session.execute_cmd(cmd, COMMAND_STATIC, client=client)
            cmd = 'sudo sh -c "systemctl start ntpd"'
            vm_session.execute_cmd(cmd, COMMAND_STATIC, client=client)
            cmd = 'sudo sh -c "systemctl stop chronyd"'
            vm_session.execute_cmd(cmd, COMMAND_STATIC, client=client)
            cmd = 'sudo sh -c "systemctl disable chronyd"'
            vm_session.execute_cmd(cmd, COMMAND_STATIC, client=client)
    
        except paramiko.SSHException as e:
            raise EdgeException("SSHException: {}".format(e.args[0]))
        finally:
            client.close()
        return "OK"

    def configure_rsyslog(self, ip_address, network_id, network_az=None):
        vm_session = VmSessionSsh(ip_address)
        client = paramiko.SSHClient()
        try:
            key = paramiko.RSAKey.from_private_key(StringIO(self.key))
            destination = "/tmp/logcolcor.conf"
            if network_id in ('TECH_CCELL_BSC', 'TECH_CCELL_ITIM', 'APP_CCELL_ITIM', 'APP_CCELL_BSC'):
                # Open a SSH connection to VM
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                client.connect(hostname=ip_address, username=self.user, pkey=key)
                sftp = client.open_sftp()
                if network_az is None:
                    raise EdgeException("network_az must be provided for cloudcell networks...")
                if network_az == "eu-fr-north-1":
                    source = "{}/files/logcolcor_seclin.conf".format(os.path.abspath(os.path.dirname(__file__)))
                elif network_az == "eu-fr-paris-2":
                    source = "{}/files/logcolcor_tigery.conf".format(os.path.abspath(os.path.dirname(__file__)))
                else:
                    raise EdgeException("Cloudcell networks are not exist for this az={}...".format(network_az))
                sftp.put(source, destination)
                sftp.close()
                cmd = 'sudo sh -c "test -f /etc/rsyslog.d/logcolcor.conf"'
                code_status, stdout, stderr = vm_session.execute_cmd(cmd, COMMAND_STATIC, client=client)
                if code_status != 0:
                    raise EdgeException("/etc/rsyslog.d/logcolcor.conf does not exist for configuring rsyslog")
                cmd = 'sudo sh -c "cp /tmp/logcolcor.conf /etc/rsyslog.d/logcolcor.conf"'
                vm_session.execute_cmd(cmd, COMMAND_STATIC, client=client)
                cmd = 'sudo sh -c "systemctl restart rsyslog"'
                vm_session.execute_cmd(cmd, COMMAND_STATIC, client=client)
        except paramiko.SSHException as e:
            raise EdgeException("SSHException: {}".format(e.args[0]))
        finally:
            client.close()
        return "OK"

#!/usr/bin/env python
# -*- coding: utf-8 -*-

import testinfra
from itertools import product
from behave import *


@then('FS is created and extended')
def step_impl(context):
    print("Test extra disk is present")
    print("###########################################################################################")
    server = testinfra.get_host('ssh://automation@' + context.params['vm_ipaddr'])
    cmd_disk = server.run("lsblk -l --noheadings --nodeps /dev/sdb -o size")

    if cmd_disk.stdout.strip() == context.params['vm_extra_disk']:
        assert context.failed is False
    else:
        assert context.failed is True

    print("Test FS are mounted and extended")
    print("###########################################################################################")

    command = "lsblk -P -o 'MOUNTPOINT,SIZE' -I 8"
    fs_requested = []
    for fs in context.params['fs_list']:
        fs_requested.append('mountpoint="{}" size="{}"'.format(fs["mountpoint"], fs["size"].lower()))
    #fs_requested = ['mountpoint="/" size="22g"', 'mountpoint="/bases" size="4g"', 'mountpoint="/firstfstest" size="1g"',
    #                'mountpoint="/secondfstest" size="1g"']
    n = len(fs_requested)
    print(n)
    server = testinfra.get_host('ssh://automation@' + context.params['vm_ipaddr'])
    config = server.run(command)
    fs_on_vm = config.stdout.lower().splitlines()

    a = []
    for fs_list, fs_on_vm in product(fs_requested, fs_on_vm):
        print("search {} in {}".format(fs_list, fs_on_vm))
        if fs_list.lower() == fs_on_vm.lower():
            print("fs {} is created".format(fs_list))
            a.append(fs_list)
            print(a)
        else:
            pass
    print(len(a))
    if len(a) == n:
        assert context.failed is False
    else:
        assert context.failed is True


import re
import logging

from edge.conf import settings
from edge.exception import EdgeException

logging.basicConfig(level=logging.getLevelName(settings.LOGGER_LEVEL))
logger = logging.getLogger(__name__)


class ManageIP(object):

    ERRORS_REGEX_FOR_UPDATE_DNS_RECORD = {
        "ssh": (
            r'.*Unknown.*host.*:.*Authentification.*failed.*',
            r'.*Authentification.*error.*for.*',
            r'.*SSHException.*',
            r'.*Connection.*timeout.*',
            r'.*Error.*when.*executing.*command.*',
            r'.*command.*is.*not.*allowed.*to.*be.*executed.*'
        ),
        "rdp": (
            r'.*Connexion.*RDP.*OK.*',
        ),
        "ping": (
            r'.*Connexion.*Ping.*OK.*',
        )
    }

    def __init__(self, idm, cnx_helper, feeder, updater, cleaner): 
        self.idm_cls = idm
        self.cnx_cls = cnx_helper
        self.feeder_cls = feeder
        self.updater_cls = updater
        self.cleaner_cls = cleaner
        self._counter = 1
        self.has_changed = False

    def _check_multiple_regex(self, data, *regex):
        for r in regex:
            if re.search(r, data):
                return True
        return False

    def _tag_in_case_error(self, func, func_args=None, func_kwargs=None, error_type=None):
        if error_type is None:
            raise Exception("Error type must be specifed for {}".format(func.__name__))
        if func_args is None:
            func_args = tuple()
        if func_kwargs is None:
            func_kwargs = dict()
        try:
            return func(*func_args, **func_kwargs)
        except Exception as err:
            raise Exception("{} : {}".format(error_type, err.args[0]))

    def run(self, env, region_cloud, az_cloud, network_id, trigram, hostname, max_retries=int(settings.NB_ATTEMPT)):
        responses = []
        cnx_helper = self.cnx_cls()
        feeder = self.feeder_cls(env, region_cloud, az_cloud, network_id, trigram=trigram, hostname=hostname)

        while self._counter <= max_retries:
            self._counter += 1
            try:
                response = self._tag_in_case_error(feeder.run, error_type="DodFeederError")
                cnx_resp = self._tag_in_case_error(
                    cnx_helper.check_ip_address, func_args=(response["output"][0]['ip'],), error_type="ConnexionHelperError"
                )
                try:
                    cnx_resp = cnx_resp.decode('utf-8')
                except Exception:
                    pass
                match_hostname = re.match(r'^({0}\..*)|({0})$'.format(response["output"][0]['hostname']), cnx_resp)
                if cnx_resp == "No host responding to Ping" or match_hostname:
                    idm = self.idm_cls(response["output"][0]['hostname'])
                    whats_resp = self._tag_in_case_error(
                        idm.check_whats, func_kwargs={
                            "whats_ip": response["output"][0]['ip'], "whats_hostname": response["output"][0]['hostname']
                        },
                        error_type="WhatsError"
                    )
                    if whats_resp["status"] == 200:
                        self.has_changed = feeder.changed
                        return response
                    elif whats_resp["status"] == 202:
                        responses.append("IP conflict with whats_hostname: {}, contact Edge team to get more information!".format(whats_resp))
                        cleaner = self.cleaner_cls(env, region_cloud, az_cloud, network_id, trigram=trigram, hostname=response["output"][0]['hostname'])
                        self._tag_in_case_error(cleaner.run, error_type="DodcleanerError")
                        break
                    else:
                        updater = self.updater_cls(env, region_cloud, az_cloud, network_id, trigram=trigram, hostname=response["output"][0]['hostname'])
                        update_resp = self._tag_in_case_error(updater.run, func_kwargs={"cause": "whats"}, error_type="DodUpdaterError")
                        responses.append("IP conflict with whats: {}".format(update_resp))
                else:
                    updater = self.updater_cls(env, region_cloud, az_cloud, network_id, trigram=trigram, hostname=response["output"][0]['hostname'])
                    update_resp = self._tag_in_case_error(updater.run, func_kwargs={"cause": "ssh"}, error_type="DodUpdaterError")
                    responses.append("IP conflict with unix server : {}".format(update_resp))
            except Exception as err:
                if self._check_multiple_regex(err.args[0], *self.ERRORS_REGEX_FOR_UPDATE_DNS_RECORD["ssh"]):
                    updater = self.updater_cls(env, region_cloud, az_cloud, network_id, trigram=trigram, hostname=response["output"][0]['hostname'])
                    update_resp = self._tag_in_case_error(updater.run, func_kwargs={"cause": "ssh"}, error_type="DodUpdaterError")
                    responses.append("IP conflict with unix server: {}".format(update_resp))
                    continue
                if self._check_multiple_regex(err.args[0], *self.ERRORS_REGEX_FOR_UPDATE_DNS_RECORD["rdp"]):
                    updater = self.updater_cls(env, region_cloud, az_cloud, network_id, trigram=trigram, hostname=response["output"][0]['hostname'])
                    update_resp = self._tag_in_case_error(updater.run, func_kwargs={"cause": "rdp"}, error_type="DodUpdaterError")
                    responses.append("IP conflict with windows server: {}".format(update_resp))
                    continue
                if self._check_multiple_regex(err.args[0], *self.ERRORS_REGEX_FOR_UPDATE_DNS_RECORD["ping"]):
                    updater = self.updater_cls(env, region_cloud, az_cloud, network_id, trigram=trigram, hostname=response["output"][0]['hostname'])
                    update_resp = self._tag_in_case_error(updater.run, func_kwargs={"cause": "ping"}, error_type="DodUpdaterError")
                    responses.append("IP conflict with a component: {}".format(update_resp))
                    continue
                try:
                    cleaner = self.cleaner_cls(
                        env, region_cloud, az_cloud, network_id,
                        trigram=trigram, hostname=response["output"][0]['hostname']
                    )
                    self._tag_in_case_error(cleaner.run, error_type="DodcleanerError")
                    responses.append(err.args[0])
                except (TypeError, KeyError) as e:
                    responses.append(
                        "Error while trying to suppress ghost entries : response['output'][0]['hostname'] - {}".format(e.args[0])
                    )
                except UnboundLocalError:
                    responses.append("Error while trying to record dns : {}".format(err.args[0]))
                except Exception as e:
                    responses.append("Error while trying to suppress ghost entries : {}".format(e.args[0]))
        raise EdgeException(
            "Error getting IP address after {} attempts in {}. See errors : {}".format(
                max_retries, feeder, responses
            )
        )


from edge.whats.enrollment import RegisterWhatsClient

from edge.whats.idm import Idm
from whatsaw.idm import IdmWrapper


class IdmImpl(Idm):
    def __init__(self, hostname):
        Idm.__init__(self)
        self.idm_wrapper = IdmWrapper(hostname)

    def get_realm(self):
        return self.idm_wrapper.get_realm()

    def get_domain(self):
        return self.idm_wrapper.get_domain()

    def destroy_token(self):
        return self.idm_wrapper.destroy_token()

    def enroller(self, hostname, ip_address, trigram):
        return self.idm_wrapper.enroller(hostname, ip_address, trigram)

    def unroller(self, hostname):
        return self.idm_wrapper.unroller(hostname)

    def ip_checker(self, environment, ip_address):
        return self.idm_wrapper.ip_checker(environment, ip_address)

    def host_checker(self, hostname):
        return self.idm_wrapper.host_checker(hostname)


class WhatsModuleError(Exception):
    pass


PRESENT, ABSENT, STATUS, CHECK_HOSTNAME = 'present', 'absent', 'status', 'check_hostname'


def whats_module(whats_hostname, whats_ip, whats_trigram, state="present"):
    try:
        idm = IdmImpl(whats_hostname)
        if state == PRESENT:
            response = idm.create_whats(
                whats_hostname=whats_hostname,
                whats_ip=whats_ip,
                whats_trigram=whats_trigram,
            )
            if response['error'] is None or response["error"]["code"] == 4002:
                return idm.has_changed, response
            else:
                raise WhatsModuleError("WhatsError : {}".format(response))
        elif state == ABSENT:
            response = idm.delete_whats(whats_hostname)
            if response['error'] is None or response["error"]["code"] == 4001:
                return idm.has_changed, response
            else:
                raise WhatsModuleError("WhatsError : {}".format(response))
        elif state == STATUS:
            response = idm.check_whats(
                whats_ip=whats_ip,
                whats_hostname=whats_hostname
            )
            if response["status"] == 200:
                return idm.has_changed, response
            else:
                raise WhatsModuleError("WhatsError : {}".format(response))
        elif state == CHECK_HOSTNAME:
            response = idm.check_hostname(whats_hostname=whats_hostname)
            if response["status"] == 200:
                return idm.has_changed, response
            else:
                raise WhatsModuleError("WhatsError : {}".format(response))
    finally:
        try:
            idm.destroy_token()
        except NameError:
            pass


def whats_client_module(domain, hostname, realm, ip_address):
    register_client = RegisterWhatsClient(
        ip_address=ip_address,
        hostname=hostname,
        domain=domain,
        realm=realm
    )
    response = register_client.launch()
    return False, response

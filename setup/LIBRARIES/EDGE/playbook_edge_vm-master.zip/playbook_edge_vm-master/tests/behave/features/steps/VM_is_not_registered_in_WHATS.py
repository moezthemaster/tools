#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
import socket

@then('VM is not registered in WHATS')
def step_impl(context):
      assert context.failed is False


#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import socket
import paramiko
from edge.conf import settings
from edge.exception import EdgeException
from edge.tools.tools import VmSessionSsh


COMMAND_STATIC = 'static'
COMMAND_DYNAMIC = 'dynamic'

class ConnectionHelper(object):
    '''
    '''
    def __init__(self):
        self.has_changed = False

    def authorized_key(self,ip_address,remote_user,remote_group,pubkey):

        vm_session = VmSessionSsh(ip_address)
            
        cmd = 'sudo sh -c "grep \'^{user}:\' /etc/passwd | cut -d: -f6 | tail -1"'.format(user=remote_user)
        code_status, stdout, stderr = vm_session.execute_cmd(cmd, COMMAND_DYNAMIC)
        homedir = stdout.rstrip().decode('utf-8')
        if not homedir:
            raise EdgeException("User {} not found on server".format(remote_user))

        cmd = 'sudo sh -c "grep \'{pubkey}\' {hd}/.ssh/authorized_keys"'.format(pubkey=pubkey, hd=homedir)
        code_status, stdout, stderr = vm_session.execute_cmd(cmd, COMMAND_DYNAMIC)
        response=stdout.rstrip()
        if code_status != 0:
            cmd = 'sudo -u automation sh -c "mkdir -p {hd}/.ssh; chmod 700 {hd}/.ssh; echo \'{pubkey}\' >>{hd}/.ssh/authorized_keys; chown {user}:{group} {hd}/.ssh/authorized_keys; chmod 600 {hd}/.ssh/authorized_keys; hostname"'.format(pubkey=pubkey, user=remote_user, group=remote_group, hd=homedir)
            code_status, stdout, stderr = vm_session.execute_cmd(cmd, COMMAND_DYNAMIC)
            response=stdout.rstrip()
            if code_status == 0:
                self.has_changed = True
            else:
                raise EdgeException("Error in pubkey copy : {}".format(stderr))

        return response


    def check_ssh_connection(self, ip_address, timeout=5, cmd = 'sudo sh -c "hostname"'):
        vm_session = VmSessionSsh(ip_address)

        self.has_changed = True
        try:
            code_status, stdout, stderr = vm_session.execute_cmd(cmd, COMMAND_STATIC)
            response = stdout.rstrip()
        except paramiko.AuthenticationException as e:
            raise EdgeException("Unknown host : Authentification failed")
        except Exception as e :
            self.has_changed = False
            return "SSH connection KO"
        return response

    def check_ping(self, address):
        
        output = os.system("ping -c 1 " + address)

        if output == 0: 
            raise EdgeException("Connexion Ping OK")
        
        return "No host responding to Ping"

        

    def is_alive(self, address, port, timeout=5):

       # Create a socket object to connect with
       s = socket.socket()
       s.settimeout(timeout)


       # Now try connecting, passing in a tuple with address & port
       try:
           s.connect((address, port))
           return True
       except socket.error:
           return False
       finally:
           s.close()

    def check_rdp_connection(self,ip_address, timeout=5):

        self.has_changed = True
        response = self.is_alive(address=ip_address,port=33089,timeout=timeout)
        if response:
           raise EdgeException("Connexion RDP OK")

        response = self.is_alive(address=ip_address,port=3389,timeout=timeout)

        if response:
            raise EdgeException("Connexion RDP OK")
        self.has_changed = False
        return "No host responding in RDP"

    def check_ip_address(self, ip_address):

        response = self.check_ssh_connection(ip_address)
        
        if response == "SSH connection KO":
           response = self.check_rdp_connection(ip_address)

        if response == "No host responding in RDP":
           response = self.check_ping(ip_address)

        return response


    def discover_disk(self, ip_address):

        vm_session = VmSessionSsh(ip_address)
        cmd = 'sudo sh -c "grep -ni mpt /sys/class/scsi_host/host?/proc_name /sys/class/scsi_host/host??/proc_name | cut -d\':\' -f1 | sort | uniq | sed \'s!^.*\/\(host[0-9]*\)\/.*$!\1!\' | while read host; do echo \'---\' > /sys/class/scsi_host/${host}/scan; done"'
        code_status, stdout, stderr = vm_session.execute_cmd(cmd, COMMAND_STATIC)
        recup_disk = "echo \"/dev/`lsblk -r -d -e 11,2,1 -o NAME -n | sed -n '$p'`\""
        code_status, stdout, stderr = vm_session.execute_cmd(cmd, COMMAND_STATIC)
        return stdout 

from edge.interfaces import MarleyHPOO


class MockedMarleyHPOO(MarleyHPOO):
    def invoc_step_marley_v5(self, **params):
        return 'dummy_result'

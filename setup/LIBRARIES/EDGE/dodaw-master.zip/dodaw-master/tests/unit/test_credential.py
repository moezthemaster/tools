import unittest
try:
    from unittest import mock
except ImportError:
    import mock
from py_edge_vault import secrets
from tests.mock.dodaw import mock_vault
from dodaw.credential import get_user_pwd

class TestVault(unittest.TestCase):
    @mock.patch('py_edge_vault.secrets.get_secrets')
    def test_get_credentials(self, mock_creds):
        result = {
            "username": "userX",
            "password": "Pass"
        }
        mock_creds.return_value = mock_vault()
        response = get_user_pwd(context="ret-dodv2")
        assert response == (result['username'], result['password']) 

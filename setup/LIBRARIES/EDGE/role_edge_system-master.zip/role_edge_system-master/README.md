role_edge_system
================

Rôle de post configuration de la couche système d'une VM.
  - Mise en place des fichiers de configuration des repositories yum nécessaires.
  - Ajout du user patrol dans le sudoers 
  - Ajour des commandes sudo autorisées au groupe me<tri>

Requirements
------------

Pas de pré-requis particulier, à part l'existance de la vm spécifiée

Role Variables
--------------

vm_hostname : Nom de la vm à configurer (Obligatoire)

system_trigram : Trigramme applicatif a utiliser pour donner les droits sudo (Obligatoire)

FILES_PATH : Chemin 'accès pour les objets files. Ce paramètre est notemment utilisé dans le cas où le role est inclus depuis un autre. Par défaut, il pointe vers le répertoire files du role.

Dependencies
------------

Aucune dépendance.

Example Playbook
----------------

License
-------

BSD

Author Information
------------------

Role créé par la feature Team PaaS

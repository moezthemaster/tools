# configbox
This repo contains configuration files and secrets used by playbook_edge_vm.

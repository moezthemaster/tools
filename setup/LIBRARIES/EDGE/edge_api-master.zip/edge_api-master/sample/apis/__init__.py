""" Defining Routes for the API """
import os

from flask import request
from flask_restplus import Resource, Api as BaseApi

from sample.apis.vm import namespace as vm
from sample.apis.contacts import namespace as contact
from sample.apis.authentication import namespace as token

module_infos = os.path.join(
    os.path.dirname(
        os.path.dirname(
            os.path.dirname(__file__)
    )), "edge_infos.py"
)
version_line = [line for line in open(module_infos)
                if line.startswith('__version__')][0]

__version__ = version_line.split('__version__ = ')[-1][1:][:-2]


class Api(BaseApi):

    def _register_doc(self, app_or_blueprint):
        if self._add_specs and self._doc:
            app_or_blueprint.add_url_rule(self._doc, 'doc', self.render_doc)

    @property
    def base_path(self):
        return ''

    def render_root(self):
        self.abort(404)


authorizations = {
    'oauth2_implicit': {
        'type': 'oauth2',
        'flow': 'implicit',
        'authorizationUrl': 'https://sso.sgmarkets.com/sgconnect/oauth2/authorize',
        'scopes': {
            'openid': 'OpenID connect scope',
            'itaas': 'ITaaS profil',
            'profile': 'For Active directory login'
        }
    }
}

api = Api(title='EDGE API',
          version=__version__,
          description='API for deploy and manage vm with \
                        service providers',
          doc=False,
          security=[{'oauth2_implicit': ['openid', 'itaas',
                    'profile']}],
          authorizations=authorizations)

home = api.namespace('home', description='Edge api', path='/')
@home.route('/')
class Home(Resource):
    def get(self):
        return {
            "team": "Edge Automation",
            "documentation": "".join((request.url, "documentation/")),
            "version": __version__
        }

api.add_namespace(vm)
api.add_namespace(contact)
api.add_namespace(token)

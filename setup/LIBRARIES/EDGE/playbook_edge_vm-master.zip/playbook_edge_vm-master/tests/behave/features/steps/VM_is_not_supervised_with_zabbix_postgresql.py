#!/usr/bin/env python
# -*- coding: utf-8 -*-

from behave import *
from time import sleep
import testinfra


def all_is_false(iterable):
    for element in iterable:
        if element:
            return False
    return True

@then('VM is not supervised with zabbix postgresql')
def step_impl(context):
    files = (
        '/etc/zabbix/zabbix_agentd.d/PGS/check_postgres.pl',
        '/etc/zabbix/zabbix_agentd.d/zbx_userparameter_postgresql.conf',
        '/etc/zabbix/zabbix_agentd.d/PGS/zbx_PG_discover.sh',
        '/etc/zabbix/zabbix_agentd.d/PGS/zbx_pghoard.ksh',
        '/etc/zabbix/zabbix_agentd.d/PGS/zbx_postgresql.sh'
    )
    if context.params['vm_supervision'] == 'none':
        print("Skipping Zabbix check as no supervision has been set\n")
        return

    print("Test if all postgresql files for supervision zabbix are absent on vm={}\n".format(
            context.params['vm_ipaddr']
        )
    )

    server = testinfra.get_host('ssh://automation@' + context.params['vm_ipaddr'])

    tests = (server.file(v).exists for v in files)

    if all_is_false(tests):
        assert context.failed is False
    else:
        assert context.failed is True

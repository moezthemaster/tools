
egrep ':DNS:Missing [Aa]' logs/*.log | while read line; do 
  trig=`echo $line | cut -c6-8`
  server=`echo $line | cut -d':' -f2`
  infos=`egrep "^$server:[EC]" logs/$trig.log`
  echo "$server:$infos"
done

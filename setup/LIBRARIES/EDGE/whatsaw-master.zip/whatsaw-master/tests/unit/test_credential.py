import unittest
try:
    from unittest import mock
except ImportError:
    import mock
from py_edge_vault import secrets
from tests.mock.idm import mock_vault
from whatsaw.credential import get_user_passwd


class TestVault(unittest.TestCase):

    @mock.patch('py_edge_vault.secrets.get_secrets')
    def test_get_credentials(self, mock_creds):
        result = {
            "username": "userX",
            "password": "Pass"
        }
        mock_creds.return_value = mock_vault()
        user, password = get_user_passwd('DEV')

        assert (user, password) == (result['username'], result['password']) 

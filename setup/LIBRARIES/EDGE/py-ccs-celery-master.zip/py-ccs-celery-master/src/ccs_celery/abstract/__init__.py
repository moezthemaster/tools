
import traceback

from ccs_celery.tools.logger import set_up_logger


class TaskFailedError(Exception):
    def __init__(self, msg, **kwargs):
        self.meta = {
            "msg": msg,
            "task_kwargs": kwargs
        }


class TaskServiceManager(object):

    nor_state = lambda self, x: {"present": "absent", "absent": "present"}[x]

    def __init__(self, name, data):
        self._task_name = name
        self.data = data
        self.logger = set_up_logger(self._task_name, self.data.log_file, log_level=self.data.log_level)

    def on_failure(self, exc, kwargs, excinfo):
        raise NotImplemented

    def on_success(self, result, kwargs):
        raise NotImplemented

    def task(self):
        raise NotImplemented

    def run(self):
        try:
            result = self.task()
            self.logger.info("{} module has succeeded and return_value={}".format(self._task_name, result))
            self.on_success(result, self.data.services[self._task_name]["service_kwargs"])
            return result
        except Exception as exc:
            self.logger.error("{} module has failed and msg_error={}".format(self._task_name, str(exc)))
            self.on_failure(exc, self.data.services[self._task_name]["service_kwargs"], traceback.format_exc())
            raise TaskFailedError(str(exc), **self.data.services[self._task_name]["service_kwargs"]) from exc

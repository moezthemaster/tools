
import time
from edge.dns import DnsFeederFactory, DnsUpdaterFactory, DnsCleanerFactory, DnsInformerFactory


def _str(self):
    return "<DOD:{}>".format(self._type.upper())


def _run_mkt(self, cause):
    timestamp = time.time()
    self.new_hostname = "edge_conflict_{}_{}".format(cause, int(timestamp))
    return self._run()


class DnsFeederMetaClass(type):
    def __call__(cls, *args, **kwargs):
        env, region_cloud, az_cloud, network_id = args[0], args[1], args[2], args[3]
        start_ins = object.__new__(cls)
        start_ins.__init__(*args, **kwargs)
        feeder_cls, feeder_type = DnsFeederFactory(
            env=env,
            region_cloud=region_cloud,
            az_cloud=az_cloud,
            network_id=network_id
        )

        attrs = {
            '__init__': feeder_cls.__init__,
            '_type': feeder_type.upper(),
            '__str__': _str
        }
        attrs.update(start_ins.__dict__)
        # cls_final can be cached for optimization
        cls_final = type(feeder_cls.__name__, (cls, feeder_cls), attrs)
        ins = object.__new__(cls_final)
        ins.__init__(*args, **kwargs)
        return ins


class DnsUpdaterMetaClass(type):
    def __call__(cls, *args, **kwargs):
        env, region_cloud, az_cloud, network_id = args[0], args[1], args[2], args[3]
        start_ins = object.__new__(cls)
        start_ins.__init__(*args, **kwargs)
        updater_cls, updater_type = DnsUpdaterFactory(
            env=env,
            region_cloud=region_cloud,
            az_cloud=az_cloud,
            network_id=network_id
        )

        attrs = {
            '__init__': updater_cls.__init__,
            '_type': updater_type.upper(),
            '__str__': _str
        }
        if updater_type == "mkt":
            attrs.update(
                {
                    '_run': updater_cls.run,
                    'run': _run_mkt
                }
            )
            kwargs["new_hostname"] = None
        attrs.update(start_ins.__dict__)
        # cls_final can be cached for optimization
        cls_final = type(updater_cls.__name__, (cls, updater_cls), attrs)
        ins = object.__new__(cls_final)
        ins.__init__(*args, **kwargs)
        return ins


class DnsCleanerMetaClass(type):
    def __call__(cls, *args, **kwargs):
        env, region_cloud, az_cloud, network_id = args[0], args[1], args[2], args[3]
        start_ins = object.__new__(cls)
        start_ins.__init__(*args, **kwargs)
        cleaner_cls, cleaner_type = DnsCleanerFactory(
            env=env,
            region_cloud=region_cloud,
            az_cloud=az_cloud,
            network_id=network_id
        )

        attrs = {
            '__init__': cleaner_cls.__init__,
            '_type': cleaner_type.upper(),
            '__str__': _str
        }
        attrs.update(start_ins.__dict__)
        # cls_final can be cached for optimization
        cls_final = type(cleaner_cls.__name__, (cls, cleaner_cls), attrs)
        ins = object.__new__(cls_final)
        ins.__init__(*args, **kwargs)
        return ins


class DnsInformerMetaClass(type):
    def __call__(cls, *args, **kwargs):
        start_ins = object.__new__(cls)
        start_ins.__init__(*args, **kwargs)
        informer_cls, informer_type = DnsInformerFactory(
            network_index=kwargs["network_index"]
        )
        kwargs.pop("network_index")
        attrs = {
            '__init__': informer_cls.__init__,
            '_type': informer_type.upper(),
            '__str__': _str
        }
        attrs.update(start_ins.__dict__)
        # cls_final can be cached for optimization
        cls_final = type(informer_cls.__name__, (cls, informer_cls), attrs)
        ins = object.__new__(cls_final)
        ins.__init__(*args, **kwargs)
        return ins
